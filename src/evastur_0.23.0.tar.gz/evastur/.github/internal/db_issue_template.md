## 🚨 Broken URLs detected

Some URLs from the data sources table are not reachable.

### Workflow info
- **Workflow:** check-db.yml
- **Run ID:** $GITHUB_RUN_ID
- **Run URL:** $GITHUB_SERVER_URL/$GITHUB_REPOSITORY/actions/runs/$GITHUB_RUN_ID

### Summary
Below are the endpoints that could not be reached during the latest automated check.
