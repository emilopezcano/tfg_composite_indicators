# evastur 0.23.0
_Fecha versión_: 2026-05-12

## Mejoras gestión sistema de indicadores

* Búsquedas mejoradas: 
  - Búsqueda también por código.
  - La búsqueda de "%" busca ese carácter, no todos los indicadores.
  - Para buscar todos los indicadores, buscar sin poner nada.
  - Al cambiar selección a la derecha se actualiza la búsqueda automáticamente.

* Añadida funcionalidad de eliminación de indicadores y variables personalizados.

* Añadida gestión de unidades y periodos al crear variables.

## Mejoras documentación

* Integrada documentación nuevas variables DATAESTUR

## Corrección de errores

* Cálculo de la serie total en el gráfico de exploración de variables (dejó de funcionar tras la última actualización)

* Corregido error al mostrar mapa en gestión de áreas geográficas

* Corregido error que impedía mostrar los datos de INSTO


# evastur 0.22.0
_Fecha versión_: 2026-04-27

## Mejoras UX

* KPIs página de inicio: calculados sobre año seleccionado y aclarado el texto en "i"

* Mejorada visualización de mapas en exploración variables e indicadores: resaltar área seleccionada y mostrar; formateo de valores; mejora en mensajes sin datos.

* Mejorada visualización de series en exploración variables e indicadores: rotura de la serie si no hay datos (antes unía); formateo de periodo (según period_id); formateo de valores.

* Los selectores de dimensión ahora se muestran con el color de la dimensión.

* Evitar en el cambio de idioma pulsar ocultación sidebar.

* Traducciones en tablas (anterior, siguiente, etc.)

* Traducción en carga de archivos (gestión)


## Mejoras técnicas

* Fix deprecated sidebar_toggle()

* Add directories and files to .renvignore

* Add AGENTS.md file

* Update {scales} to avoid spurious errors.

# evastur 0.21.0
_Fecha versión_: 2026-03-06


## Mejoras en informes

* Logo alineado con configuración de tema

* Saltos de página después de configuración

* Tabla compacta en comparación de indicadores, añadiendo anexo con los nombres.

## Procesos ETL

* Mejorada importación Dataestur (variables con varios valores misma área, como estaciones meteorológicas)

* Corrección error en grabado de periodos y mejora rellenado de nulos

## Mejoras documentación

* Documentadas nuevas variables e indicadores Dataestur

## Corrección de errores

* Mapa exploración indicadores se evita el error cuando no hay datos

* Mapa exploración variables se oculta el total si está seleccionado para que se puedan ver cada área



# evastur 0.20.0
_Fecha versión_: 2026-02-27

## Nueva funcionalidad

* Importación de datos de Dataestur ampliada a iterar en áreas geográficas.

* Se permite activar/desactivar indicadores en gestión de indicadores (mismo cuadro de diálogo para cambiar al peso)

## Mejoras UX

* Cálculo del total grupo en exploración de variables (datos y gráfico)

## Corrección de errores

* Se ha corregido el problema cuando no se mostraban bien las tablas de datos en exploración de variables (cambiaba el título pero no los datos al cambiar de fila después de haber visualizado un gráfico)



# evastur 0.19.0
_Fecha versión_: 2026-02-25

## Nueva funcionalidad

* Importación de datos de DATAESTUR generalizada con filtros por url y variable

## Mejoras Informes

* Reorganizadas columnas informe imputación y añadidas traducciones que faltaban.

## Mejoras UX

* Selección de áreas: límite a 10 y quitar botón "todas" en visualización.

## Corrección de errores

* Corregido error en informe imputación que se producía por los caracteres "&" en las notas.

# evastur 0.18.3
_Fecha versión_: 2026-02-19

## Mejoras UX

* Mejorada la búsqueda de áreas geográficas en gestión

# evastur 0.18.2
_Fecha versión_: 2026-02-13

## Informes

- Informe mejorado imputación: tablas de códigos, mejora visualización, apéndices.


# evastur 0.18.1
_Fecha versión_: 2026-02-06

## Mejoras en la documentación

- Info en iconos de mantenimiento de áreas.
- Documentación de variables que faltaban, y modificación variables modificadas. 

## Corrección de errores

- Columnas de valores en informe imputación corregidas.


# evastur 0.18.0
_Fecha versión_: 2026-02-05

## Nueva funcionalidad

- Informe de trazabilidad en página principal: valores de variables, notas y _flags_ para ver su imputación.

## Mejora funcionalidad

- Mejoras en gestión de áreas geográficas: se muestran países que lo componen, se despliega al seleccionar, entre otras. Mejor control de errores y gestión de objetos reactivos.

## Mejoras UX

- Encabezado de informes coherente con configuración (logo, color, título)


# evastur 0.17.2
_Fecha versión_: 2026-01-29

## Documentación

* Cambiadas imágenes en pestaña About de página Help

## Mejora UX

* El selector de años ahora se muestra completo para pantallas pequeñas


# evastur 0.17.1
_Fecha versión_: 2026-01-20

## Mejora de funcionalidad

* Control de errores cuando no hay datos para gráficos indicadores en exploración.
* Mejora experiencia "waiter" en exploración.

## Mejora actualización datos

* Control de errores en comprobación fechas ONU Turismo
* Actualización vuelve a funcionar (cambiaron texto en página web: on vs in)


# evastur 0.17.0
_Fecha versión_: 2026-01-16

## Funcionalidad modificada

* En la carga de datos de indicadores, se ha eliminado la carga de indicadores. Solo se cargan variables.

## Mejoras UX

* Cambios realizados a informes (home y visualización)

# evastur 0.16.0
_Fecha versión_: 2025-12-19

## Nueva funcionalidad

* Añadido icono de documentación en gestión de variables
* ETL INE FRONTUR Y EGATUR
* ETL ETR
* ETL mejorada de WB-DATA con la nueva versión de la API


# evastur 0.15.0
_Fecha versión_: 2025-12-04

## Nueva funcionalidad

* ETL DATAESTUR: Implementada actualización automática (bajo demanda). Esta fuente no reporta fecha de última actualización, por lo que se actualiza siempre que se lanza la actualización automática.

* Manual de usuario actualizado con todas las funcionalidades actuales.

# evastur 0.14.0
_Fecha versión_: 2025-12-01

## Nueva funcionalidad

* ETL UNWTO-STATS actualizado a nueva versión de la fuente. Mejoras en el proceso.

* ETL WB-DATA Implementada actualización automática (bajo demanda). Generalizado para cuando se añadan más variables a la base de datos aunque no se usen en indicadores.

# evastur 0.13.0
_Fecha versión_: 2025-11-21

## Nueva funcionalidad

* Cálculo de indicadores a partir de las variables implementado.

* Imputación de variables implementada.

* Uso de valores imputados en configuración

## Corrección de errores

* Corregido error en análisis cuando no hay suficientes datos.




# evastur 0.12.0
_Fecha versión_: 2025-10-31

## Nueva funcionalidad

* Nueva opción de configuración "tema", que determina conjunto de colores y logo en la base de datos (tabla ct_theme). Por defecto "evastur".

## Mejoras UX

* Iconos en cajas de Análisis ahora son más grandes y con borde, más acorde con la información en "i".
* Botón de descarga de datos estilizado: ahora con icono, debajo de la tabla y a todo el ancho.
* En la documentación de indicadores no calculables, ahora no se muestra fórmula con NA y se indica que no se puede calcular (ver por ejemplo IECO0003).
* En la documentación de indicadores, ahora se incluye también la información de indicadores que se indican como relacionados (ver por ejemplo IECO0003).


# evastur 0.11.3
_Fecha versión_: 2025-10-23

## Nueva funcionalidad

* Comprobación semanal de URLs de fuentes de datos.

## Mejoras UX

* Biblioteca de indicadores ahora se puede buscar por código

## Corrección de errores

* Corregidas etiquetas indicadores relacionados en documentación


# evastur 0.11.2
_Fecha versión_: 2025-10-22

## Nueva funcionalidad

* En visualización, análisis y exploración de áreas geográficas se han añadido iconos en mapas y series para ver y descargar los datos.

## Mejoras UX

* Si hay un área geográfica seleccionada, esta se muestra por defecto en visualización/comparación de áreas, además del total.

* Los iconos de cerrar en los popup de visualización y descarga de datos en cards ahora tienen un mayor contraste.

* Se muestra el código de área geográfica junto al nombre en los picker input

## Mejoras de seguridad

* Protección contra SQLi

## Corrección de errores

* Ahora vuelve a funcionar la búsqueda de indicadores en gestión 

* Se introduce un segundo de retardo al cambiar el título de la aplicación en configuración para evitar bucles infinitos

## Mejoras internas código

* Eliminados warnings plotly click espúreos


# evastur 0.11.1
_Fecha versión_: 2025-10-21

## Mejoras UX

* Exploración áreas geográficas ahora la tabla es más compacta (fechas en título, no en columnas que se repetían)
* Mantenimiento áreas geográficas el mapa de todo el mundo ahora no se muestra desalineado.

# evastur 0.11.0

## Mejoras UX

* Mejoras en análisis: 
  + Mejora reactividad (1.5 seg. retardo para actualizar).
  + Cálculos al cambiar los controles todo seguido, sin botones.
  + Tabla más informativa cuando no hay solución factible.
  + Lista de indicadores con todo el ancho.

# evastur 0.10.3

## Mejoras UX

* Mejoras gestión de la configuración: botón para eliminar, "waiter" para evitar bucles, alineación valores iniciales.
* Eliminado icono y enlace de plotly en las series.
* Traducido texto "Nothing selected" en pickerInputs múltiples.
* Borde en Value boxes
* Color en icono de sidebar
* Icono de sidebar ahora no confunde al cambiar de idioma
* Scrollbar derecha espúrea ya yo se muestra


## Corrección de errores

* Exploración áreas geográficas ahora muestra también niveles dentro del país aunque no tengan indicadores.

# evastur 0.10.2
_Fecha versión_: 2025-10-09

## Mejoras UX

* Picker inputs ahora se muestran en toda su anchura sin necesidad de scrolling horizontal.
* La exploración de áreas geográficas ahora tiene su propio selector de grupos de países.

## Corrección de errores

* Clic en map ahora devuelve el foco a la pestaña de selección para que se refleje el cambio si se está en "i"
* Picker input y selección en mapa en gestión de áreas geográficas ya sincronizan
* Error en indicadores sin datos corregido #350

# evastur 0.10.1
_Fecha versión_: 2025-10-05

## Mejoras funcionalidad

* Módulo de informes: añadida toda la información de las páginas

# evastur 0.10.0
_Fecha versión_: 2025-09-25

## Nueva funcionalidad

* Implementación nuevo módulo de configuración. Pasa a ser página, configuración guardada en base de datos
(tabla `ct_app`). 
* Se carga una configuración añadiendo `/?profile=<nombre perfil>`, por ejemplo ine_es como nombre perfil. Si no, se carga el perfil `default`.
* En la propia página de configuración se puede cambiar el perfil, modificar y eliminar (salvo el default)

# evastur 0.9.0
_Fecha versión_: 2025-09-22

## Nueva funcionalidad

* Implementaciónn nuevo módulo de configuración. Pasa a ser página, configuración guardada en base de datos
(tabla `ct_app`). 
Se carga una configuración añadiendo `/?profile=<nombre perfil>`, por ejemplo ine_es como nombre perfil. Si no, se carga el perfil `default`.
* Implementación módulo de descarga de informes

# evastur 0.8.1

_Fecha versión_: 2025-09-16

## Corrección de errores

* Volver a mostrar las páginas de análisis (nueva) y experimental


# evastur 0.8.0

## Nueva funcionalidad

* Implementación módulo de exploración de áreas geográficas y gestión de áreas personalizadas.

## Mejoras documentación indicadores

* Completada documentación de indicadores faltante: valor de referencia en tabla, indicadores relacionados y dirección en cuadro de diálogo.


# evastur 0.7.8

* Nueva página de análisis usando base de datos
* Nueva opción de configuración para el método de predicción
* Nueva página "Experimental", movido ahí el recomendador de indicadores


# evastur 0.7.7

## Correción de errores

* Actualización de datos de UN Tourism ahora verifica bien última fecha


# evastur 0.7.6

* Incluida documentación completa de fuentes

# evastur 0.7.5

* Incluida documentación completa de indicadores y variables pendientes


# evastur 0.7.4

* Eliminado menú de visualización anterior
* Mejorada gestión de geografías/destinos para permitir INSTO y cualquier tipo de agrupamiento
* Inlcuidos nuevos indicadores y variables de varias fuentes

# evastur 0.7.3

## Corrección de errores

* Título del gráfico de serie original al comparar áreas geográficas (salía siempre etiqueta de grupo)
* Serie original del grupo cuando no hay seleccionado ningún país (si no había ningún país seleccionado al hacer clic en el grupo salía el gráfico vacío)

# evastur 0.7.2

## Mejoras UX

* Página de visualización finalizada

# evastur 0.7.1

## Nueva funcionalidad

* Nueva página de visualización

## Mejoras UX

* Textos revisados y corregidos (UI y ayuda)

## Correción de errores

* Implementado cambio en url de UNWTO para actualización automática.
* Aplicado filtro de selección en gráfico exploración variables.

# evastur 0.7.0

## Mejoras exploración

* Implementado módulo de documentación: se muestra toda la información de la base de datos, más texto libre en archivos y resumen de cobertura de datos. Implementado para fuentes, indicadores y variables.

## Mejoras gestión
* Data update: Eliminar columnas que no decían nada, añadir texto "i" y
mensaje de no selecciones adicionales

## Corrección de errores

* Controlar url no disponible UNWTO en Data update

# evastur 0.6.7

## Mejoras exploración

* Nueva pestaña fuentes de datos en exploración.

* Nueva pestaña biblioteca de indicadores en exploración.

* Gráficos de variables e indicadores desde exploración, nuevo icono.

## Mejoras UX

* Implementado _waiter_ para spinners

# evastur 0.6.6

## Mejoras exploración

* Tooltip en encabezado pestaña IS
* Tooltips en iconos de doc y data
* Icono rojo en indicadores desactivados, se muestran con letra gris.
* Modal datos indicadores: más compacto, formateados números, textos y encabezados columnas, filtro según selección global.
* Fórmula indicador: se ve al expandir como encabezado de la tabla de variables
* Indicadores agrupados por subdimensión
* Modal datos variables: más copacto, formateados números, textos y encabezados. 
* Tabla de valores de variables: Se muestran aquí las variales 
(dependen de la fuente). Icon de más información con fuente e indicación de si es confidencial o provisional.
* Botones de descarga de datos de indicadores y variables
* Texto de información detallada
* Se usan los filtros seleccionados en configuración y en menú lateral (escalado y solo personalizados)


## Corrección de errores
* Edición de peso indicador: no lo estaba cargando bien

# evastur 0.6.5

## Mejoras UI

* Mejorada búsqueda y creación de variables e indicadores (código automático, mejoras visuales y de usabilidad, validación formulario)
* Mejoras edición pesos dimensiones
* Mejoras carga de datos (validación, usabilidad, ejemplos)
* Instrucciones en página de gestión IS: Añadidos textos "i" en gestión de indicadores

## Mejoras base de datos

* Añadida clave foránea para uniades en bt_variable_source.Se elimina columna en dt_variables.

* Sentencias SQL en gestiòn de indicadores se ejecutan como transacciones para asegurar consistencia.

## Corrección de errores

* Corregido error en página principal al seleccionar escalado Max-min

# evastur 0.6.4

## Gestión de indicadores

* Implementada actualización de la base de datos con **nuevos** valores para los datos de UNWTO-STATS (OMT)

## UX

* Eliminada antigua "home" tras comprobar los datos

## Base de datos
* Añadidos campo al enlace variable-fuente para gestionar unidades (factor de multiplicación)
* Nuevas tablas de dt_units y lt_units para gestionar traducciones de unidades
* Refactorizados para usar grupos de países de tabla bt_geo_group
* Añadido campo geo_active para poder desactivar países o zonas

# evastur 0.6.3

## Mejoras UX
* Descarga de datos de mapa y serie y mejora de estilos
* Mapa clicable
* Mejoras de textos home
* Texto tooltip tipo de escalado
* Los datos de observatorios iNSTO ya se muestran sin necesidad de elegir la fuente 
* Selección área ahora por defecto total, y se cambia solo en menú (no en config)

## Corrección de errores

* Evitar errores momentáneos al volver a supranacional después de nacional.

* Evitar doble renderizado al seleccionar nacional

# evastur 0.6.2

* Gestión de variables, indicadores y pesos dimensiones funcionando

* Carga de datos funcionando

## Bug fixes

* Al probar cargando un país, se ha detectado que se producían errores si solo
había datos de un país un año en el mapa, por no poder calcular cuantiles. 
Se ha solucionado contemplando los distintos casos.

# evastur 0.6.1

* Nueva opción de configuración último año

* Selección del año a mostrar en el mapa

* La selección de dimensión filtra también el mapa (lo pone en la leyenda) y en las cajas

* Unificadas las fuentes de indicadores

* Mapa de inicio: se muestra el grupo seleccionado en el encabezado (país o grupo de país), y la dimensión seleccionada en la leyenda.

* Nueva selección de áreas geográficas:
  - En configuración, alcance nacional o supranacional, y selección de país o grupo de países.
  - En el sidebar de selección, se seleccionar país (si supranacional) o área geográfica nivel 2 dentro del país (si nacional)
  - El control del sidebar también se muestra en la configuración, pero son independientes: al arrancar la aplicación el de la configuración se cargan según las opciones del paquete. Si se cambia de momento no hace nada. El del sidebar se mantiene en las páginas al cambiar.

# evastur 0.6.0

* Indicadores clave nueva página de incio
* Serie de nueva página de inicio
* Encabezados de mapa y serie, incluyendo visualizar datos representados

* Mapa de inicio funcionando con distintas selecciones y mostrando 
indicador compuesto
* Función de escalado permitiendo por geo o por time
* Nueva columna en bt_indicator_source para valores de referencia
* Destino preferido como árbol, agrupaciones de países incluidas
* Mapa de inicio (nuevo) se recalculan los intervalos y leyenda
* Configuración: concepto "location" en vez de país


# evastur 0.5.0

## Nuevas funcionalidades

* Mapa en nueva página de inicio, con selección desde nuevo módulo, lectura de 
datos de la base de datos.

* Selección de país en la configuración. Afecta a visualizaciones por defecto y
etiquetas de desagregaciones geográficas.

* Estructura página de gestión de variables, indicadores, datos, y pesos indicador compuesto

* Prototipo formulario variables

## Mejoras datos

* Indicadores de INSTO ahora aparecen en exploración, clasificados según 
la correspondencia asignada con dimensiones ETIS.

## Mejoras UX

* Selección de geografías ahora usa etiquetas personalizadas por país o "niveles" por defecto.
* Ordenar fuentes e indicadores por el orden en columnas `*_order`.

# evastur 0.4.0

## Nueva funcionalidad

* Esqueleto página de gestión de indicadores

* Módulo de selección de áreas geográficas por nivel y país

* Esqueleto nueva página home

* _Popover_ de configuración: opciones del paquete y cambio de idioma (funcionando número de años y decimales STI)

## Mejoras UX

* Mejoras pesos recomendación: ancho controles y mantiene valores
* Mejora hover en selector escalado (se quedaba fijo)


## Mejoras documentación

* Se incluye explicación intervención (contrafácticos)

# evastur 0.3.0

## Mejoras UX

* Se mantiene la selección de Comunidad Autónoma en las distintas páginas cuando es posible

## Mejoras en documentación

* Añadida documentación sobre escalados en ayuda, y fórmulas en "i".

## Correcciones de errores

* Corregido filtro erróneo en Exploración
* Corregidos valores de variables cambiadas en medios de transporte.


# evastur 0.2.2

* Añadido el sentido del indicador en la tabla de exploración
* Implementada activación/desactivación de indicadores
* Completada documentación para los indicadores que tenemos

# evastur 0.2.1

## Mejoras en datos

* Dos nuevos indicadores de dimensión social

# evastur 0.2.0

## Nueva funcionalidad

* Pestaña Sistema de Indicadores EVASTUR en página Exploración:
  - Accordion con dimensiones
  - Tabla con indicadores + documentación + exploración de datos
  - Se expande a variables + documentación + exploración de datos

## Mejoras en datos

* Dos indicadores nuevos de Canarias
* Corregido cálculo de indicadores EGATUR, incluido estancia media
* Valores de indicadores y variables en la base de datos
 
## Mejoras UX

* Intervención: Se muestra un mensaje si alguna de las dimensiones no tiene solución.
* Intervención: se muestran solo las columnas relevantes.
* Inicio: texto "nivel" cambiado a STI.
* Inicio: Se muestra último periodo antes de las cajas.
* Añadido STI al encabezado de las series en Inicio. NOTA: no se añade a las 
series de visualización porque según lo seleccionado no es STI sino los indicadores 
individuales
* Visualización: cambiado orden título leyenda a "Destino e indicador"
* Se muestran las dimensiones de forma coherente en selecciones:
Económico-ambiental-social, primera mayúscula
* Traducidas dimensiones en los selectores
* Se muestra mensaje al entrar en visualización en el gráfico de la derecha hasta que se selecciona un indicador.
* Se muestra primero la info del proyecto y después manual en página de ayuda


## Correcciones

* Corregidos errores en intervención.
* Homogeneizado el cálculo del indicador global. Pasos: 1) Media de indicadores; 2)
Escalar; 3) Media de escalados por dimensión; 4) Media de dimensiones.
* Corregido error en predicción cuando hay indicadores con pocos valores (menos de 3)
* Se muestra página "About" que no salía
* Ya se traducen las dimensiones en Home al cambiar de idioma
* Ya no sale error en la serie original, pero se cambia al primer indicador de los escalados, ver más adelante


# evastur 0.1.5
 
* Intervención: cajas y lista de indicadores coloreadas según leyenda de las series

## Datos

* Nuevos indicadores de comunidades dimensión medioambiental
* Variables de Canarias

## Mejoras UX

* Visualización: Añadido nombre más completo de indicadores ccaa
* Visualización: Al entrar se muestrA el total nacional (configurable en options)
* Inicio: Selector de comunidades para poder volver al nacional
* Inicio: Colores del mapa en verde
* Inicio: Categorización y leyenda en cuartiles
* General: Hacer desaparecer los popups "i" al dejar de tener el hover

## Bug fixes

* Textos “i”: corregidos errores cambio de idioma
* Corregidos mensajes de error innecesarios


# evastur 0.1.4

* Intervención: se realiza en dos etapas: 1) dimensiones, seleccionando cuáles; 2) indicadores, seleccionando cuáles de cada dimensión
* Predicción: se realiza por indicador y se guarda la información
* Intervención: Se muestra un símbolo de diamante en el gráfico de predicción que representa 
el objetivo a conseguir con la intervención
* Cálculo dinámico de los límites de la intervención (slider) y número de dimensiones a cambiar.
* Total España por defecto en predicción e intervención
* Opción para elegir otra geografía por defecto. Ejemplo: 
`Rscript -e 'devtools::load_all();options(evastur.default_geo="Catalunya");app_run()'
* Implementada predicción e intervención CCAA

## Mejoras UX
* Ampliados y mejorados textos informativos
* Mejorados controles de pestaña predicción y value boxes

## Bug fixes
* Corregido error al no encontrar solución factible en la intervención
* Corregido estilo filtros tabla de indicadores en Exploración
* Eliminado control de escalado en Análisis/Recomendación

# evastur 0.1.3

* Añadido STI y leyenda al mapa de comunidades.
* Añadida información en botones "i" de Home, exploration, visualization.
* Notas metodológicas de variables del ejemplo.
* Cambiado orden pestañas: primero CCAA, después observatorios.
* En las series de home, se muestra por defecto la media nacional.
en vez de una comunidad/observatorio, y se muestran las 4 líneas por defecto.
* En Home se muestra Global antes de las otras dimensiones.
* Añadidos indicadores de estado ocupado en outputs mientras cargan.

## Base de datos
* Añadidas tablas para gestionar los datos segmentados por perfiles.
* Añadidas tablas para ODS.
* Añadida columna `indicator_direction` en la tabla `dt_indicators`.
* Añadida columna `indicator_formula` en la tabla `dt_indicators`.
* Mejorada seguridad.
* Las tablas obsoletas ahora están en el esquema `old_model`.

# evastur 0.1.2

## Nueva funcionalidad

* Intervención en indicadores de destinos (contrafácticos)

# evastur 0.1.1

## Mejoras documentación

* Documentación del modelo de datos actualizada (aunque sin terminar aún)

# evastur 0.1.0

## Mejoras interfaz

* Visualización por comunidades autónomas
* Gráficos de visualización en paralelo

## Mejoras datos

* Nuevo Modelo de datos finalizado

## Mejoras documentación
* Documentación del paquete renderizada en http://gondor.etsii.urjc.es:3801/www/docs/index.html
* Documentación del modelo de datos como artículo en la documentación
(http://gondor.etsii.urjc.es:3801/www/docs/articles/database.html, en proceso)
