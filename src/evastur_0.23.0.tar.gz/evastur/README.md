# EVASTUR

Repositorio del proyecto EVASTUR (Exploration, Visualization, and Analysis
for Sustainable Tourism)

## Background

* ETIS: https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es

* INSTO: https://insto.unwto.org. Guidebook: https://www.e-unwto.org/doi/book/10.18111/9789284407262; En español: https://www.ucipfg.com/Repositorio/MGTS/MGTS14/MGTSV-07/tema2/OMTIndicadores_de_desarrollo_de_turismo_sostenible_para_los_destinos_turisticos.pdf.

* SF-MST: https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism

## Estructura

El repositorio es un paquete de R que ejecuta una aplicación shiny:

````
library(evastur)
app_run()
````

Se encuentra desplegada en el servidor del dslab:

https://evastour.dslabapps.es/

La ayuda del paquete se encuentra en la propia aplicación, con documentos detallados de administración y uso:

https://evastour.dslabapps.es/www/docs/

Un componente importante del sistema es la base de datos de indicadores.
Está desplegada en el mismo servidor. 

El modelo de datos se encuentra descrito en el artículo correspondiente
de la documentación del paquete: 

https://evastour.dslabapps.es/www/docs/articles/database.html

## Despliegue

El sistema se despliega mediante dos contendores Docker,
orquestados con docker compose.
