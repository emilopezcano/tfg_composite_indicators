#### Explore data sources

This section shows the list of data sources from which the **values of the variables** used to calculate the indicators are obtained. The following information is shown:

* Name of the source
* Source label with link to the source URL.
* "i" icon. When hovering the mouse over it, a description of the source is displayed.
* _Intelligent Data Acquisition_ (IDA). Level of automation, which takes the following values: Bad (no automation), Fair (some automation without implementing functions), Good (automated with functions but not implemented in dashboard), Excellent (implemented in dashboard, see page “Data update”).
* "Documentation/Methodology" icon: A pop-up window opens with extended information, including period coverage, geographical areas, indicators and dimensions (see below)

**Source documentation/methodology**

For the selected source, the following information is displayed, organized in three tabs:

* **General information**: Source literals, including extended description; link; Automation level; and variables available in the source.

* **Details**: Detailed information on the methodology common to all variables.

* **Coverage**: For each variable for which there is data and taking into account the global selection, the total number of rows, the total number of geographical areas covered and the total number of periods covered are indicated. Note that 100% coverage of areas and periods does not imply 100% coverage of all possible combinations.