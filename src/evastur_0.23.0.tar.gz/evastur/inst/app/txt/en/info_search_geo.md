Click the search button to find geographic areas that match your text. If none of them
fits your needs, click the button 'Modify geographic areas' to create a new one.
Type just "%" for getting all available geographic areas. 
Existing geographic areas can also be modified.

