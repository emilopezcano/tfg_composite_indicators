The INSTO destination to which the recommended indicator system belongs is displayed.
