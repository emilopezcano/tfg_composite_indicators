#### Search Available Indicators to Incorporate

1. Search for possible indicators by name. By typing "%", all indicators are displayed.
2. A filter can be applied by dimension. Indicators within the selected dimension are displayed. "Global" means "all dimensions."
3. Only custom variables created by the user can be filtered.
4. If none of the available indicators meet your needs, a new one can be added by expanding the "Create New Indicator" section.

### Create new indicator

A unique identification code is assigned to each indicator, with the format 'ICUSXXXX', which corresponds to the prefix 'indicator custom' and an incremental number.

Fill in the required information for the indicator:

1. **Name**: The name of the indicator. A "one phrase" text is expected. It will be used in reports and screens where the full name fits in the space.

2. **Label**: A short name for the indicator. A short label is expected, ideally one word, but more than one and the use of abbreviations to distinguish between similar variables are accepted.
The values of the indicator will be used to calculate the composite indicator of the dimension and, therefore, the global indicator.

3. **Dimension and Subdimension**: Select the dimension and subdimension where the created indicator best fits. The indicator values will be used to calculate the composite indicator of the dimension, and therefore the global one. While the dimension may be clear, the subdimension may not be so clear. For those cases, within each dimension we have an "others" subdimension.

4. **Direction**: Indicates whether the indicator contributes positively to sustainability (+) or negatively (-). For example, the use of renewable energies would have a sense "+", while tourist pressure would have a sense "-".

5. **Description**: A longer and more detailed description of the new indicator that can clarify beyond the name. A "one paragraph" text is expected. This text is used in _tooltips_ and reports.

6. **Weight and its basis**: Indicates the weight of the indicator in the calculation of the composite indicator of the dimension. By default, all indicators have a weight of 1. If an indicator is assigned a weight of, for example, 2, we are giving that indicator twice the weight in the dimension as those with 1. It is necessary to add a justification for the weight assignment. In the case of assigning the default weight of 1, it can simply be indicated "Default weight."

7. **Variables and Formula**. An indicator is normally calculated by performing arithmetic operations with more than one variable. The variables with which the indicator is calculated are selected from the dropdown, being possible to search by text. As variables are added, they are displayed on the right in a table with their codes, which are used in the formula. The codes can be copied to the "Formula" section by clicking the "Copy to formula" button. The codes must be organized to have a valid formula, using arithmetic operators and parentheses appropriately.

Click the "Save Indicator" button. If the data is correct, a pop-up message is displayed. If inconsistencies arise in the database, a notification is displayed in the lower right corner.
