#### Manage Geographical Areas

This section allows you to create, edit, and manage geographical areas. Custom areas enable you to define your own sets of countries or regions for sustainability assessment.

**Search and Browse Geographical Areas**

1. **Search geographical areas**: Type in the search box to find geographical areas by name. The search is case-insensitive and matches partial names.
2. **Filter options**: Use the "Only custom" toggle in the Selection panel to show only user-created custom areas, or disable it to see all available geographical areas.
3. **Available areas table**: The Available geographical areas accordion panel displays a table with existing areas showing **Code** (the geographical identifier, e.g., GCUS0001 for custom areas), **Name** (the full name of the geographical area), **Label** (the short label used in visualizations), and an **Info icon** (hover to see the full description).

**Create a New Custom Geographical Area**

A unique identification code is assigned to each custom area, with the format 'GCUSXXXX', which corresponds to the prefix 'geographical custom' and an incremental number. To create a new custom area:
1. Expand the "Modify geographical areas" accordion panel.
2. **Fill in the required information**:

   **Name:** The full name of the geographical area. A "one-phrase" text is expected. It will be used in reports and screens where the whole name fits the space. Example: "Mediterranean Countries"

   **Label:** A short name for the area. A short label is expected, ideally one or a few words. Example: "Mediterranean"

   **NUTS Level:** Currently fixed to "Country group". This determines the geographical level of the area.

   **Description:** A longer description of the area that can clarify its purpose beyond the name. A "one paragraph" text is expected. Example: "Countries with coastlines on the Mediterranean Sea"
3. **Save the area**: Click the "Save area" button. If the data is correct, a success message is displayed. The new area will be assigned an ID. After creation, you can edit the area to add geographical areas to it.

**Edit an Existing Custom Geographical Area**

1. In the Selection panel, use the "Custom areas" dropdown to select the custom area you want to edit. The form will automatically populate with the existing data (Name, Label, NUTS Level, and Description).
2. **Modify the information**: Edit any of the text fields (Name, Label, Description) as needed. The header will show "Edit: [AREA_ID]" to indicate edit mode. Click the "Update" button to save your modifications. A success message confirms the update.
3. **Add geographical areas to the area**: You can add countries or regions to your custom area using two methods.

   **Interactive Map:** In the Selection panel, choose the geographical Scope (Supranational or National) and the base Group from which to select areas. The interactive map on the right displays available geographical areas with color-coding showing the number of active indicators. Click on countries or regions on the map to select them - selected areas appear as badges below the map showing their names.

   **Multi-Picker:** Use the multi-picker dropdown to select multiple geographical areas from a list. This method is particularly useful when you need to select many areas or prefer a list-based selection over the map interface.

   **To confirm selection:** Click the "Manage Selected Areas" button. A confirmation dialog shows the areas that will be added. Click "Confirm" to add them to the area.

4. **Remove areas from the area**: When a custom area is selected, the map shows all countries/regions currently in that area. Click on countries/regions you want to remove (they will appear as badges). Click "Manage Selected Areas" - the dialog will indicate that areas will be REMOVED from the area. Confirm to remove the selected areas.

**Delete a Custom Geographical Area**

1. Select the custom area from the "Custom areas" dropdown in the Selection panel.
2. The form loads in edit mode showing the "Delete" button.
3. Click the "Delete" button.
4. A confirmation dialog appears asking you to confirm the deletion, warning that this action cannot be undone.
5. Click "Delete" to confirm. The area and all its associations will be permanently removed from the database.

Important notes:
- Only custom areas (with GCUS codes) can be deleted. Predefined geographical areas cannot be removed.
- Deleting an area removes it from all selectors throughout the application.
- Any visualizations or analyses using the deleted area will no longer have access to it.

**Using Custom Geographical Areas**

Once created, custom geographical areas can be used throughout the application. Custom areas appear in the geographical selection dropdowns alongside predefined areas like OECD.
