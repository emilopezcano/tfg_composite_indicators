#### Data update

From this page you can consult for each data source what is the latest
date available. If the source is fully automated, you can update
the database with the most recent data, if available. 

The 'binoculars' icon is displayed on sources with an 'Excellent' IDA 
(Intelligent Data Acquisition) classification. When clicked, it checks the most 
recent available date in the source, whether through _web scraping_, API, or direct download. 
A pop-up window opens displaying the most recently published date and a button to update 
the data in the database.  
If the source is no longer available, an error message is displayed.
