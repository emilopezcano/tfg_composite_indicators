Prediction of the Sustainable Tourism Indicator and its dimensions for the selected geographical area,
according to the selected scaling method. Once the prediction is obtained, an intervention can be carried out to increment the value of the next-period prediction. The intervention is made in two phases. Firstly, the dimensions in which the intervention is pursued. Secondly,
the specific indicators to intervine can be selected.
