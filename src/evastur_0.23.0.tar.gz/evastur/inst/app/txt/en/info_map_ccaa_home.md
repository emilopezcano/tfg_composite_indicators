The Sustainable Tourism Indicator values by autonomous community (CC.AA.) with a color scale.
The darker colors represent the Autonomous Communities with higher values for the indicator.
Click on a community to see its sustainable tourism indicators.