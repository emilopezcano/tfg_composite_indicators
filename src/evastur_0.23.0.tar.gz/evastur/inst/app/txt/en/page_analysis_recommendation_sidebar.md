**Compute button:** 
Press once the tourist area has been selected on the map.

**Set weights:**
Pop-up screen where you can choose weights (from 0 to 10)
of the variables that allow to measure the distances between the tourist areas and the recommended destinations. 
