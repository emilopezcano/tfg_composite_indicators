Display of the indicators for the selected Autonomous Communities and with the desired scaling method.
Move over the series to get the actual values in the right window.
