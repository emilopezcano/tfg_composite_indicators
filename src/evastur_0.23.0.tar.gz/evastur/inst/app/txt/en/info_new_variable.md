Click the search button to find variables that match your text. If none of them
fits your needs, click the button to create a new one.
Type just "%" for getting all the variables. Results can be filtered by dimension. 
When a dimension is selected, only the variables used by the indicators belonging to that dimension are displayed.
