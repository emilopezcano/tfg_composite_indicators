**Scaling method**:

* Z-score: For each indicator, the number of standard deviations that a given value takes with respect to the mean of the indicator for the selected destination.

$$I_{z-score} = \frac{X_{it} - \mu_i}{\sigma_i}$$

* Range: Scaling of each individual indicator. The combination of indicators forms the indicator for each dimension.

$$I_{min-max} = \frac{X_{it} - \min_i}{\max_i - \min_i}$$

* Reference value: Scaling between 0 and 100. The indicator is divided by its maximum.

$$I_{reference} = \frac{X_{it}}{\max_i}\times 100$$


**Destinations:**

Picker input to select the destination.


**Dimensions:**

Check box to select the desired dimensions.

**Inside indicators:**

* Trend: Trend of the sustainable tourism indicator with respect to the previous period.


* Level: Overall level of the tourism indicator


* Distance to maximun: How far the current period is from the maximum reached by the indicator.


* Ranking 10 years: Position of the last period with respect to the last 10 years. 1st means that it is the highest value in the last 10 years.