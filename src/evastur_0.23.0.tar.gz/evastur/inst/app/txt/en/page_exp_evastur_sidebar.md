#### Explore the EVASTUR Indicator System

The dimensions of the indicator system are displayed. By clicking on 
the dimension, the table of indicators belonging to that 
dimension is expanded.

**Indicator table**

They are grouped by sub-dimensions, showing the number of indicators
within each sub-dimension. Expanding the sub-dimension shows the
following information:

- The name of the indicator.
- The direction: "+" if a higher value indicates better sustainability, and "-" otherwise.
- The weight of the indicator: used in the calculation of the composite indicator. 
If the default weight has been edited, a help icon appears to show 
the justification in a pop-up note.
- Formula: expanding this column shows the formula and the details of the 
variables involved (see below).
- "i" icon: Displays additional information in a pop-up note in the following 
format: [\<id\>] \<label\>: \<description\>.
- "!" icon (optional): Only shown if the indicator is disabled 
(not used in calculations or visualizations).
- "Documentation/Methodology" icon: Actionable button that opens a modal window
with all the information about the indicator and its methodology (see below).
- "Data" icon: Actionable button that opens a modal window
with the available data of the indicator for the current selection.
- "Plot" icon: Actionable button that opens a modal window
with two tabs: Time series and Map, where the available data of the indicator for the current selection are represented.

**Variable table**

Expanding the "Formula" column of an indicator shows the complete formula 
with the arithmetic operations to be performed with the
variables to obtain the indicator. Below, a table with the variables
involved and the following information for each one:

- Variable code
- Variable name
- "i" icon: Displays additional information in a pop-up note in the following 
format: \<label\>: \<description\>.
- "Documentation/Methodology" icon: Actionable button that opens a modal window
with all the information about the variable and its methodology (see below).
- "Data" icon: Actionable button that opens a modal window
with the available data of the variable for the current selection.
- "Plot" icon: Actionable button that opens a modal window
with two tabs: Time series and Map, where the available data of the variable for the current selection are represented.

**Indicators documentation/methodology**

For the selected indicator, the following information is displayed, organized into three tabs:

* **General information**: Literals of the indicator, including extended description; calculation of the indicator, including its formula and variables involved; classification of the indicator; weight of the indicator in the calculation of the composite indicator; relationship to the Sustainable Development Goals (SDGs) if identified.

* **Details**: Detailed or additional information on the indicator methodology not included in the 
general information.

* **Coverage**: For each indicator and according to the global selection, the total number of geographical areas covered, the total number of periods covered and their distributions are indicated. Note that 100% coverage of areas and periods does not imply 100% coverage of all possible combinations.

**Indicator data**

Clicking the indicator data button opens a window with the data table
for that indicator for the current selection (group of countries/regions, periods, 
type and scaling method). The table contains the following information:

- Period for which the indicator has been calculated. Depending on the data source,
it may have higher or lower resolution. For example, years or months.

- Geographic area: Each of the geographic areas of the selected group.

- Value: Value of the indicator on its scale.

- Scaled value: Scaled value of the indicator according to the selected type and method.

The data can be downloaded in csv format using the "Download" button.

**Variables documentation/methodology**

For the selected variable, the following information is displayed organized in three tabs:


* **General information**: Literals of the variable, including extended description; temporal and spatial aggregate operations; sources in which the variable is found; indicators in which the variable is used.

* **Details**: Detailed or additional information on the variable's methodology not included in the general information, such as ETL processes performed or source-specific notes for the variable.

* **Coverage**: For each variable and according to the global selection, the total number of geographical areas covered, the total number of periods covered and their distributions are indicated. Note that 100% coverage of areas and periods does not imply 100% coverage of all possible combinations.

**Variable data**

Clicking the variable data button opens a window with the data table
for that variable for the current selection (group of countries/regions and periods). 
The table contains the following information:

- Period for which the variable has been obtained. Depending on the data source,
it may have higher or lower resolution. For example, years or months.

- Geographic area: Each of the geographic areas of the selected group.

- Value: Value of the variable.

- Units: units of the variable.

- "i" icon: Displays the data source information in a pop-up note. 
It also indicates if the data is provisional or hidden due to statistical confidentiality, 
and in these cases, the icon is shown in red.

The data can be downloaded in csv format using the "Download" button.


