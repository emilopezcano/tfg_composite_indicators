Display of the indicator in actual values.
