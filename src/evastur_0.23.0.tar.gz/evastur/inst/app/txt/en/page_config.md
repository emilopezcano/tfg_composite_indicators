##### Scaling Method

* Z-score: For each value, the number of standard deviations from the mean of the indicator for the selected area.

$$I_{z-score} = \frac{x_{it} - \bar{x}_i}{s_i}.$$

  Note that the sample standard deviation is used. Positive values indicate that the indicator is above its mean, and negative values indicate it is below its mean.

* Max-Min: Value scaled to the interval $[0, 1]$, so that the minimum takes the value zero and the maximum takes the value 1.

$$I_{max-min} = \frac{x_{it} - \min(x_i)}{\max(x_i) - \min(x_i)}.$$

  Values close to 1 will be near the maximum, and values close to 0 will be closer to the minimum.

* Reference Value: A reference value of the indicator is taken, and the scaled indicator is the value of the indicator divided by the reference value. When there is no reference value, it is taken as the 95th percentile.

$$I_{\mathit{reference}} = \frac{x_{it}}{x_{\mathit{reference}_i}}$$

Note that the scaled indicator can be multiplied by 100 to understand it as a percentage. Values greater than 1 indicate that the indicator is above the reference value, and values less than 1 indicate that the indicator is below the reference value.

##### Scaling Type

Indicates how the indicator is scaled. A series is available for each geographic area, and there are two options:

* Periods: The value of the indicator for each destination is scaled with respect to all periods of that destination. Therefore, the interpretation is "the destination with respect to its historical series."

* Destinations: The value of the indicator for each period is scaled with respect to all destinations with data in that period. Therefore, the interpretation is "the destination with respect to the rest of the destinations that year."
