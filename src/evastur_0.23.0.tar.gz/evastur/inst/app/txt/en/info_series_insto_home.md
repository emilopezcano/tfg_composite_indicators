Sustainable Tourism Indicator and its dimensions for the selected observatory, according to the desired scaling method.
Move over the series to see the exact values.
