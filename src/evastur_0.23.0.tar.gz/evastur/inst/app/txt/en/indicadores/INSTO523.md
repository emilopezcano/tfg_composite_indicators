
#  Parity indices (between women and men) of the population aged 15-64 who study academic or training in the last four weeks 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Labour Force Survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Women aged 15-64 who have performed educational activities (formal or non-formal) in the last 12 months in year t }}{ \text{ Men aged 15-64 who have performed educational activities (formal or non-formal) in the last 12 months in year t }} \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

## 7. Observations

The reference value of this indicator is 100, which is held when parity is absolute. The degree of disparity is greater the further the value of the indicator differs from 100, reflecting an unfavourable or favorable situation of the numerator population group compared to the denominator population group as it takes a value lower or higher than 100 respectively. When interpreting this indicator it should be taken into account that it is not symmetric around 100.


