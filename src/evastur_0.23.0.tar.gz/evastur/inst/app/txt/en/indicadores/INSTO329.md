# Percentage of tourists who actively move within the destination

## 1. Categories

* Section: Environmental
* Theme: Mobility

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Tourists who, more frequently, actively move}}{\text{Tourists total}}\cdot\ 100$

### 2.2 Unit
% (percentage)

## 3. Interpretation

The greater the proportion of tourists actively moving, the less contribution to air pollution and climate change.

Desired trend: 100%

## 4. Justification

Active mobility is related to better health and less air pollution and contribution to climate change.
