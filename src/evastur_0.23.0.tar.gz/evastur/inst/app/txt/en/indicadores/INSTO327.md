# Percentage of energy generated from renewable sources in Catalonia

## 1. Categories

* Section: Environmental
* Theme: Energy and water management

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Power generation from renewable energies}}{\text{Total power generation}} \cdot\ 100$

### 2.2 Unit
% (percentage)

## 3. Interpretation 

A high proportion indicates more sustainable energy production.

Desired trend: 100%

## 4. Justification

It shows the progress of the destination towards the energy transition.
