
# Headquarters regulations, maintenance and testing of septic tanks and wastewater treatment systems, and evidence of their application


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Organization


## 2. Project implementers


## 5. Period



## 6. Observations
