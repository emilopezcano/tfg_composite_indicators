# Ratio between the average salary of the tourist activity compared to the rest of the activities
## 1. Categories

* Section: Economic  
* Theme: Work market

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Average salary in tourism activity}}{\text{Average salary for other activities}}$

### 2.2 Units
 -(ratio)

## 3. Interpretation 

If the result is:

* = 1 indicates that the average tourist salary is equal to the rest of activities

 * "<1" means that the average tourist salary is lower than the rest of activities

 * ">1"means that the average tourist salary is higher than the rest of activities

 * Desired trend = 1

## 4. Justification

It allows identifying possible salary inequalities in tourism activity with respect to other activities.
