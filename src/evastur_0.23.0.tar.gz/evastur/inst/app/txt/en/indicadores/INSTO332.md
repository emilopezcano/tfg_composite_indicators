# Availability of specific plans or strategies in force in sustainable tourism in the destination

## 1. Categories

* Section: Economic
* Theme: Development control

## 2. Calculation

### 2.1 Caluculation method

Availability of specific plans or strategies in force in sustainable tourism in the geographical area of analysis

### 2.2 Units

YES/NO

## 3. Interpretation 

If there is a sustainable tourism plan or strategy, it means that work is being done to achieve a better territorial, social and economic fit for tourism activity in the territory.

Desired trend: 100% YES

## 4. Justification

This indicator reflects the commitment that destinations show to the development of sustainable tourism activity.
