# Per capita energy consumption

## 1. Categories

* Section: Environmental
* Theme: Energy and water management

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Total energy consumption at the destination}}{\text{Residents}}$

### 2.2 Unit
kWh/person/year

## 3. Interpretation 

The higher the result, the more energy consumption there is in the territory.

Desired trend: downward temporal evolution and lower than the average of the comparison between territories

## 4. Justification

Energy consumption shows the degree of pressure that activities put on energy flows.