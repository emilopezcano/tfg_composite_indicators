
# Share of regional government expenditure on employment promotion


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Liquidation of the budgets of the autonomous communities, Ministry of Finance

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Employment promotion expenditure in the liquidation of consolidated budgets of the autonomous community (functional classification expenditure policy 24) in year t }}{\text{ Total expenditure on the clearance of consolidated budgets of the autonomous community in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage
