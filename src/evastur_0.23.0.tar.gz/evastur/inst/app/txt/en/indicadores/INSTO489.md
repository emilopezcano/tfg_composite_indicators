
# Urban waste generated per capita


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Solid waste management

## 2. Organization

IBESTAT

## 3. Source

Statistics on waste collection and treatment, Instituto Nacional de Estadística (INE)
Population figures, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Amount of urban waste collected in year t }}{ \text{ Population at 1 July of year t  }  }$

## 5. Unit of measurement

Kilograms

## 6. Frequency of data collection

Annual

## 7. Observations

The collection of municipal waste includes domestic waste and commercial or industrial waste similar to the previous ones that are of municipal competence, collected through urban containers, clean points or other municipal collection systems. It also includes road cleaning and biodegradable road cleaning waste
cleaning of parks and gardens.

 