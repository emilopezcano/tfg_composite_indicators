
# Number of tourist nights per month (distinguishing national and international tourists classified by main countries of residence) (ETIS) (InRouTe)   


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Expenditure of tourists with main destination the Balearic Islands (EGATUR)

## 3. Data collection method
Destination Management Survey Visitor Survey

## 4. Calculation method
${\text{Tally number of tourist nights every month: }} \frac{\text{ Tally total number of tourist nights annually }}{ 12 } = {\text{ Average number of tourist nights per month }}$

## 5. Unit of measurement
Occupancy rate (the closest industry standard measure)

## 6. Frequency of data collection
Monthly and annually

## 7. Fieldwork 
2015M10 - 2023M02

## 8. Territories
Mallorca, Menorca, Ibiza and Formentera, Balearic Islands


