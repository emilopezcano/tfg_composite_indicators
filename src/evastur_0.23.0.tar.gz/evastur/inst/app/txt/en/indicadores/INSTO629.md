
# Maritime passenger traffic on regular lines by type of movement, port, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

Ibestat, from data of Port Authority of Baleares (APB) and Ports IB

## 3. Source

Maritime passenger traffic by period, port/island and movement in the main ports of state and regional competence

## 4. Period

2006-2023

## 5. Observations

The data refer to passenger traffic in which the port of origin and/or destination is in the Balearic Islands. The Ibestat agency provides segregated data only for the ports of Palma, Alcúdia and Cala Rajada. The sum of these values is not identical to the data provided by the same body for the total of Mallorca. For more information, consult the methodology on the Ibestat website.

