
# Admissions to treatment for abuse or dependence on psychoactive substances other than alcohol  


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

National Institute of Statistics (INE)

## 4. Calculation method

Count of people entering treatment

## 5. Unit of measurement

Number of people

## 6. Frequency of data collection

Annual

