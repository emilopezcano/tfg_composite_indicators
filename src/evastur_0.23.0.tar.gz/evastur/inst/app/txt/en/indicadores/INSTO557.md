
# Rating (over 10) on the perception of the resident and tourist in various aspects of transport


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Plan sectorial director de mobilitat de les Illes Balears - Document I: Diagnosi, pp. 98-107, 128-132

## 4. Methodology

Surveys

## 5. Sample

3,380 residents and 800 visitors

## 6. Period

April - August 2017

## 7. Observations

Error: <1.8% (resident universe), <1.04% (resident displacement universe), <3.45% (visitor universe), <1.05% (visitor displacement universe).
