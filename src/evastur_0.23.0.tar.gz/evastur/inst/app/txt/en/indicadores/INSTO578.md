
# Proportion of children between 2 and 17 years with obesity, overweight or underweight 


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute of Spain)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

National Health Survey, National Statistics Institute of Spain (INE) and Ministry of Health

## 4. Calculation method

$\frac{\text{ Population between 2 and 17 years with malnutrition in year t }}{ \text{ Population between 2 and 17 years in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Five-year

## 7. Observations

The malnourished population is those with obesity (BMI>=30), overweight (25<=BMI<30) or insufficient weight (BMI<18.5), where BMI is the body mass index, which is obtained by dividing the weight (kg) by the square of height (m). The 2011 data corresponds to the National Health Survey 2011-2012, which was carried out between the second half of 2011 and the first half of 2012.

