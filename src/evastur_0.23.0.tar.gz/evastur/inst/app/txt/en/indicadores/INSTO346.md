# Overall evaluation of the municipality by the tourist

## 1. Categories

* Eje: Sociocultural
* Temática: Satisfacción del turista

## 2. Calculation

### 2.1 Calculation method

Average overall rating of the destination

### 2.2 Unit

Score from 0 to 10

## 3. Interpretation 

A higher rating indicates greater overall visitor satisfaction with the destination.

Desired trend: 10

## 4. Justification

Visitor satisfaction indicates the competitiveness of the destination.