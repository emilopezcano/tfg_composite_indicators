
# Proportion of young people (aged 15-24) not enrolled, employed or trained  

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Labour Force Survey

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Population between 15 and 24 years of age who have not been employed or have completed studies or training (regulated or unregulated) in the last four weeks in year t }}{\text{ Population aged 15-24 in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage