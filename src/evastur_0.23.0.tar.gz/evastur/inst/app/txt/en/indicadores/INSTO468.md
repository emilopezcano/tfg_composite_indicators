
# Manufacturing value added per capita


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Organization

National Institute of Statistics (INE)

## 3. Source

Spain’s annual national accounts: main aggregates

## 4. Calculation method

$\frac{\text{ Gross manufacturing value added at constant prices in 2015 }}{ \text{ Population at 1 July of year t }  } \cdot\ 100$
  
## 5. Unit of measurement
  
Constant dollars of 2015

## 6. Frequency of data collection

Annual

 