
# Proportion of births attended by skilled health personnel   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Birth statistics, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Births attended by specialized health personnel in year t }}{ \text{ Births in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual