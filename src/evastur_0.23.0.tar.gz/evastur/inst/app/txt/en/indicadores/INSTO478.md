
# Non-compliance (months)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Source

Communication of data to the European Commission on waste water treatment plants for 2016 and 2018
Purified water flow in the regional treatment plants (Abaqua)

## 3. Unit of measurement

Months

## 4. Period

2015-2021 

## 5. Observations

Number of months in which the treatment plant exceeds its maximum treatment capacity, according to information from Abaqua. Information is only available on the treatment plants of regional competence. The green color is assigned for defaults of 0 to 1 months; orange, 2 to 6 months, and red, 7 to 12 months.