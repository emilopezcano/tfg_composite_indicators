
# Annual growth rate of productivity   


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Spain’s annual national accounts: main aggregates

## 3. Calculation method
$\frac{\frac{\text{  Real gross domestic product of year t at constant prices (2015 USD) }}{ \text{ Equivalent jobs in year t }  } - \frac{\text{ Real gross domestic product of year t-1 at constant prices (2015 USD) }}{ \text{ Equivalent jobs in year t-1  }  } }  { \frac{\text{ Real gross domestic product of year t-1 at constant prices (2015 USD) }}{ \text{ Equivalent jobs in year t-1  }  } } \cdot\ 100$
    
## 4. Unit of measurement
Percentage

## 5. Frequency of data collection
Annual
  