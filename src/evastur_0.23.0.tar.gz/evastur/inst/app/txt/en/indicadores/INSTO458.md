
# Population at risk of relative poverty (income < 60% median)   


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
INE (Spanish National Statistics Institute)

## 3. Data collection method
Statistical operation

## 4. Calculation method
$\frac{\text{ Population at risk of relative poverty considering the national poverty line 60 % of median national income per unit of consumption (modified OECD scale) in year t }}{ \text{ Total population in year t }  } \cdot\ 100$

## 5. Unit of measurement
Percentage

## 6. Frequency of data collection
Annual