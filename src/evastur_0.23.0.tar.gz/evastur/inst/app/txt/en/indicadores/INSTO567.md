
# Average daily intensity of roads (year 2020)


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Source

Mobility and Infrastructure Department of the Consell de Mallorca

## 3. Definitions

IMD: Average Daily Intensity. Reflects the average number of vehicles passing through the stations.

Vehicle kilometres are defined as the magnitude indicating the total sum of the kilometres travelled by all vehicles using the relevant road over a period of time, grouped in the same way as for the calculation of the average daily intensity.

## 4. Calculation method

$\frac{\text{ Vehicle-kilometers }}{ \text{ Kilometers-days in service of roads }}$

## 5. Unit of measurement

Number of vehicles

## 6. Period

2020
