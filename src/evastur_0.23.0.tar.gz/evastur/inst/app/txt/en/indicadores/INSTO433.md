
# Unemployment rate for people aged 16 - 64 with disability


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Employment statistics of people with disability, National Statistics Institute (INE)

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Unemployed people aged 16-64 with disability in year t  }}{\text{ Economically active people aged 16-64 with disability in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage