 
# Estimated proportion of water consumed by tourism (%) in 2012


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Source

Academic article: “Zero tourism due to COVID-19: an opportunity to assess water consumption associated to tourism”.

## 3. Unit of measurement

Percentage

## 4. Period

April to June 2020.

## 5. Observations

Estimates from linear regressions comparing water consumption between April and June 2020 compared to 2019. Data on the whole of the Balearic Islands.



