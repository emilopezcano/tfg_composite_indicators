
# Opinion of tourists about noise

## 1. Categories

* Section: Environmental
* Theme: Noise pollution

## 2. Calculation

### 2.1 Calculation method

Average tourist noise opinion score

### 2.2 Unit
Score from 0 to 10

## 3. Interpretation 

The lower the score, the more noise the tourist has when visiting the city.
Desired trend: 10

## 4. Justification

It offers information on the tourist's perception of the destination's noise pollution.