
# Average hourly earnings of persons without disabilities 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Wage statistics of people with disabilities, National Statistical Institute (INE)

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Gross earnings of employees without disabilities in year t }}{\text{ Normal hours of employees without disability in year t }} $
  
## 5. Unit of measurement
Euros