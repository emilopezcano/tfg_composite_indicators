
# Number of tourists, hikers, visitors per 100 residents (ETIS)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Local satisfaction

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Flow of tourists with main destination the Balearic Islands (FRONTUR) 
Register of the municipal register of the Balearic Islands of the National Statistics Institute (Population)

## 4. Calculation method

$\frac{\text{ Total number of tourists } \cdot\ \text{ Average length of stay }}{ \text{ Total residents }  \cdot\ 365  } \cdot\ 100$

## 5. Unit of measurement

Tourists per 100 residents

## 6. Territories

Mallorca, Menorca, Ibiza and Formentera, Balearic Islands

## 7. Period

2010-2022

## 8. Frequency of data collection

Monthly



