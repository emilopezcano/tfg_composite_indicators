# Percentage of tourists who travel by public transportation within the destination

## 1. Categories

* Section: Environmental
* Theme: Mobility

## 2. Calculation

### 2.1. Calculation method


$\frac{\text{Tourists moving by public transport}}{\text{Total tourists}} \cdot\ 100$

### 2.2 Units
% (percentage)

## 3. Interpretation

The greater the proportion of tourists who travel by public transport, the better the sustainable mobility model there will be in the destination. Energy expenditure will be more efficient and will help reduce the carbon footprint and relative air pollution.

Desired trend: 100%

## 4. Justification

The use of public transport is related to energy efficiency and the minimization of emissions caused by mobility (air pollution and climate change).
