 
# Water consumed per tourist, hotel category and day (L/person-day) in 2015


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Source

Academic article: “Implementation of Water-Saving Measures in Hotels in Mallorca”.

## 3. Unit of measurement

Liters

## 4. Period

2015

## 5. Observations

Data compiled from surveys of 59 hotels in Mallorca.




