# Opinion of tourists about citizen security

## 1. Categories

* Section: Sociocultural
* Theme: Public security

## 2. Calculation

### 2.1 Calculation method

Average score of tourists on citizen safety

### 2.2 Unit

Score from 0 to 10

## 3. Interpretation

The higher the score, the higher the perceived level of security.

Desired trend: 10

## 4. Justification

A low level of security can affect the image of the destination and the visitor experience.