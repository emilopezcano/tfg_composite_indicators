
# Death rate from road traffic injuries   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics of deaths according to cause of death, Instituto Nacional de Estadística Population figures, Instituto Nacional de Estadística (INE)

## 4. Calculation method

$\frac{\text{ Deaths attributed to road traffic accidents (extensive list of ICD-10 codes, available in the Cause of Death Statistics methodology) in year t }}{ \text{ Population at 1 July of year t } } \cdot\ 100000$

## 5. Unit of measurement

Per hundred thousand

## 6. Frequency of data collection

Annual

## 7. Observations

From 2016, this includes motor vehicle traffic accidents, transport accidents not specified as due or not due to traffic and traffic accident victims in which at the time of the accident they were getting on or off the vehicle.
