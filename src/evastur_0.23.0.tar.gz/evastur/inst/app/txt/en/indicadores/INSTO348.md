# Percentage of tourists who have been victims of a crime or attempted crime on their person or vehicle

## 1. Categories

* Eje: Sociocultural
* Temática: Public security

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Tourists who have been victims of a crime or attempted crime, their person or vehicl}}{\text{Tourists}}\cdot\ 100$


### 2.2 Units

% (percentage)

## 3. Interpretation 

The higher the percentage, the higher the vulnerability of tourists in the destination.

Desired trend: 0%

## 4. Justification

It shows what proportion of tourists have directly suffered insecurity situations. The lack of security is a risk for the development of tourism in the long term, as it will affect the image, but it can also affect the safety of residents
