
# Share of people aged 18-79 with a current account 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Financial competence survey, Banco de España and Comisión Nacional del Mercado de Valores (CNMV)

## 3. Calculation method
$\frac{\text{ People between 18 and 79 years of age who have a personal or joint current account, book or other deposit that can be used to make payments by cards or checks in the year t }}{\text{ Population aged 18-79 in year t }} \cdot\ {100}$
  
## 4. Unit of measurement
Percentage
