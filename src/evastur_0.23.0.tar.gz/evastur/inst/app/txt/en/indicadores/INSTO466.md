
# Annual growth rate of real GDP per person employed 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Organization

IBESTAT

## 3. Source

Regional accounting of Spain,  Spanish National Institute of Statistics (INE)

## 4. Calculation method

$\frac{\frac{\text{  Gross domestic product in bound volume with reference 2015 in year t }}{ \text{ Employment (people) in year t  }  } - \frac{\text{ Gross domestic product in volume in reference 2015 in year t-1 }}{ \text{ Employment (people) in year t-1  }  } }  { \frac{\text{ Gross domestic product in bound volume with reference to 2015 in year t }}{ \text{ Employment (people) in year t-1  }  } } \cdot\ 100$
    
## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual
  