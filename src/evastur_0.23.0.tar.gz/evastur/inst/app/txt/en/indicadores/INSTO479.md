
# Percentage of primary treatment 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Source

Communication of data to the European Commission on waste water treatment plants for 2016 and 2018
Purified water flow in the regional treatment plants (Abaqua)

## 3. Definition

Method by which a treatment plant treats urban waste water, according to the data of the last revision of the Balearic Islands Water Plan.

Urban waste water treatment by a physical and/or chemical process including sedimentation of suspended solids, or other processes in which biochemical oxygen demand (BOD 5) at least 20 % of incoming waste water is reduced before discharge and the total suspended solids in incoming waste water is reduced by at least 50 %.

## 4. Unit of measurement

Percentage

## 5. Period

2015-2021 

## 6. Observations

The only complete series for all of Mallorca are from 2016 and 2018 based on data from Abaqua and the European Environment Agency (EEA). For the rest of the years, only the plants managed by Abaqua are shown. The data only include waste water treated in public treatment plants and do not include other assumptions (e.g. untreated water discharges, sewage treatment plants in hotels or chemical companies...).