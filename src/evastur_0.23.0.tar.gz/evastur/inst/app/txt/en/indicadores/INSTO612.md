
# Passengers transported at Palma airport on interisland flights per month and year


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Passenger air traffic between islands

## 4. Period

2004-2023

## 5. Frequency of data collection

Monthly

## 6. Unit of measurement

Thousands of passengers