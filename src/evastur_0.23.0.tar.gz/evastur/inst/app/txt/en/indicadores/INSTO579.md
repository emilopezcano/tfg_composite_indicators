
# Maternal mortality rate   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics of deaths by cause of death, National Statistics Institute (INE)
Birth statistics, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Deaths of women attributed to pregnancy, childbirth and puerperium (ICD-10 codes O00-O99) in year t }}{ \text{ Births in year t } } \cdot\ 100$

## 5. Unit of measurement

Per hundred thousand

## 6. Frequency of data collection

Annual
