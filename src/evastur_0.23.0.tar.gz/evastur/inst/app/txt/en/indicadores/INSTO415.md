
# Percentage of farm owners in relation to total agricultural workers  

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the structure of agricultural holdings

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$ frac{ text{People holding agricultural holdings in year t}}{ text{People employed in agriculture in year t}}  cdot  {100}$
  
## 5. Unit of measurement
Percentage 