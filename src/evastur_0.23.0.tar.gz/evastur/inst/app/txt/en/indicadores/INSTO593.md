
# Unmet need for health care   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Living Conditions Survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Population aged 16 and over indicating unmet health care needs in year t }}{ \text{ Population aged 16 and over in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

## 7. Observations

Unmet self-reported needs refer to a person’s own assessment of whether he or she needed medical examination or treatment (excluding dental care), but did not or did not seek it.

An unmet need for medical care may be due to one of the following reasons: financial reasons, list of
waiting and/or too far to travel.

