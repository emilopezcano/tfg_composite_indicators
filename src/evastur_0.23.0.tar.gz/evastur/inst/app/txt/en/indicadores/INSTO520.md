
# People between 18 and 64 years of age who have done educational activities in the last 12 months


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Survey on the participation of the adult population in learning activities, Instituto Nacional de Estadística (INE)

## 4. Calculation method

$\frac{\text{ Population aged 18-64 who have completed studies or training (regulated or unregulated) in the last 12 months in year t }}{ \text{ Population aged 18-64 in year t }} \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Five-year


