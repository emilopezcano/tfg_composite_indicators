
# Number of pharmacists per 10,000 inhabitants   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics of registered health professionals, National Statistics Institute (INE) 
Population figures, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Health personnel enrolled in pharmacy at 31 December of year t }}{ \text{ Population on 1 January of year t+1 } } \cdot\ 10000$

## 5. Unit of measurement

Per ten thousand

## 6. Frequency of data collection

Annual
