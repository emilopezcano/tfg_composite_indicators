# Percentage of tourists who arrive in sustainable collective vehicles

## 1. Categories

* Section: Environmental
* Theme: Mobility

## 2. Calculation

### 2.1. Calculation method

$\frac{\text{Tourists arriving by sustainable collective vehicle}}{\text{Total tourists}}\cdot\ 100$

### 2.2. Units
% (percentage)

## 3. Interpretation

The higher the proportion of tourists who travel in sustainable vehicles, the better the sustainable mobility model. Energy expenditure will be more efficient and will contribute to reducing the carbon footprint and relative air pollution.

Desired trend: 100%

## 4. Justification

The use of sustainable public transport is related to energy efficiency and the minimization of emissions caused by mobility (air pollution and climate change).
