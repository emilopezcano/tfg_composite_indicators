
# Annual summary of measurements of pollutants by port, type of pollutant and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility


## 2. Organization

APB

## 3. Source

Report on air quality in ABS ports

## 4. Period

2021

## 5. Observations

The nomenclature of the sensors corresponds to that of the reports of the Balearic Port Authority.

