
# Neonatal mortality rate   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Death statistics, National Statistics Institute (INE) Birth statistics,
National Institute of Statistics (INE)

## 4. Calculation method

$\frac{\text{ Deaths of children under 28 days completed in year t }}{ \text{ Births in year t } } \cdot\ 100$

## 5. Unit of measurement

So much per hundred thousand

## 6. Frequency of data collection

Annual

