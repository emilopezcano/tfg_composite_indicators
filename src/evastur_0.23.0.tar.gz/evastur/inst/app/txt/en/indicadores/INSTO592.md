
# Adolescent fertility rate (15-19 years) per 1,000 women in this age group   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Birth statistics, Instituto Nacional de Estadística (INE) 
Population figures, Instituto Nacional de Estadística (INE)

## 4. Calculation method

$\frac{\text{ Births of mothers between 15 and 19 years old in year t }}{ \text{ Women between 15 and 19 years old on 1 July of year t } } \cdot\ 1000$

## 5. Unit of measurement

Per thousand

## 6. Frequency of data collection

Annual

