
# Manufacturing sector employment as a proportion of total employment 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Organization

IBESTAT

## 3. Source

Regional accounting of Spain, Spanish National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Employment (people) in the manufacturing sector in year t }}{ \text{ Employment (people) in year t  }  } \cdot\ 100$

## 5. Unit of measurement
  
Percentage

## 6. Frequency of data collection

Annual

 