
# Desalinated water produced (m³)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Organization

IBESTAT

## 3. Source

Directorate-General for Water Resources of the Govern de les Illes Balears

## 4. Definition

Treated sea water to make it drinkable.

## 5. Unit of measurement

Percentage

## 6. Period

2000-2021

## 7. Observations

In the province of Mallorca, the desalinated water produced is measured according to facilities called IDAM. An IDAM is a seawater desalination facility. 
In Mallorca there are 5 different: IDAM Alcúdia, which began operating in 2010. IDAM Andratx, began operating at full capacity until 2016, in the years 2000-2013 and 2015, the value 0 is recorded according to the data of the DGRH. IDAM Badia de Palma, in operation since 1999. IDAM Son Ferrer, active desalination between 2000 and 2010. Finally, there is a Modular IDAM, which are portable temporary installations. According to the DGRH, they were located in Salinar de Camp de Mar (Andratx), with the exception of November 2001 that they were in Cala Gamba (Palma), next to the Sant Joan de Déu Hospital.

