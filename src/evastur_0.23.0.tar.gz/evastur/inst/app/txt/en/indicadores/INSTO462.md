
# Population living in low-intensity households   


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
INE (Spanish National Statistics Institute)

## 3. Data collection method
Statistical operation

## 4. Calculation method
$\frac{\text{ Population between 0 and 59 years belonging to households without employment or with low intensity in employment in year t }}{ \text{ Population between 0 and 59 years in year t }  } \cdot\ 100$

## 5. Unit of measurement
Percentage

## 6. Frequency of data collection
Annual