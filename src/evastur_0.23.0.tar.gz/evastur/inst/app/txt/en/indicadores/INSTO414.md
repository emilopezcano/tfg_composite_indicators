# Percentage of seasonal tourism jobs (ETIS)

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Data collection method
Employment survey

## 3. Source
Affiliates and social security contribution accounts (TGSS data)

## 4. Origin 
IBESTAT

## 5. Frequency of data collection 
Monthly

## 6. Fieldwork 
2020M05 - 2022M03

## 7. Calculation method
$\frac{\text{Total number of seasonal tourist job}}{\text{Total number of tourist jobs}} \cdot\ {100}$

## 8. Unit of measurement
Number of affiliations (percentage)

## 9. Territories
Mallorca, Menorca, Ibiza, Formentera, Balearic Islands

## 10. Observations
In 2007, in Europe, 24% of hotel and/or restaurant employees and 30% of tourist accommodation employees were employed on a seasonal basis
