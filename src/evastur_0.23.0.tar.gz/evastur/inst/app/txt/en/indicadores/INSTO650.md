
# Daily average of passengers arriving in Mallorca by sea (lines and cruises) by port, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

Ibestat, from APB and Ports IB data

## 3. Source

Maritime passenger traffic on regular lines and cruises by period, port/island and movement in the main ports of state and regional competence

## 4. Methodology

For the calculation of the indicator, passengers arrived through regular lines to the ports of Palma, Alcúdia and Cala Rajada, as well as passengers from base cruises or in transit arrived at the ports of Palma, Alcúdia, Cala Rajada, Andratx, Sóller and the Colònia de Sant Jordi. The sum of the monthly value has been divided by the number of days of the month in question. Since cruise data from ports of regional competence (Cala Rajada, Andratx, Sóller and Colònia de Sant Jordi) are not disaggregated by month, they have been allocated on a regular basis by dividing the annual data between 12 months.

## 5. Period

2006-2023

