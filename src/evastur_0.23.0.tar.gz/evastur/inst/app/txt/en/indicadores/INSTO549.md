
# Proportion of women using the mobile for particular reasons (16 to 74 years old)      


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Survey on equipment and use of information and communication technologies in households, National Statistics Institute (INE)

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Women between 16 and 74 years who in the last three months has used the mobile in year t }}{ \text{ Women between 16 and 74 years in year t }} \cdot\ 100$

## 6. Unit of measurement

Percentage

## 7. Observations

In the years in which the indicator is not published is because in those years the questions that allow its calculation are not asked


