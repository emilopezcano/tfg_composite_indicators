
# Number of researchers (in full-time equivalent) per million population   


## 1. Categories

* General destination performance criteria
* Dimension: Innovation

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Statistics on R&D activities, Instituto Nacional de Estadística (INE) Population figures, Instituto Nacional de Estadística (INE)

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Full-time equivalent researchers in year t }}{ \text{ Population at July 1 of year t }} \cdot\ 100$

## 6. Unit of measurement

Parts per million (ppm)


