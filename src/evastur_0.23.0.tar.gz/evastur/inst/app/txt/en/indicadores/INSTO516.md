
# Total net enrolment rate of 5-year-old girls  


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Statistics on non-university education, Ministry of Education and Vocational Training

## 4. Calculation method

$\frac{\text{ Total 5-year-old girls enrolled in pre-school, primary and special education in the school year t-1/t }}{ \text{ Total number of girls aged 5 years }} \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual


