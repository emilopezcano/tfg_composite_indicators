
# Reclaimed water (m3)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Source

Volume of reclaimed water used in 2015 and 2021
Purified water flow in the regional treatment plants (Abaqua)

## 4. Unit of measurement

cubic meters

## 5. Period

2015-2021 

## 6. Observations

The point of discharge is the way in which a sewage treatment plant returns the purified water to the environment, according to the data of the last revision of the Balearic Islands Hydrological Plan.

It is measured for 5 different areas: golf courses, irrigation of public gardens, agricultural irrigation plan, other agricultural irrigation and other private uses. 

We only have data from 2015 of reclaimed water and reclaimed water used. From 2021 only of reclaimed water used.