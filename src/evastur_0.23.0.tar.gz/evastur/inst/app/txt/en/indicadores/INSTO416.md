
# Percentage of men holding agricultural holdings in relation to the total of men working in agriculture 

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the structure of agricultural holdings

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{Men holding agricultural holdings in year t}}{\text{Number of men employed in agriculture in the year t}} \cdot\ {100}$

## 5. Unit of measurement
Percentage

