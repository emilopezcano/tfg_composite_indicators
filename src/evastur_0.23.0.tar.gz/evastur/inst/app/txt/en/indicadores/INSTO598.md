
# Number of doctors per 10,000 inhabitants   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics of registered health professionals, National Statistics Institute (INE) 
Population figures, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Medical health personnel on 31 December of year t }}{ \text{ Population on 1 January of year t+1 } } \cdot\ 10000$

## 5. Unit of measurement

Per ten thousand

## 6. Frequency of data collection

Biennial / triennial

## 7. Observations

The following note is variable depending on the published data: The results of the National Health Survey 2011-2012 have been attributed to both years. The 2011 data corresponds to the National Health Survey 2011-2012, which was carried out between the second half of 2011 and the first half of 2012. The data for 2012 corresponds to the National Health Survey 2011-2012, which was carried out between the second half of 2011 and the first half of 2012.

