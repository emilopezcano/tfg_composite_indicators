
# Arrivals of charter flights and regular flights to Mallorca by year


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

AENA

## 3. Source

Airport statistics system (Estop) - Air operations by company

## 4. Period

2004-2023

## 5. Frequency of data collection

Annual

## 6. Unit of measurement

Millions of arrivals

