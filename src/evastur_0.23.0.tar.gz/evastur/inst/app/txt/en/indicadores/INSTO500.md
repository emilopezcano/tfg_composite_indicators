
# Water consumed per capita (m3/hab-year)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Organization

IBESTAT

## 3. Source

Directorate-General for Water Resources of the Govern de les Illes Balears

## 4. Calculation method

$\frac{\text{ Water consumption in m³ of year t }}{ \text{ Population registered in year t }  }$


## 5. Unit of measurement

Cubic metres per population in year t

## 6. Period

2000-2021

## 7. Observations

The calculation does not take into account the human pressure of the municipality (e.g. tourism).

