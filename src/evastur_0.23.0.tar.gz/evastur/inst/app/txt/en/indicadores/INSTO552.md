
# Research and development expenditure as a proportion of GDP  


## 1. Categories

* General destination performance criteria
* Dimension: Innovation

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Statistics on R&D activities, Instituto Nacional de Estadística (INE) 
Regional accounting of Spain, Instituto Nacional de Estadística (INE)

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Expenditure on research and development in year t }}{ \text{ Gross domestic product at current prices in year t }} \cdot\ 100$

## 6. Unit of measurement

Percentage

## 7. Observations

In the denominator has been taken since 2012 the PIBpm Statistical Review 2019, which is provisional for 2018 and data progress for 2019. Its source is the Annual National Accounts.
The population scope of R&D Statistics covers companies, public bodies, universities and higher education institutions and private non-profit institutions that carry out R&D activities.