
# Maximum value of same-day cruise calls per port, vessel type and date


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB

## 3. Source

Docking operations in the ports of the Balearic Islands

## 4. Methodology

For the calculation of the maximum daily stopovers, in case a ship has been in port for two days, it has been computed only for the date on which the ship has been moored for more hours. If the berth has lasted more than two days, it has been counted on the day of arrival or departure (only on the day on which the berth has lasted more hours) and on all days between arrival and departure.

## 5. Period

2019-2023


