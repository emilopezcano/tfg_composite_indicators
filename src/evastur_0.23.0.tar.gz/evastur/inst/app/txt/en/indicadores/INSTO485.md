
# Recycled water (%)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Source

Volume of reclaimed water used in 2015 and 2021
Purified water flow in the regional treatment plants (Abaqua)

## 4. Unit of measurement

Percentage

## 5. Period

2015-2021 

## 6. Observations

It is measured according to sewage plant and for 5 different zones: golf courses, irrigation of public gardens, agricultural irrigation plan, other agricultural irrigation and other private uses. 