
# Proportion of c) lower secondary school teachers who have received at least the minimum pre-service or in-service organized teacher training (e.g., pedagogical training) required to provide education at that level       


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Statistics on non-university education, Ministry of Education and Vocational Training

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Lower secondary teachers with teacher training in the school year t-1/t }}{ \text{ Total lower secondary teachers in the school year t-1/t }} \cdot\ 100$

## 6. Unit of measurement

Percentage

## 7. Observations

The indicator is 100 per cent, since educational legislation establishes that teaching requires the accreditation of pedagogical and didactic training


