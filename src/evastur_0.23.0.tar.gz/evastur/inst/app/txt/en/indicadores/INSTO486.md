
# Program to help tourism businesses safely treat and reuse waste water with minimal adverse effects on local people and the environment


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Organization

Global Sustainable Tourism Council

## 3. Project implementers

Coordinating beneficiary: EGTC Eurorégion Pyrénées-Méditerranée
Associate Beneficiary(ies): ABAQUA, ACA, AD'OCC, AETIB, AQUAVALLEY, CLIQIB,
CWP and EURECAT

## 4. Period

01/09/2020 - 30/09/2023

## 5. Observations

The budget has a total amount: €1,587,985 and an EC co-financing rate: 55%.