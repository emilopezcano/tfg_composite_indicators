
# Comparison of passengers transported by airport and type of movement


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

AENA

## 3. Source

System of airport statistics (Estop) - Passengers and goods by port of call

## 4. Period

2004-2023

## 5. Frequency of data collection

Monthly

## 6. Unit of measurement

Million passengers