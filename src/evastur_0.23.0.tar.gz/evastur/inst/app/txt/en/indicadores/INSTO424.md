
# Unemployment rate of people with disabilities

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the wage structure

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Unemployed people with disabilities in year t }}{\text{ Economically active people with disabilities in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage