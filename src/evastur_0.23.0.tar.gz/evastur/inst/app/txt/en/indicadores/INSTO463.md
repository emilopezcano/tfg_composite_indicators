
# Population with high housing expenditure   


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
INE (National Statistics Institute)

## 3. Data collection method
Statistical operation

## 4. Calculation method
$\frac{\text{Population whose households have housing expenses above 40% of their income in year t }}{ \text{  Total population in year t }  } \cdot\ 100$
  
## 5. Unit of measurement
Percentage

## 6. Frequency of data collection
Annual