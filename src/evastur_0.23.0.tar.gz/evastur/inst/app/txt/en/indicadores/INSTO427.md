
# Average income per hour of men’s work  


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Annual wage structure survey, National Statistics Institute (INE)

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Gross earnings of salaried men in year t }}{\text{ Normal working hours of salaried men in year t }} $
    
## 5. Unit of measurement
Euros