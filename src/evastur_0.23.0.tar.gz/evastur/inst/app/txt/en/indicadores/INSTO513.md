
# Proportion of women, aged 18-49, married to a man or a male partner, who meet their family planning needs with modern methods


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Fertility Survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Number of women aged 18-49 meeting their needs for family planning with modern methods, in year t }}{ \text{ Number of women aged 18-49 in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual


