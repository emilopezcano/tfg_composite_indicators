# Per capita water consumption

## 1. Categories

* Section: Environmental
* Theme: Energy and water management

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Total water consumption at the destination}}{\text{Residents}}$

### 2.2 Unit
m³/person/year

## 3. Interpretation 

The higher the result of this indicator, the more pressure and consumption of the territory's water resources. It must be taken into account that water is a scarce resource in the regions of the Mediterranean arc.

Desired trend: downward temporal evolution and lower than the average of the comparison between territories

## 4. Justification

Water consumption quantifies the rate of exploitation of a territory's water resources.
