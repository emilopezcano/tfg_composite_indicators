
# Maritime passenger traffic on regular lines by origin/destination, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

Ibestat, from APB and Ports IB data

## 3. Source

Maritime passenger traffic by origin and destination

## 4. Period

2006-2023

## 5. Observations

The data refer to passenger traffic in which the port of origin and/or destination is in the Balearic Islands.


