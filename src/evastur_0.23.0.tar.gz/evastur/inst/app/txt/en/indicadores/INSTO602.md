
# Proportion of women who marry at 16 and 17  


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics of registered health professionals, National Statistics Institute (INE) 
Population figures, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Marriages of women aged 16 and 17 with a man in year t }}{ \text{ Women aged 16 and 17 on 1 July of year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

