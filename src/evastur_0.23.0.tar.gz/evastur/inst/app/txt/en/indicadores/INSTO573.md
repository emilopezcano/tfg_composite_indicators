
# Proportion of dwellings with toilet  


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Population and housing censuses, National Statistics Institute (INE)

## 4. Calculation method

$ frac{ text{ Dwellings with toilet in year t }}{  text{ Total dwellings in year t }  }  cdot 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

## 7. Observations

Main dwelling is a dwelling that is used all or most of the year as a habitual residence by one or more people

