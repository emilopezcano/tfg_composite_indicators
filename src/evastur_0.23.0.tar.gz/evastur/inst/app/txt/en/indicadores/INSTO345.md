# Percentage of residents who consider that the capacity limit to host tourism is being reached

## 1. Categories

* Section: Sociocultural
* Theme: Citizen satisfaction

## 2. Calculation

### 2.1 Calculation method

Percentage of residents who consider that the capacity limit to host tourism is being reached

### 2.2 Unit
% (percentage)

## 3. Interpretation 

The higher the percentage, the greater the rejection of tourism by residents.

Desired trend: 0%

## 4. Justification

The perception of reaching an acceptable limit conditions tolerance towards the activity.