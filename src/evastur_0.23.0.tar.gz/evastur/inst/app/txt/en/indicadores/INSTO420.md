
# Percentage of women holding leased agricultural holdings in relation to total holders of leased agricultural holdings      

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the structure of agricultural holdings

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Women holders of agricultural holdings leased in year t }}{\text{ Holders of agricultural holdings leased in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage