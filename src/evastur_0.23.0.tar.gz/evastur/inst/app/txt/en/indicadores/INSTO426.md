
# Total public expenditure on employment promotion 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Statistics on the Liquidation of the State Budget and its Public Bodies, Enterprises and Foundations

## 3. Frequency of data collection 
Annual

## 4. Calculation method
Expenditure on social services and social promotion of the consolidated general government budgets

## 5. Unit of measurement
Million Euros