
# Proportion of population with large health expenditures per household (> 25%) as a percentage of total household expenditures   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Household budget survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Population living in households with large health expenditures, exceeding 25% of total household expenditure, in year t }}{ \text{ Total population in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

