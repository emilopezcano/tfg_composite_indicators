 
# Water consumed per visitor or resident per day (L/Person-day) in 2020


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Source

Explanatory memorandum of the Plan of Intervention of Tourist Areas (PIAT)

## 3. Unit of measurement

Liters

## 4. Period

2012

## 5. Observations

Estimates from a study carried out by the UTE CCRS-GAAT for the Consell de Mallorca.



