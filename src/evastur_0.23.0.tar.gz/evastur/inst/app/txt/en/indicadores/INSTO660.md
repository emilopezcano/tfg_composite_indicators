
# Polluting emissions produced by maritime transport in the Balearic Islands per year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB and European Maritime Safety Agency (EMSA)

## 3. Source

Directorate-General for Energy and Climate Change of the Govern de les Illes Balears

## 4. Period

1990-2020

## 5. Unit of measurement

Tonnes: CH4, CO, NMVOC, N2O, NH3, NOx, SOx
Kilotons: CO2

## 6. Observations

Annual series from the categories corresponding to the groups of issuing activities according to the nomenclature Selected Nomenclature for Air Pollution (SNAP-97). Calculations carried out according to the methodology developed by the European EMEP/CORINAIR project and the IPCC.

Particles:
  - PM2,5: Particles with an aerodynamic diameter of less than 2,5 microns
  - PM10: Particles with an aerodynamic diameter of less than 10 microns
  - SWP: Total suspended particles
  - BC: Black carbon (black carbon)

Heavy metals:
  - As: Arsenic
  - Cd: Cadmium
  - Cr: Chromium
  - Cu: Copper
  - Hg: Mercury
  - Ni: Nickel
  - Pb: Lead
  - Se: Selenium
  - Zn: Zinc

Finishers:
  - SOx: Sulphur oxides 
  - NOx: Nitrogen oxide
  - NMVOC: volatile organic compounds other than methane
  - CH4: Methane
  - CO: Carbon monoxide
  - CO2: Carbon dioxide
  - N2O: Nitrous oxide
  - NH3: Ammonia
  - SF6: Sulphur hexafluoride
  - HFCs: Hydrofluorocarbons
  - PFC: Perfluorocarbons

Pollutants:
  - HCB: Hexachlorobenzene
  - DIOX: Dioxins and furans
  - BENZO(a): Benzo(a)pyrene
  - BENZO(b): Benzo(b)fluoranthene
  - BENZO(k): Benzo(k)fluoranthene
  - INDENO: Indeno(1,2,3-cd)pyrene
  - PAH: Polycyclic aromatic hydrocarbons
  - PCBs: polychlorinated biphenyls
  
  