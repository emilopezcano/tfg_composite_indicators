
# Registered unemployed by period, island, sex and age group

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Seasonality in tourism

## 2. Source
Unemployed, jobseekers and registered contracts (SOIB)

## 3. Origin 
IBESTAT

## 4. Unit
Number of people

## 5. Fieldwork
2005-2022