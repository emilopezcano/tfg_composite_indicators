# Percentage of tourism marketing actions that apply sustainability criteria
## 1. Categories

* Eje: Sociocultural
* Temática: Marketing for sustainable tourism

## 2. Calculation 

### 2.1 Calculation method

$\frac{\text{Marketing actions that apply sustainability criteria}}{\text{Total marketing actions}}\cdot\ 100$

### 2.2 Units
% (percentage)

## 3. Interpretation 

The higher the value of the indicator, the better incorporated the sustainability strategy is in the tourism marketing of the destination.

Desired trend: 100%

## 4. Justification

This indicator reflects the commitment of destinations to incorporating sustainability criteria into their marketing strategies.
