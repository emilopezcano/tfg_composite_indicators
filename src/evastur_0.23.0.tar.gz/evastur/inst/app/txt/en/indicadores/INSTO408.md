
# Tourists with main destination the Balearic Islands by period, island and main reason for the trip

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Seasonality in tourism

## 2. Source
Flow of tourists with main destination the Balearic Islands (FRONTUR)

## 3. Origin 
IBESTAT

## 4. Unit
Number of people

## 5. Fieldwork
2009-2022