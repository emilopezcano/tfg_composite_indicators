
# Average distance traveled by tourists from origin to destination

## 1. Categories

* Section: Environmental
* Theme: Climate change

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Km per origin}\ \cdot\ \text{Tourists by origin}}{\text{Total Tourists}}$

### 2.2 Unit
km per tourist

## 3. Interpretation 

The greater the distance traveled from the origin, the more greenhouse gases will be generated and, therefore, there will be a greater contribution to climate change.
Desired trend: downward temporal evolution and lower than the average of the comparison between territories.

## 4. Justification

This is one approach to the contribution to the carbon footprint of tourism in destinations.
