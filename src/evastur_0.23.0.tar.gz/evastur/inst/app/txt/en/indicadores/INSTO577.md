
# Population living in households with certain housing deficiencies  


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Living Conditions Survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Population experiencing at least one of the basic deficits in their housing conditions in year t }}{ \text{ Total population in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual