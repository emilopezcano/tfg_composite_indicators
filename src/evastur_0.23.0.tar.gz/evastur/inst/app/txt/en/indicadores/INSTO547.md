
# Percentage of women entrepreneurs        


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Economic Activity Performance Statistics, Ministry of Finance

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Female self-employed population in year t }}{ \text{ Self-employed population in year t }} \cdot\ 100$

## 6. Unit of measurement

Percentage

