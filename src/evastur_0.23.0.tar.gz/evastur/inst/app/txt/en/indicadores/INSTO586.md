
# Mortality rate attributed to cancer      


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics on deaths by cause of death, National Statistics Figures
National Institute of Statistics (INE)

## 4. Calculation method

$\frac{\text{ Deaths attributed to cancer (ICD-10 codes C00-C97) in year t }}{ \text{ Population at 1 July of year t } } \cdot\ 100$

## 5. Unit of measurement

So much per hundred thousand

## 6. Frequency of data collection

Annual

