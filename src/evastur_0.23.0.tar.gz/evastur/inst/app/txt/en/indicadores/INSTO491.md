
# Proportion of urban waste incinerated


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Solid waste management

## 2. Organization

IBESTAT, National Statistics Institute (INE)

## 3. Source

Annual report on waste generation and management. Municipal waste, Ministry for Ecological Transition and the Demographic Challenge.

## 4. Calculation method

$\frac{\text{ Amount of municipal waste discharged in year t }}{ \text{ Total amount of municipal waste generated and treated in year t }  }$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

## 7. Observations

Municipal waste means domestic and commercial waste, from households and the service sector (commerce, offices and institutions) managed by local authorities, not including commercial waste managed by private channels other than the municipal one, nor waste from industry. At present there is no harmonised definition of municipal waste within the European Union. The Ministry therefore specifies in its report the LER codes for municipal waste.

 