
# Percentage of employed in manufacturing


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Organization

IBESTAT

## 3. Source

Labour Force Survey, Spanish National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Employed population in the manufacturing sector (section C of CNAE-2009) in year t }}{ \text{ Employed population in year t* }  } \cdot\ 100$

* taking into account that each of these stocks is calculated as the arithmetic mean of the four quarters of the yea
  
## 5. Unit of measurement
  
Percentage

## 6. Frequency of data collection

Annual

 