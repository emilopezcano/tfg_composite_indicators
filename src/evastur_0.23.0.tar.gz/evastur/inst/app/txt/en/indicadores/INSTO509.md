
# Number of beds available in commercial accommodation establishments per 100 residents


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Local satisfaction

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Flow of tourists with main destination the Balearic Islands (FRONTUR) 
File of the municipal register of the Balearic National Institute of Statistics (Population)

## 4. Calculation method

$\frac{\text{ Total number of beds in commercial accommodation }}{ \text{ Total number of residents }  } \cdot\ 100$

## 5. Unit of measurement

Number of beds

## 6. Territories

Mallorca, Menorca, Ibiza and Formentera, Balearic Islands

## 7. Period

2010-2022

## 8. Frequency of data collection

Annual



