
# Water consumption (m³)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Organization

IBESTAT

## 3. Source

Directorate-General for Water Resources of the Govern de les Illes Balears

## 4. Definition

The amount of water used in the various urban supply points of a municipality.

## 5. Unit of measurement

Cubic metres

## 6. Period

2000-2021



