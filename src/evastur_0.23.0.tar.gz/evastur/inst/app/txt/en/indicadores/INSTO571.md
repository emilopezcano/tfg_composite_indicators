
# Proportion of agricultural land under organic farming


## 1. Categories

* General destination performance criteria
* Dimension: Land use and planning

## 2. Organization

INE (National Statistics Institute of Spain)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Organic production statistics, Ministry of Agriculture, Fisheries and Food Survey of areas and crop yields, Ministry of Agriculture, Fisheries and Food

## 4. Calculation method

$\frac{\text{ Agricultural area destined for organic production in year t }}{ \text{ Agricultural area (crops, meadows and grasslands) in year t }  } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual
