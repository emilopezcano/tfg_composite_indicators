# Average expenditure during the stay per tourist per night

## 1. Categories

* Section: Economic
* Theme: Economic impact of tourism on the destination

## 2. Calculation

### 2.1 Calculaton method

$\frac{\text{Average expenditure during the stay per tourist}}{\text{Nights of tourist stay}}$

### 2.2 Units
€ (euros)

## 3. Interpretation 

The higher the spending per person per night, the more wealth the tourist activity generates in the city.

Desired trend: upward temporal evolution and greater than the average of the comparison between territories

## 4. Justification

Spending per tourist per night indicates the income directly attributable to tourist activity and can be an indicator of the type of tourism received at the destination, as well as its economic efficiency.
