
# Night noise pollution caused by Palma airport


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

AENA

## 3. Source

Annual report on environmental management

## 4. Period

Last report published in 2017 with data from 2007, 2012 and 2017

## 5. Observations

Population exposed to noise of 55 dB(A) or more caused by Palma airport by time slot, noise limit and year