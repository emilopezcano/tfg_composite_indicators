
# Number of second homes per 100 households (ETIS)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Local satisfaction

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistical Institute of the Balearic Islands (IBESTAT) 
Register of the municipal register of the Balearic Islands of the National Statistics Institute (Population)

## 4. Calculation method

$\frac{\text{ Total number of second homes }}{ \text{ total number of homes }  } \cdot\ 100$

## 5. Unit of measurement

Number of beds per 100 residents

## 6. Territories

Mallorca, Menorca, Ibiza and Formentera, Balearic Islands

## 7. Period

2010-2022

## 8. Frequency of data collection

Annual



