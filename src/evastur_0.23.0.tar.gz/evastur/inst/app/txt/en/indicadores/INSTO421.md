
# Average hourly wage     

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the wage structure

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Gross earnings of employees in year t }}{\text{ Normal working hours of employees in year t }} $
  
## 5. Unit of measurement
Euros
