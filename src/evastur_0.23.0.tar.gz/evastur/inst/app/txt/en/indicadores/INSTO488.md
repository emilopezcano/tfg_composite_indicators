
# Regulation to ensure that the size and type of wastewater treatment is appropriate for its location, and evidence of its application 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Organization


## 2. Project implementers:



## 5. Period


## 6. Observations

