# Percentage of wastewater treated at least at a secondary level

## 1. Categories

* Section: Environmental
* Theme: Waste and wastewater management

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Wastewater treated at least at a secondary level}}{\text{Total wastewater}}\cdot\ 100$

### 2.2 Unit
% (percentage)

## 3. Interpretation

The higher the value, the more risk to health and the general environmental environment of the destination.

Desired trend: 100%

## 4. Justification

Correct wastewater treatment minimizes potential serious environmental and health problems.
