
# Percentage of women holding agricultural holdings in relation to total holders of agricultural holdings 

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the structure of agricultural holdings

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{Women holding agricultural holdings in year t}}{\text{people holding agricultural holdings in year t}} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage