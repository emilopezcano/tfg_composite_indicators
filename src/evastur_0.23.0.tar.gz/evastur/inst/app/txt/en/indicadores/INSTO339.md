# Tourist opinion on motor accessibility
## 1. Categories

* Section: Sociocultural
* Theme: Accesibility

## 2. Calculation

### 2.1 Calculation method

Average motor accessibility opinion score

### 2.2 Unit
Puntuations del 0 al 10

## 3. Interpretation 

The higher the score, the higher the perceived level of motor accessibility.

Desired trend: 10

## 4. Justification

La oferta de productos turísticos para personas con discapacidades promueve un modelo turístico inclusivo.
