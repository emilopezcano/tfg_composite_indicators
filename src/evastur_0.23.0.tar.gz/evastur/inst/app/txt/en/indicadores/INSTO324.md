# Waste generated per capita

## 1. Categories

* Section: Environmental
* Theme: Waste and wastewater management

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Total annual waste production at the destination}}{\text{Residents}}$

### 2.2 Unit
kg/person/year

## 3. Interpretation 

A higher value implies a greater consumption of resources in general, and represents an environmental and economic cost in waste management.
Desired trend: downward temporal evolution and lower than the average of the comparison between territories

## 4. Justification

Waste production indicates the manner and pace of resource consumption in a given area.

