
# More polluting ships docking in the main ports of Mallorca (kg CO2 per nautical mile)


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB and European Maritime Safety Agency (EMSA)

## 3. Source

Berthing operations in the ports of the Balearic Islands and declared CO emissions of each vessel

## 4. Period

2019-2023

