
# Share of total public spending on education  


## 1. Categories

* General destination performance criteria
* Dimension: Innovation

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

National accounts. Functional classification of general government expenditure, Ministry of Finance

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Regional government expenditure on education (functional group 09 of the Classifications of the Functions of Government (COFOG)) in the year t }}{ \text{ Total regional government expenditure in the year t }} \cdot\ 100$

## 6. Unit of measurement

Percentage

## 7. Observations

The Classifications of the Functions of Government (COFOG), developed by the Organization for Economic Cooperation and Development (OECD) and published by the United Nations Statistics Division, structures public expenditure into 10 functional groups: 01 General public services, 02 Defence, 03 Public order and security, 04 Economic affairs, 05 Environmental protection, 06 Housing and community services, 07 Health, 08 Leisure,
culture and religion, 09 Education, 10 Social protection.