
# Sum of ships docked per hour, port, ship, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB

## 3. Source

Docking operations in the ports of the Balearic Islands

## 4. Methodology

For the calculation, the start and end times of each berth have been truncated and how many ships have been in port have been counted. The sum shown is the total number of ships berthed for each hour of the day during the selected period.

## 5. Period

2019-2023

