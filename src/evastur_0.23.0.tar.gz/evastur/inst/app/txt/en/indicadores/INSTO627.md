
# Daytime noise pollution caused by Palma and Son Bonet airports


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

Department of Territory of the Consell de Mallorca

## 3. Source

Map viewer of the Territorial Plan of Mallorca: layer of acoustic easements

## 4. Observations

Population exposed to noise equal to or greater than 65 dB(A) caused by Palma airport by time slot, noise limit and year

