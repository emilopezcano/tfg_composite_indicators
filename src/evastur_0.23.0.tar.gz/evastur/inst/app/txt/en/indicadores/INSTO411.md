
# Temporary rate of social security membership in the tourism sector by quarter and island (%)

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Seasonality in tourism

## 2. Source
Social security affiliations in the tourism sector

## 3. Origin 
IBESTAT

## 4. Unit
Percentage of temporary affiliation

## 5. Fieldwork
2009-2022