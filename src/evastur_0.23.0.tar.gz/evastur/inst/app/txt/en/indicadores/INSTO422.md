
# Average wage per hour of people with disabilities 

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the wage structure

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Gross earnings of people with disabilities in the year t }}{\text{ Normal working hours of people with disabilities in year t }} $
  
## 5. Unit of measurement
Euros