
# Air mail traffic by airport, month and year (kg)


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

AENA

## 3. Source

Airport statistics system (Estop) - Passengers and goods by company

## 4. Period

2004-2023

## 5. Frequency of data collection

Monthly

## 6. Unit of measurement

Kilograms