
# Distribution of vehicles according to the type of propulsion


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Institut d'Estadística de les Illes Balears - 2.02 Registration of vehicles registered in the Balearic Islands, by period, island, type of vehicle and type of propulsion

## 4. Period

2015 - 2020

## 5. Observations

It distinguishes between different types of propulsion: gasoline, diesel, hybrid, electric, gas, without propulsion, does not consist or other type.

Diesel refers to a vehicle powered by diesel.
Electric refers to a vehicle powered by at least one or more electric motors.
Gas refers to a vehicle powered by liquefied petroleum gas, compressed natural gas or liquefied natural gas.
Gasoline refers to a vehicle powered by gasoline.
Hybrid refers to a vehicle equipped with a propulsion system containing at least two different categories of propulsion energy converters and at least two different categories of propulsion energy storage systems. Hybrid electric vehicle, equipped with batteries that can be recharged from an external electrical power source, which at will can be propelled only by its motor(s) electric(s).
Other types refer to a vehicle propelled by another type of propulsion.
No propulsion refers to a vehicle that lacks propulsion.
Other types refer to a vehicle propelled by another type of propulsion.
No propulsion refers to a vehicle that lacks propulsion.