
# Time spent at home and family on an average day       


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Time Use Survey, National Statistics Institute (INE)

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Minutes dedicated by the population to the household and the family on an average day in year t }}{ \text{ Population allocating time to the household and family on an average day in year t }} \cdot\ 100$

## 6. Unit of measurement

Minutes


