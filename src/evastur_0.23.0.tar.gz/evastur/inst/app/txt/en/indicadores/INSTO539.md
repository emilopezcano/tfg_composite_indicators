
# Proportion of people between 16 and 74 who have used some computer skills in the last 12 months      


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Survey on equipment and use of information and communication technologies in households, National Statistics Institute (INE)

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Population between 16 and 74 years who in the last 12 months have used some computer skills in year t }}{ \text{ Population between 16 and 74 years in year t }} \cdot\ 100$

## 6. Unit of measurement

Percentage

## 7. Observations

In the years in which the indicator is not published it is because in those years the questions that allow your calculation


