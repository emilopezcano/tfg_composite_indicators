
# Target to reduce pollutant emissions from road transport by 55% compared to 1990


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Source

Directorate-General for Energy and Climate Change of the Govern de les Illes Balears

## 3. Definitions

IMD: Average Daily Intensity. Reflects the average number of vehicles passing through the stations.

Vehicle kilometres are defined as the magnitude indicating the total sum of the kilometres travelled by all vehicles using the relevant road over a period of time, grouped in the same way as for the calculation of the average daily intensity.

## 4. Period

1990 - 2020

## 5. Unit of measurement

 - g grams
 - kg kg
 - kt kilotonnes
 - t tonnes
 - t CO2eq tonnes CO2 equivalent

## 6. Observations

Annual series from the categories corresponding to the groups of issuing activities according to the nomenclature Selected Nomenclature for Air Pollution (SNAP-97). Calculations carried out according to the methodology developed by the European EMEP/CORINAIR project and the IPCC.

Pollutants: 
 - BENZO(a) Benzo(a)pyrene
 - BENZO(b) Benzo(b)fluoranthene
 - BENZO(k) Benzo(k)fluoranthene
 - DIOX Dioxins and furans
 - PAH Polycyclic aromatic hydrocarbons
 - HCB Hexachlorobenzene
 - INDENO Indeno(1,2,3-cd)pyrene
 - PCBs Polychlorinated biphenyls
 
Heavy metals:
 - As Arsénio
 - Cd Cadmium
 - Cr chromium
 - Cu Copper
 - Hg Mercury
 - Ni Nickel
 - Pb Lead
 - Se Selenio
 - Zn Zinc
 
Acidifiers:
 - CH4 Methane
 - CO Carbon monoxide
 - CO2 Carbon dioxide
 - NMVOC Volatile organic compounds other than methane
 - HFC Hydrofluorocarbons
 - N2O Nitrous oxide
 - NH3 Ammonia
 - NOx Oxides of nitrogen
 - PFC Perfluorocarbons
 - SF6 Sulphur hexafluoride
 - SOx Oxides of sulphur
 
Particulates
 - BC Carbon black (black carbon)
 - PM10 Particles with an aerodynamic diameter of less than 10 microns
 - PM2,5 Particles with an aerodynamic diameter of less than 2,5 microns
 - PST Total suspended particles
 
Calculation formula for tonnes of CO2eq
 - CH4 CH4 * 25
 - CO2 CO2 * 1000 (t a kt)
 - N2O N2O * 25
 - HFC HFC (t CO2eq)
 - PFC PFC (t CO2eq)
 - SF6 SF6 (t CO2eq)