
# Degree of accommodation by period, island and category

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Seasonality in tourism

## 2. Source
Occupation of the tourist offer

## 3. Origin 
IBESTAT

## 4. Unit
Percentage of occupancy

## 5. Fieldwork
2008-2022
