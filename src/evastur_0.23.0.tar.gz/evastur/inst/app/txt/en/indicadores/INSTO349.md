# Security at the destination (anti-terrorist alert level in Spain)
## 1. Categories

* Section: Sociocultural
* Theme: Tourist security

## 2. Calculation

### 2.1 Calculation method

Maximum annual alert level for terrorism in Spain


### 2.2 Unit

% (percentage)

## 3. Interpretation 

The higher the value of the indicator, the more preventive actions are put in place to prevent terrorist threats.

Desired trend: 1


## 4. Justification

Reports on the level of terrorism risk in the destination. A high alert level can generate an image of insecurity of the destination in the sending markets.