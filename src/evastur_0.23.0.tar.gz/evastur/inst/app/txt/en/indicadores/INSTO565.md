
# Deaths in urban accidents


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Source

DGT - DGT in figures - Files microdatos de accidentes con víctimas

## 3. Period

2016 - 2021

## 4. Observations

Inhabitants: Municipal register
Municipality: Information about the municipality: Code municipality, name of the municipality, province of the municipality and CCAA of the municipality.
Deaths: Total number of deaths recorded in the accident, counted to 30 days.
Urban accidents: Accidents that take place on public roads in the town.
