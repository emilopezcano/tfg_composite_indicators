
# Amount of greenhouse emissions


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Source

Directorate-General for Energy and Climate Change of the Govern de les Illes Balears

## 3. Definitions

IMD: Average Daily Intensity. Reflects the average number of vehicles passing through the stations.

Vehicle kilometres are defined as the magnitude indicating the total sum of the kilometres travelled by all vehicles using the relevant road over a period of time, grouped in the same way as for the calculation of the average daily intensity.

## 4. Period

1990 - 2020

## 5. Unit of measurement

Tonnes except CO2 measured in kilotonnes

## 6. Observations

Annual series from the categories corresponding to the groups of issuing activities according to the nomenclature Selected Nomenclature for Air Pollution (SNAP-97). Calculations carried out according to the methodology developed by the European EMEP/CORINAIR project and the IPCC.

The emissions measured are:
 - CO2 Carbon dioxide
 - N2O Nitrous oxide
 - CH4 Methane
 - SF6 Sulphur hexafluoride
 - HFC Hydrofluorocarbons
 - PFC Perfluorocarbons

All of them are acidifiers.