
# Number of days with cruise stopovers by port, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB

## 3. Source

Docking operations in the ports of the Balearic Islands

## 4. Period

2019-2023


