
# Passengers arriving in Mallorca by access, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

Ibestat, from AENA, APB and Ports IB data

## 3. Source

Passenger air traffic statistics at the airports of the Balearic Islands and maritime passenger traffic statistics at ports of state competence and those of regional competence

## 4. Methodology

For the calculation of this indicator, monthly arrivals of passengers by sea and air have been added. For air traffic, only passenger arrivals data at Palma airport have been considered (Ibestat air transport table 1.1). For sea traffic, passengers arriving per month at the ports of Palma and Alcúdia (Table 2.2.01); passengers per month completing a base cruise at the ports of Palma and Alcúdia (Table 2.2.02); passengers per month of cruise ships in transit arriving at the ports of Palma and Alcúdia (Table 2.2.03); passenger arrivals at the port of Cala Rajada (Table 2.3.01); and cruise passenger arrivals at the ports of Cala Rajada, Sóller, Colònia de Sant Jordi and Andratx per year (Table 2.3.02). Since the cruise data in Table 2.3.02 are not disaggregated in months, they have been regularly attributed by dividing the annual data between 12 months.

## 5. Period

2006-2023

## 6. Frecuencia de la recopilacion de datos

Monthly

## 7. Observations

For air arrivals data, the airports of Palma and Son Bonet have been considered. For the arrivals by sea, the data of regular traffic and cruises of the ports of Palma, Alcúdia, Cala Rajada, Sóller, Colònia de Sant Jordi and Andratx have been counted. Data on private facilities have not been recorded.


