
# Number of airlines operating by airport, month and year


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Airport statistics system (Estop) - Passengers and goods by company / Air operations by company

## 4. Origin

AENA

## 5. Period

2004-2023

## 6. Frequency of data collection

Monthly

## 7. Observations

By default, the display shows the data of those airlines that carry a minimum of 5,000 passengers per year at the selected airport and period. Arrival and departure data are included. To display all airlines, you can customize the chart using the "Passengers per year" filter.


