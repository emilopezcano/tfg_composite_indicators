
# Electric vehicle charging points


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Source

Electromaps

## 3. Definitions

Availability
 - Available: charging point connected to Electromaps and currently available
 - Occupied: charging point connected to Electromaps and currently occupied
 - Not working: charging point connected to Electromaps and not working at the moment
 - No information: charging point that is not connected to Electromaps and does not transfer information in real time

Type of load
 - Slow: between 3 and 7 kW approx
 - Semi-fast: between 11 and 22 kW approx
 - Fast: 50 kW approx
 - Ultra fast: between 100 and 200 kW approx

User report:
 - In operation: charging point operating according to users
 - Partially Working: Charging Point Partially Working According to Users
 - Not working: load point not working according to users
 - No information: loading point that has not been rated by users

## 4. Last updated

20/10/2023 03:53:53

## 5. Observations

These are public charging points.
The detected connectors are of type: TYPE 2, Schuko (EU Plug), CCS2, CHAdeMO, Tesla Dest.Charger, CEE 2P+E (blue - camping)

Operational load points refer to the load points that are available and those that users report are in operation.

Total load points: 40
Operating Load Points: 36
Operational percentage: 90%

