
# Proportion of men aged 16-65 who have reached at least a fixed level of functional competence in literacy


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

International Adult Competence Assessment Programme, Ministry of Education and Vocational Training

## 4. Calculation method

$\frac{\text{ Men between 16 and 65 years who have reached at least level 2 proficiency on the reading comprehension scale in year t }}{ \text{ Men between 16 and 65 years in year t }} \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Five-year

## 7. Observations

The International Adult Competence Assessment Programme uses a 500-point scale to assess reading comprehension. To help interpret these scores, the scale is divided into six competition categories: - Below level 1: score below 176 - Level 1: score between 176 and 225 - Level 2: score between 226 and 275 - Level 3: score between 276 and 325 - Level 4: score between 326 and 375 - Level 5: score between 376 and 500 A person reaches at least level 2 proficiency on the reading comprehension scale when he is usually able to understand texts on topics he does not know, even if you have difficulty with tasks such as comparing and contrasting different texts or searching for digital texts on a specific subject you do not know. The data for 2012 corresponds to the study carried out between the third quarter of 2011 and the first quarter of 2012.


