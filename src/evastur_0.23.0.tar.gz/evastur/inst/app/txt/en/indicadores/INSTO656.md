
# Annual summary of noise measurements by port, pollutant type and year


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB

## 3. Source

Report on air quality in ABS ports

## 4. Methodology

For the allocation of the air quality level, the worst level of those measured by a station is taken into account, in accordance with the state regulations.

## 5. Period

2021

## 6. Observations

The nomenclature of the sensors and the annual percentiles in the measurements corresponds to that of the reports of the Balearic Port Authority. The air quality colours and ranges follow the parameters set out in the Annex to Order TEC/351/2019 of 18 March approving the National Air Quality Index and the Resolution of 2 September 2020, of the Directorate-General for Quality and Environmental Assessment, which amends the above-mentioned Annex.


