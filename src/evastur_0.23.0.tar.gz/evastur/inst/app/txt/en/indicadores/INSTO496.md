
# Greenhouse Gas Emissions compared to 1990 (index 1990=100)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Climate action

## 2. Organization

IBESTAT, National Statistics Institute (INE)

## 3. Source

Inventory of Pollutant Emissions to the Atmosphere 
National greenhouse gas (GHG) inventory, Ministry for Ecological Transition and Demographic Challenge

## 4. Calculation method

$\frac{\text{ CO2 emissions in year t } - \text{ CO2 emissions in year 1990 }}{ \text{ CO2 emissions in year 1990 }  }$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual



