
# Expenditure of foreign tourists with main destination the Balearic Islands and other Comunidad Autónoma by period


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Tourist spending and profile (EGATUR)

## 4. Calculation method
Expenditure of foreign tourists with main destination the Balearic Islands and other Comunidad Autónoma by period

## 5. Unit of measurement
Euros or million of euros

## 5. Fieldwork 
2016M01 - 2023M08

## 6. Territories
Mallorca, Menorca, Ibiza and Formentera, Balearic Islands