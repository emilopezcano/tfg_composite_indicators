
# Share of small-scale industries in total value added in the sector


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Climate action

## 2. Organization

IBESTAT, National Statistics Institute (INE)

## 3. Source

Structural business statistics: industrial sector, Instituto Nacional de Estadística (INE)

## 4. Calculation method

$\frac{\text{ Gross value added for manufacturing enterprises with less than 20 employees in year t }}{ \text{ Total gross value added in manufacturing in year t }  } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

## 7. Observations

At the regional level, companies are identified with legal units, that is, each legal unit is considered to be a company, which may consist of one or more establishments. At national level, until 2017 companies are identified with legal units, but from 2018 the concept of company established by the European Union Regulation (696/93) is used, according to which a company can be formed by one or several legal units, which in turn may consist of one or more establishments. It should be noted that most companies are independent legal units, so this change only affects legal units that are part of business groups. As a result, since 2018 regional data are not strictly comparable with national data. Likewise, national data since 2018 are not strictly comparable with those available until 2017.


 