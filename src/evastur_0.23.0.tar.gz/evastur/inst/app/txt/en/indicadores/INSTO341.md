# Percentage of instruments for good governance
## 1. Categories

* Section: Sociocultural
* Theme: Governance

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Good governance instruments available}}{\text{Total instruments of good governance}}\cdot\ 100$

### 2.2 Unit
% (Percentage)

## 3. Interpretation 

If government instruments are effectively available, it means that, in the destination's tourism development model, work is being done to promote participation, consensus, responsibility and equity, among others.
Desired trend: 100%

## 4. Justification

It reflects the commitment that destinations show to good tourism governance.
