# Percentage of tourism companies that have sustainability certifications

## 1. Categories

* Section: Environmental
* Theme: Sustainability and environmental management policies and practices in tourism companies

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Tourism companies certified in Biosphere Responsible Tourism}}{\text{Members of Turisme de Barcelona and Círculo de la Diputación de Barcelona}} \cdot\ 100$

### 2.2 Units
% (percentage)

## 3. Interpretation 

The higher the percentage of certified tourism companies, the greater the commitment to the sustainability of the destination.

Desired trend: 100%

## 4. Justification

The acquisition of these certifications indicates the willingness of tourism agents to improve environmental management and/or the quality of services.
