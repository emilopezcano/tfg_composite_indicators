
# CO2 emissions from resident units per unit of value added. Manufacturing


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Climate action

## 2. Organization

IBESTAT, National Statistics Institute (INE)

## 3. Source

National Greenhouse Gas Inventory (GHG), Ministry for Ecological Transition and the Demographic Challenge Air Emissions Account, National Statistics Institute (INE) Regional Accounts of Spain, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ CO2 emissions of the resident economic units of the manufacturing sector in year t* }}{ \text{ Gross value added of the manufacturing sector in volume chained with reference 2015 in year t }  }$

* the national total of CO2 emissions from the Emissions to Air Account is distributed according to CO2 emissions by autonomous communities in the National Greenhouse Gas Inventory (GHG)


## 5. Unit of measurement

Kilograms

## 6. Frequency of data collection

Annual



