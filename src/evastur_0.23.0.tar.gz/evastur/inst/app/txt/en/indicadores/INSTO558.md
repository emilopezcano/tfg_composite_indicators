
# New vehicle registration plates


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Institut d'Estadística de les Illes Balears - 2.02 Registration of vehicles registered in the Balearic Islands, by period, island, type of vehicle and type of propulsion

## 6. Period

2015 - 2020

## 7. Observations

Distinguish between electric vehicles and combustion vehicles.

An electric vehicle is a vehicle powered by at least one or more electric motors.
A combustion vehicle is a vehicle powered by diesel or gasoline.