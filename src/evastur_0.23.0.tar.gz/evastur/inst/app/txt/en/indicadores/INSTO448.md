
# Tourists with main destination the Balearic Islands by period and island 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Flow of tourists with main destination the Balearic Islands (FRONTUR)

## 4. Calculation method
Tourists with main destination the Balearic Islands by period and island 

## 5. Unit of measurement
Number of people

## 5. Fieldwork 
2016M01 - 2023M08

## 6. Territories
Mallorca, Menorca, Ibiza and Formentera, Balearic Islands