
# Pollutant emissions produced by air transport in the Balearic Islands per year


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

AENA

## 3. Source

Directorate-General for Energy and Climate Change of the Govern de les Illes Balears

## 4. Period

1990-2023

## 5. Frequency of data collection

Annual

## 6. Unit of measurement

Kilograms: AS, Cd, Cr, Cu, Hg, Ni, Pb, Se, Zn
Tons: BC, PM10, PM2,5, PST

## 7. Particles

- PM2,5: Particles with an aerodynamic diameter of less than 2,5 microns
- PM10: Particles with an aerodynamic diameter of less than 10 microns
- PST: Total suspended particles
- BC: Black carbon (black carbon)

## 8. Heavy metals

- As: Arsenic
- Cd: Cadmium
- Cr: Chromium
- Cu: Copper
- Hg: Mercury
- Ni: Nickel
- Pb: Lead
- Se: Selenium
- Zn: Zinc

## 9. Acidifiers

- SOx: Sulphur oxides 
- NOx: Nitrogen oxide
- COVNM: volatile organic compounds other than methane
- CH4: Methane
- CO: Carbon monoxide
- CO2: Carbon dioxide
- N2O: Nitrous oxide
- NH3: Ammonia
- SF6: Sulphur hexafluoride
- HFC: Hydrofluorocarbons
- PFC: Perfluorocarbons

## 10. Pollutants

- HCB: Hexachlorobenzene
- DIOX: Dioxins and furans
- BENZO(a): Benzo(a)pyrene
- BENZO(b): Benzo(b)fluoranthene
- BENZO(k): Benzo(k)fluoranthene
- INDENO: Indeno(1,2,3-cd)pyrene
- HAP: Polycyclic aromatic hydrocarbons
- PCB: polychlorinated biphenyls

## 11. Observations

Annual series from the categories corresponding to the groups of issuing activities according to the nomenclature Selected Nomenclature for Air Pollution (SNAP-97). Calculations carried out according to the methodology developed by the European EMEP/CORINAIR project and the IPCC.

