
# Desalinated water + indifference consumed (m³) 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Organization

IBESTAT

## 3. Source

Directorate-General for Water Resources of the Govern de les Illes Balears

## 4. Definition

Desalinated water is treated seawater to make it drinkable.
Groundwater is water extracted from a body of groundwater.
Undifferentiated water is mainly a mixture of groundwater and desalinated water. In some cases, the reservoirs are shallow. Although origin production is known, the percentage of contribution is unknown.

## 5. Unit of measurement

Percentage

## 6. Period

2000-2021



