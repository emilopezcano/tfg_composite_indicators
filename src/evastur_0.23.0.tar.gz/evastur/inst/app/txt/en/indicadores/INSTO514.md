
# Total net enrolment rate of 5 years  


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Statistics on non-university education, Ministry of Education and Vocational Training

## 4. Calculation method

$\frac{\text{ Students of 5 years enrolled in nursery, primary and special education in the school year t-1/t }}{ \text{ Population of 5 years to 1 January of the year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual


