
# Percentage of adults (16 to 74 years) who in the last 3 months have used any of the computer skills collected  


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 4. Calculation method

$\frac{\text{ Population between 16 and 74 years who in the last 3 months have used some computer skills in year t }}{ \text{ Population between 16 and 74 years in year t }} \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual


