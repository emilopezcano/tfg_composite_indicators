
# Non-revenue water (%)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Water management

## 2. Organization

IBESTAT

## 3. Source

Directorate-General for Water Resources of the Govern de les Illes Balears

## 4. Definition

Volume of water that municipal urban water services do not account for. It may be due to losses in the supply network, unrecorded supply points, etc.

## 5. Unit of measurement

Percentage

## 6. Period

2000-2021

## 7. Observations

The maximum percentages of eligible losses of a municipal urban supply network are those expressed in Article 64 of the Second Balearic Islands Water Plan (PHIB).





