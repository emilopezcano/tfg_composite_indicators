
# Average length of stay of tourists (nights)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Expenditure of tourists with main destination the Balearic Islands (EGATUR)

## 3. Data collection method
Destination Management Survey

## 4. Calculation method
$\frac{\text{ Tally the total tourist nights per respondent }}{ \text{ Total number of respondents }  }  {\text{ = Average length of stay per tourist }}$

## 5. Unit of measurement
Number of nights

## 6. Frequency of data collection
Mensually and Annually

## 7. Fieldwork 
2015M10 - 2023M02

## 8. Territories
Mallorca, Menorca, Ibiza and Formentera, Balearic Islands


