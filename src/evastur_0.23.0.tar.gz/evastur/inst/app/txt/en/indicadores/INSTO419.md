
# Percentage of women holders of owned agricultural holdings, compared to total holders of owned agricultural holdings   

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Survey on the structure of agricultural holdings

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Women owners of agricultural holdings in year t }}{\text{ Holders of owned agricultural holdings in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage