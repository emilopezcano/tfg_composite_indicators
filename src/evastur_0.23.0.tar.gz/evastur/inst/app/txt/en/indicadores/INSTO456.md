
# Daily spending per overnight tourist (accommodation, food and drinks, other services)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Expenditure of tourists with main destination the Balearic Islands (EGATUR)

## 3. Data collection method
Visitor Survey

## 4. Calculation method
$\frac{\text{ Total annual spending by tourists }}{ \text{ Total number of annual tourists } \cdot\ 365 }  {\text{ = Average daily spending per tourist }}$

## 5. Unit of measurement
Local currency

## 6. Frequency of data collection
Mensually and Annually

## 7. Fieldwork 
2015M10 - 2023M02

## 8. Territories
Mallorca, Menorca, Ibiza and Formentera, Balearic Islands


