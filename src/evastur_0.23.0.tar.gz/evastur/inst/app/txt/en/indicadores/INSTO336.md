# Percentage of employment linked to tourism
## 1. Categories

* Section: Economic  
* Theme: Work market

## 2. Calculation

### 2.1 Caculation method

$\frac{\text{Number of people employed in tourism activity}}{\text{Total number of employed people}}\cdot\ 100$

### 2.2 Unit
% (percentage)

## 3. Interpretation 

The higher the result of the indicator, the higher the level of dependence of the destination with respect to tourist activity.
Desired trend: that the current value does not exceed (+/-) the standard deviation of the last 5 years (depending on data availability)

## 4. Justification

Indicates the importance of tourism in the employability of the total population of the destination.
