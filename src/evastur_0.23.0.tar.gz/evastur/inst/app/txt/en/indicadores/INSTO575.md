
# Number of people killed directly attributed to disasters per 100,000 inhabitants   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Statistics of deaths by cause of death, National Statistics Institute (INE)
Population figures, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Deaths attributed to natural disasters (ICD codes X30-X39-10) in year t }}{ \text{ Population at 1 July of year t } } \cdot\ 100$

## 5. Unit of measurement

Per hundred thousand

## 6. Frequency of data collection

Annual

