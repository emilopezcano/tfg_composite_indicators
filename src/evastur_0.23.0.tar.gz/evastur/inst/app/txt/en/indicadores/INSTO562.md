
# Number of rental vehicles by company (as of July 2021)


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Source

Govern Illes Balears

## 3. Description

Companies Car Rental Mallorca - Dataset of car rental companies without driver registered on the island of Mallorca.

## 4. Period

2021 - 2022

## 5. Observations

Number of vehicles: 50583
Percentage of total rental vehicles: 100 %
Percentage of total vehicles in Mallorca: 6.22 %
Number of rental vehicles per 1000 inhabitants: 55.43 %