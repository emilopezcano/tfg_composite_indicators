
# Minimum, median, average and maximum duration of berths by port, vessel type and date


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

APB

## 3. Source

Docking operations in the ports of the Balearic Islands

## 4. Period

2019-2023

## 5. Observations

The diagram of boxes and whiskers represents the hours spent by each type of vessel berthed in port during the selected period and port. The end lines represent the minimum and maximum docking time. The intermediate lines correspond to the divisions of the quartiles; that is, they separate the data set into four quarters with the same number of values in each quarter. The center line represents the median. If the data is symmetrical, the center line is in the center of the gray area. If data is unevenly distributed (biased), the median will be closer to one of the two extremes. All values are expressed in hours.

IQR: interquartile range (difference between 25th and 75th percentiles, i.e., space shaded in gray colors).
Mean: arithmetic mean (represented with white point).
Median: median (the 50th percentile, i.e., the central value of the dataset).
Quartile: quartile (each of the data set divisions in the 25th, 50th and 75th percentiles).
Lower whisker/minimum: lower end (0 percentile).
Upper whisker/maximum: top end (100th percentile).

