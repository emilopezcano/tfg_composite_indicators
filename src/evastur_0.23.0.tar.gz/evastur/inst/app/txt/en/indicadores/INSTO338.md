# Average stay
## 1. Categories

* Section: Economic  
* Theme: Performance of tourism activity

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Overnight stays}}{\text{Tourists}}$

### 2.2 Units
Nights

## 3. Interpretation 

A longer average stay helps to decentralize tourist activity and demassify the busiest places, increasing the possibility that more agents benefit from it. It can also contribute to an increase in overall spending at the destination and to maintain or reduce the number of trips to reach the destination and, therefore, the environmental impact of arrival transportation (more overnight stays with fewer or the same number of tourists). Furthermore, a longer average stay can provide tourists with greater knowledge about cultural aspects of the destination and increase the overall assessment of their stay.

Desired trend: upwards

## 4. Justification

It allows you to visualize whether the DMMO and the administrations are working to decentralize and diversify tourist activity, increase average spending, benefit more agents and value the cultural resources of the destination.
