
# Under-five mortality rate   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

Death statistics, Instituto Nacional de Estadística (INE) Birth statistics, Instituto Nacional de Estadística (INE)


## 4. Calculation method

$\frac{\text{ Deaths of children under 5 years of age in year t }}{ \text{ Births in year t } } \cdot\ 100$

## 5. Unit of measurement

So much per hundred thousand

## 6. Frequency of data collection

Annual

