
# Proportion of total public spending on health   


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

National accounts. Functional classification of general government expenditure, Ministry of Finance of Spain

## 4. Calculation method

$\frac{\text{ Regional government expenditure on health (functional group 07 of the Classifications of the Functions of Government (COFOG)) in the year t }}{ \text{ Total expenditure of regional public administrations in the year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual

## 7. Observations

The Classifications of the Functions of Government (COFOG), developed by the Organization for Economic Cooperation and Development (OECD) and published by the United Nations Statistics Division, structures public expenditure into 10 functional groups: 01 General public services 02 Defence 03 Public order and security 04 Economic affairs 05 Environmental protection 06 Housing and community services 07 Health 08 Leisure, culture and religion 09 Education 10 Social protection.

