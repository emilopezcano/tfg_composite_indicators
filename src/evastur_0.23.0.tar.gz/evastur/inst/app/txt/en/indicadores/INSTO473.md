
# Annual amount of energy consumed from renewable sources (Mwh) as a percentage of overall energy consumption at destination level per year


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Energy Management

## 2. Source

Electricity Network of Spain

## 3. Calculation method

$\frac{\text{ Total amount of renewable energy consumed per annum }}{ \text{ Total amount of energy consumed per annum  }  } \cdot\ 100$

## 4. Unit of measurement
  
MWh

## 5. Frequency of data collection

Every 5 minutes 

## 6. Observations

This indicator tracks destination progress in conversion to renewable energy sources

 