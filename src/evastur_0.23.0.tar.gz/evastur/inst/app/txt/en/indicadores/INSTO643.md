
# Comparison of cruise traffic (passengers and stopovers) by port, cruise type, month and year 


## 1. Categories

* General destination performance criteria
* Dimension: Maritime mobility

## 2. Organization

Ibestat, from APB data

## 3. Source

Sea traffic of cruises (base and transit) in the ports of state competence by period, port and movement

## 4. Period

2006-2023

## 5. Observations

For total calculations, it has been considered that the cruise ticket based in Mallorca visits the island twice (at the beginning and end). The series "Base passengers (home)" refers to the cruise ship ticket that begins your journey in a port in Mallorca. The series "Base passengers (end)" includes the cruise ticket that ends the trip on the island. Although the cruise ship is based in Mallorca, both passenger numbers do not have to coincide. The series "Base cruises (home)" refers to cruises that start their journey in a port in Mallorca. The series "Base cruises (end)" includes cruises that end the trip on the island.



