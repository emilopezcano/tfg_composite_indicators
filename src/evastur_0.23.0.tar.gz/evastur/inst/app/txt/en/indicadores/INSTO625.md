
# Ratio of number of flights in maximum month to minimum month per airport and year


## 1. Categories

* General destination performance criteria
* Dimension: Air mobility

## 2. Organization

AENA

## 3. Source

Airport statistics system (Estop) - Air operations by company

## 4. Calculation method

$\frac{\text{ Number of flights in the month with the highest number of flights at the selected airport }}{ \text{ Number of flights in the month with the lowest number of flights in those same facilities }} \cdot\ 100$

## 5. Period

2004-2023

## 6. Frequency of data collection

Monthly

## 7. Unit of measurement

Percentage

