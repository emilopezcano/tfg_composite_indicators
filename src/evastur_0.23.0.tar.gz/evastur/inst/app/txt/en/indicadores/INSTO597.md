
# Percentage of daily smokers. Population aged 15 and over.


## 1. Categories

* General destination performance criteria
* Dimension: Safety and health

## 2. Organization

INE (National Statistics Institute)
IBESTAT (Statistics Institute of the Balearic Islands)

## 3. Source

National Health Survey, National Statistics Institute (INE) and Ministry of Health
European Health Survey, National Statistics Institute (INE) and Ministry of Health

## 4. Calculation method

$\frac{\text{ Population aged 15 and over smoking daily in year t }}{ \text{ Population aged 15 and over in year t } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Biennial / triennial

## 7. Observations

The following note is variable depending on the published data: The results of the National Health Survey 2011-2012 have been attributed to both years. The 2011 data corresponds to the National Health Survey 2011-2012, which was carried out between the second half of 2011 and the first half of 2012. The data for 2012 corresponds to the National Health Survey 2011-2012, which was carried out between the second half of 2011 and the first half of 2012.

