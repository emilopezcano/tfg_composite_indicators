
# Population suffering from noise problems from neighbours or from outside


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Local satisfaction

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Living Conditions Survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Population whose households have noise problems in housing in year t }}{ \text{ Total population in year t  } } \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual


