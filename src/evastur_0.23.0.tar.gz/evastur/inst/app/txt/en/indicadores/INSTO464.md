
# Annual growth rate of real GDP per capita   


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Spain’s annual national accounts: main aggregates

## 3. Calculation method
$\frac{\frac{\text{  Real gross domestic product of year t at constant prices (2015 USD) }}{ \text{ Population at 1 July of year t (in number of people) }  } - \frac{\text{ Real gross domestic product of year t-1 at constant prices (2015 USD) }}{ \text{ Population at 1 July of year t-1 (in number of people)  }  } }  { \frac{\text{ Real gross domestic product of year t-1 at constant prices (2015 USD) }}{ \text{ Population at 1 July of year t-1 (in number of people)  }  } } \cdot\ 100$
    
## 4. Unit of measurement
Percentage

## 5. Frequency of data collection
Annual
  