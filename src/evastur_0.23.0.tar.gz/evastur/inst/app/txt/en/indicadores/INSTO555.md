
# Type of transport used


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Plan sectorial director de mobilitat de les Illes Balears - Document I: Diagnosi, pp. 126,127

## 4. Period

July 2017

## 7. Observations

The methodology used is surveys.
The types of transport are: Rental car, walking, taxi, public bus, discretionary bus, own car, motorbike, train, bicycle and others.