
# Expenditure of tourists with main destination the Balearic Islands by period, island and type of accommodation 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Economic benefits

## 2. Source
Tourist spending and profile (EGATUR)

## 4. Calculation method
Expenditure of tourists with main destination the Balearic Islands by period, island and type of accommodation

## 5. Unit of measurement
Euro or million euro

## 5. Fieldwork 
2015M10 - 2023m08

## 6. Territories
Mallorca, Menorca, Ibiza and Formentera, Balearic Islands

## 7. Observations
The type of accommodation is divided between market accommodation and non market accommodation

