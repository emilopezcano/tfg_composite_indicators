
# Parity index (people with severe limitations due to health problems and people without limitations) of the population, between 18 and 64 years of age, who have carried out educational activities in the last 12 months        


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Survey on the participation of the adult population in learning activities, National Institute of Statistics (INE)

## 4. Calculation method

$\frac{\text{ People with severe limitations due to health problems between 18 and 64 years of age who have completed studies or training (regulated or unregulated) in the last twelve months in year t }}{ \text{ People not limited between 18 and 64 years who have completed studies or training (regulated or unregulated) in the last twelve months in the year t }} \cdot\ 100$

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Five-year

## 7. Observations

The reference value of this indicator is 100, which is held when parity is absolute. The degree of disparity is greater the further the value of the indicator differs from 100, reflecting an unfavourable or favorable situation of the numerator population group compared to the denominator population group as it takes a value lower or higher than 100 respectively. When interpreting this indicator it should be taken into account that it is not symmetric around 100.


