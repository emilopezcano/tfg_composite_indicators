
# Unemployment rate for men 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Source
Labour Force Survey, National Statistics Institute (INE)

## 3. Frequency of data collection 
Annual

## 4. Calculation method
$\frac{\text{ Unemployed men in year t }}{\text{ Economically active men in year t }} \cdot\ {100}$
  
## 5. Unit of measurement
Percentage

