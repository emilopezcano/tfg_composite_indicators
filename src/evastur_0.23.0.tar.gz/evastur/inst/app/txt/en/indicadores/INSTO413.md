
# Number and percentage of tourist employees by sector (accommodation, catering, other tourist industries) compared to total occupation at destination (ETIS)

## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Employment

## 2. Method of data collection 
Balearic Islands Tourism Satellite Account (IBESTAT, 2014)

## 3. Frequency of the data collection 
Annual

## 4. Calculation method
$\frac{\text{Total number of residents directly employed by tourism}}{\text{Total size of destination workforce}} \cdot\ {100}$

## 5. Unit of measurement
Percentage 

## 6. Observations
Direct effects: includes the immediate effects of additional demand (domestic tourism consumption or total domestic tourism demand) on the processes of production and supply of goods and services in terms of additional goods and services, and additional added value and its components.