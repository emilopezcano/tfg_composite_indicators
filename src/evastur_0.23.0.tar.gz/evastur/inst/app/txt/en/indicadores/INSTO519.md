
# Percentage of adult people (25-64 years) who study academic or training in the last four weeks 


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Labour Force Survey, National Statistics Institute (INE)

## 4. Calculation method

$\frac{\text{ Population aged 25-64 who have completed studies or training (regulated or unregulated) in the last four weeks in year t }}{ \text{ Population aged 25-64 in year t* }} \cdot\ 100$

*taking into account that each of these populations is calculated as the arithmetic mean of the four quarters of the year

## 5. Unit of measurement

Percentage

## 6. Frequency of data collection

Annual


