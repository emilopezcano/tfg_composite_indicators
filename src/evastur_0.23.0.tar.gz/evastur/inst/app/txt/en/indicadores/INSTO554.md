
# Method of transport of the resident population 


## 1. Categories

* General destination performance criteria
* Dimension: Ground mobility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Plan sectorial director de mobilitat de les Illes Balears - Document I: Diagnosi, pp. 72

## 4. Period

2011, 2009, 2017

## 7. Observations

The sample is the resident population aged 15 or over travelling on a working day.