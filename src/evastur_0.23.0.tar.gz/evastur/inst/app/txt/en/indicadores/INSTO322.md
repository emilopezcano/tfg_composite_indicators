
# Number of annual days in an episode of environmental pollution

## 1. Categories

* Section: Ambiental
* Theme: Contaminación atmosférica

## 2. Calculation

### 2.1. Calculation method

Number of days per year in an environmental episode declared by the authorities due to exceeding PM10 and/or NO2 levels. In the Barcelona region, the number of days in an episode is calculated in any of its analysis subareas: Barcelona Area, Central Catalonia, Maresme, Penedés-Garraf, Plana de Vic, Pre-Pyrenees and Vallés-Baix Llobregat.

### 2.2. Units
Days

## 3. Interpretation

The higher the value, the more risk to health and the general environmental environment of the destination. Do not compare aggregated territories with individual ones.

Desired value: 0

## 4. Justification

The number of days in which the recommended threshold is exceeded indicates the danger of air pollution.