
# Proportion of women in managerial positions    


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Accessibility

## 2. Organization

IBESTAT (Statistics Institute of the Balearic Islands)
INE (National Statistics Institute)

## 3. Source

Labour Force Survey, National Statistics Institute (INE)

## 4. Frequency of data collection

Annual

## 5. Calculation method

$\frac{\text{ Women in managerial positions (CNO group 1-2011) in year t }}{ \text{ People in managerial positions (CNO group 1-2011) in year t* }} \cdot\ 100$

*taking into account that each of these stocks is calculated as the arithmetic mean of the four quarters of the year

## 6. Unit of measurement

Percentage

## 7. Observations

Group 1 of the CNO-2011 includes managerial and managerial occupations, whose main tasks are to plan, direct and coordinate the general activity of companies, governments or other organizations, as well as formulating and revising corporate strategy and government policy. This group is subdivided into five main subgroups: 11 members of the executive branch and legislative bodies; directors of the public administration and social interest organizations; CEOs 12 Directors of administrative and commercial departments 13 Directors of production and operations 14 Directors and managers of hosting companies, 15 Directors and managers of other service companies not classified under other headings Managers are all occupations included in group 1 of CNO-2011, while senior management is understood as those belonging to subgroups 11, 12 and 13 of CNO-2011.

