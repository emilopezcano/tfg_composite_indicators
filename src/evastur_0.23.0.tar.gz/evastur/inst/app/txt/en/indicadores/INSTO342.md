# Ratio between the salary of women and that of men in tourism activity (Gender salary gap)
## 1. Categories

* Section: Sociocultural
* Theme: Gender equality

## 2. Calculation

### 2.1 Calculation method

$\frac{\text{Average salary of women in the activity}}{\text{Average salary of men in tourism activity}}$

### 2.2 Unit
-(ratio)

## 3. Interpretation 

The higher the value of the indicator, the less the wage gap (inequality) between men and women.

Desired trend: 1

## 4. Justification

It shows the differences in salary conditions between men and women.
