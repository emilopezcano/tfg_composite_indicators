
# Purification capacity/year(m3)


## 1. Categories

* Mandatory emission categories that INSTO Observatories should monitor
* Dimension: Waste water management

## 2. Source

Communication of data to the European Commission on waste water treatment plants for 2016 and 2018
Purified water flow in the regional treatment plants (Abaqua)

## 4. Unit of measurement

Cubic metres

## 5. Period

2015-2021 

## 6. Observations

The only complete series for all of Mallorca are from 2016 and 2018 based on data from Abaqua and the European Environment Agency (EEA). For the rest of the years and for the values "Annual purification capacity", only the plants managed by Abaqua are shown. The data only include waste water treated in public treatment plants and do not include other assumptions (e.g. untreated water discharges, sewage treatment plants in hotels or chemical companies...).