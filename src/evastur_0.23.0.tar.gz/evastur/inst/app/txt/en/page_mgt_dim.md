#### Edit Dimension Weights

The weights of the dimensions are used in the calculation of the global indicator.

The weight of the dimensions in the calculation of the global composite indicator can be edited. 
By default, all dimensions have a weight of 1. If a dimension is assigned a weight of, for example, 
2, we are giving that dimension twice the weight in the global indicator as those with 1.

To change the weight of a dimension in the list, select the row and then click on the "Edit" button. 
A dialog box will open where the weight can be modified, and a justification for the assigned weight must be provided. 
If the default value of 1 is assigned, simply "Default value"" can be indicated.