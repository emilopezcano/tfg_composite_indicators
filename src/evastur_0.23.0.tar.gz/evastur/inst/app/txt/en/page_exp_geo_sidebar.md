#### Explore geographical areas

This section shows the coverage of active indicators across different geographical areas. It provides an interactive visualization showing which areas have available indicator data for the selected dimension and geographical scope.

**Selection controls**

Use the sidebar controls to define which geographical areas to explore:

- **Scope** (National/Supranational): Choose whether to explore areas within a single country (National) or across multiple countries (Supranational).
- **Country/Group**: Select which country or group of countries to explore.
  **National scope**: Select a country, then choose the territorial unit level.
  **Supranational scope**: Select from predefined groups (e.g., World, European Union).
- **Dimension**: Filter which sustainability indicators are counted (GLOBAL, Economic, Environmental, or Social).

**Map visualization**

The left panel displays an interactive map showing the **number of active indicators** available for each geographical area. The map features:
- **Color-coded regions**: Geographical areas are colored according to the number of active indicators available. Darker shades indicate higher indicator coverage.
- **Interactive hover labels**: Hover over any region to see its name and the exact count of active indicators.
- **Legend**: The legend in the bottom-right corner shows the range of indicator counts corresponding to each color.
- **Auto-zoom**: The map automatically adjusts to show all relevant geographical areas based on your scope and group selections.

**Data table**

The right panel displays a table with detailed information about the geographical areas shown on the map:
- **Code**: The geographical identifier (ISO code for countries, or regional code for NUTS areas).
- **Name**: The full name of the geographical area in the selected language.
- **Date range**: The time period covered by the available indicator data (from date to date).
- **Value**: The total number of active indicators available for that area in the selected dimension.

The table synchronizes with the map, showing data for all visible geographical areas.

**Dimension selector**

Use the dimension selector in the sidebar to filter which indicators are counted:
- **GLOBAL**: Shows the total count of all active indicators across economic, environmental, and social dimensions.
- **ECO** (Economic): Shows only economic sustainability indicators.
- **ENV** (Environmental): Shows only environmental sustainability indicators.
- **SOC** (Social): Shows only social sustainability indicators.

Changing the dimension updates both the map colors and the data table to reflect the indicator count for the selected dimension.

**How to use this section**
1. Select a dimension from the sidebar to focus on a specific sustainability aspect.
2. Select the geographical scope (National or Supranational) to define the area type.
3. Choose a country or country group to explore.
4. If exploring a country at national scope, select the territorial unit level (NUTS level).
5. Observe the map to identify which geographical areas have the most comprehensive indicator coverage.
6. Review the data table for precise information about indicator availability and time coverage.

This section helps you quickly assess data availability across different geographical scopes and identify areas with sufficient indicator coverage for meaningful sustainability analysis.

**Geographical data sources**

The boundaries and geometries displayed on the map are obtained from the following sources:
- **Country and NUTS level boundaries**: Obtained from GISCO (Geographic Information System of the Commission) using the GISCO R package.
- **Spanish municipalities**: Boundaries obtained using the esp_get_munic_siane() function from the mapSpain R package.
