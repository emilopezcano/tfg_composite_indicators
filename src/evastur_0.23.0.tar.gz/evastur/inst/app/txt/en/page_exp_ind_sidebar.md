#### Explore the indicators library

All indicators in the indicator library are displayed, regardless 
of whether data is available or not. You can filter by indicator name,
and display supplementary information.

The "i" icon shows an extended description of the indicator and a
label, with the format `<label>: <description>`.

The “Documentation/Methodology” icon shows the methodology and related detailed information on the indicator.


**Indicators Documentation/Methodology**

For the selected indicator, the following information is displayed, organized into three tabs:

* **General information**: Literals of the indicator, including extended description; calculation of the indicator, including its formula and variables involved; classification of the indicator; weight of the indicator in the calculation of the composite indicator; relationship to the Sustainable Development Goals (SDGs) if identified.

* **Details**: Detailed or additional information on the indicator methodology not included in the 
general information.

* **Coverage**:For each indicator and according to the global selection, the total number of geographical areas covered, the total number of periods covered and their distributions are indicated. Note that 100% coverage of areas and periods does not imply 100% coverage of all possible combinations.
