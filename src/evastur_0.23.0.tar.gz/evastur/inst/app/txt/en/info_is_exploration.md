Expand a dimension to explore the indicators and variables implemented.
