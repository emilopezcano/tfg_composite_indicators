## Display of indicators of a geographical area

In this tab you can compare values of several indicators for the same geographic area, with each other and with a composite indicator.

If no indicator is selected, only the composite indicator series of the selected dimension is displayed. In the indicator selector you can select the indicators to be compared, up to a maximum of 10.

You can select either a geographic area or the aggregate total of the group of geographic areas.
of geographical areas can be selected.

The indicators of the selected dimension appear in the indicator selector. 
If the global dimension is selected, then all available indicators are displayed.
available. In this tab you select the indicators you want to compare.

The title of the chart shows the label of the selected geographical area (which may be “Total group”). (which can be “Total group”).

The legend shows the codes of the indicators, and the pop-up text shows their label together with the values of the axes (year and scaled value of the indicator) when hovering the mouse over the series.

The plot shows the **scaled** indicators according to the type and methods selected. You can view the series of the original values of an indicator by clicking on any point in the series (NOTE: if you close the original series, to view it again you must click on a different point than the previous one).
If the composite indicator series is clicked, a message is displayed indicating that a composite indicator does not have an original scale.
