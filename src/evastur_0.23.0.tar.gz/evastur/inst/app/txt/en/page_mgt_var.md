#### Search Available Variables to Create Indicators

1. Search for possible variables by name. By typing "%", all variables are shown.
2. A filter by dimension in the Selection tab can be applied. Variables used by indicators within the selected dimension are shown. "Global" stands for "all variables" (including those not used in any indicator).
3. A filter for only custom variables in the Selection tab can be applied.
4. If none of the available variables fit your needs, a new one can be added by expanding the "Create New Variable" section.

### Create new variable

A unique identification code is assigned to each variable, with the format 'VCUSXXXX', 
which corresponds to the prefix 'variable custom' and an incremental number.

Fill in the required information for the variable:

1. **Name**: The name of the variable. A "one-phrase" text is expected. It will be used in reports and screens where the whole name fits the space.

2. **Label**: A short name for the variable. A short label is expected, ideally one word, but more than one and the use of abbreviations are acceptable to distinguish between similar variables.

4. **Units**: Select one of the available units for the variable. Visit the **Exploration** page for detailed information about the available units on the platform.

3. **Description**: A longer description of the variable that can clarify beyond the name. 

Click the "Save Variable" button. If the data is correct, a popup message is shown. Should any database inconsistencies arise, a notification is shown at the bottom right.
