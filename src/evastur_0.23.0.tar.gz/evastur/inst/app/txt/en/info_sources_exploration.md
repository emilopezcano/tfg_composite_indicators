Variable data sources. The level of automation is indicated. Refer to the source documentation for details.
