The selected tourist area.
