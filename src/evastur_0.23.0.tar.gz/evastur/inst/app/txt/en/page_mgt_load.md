#### File Upload

Comma-separated .csv files with a period as the decimal symbol are accepted.

1. Upload the indicator and variable files using the file upload controls.
2. Ensure the format meets the specifications in the preview.
3. Click the "Save data" button to upload the data to the platform and start using it. A confirmation message is displayed if no errors occur.

### Column Specification

The column names must be exactly as indicated for each file.

**Variable Data**

- **variable_id**: Valid variable code. Ensure the codes in the file correspond to indicators in the database. 
You can search in the "Indicators" tab.
- **date**: Date in ISO format (YYYY-MM-DD). The complete date is always required. If the data refers to a period, the first day of the period is indicated, and its extension is determined by the next column.
- **period_id**: Period identifier. It can be "Y" (year) or "M" (month).
- **geo_id**: Geographic area identifier. Generally, ISO3 code for countries and NUTS2 code or equivalent for regions within a country. Check valid codes on the exploration page.
- **variable_value**: Numeric value of the variable for the indicated period and geographic area in the row.

**Indicator Data**

- **indicator_id**: Valid indicator code. Ensure the codes in the file correspond to indicators in the database. You can search in the "Indicators" tab.
- **date**: Date in ISO format (YYYY-MM-DD). The complete date is always required. If the data refers to a period, the first day of the period is indicated, and its extension is determined by the next column.
- **period_id**: Period identifier. It can be "Y" (year) or "M" (month).
- **geo_id**: Geographic area identifier. Generally, ISO3 code for countries and NUTS2 code or equivalent for regions within a country. Check valid codes on the exploration page.
- **indicator_value**: Numeric value of the indicator for the indicated period and geographic area in the row.

Periods can be different in variables and indicators. Indicator values will be effectively used in the calculation of the composite indicator and must already be calculated.

