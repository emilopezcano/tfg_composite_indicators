EVASTOUR is a fundamental tool to promote sustainable tourism and support strategic decision making.

* Strategy: EVASTOUR is a technological prototype that can be used by government
authorities, regulatory entities, tourism companies and operators. EVASTOUR can
be marketed anywhere in the world, since the problem it aims to solve is
common to all destinations and tourist areas worldwide.

* Marketing: EVASTOUR embraces cultural diversity by including global perspectives and
knowledge in data collection and analysis, integrating into various tourism infrastructures around the world.

* Events: Practical demonstrations of EVASTOUR's capabilities and beneﬁts. Exhibitions at
tourism fairs, specialized conferences and meetings with potential users.

<center>
<table>
  <tr>
    <td>Home</td>
    <td>Exploration</td>
    <td>Visualization</td>
    <td>Analysis</td>
  </tr>
  <tr>
    <td><img src="www/img/home.png" width=270 ></td>
    <td><img src="www/img/exploration_new.png" width=270 ></td>
    <td><img src="www/img/visualization_new.png" width=270 ></td>
    <td><img src="www/img/analysis_new.png" width=270 ></td>
  </tr>
 </table>
</center>

<center>
<table>
  <tr>
    <td>IS Management</td>
    <td>Data Update</td>
    <td>Experimental</td>
    <td>Settings</td>
  </tr>
  <tr>
    <td><img src="www/img/IS-management.png" width=270 ></td>
    <td><img src="www/img/data-update.png" width=270 ></td>
    <td><img src="www/img/experimental-en.png" width=270 ></td>
    <td><img src="www/img/settings.png" width=270 ></td>
  </tr>
 </table>
</center>

&nbsp;

* Exploration: Advanced data processing techniques to ﬁlter, clean and transform information
collected from various sources. Ability to manage large volumes of data efﬁciently and ensure its quality and consistency.

* Visualization: EVASTOUR facilitates the presentation and interpretation of results, providing an   intuitive and user-friendly interface for end users, while incorporating the latest
 scientiﬁc and technical advances in data science.
 
* Analysis: Through the development of advanced forecasting models
and the generation of clear and transparent explanations,
EVASTUR contributes signiﬁcantly to informed decision making and strategic planning in the sustainable tourism sector.

