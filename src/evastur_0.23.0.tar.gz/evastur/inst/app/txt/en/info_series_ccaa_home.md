Sustainable Tourism Indicator and its dimensions for the selected autonomous community, according to the desired scaling method.
Move over the series to see the exact values.

