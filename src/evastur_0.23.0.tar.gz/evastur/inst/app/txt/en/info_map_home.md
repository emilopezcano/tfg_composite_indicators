The values of the Sustainable Tourism indicator of the selected destination and dimension are represented by a color scale.
