Select geographical areas to compare the selected dimension and indicator.
