Select one of the scaling methods. For more details, see “i”.
