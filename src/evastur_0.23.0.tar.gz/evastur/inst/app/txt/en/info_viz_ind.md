Select indicators to compare themselves within the selected geographical area.
