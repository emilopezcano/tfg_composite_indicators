Collected sustainable tourism indicators.
Indicators descriptions available.
