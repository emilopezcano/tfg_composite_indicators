
##### Geographic Area

Country or geographic area of the country for which the composite indicator of the series and the key figures of the lower boxes are calculated.

##### Dimension

Dimension represented on the map and for which the key figures of the lower boxes are obtained.

##### Value Boxes

* Trend: Trend of the sustainable tourism indicator compared to the previous period (difference of the last two values). It is shown in green if positive and in red if negative.

* STI: Value of the sustainable tourism indicator in the selected period. Depending on the scaling, the following colors are shown:
  + Z-score: Shown in green if greater than 1, in red if less than -1, and in orange otherwise.
  + Max-Min: Shown in green if greater than 0.75, in red if less than 0.25, and in orange otherwise.
  + Reference Value: Shown in green if greater than 1, in red if less than 1, and in orange otherwise (equal to 1).

* Distance to Maximum: Distance between the current value and the maximum reached by the indicator in the shown history, categorized as less than or greater than 0.25 (shown in green and red respectively).

* Position of the last period compared to the selected years. 1st means it is the highest value among those years. It is shown in green with a check mark if it is in first place, in green with an upward arrow if it is in second place, in yellow if it is between 3 and the penultimate position, and in red if it is among the last two.
