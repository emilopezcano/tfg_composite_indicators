---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-ETR

The INE-ETR source constitutes the Data Database of ETR (Resident Travel
Survey (ETR/FAMILITUR)). It is, therefore, a source of **Data**.

Variables from INE-ETR are used to generate indicators that aim to align
with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Resident Travel Survey

The Resident Tourism Survey is a continuous survey whose main objective
is to provide monthly, quarterly, and annual estimates of trips made by
the resident population in Spain and their main characteristics
(destination, duration, motive, accommodation, mode of transport,
expenditure, sociodemographic characteristics of travelers, etc.).

This survey continues the Tourist Movements of Spaniards Statistics
(FAMILITUR) and has been disseminating results since February 2015. Data
prior to that date and the link between both series can be consulted in
the [Related Links
section](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176990&menu=enlaces&idp=1254735576863).

#### Register Design and Valid Variable Values

The variables used to calculate the indicators follow a record design
and valid values defined by INE in an Excel file titled [*Register
design and valid variable
values*](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176990&menu=resultados&idp=1254735576863#_tabs-1254736195352).

#### Methodology and Questionnaire

The methodology, questionnaire, and a user guide for the files, which
explain all data-related information in greater detail, are also
provided on the [INE website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176990&menu=metodologia&idp=1254735576863).

