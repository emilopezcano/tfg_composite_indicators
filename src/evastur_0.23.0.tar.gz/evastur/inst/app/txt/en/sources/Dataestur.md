---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: DATAESTUR

The DATAESTUR source constitutes the Dataestur Data Database.
It is, therefore, a source of **Data**.

Con las variables de Dataestur se generan los indicadores que buscarán
acomodarse a alguno de los sistemas de indicadores de turismo sostenible
conocidos, en este orden:

Dataestur variables generate indicators designed to align with known
sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is Dataestur

Dataestur is a unique national tourism data site where you can access
figures from various information sources.

Dataestur allows for the addition of new public and private data sources
to classic sources already published by other institutions.

#### Data Structure

The data is structured into six categories:

-   General: international tourist arrivals, tourism expenditure,
    resident tourism survey, World Tourism Barometer, broadband coverage
    data, etc.

-   Economy: tourism revenue, GDP contribution, tourism employment (job
    seekers, unemployment, and contracts), etc.

-   Transport: air passengers, scheduled air capacity, passenger traffic
    by ports, trains, and roads, etc.

-   Accommodations: hotel occupancy, accommodation prices, and hotel
    sector profitability indicators, etc.

-   Sustainability: air quality, nature protection, climatological
    values, bathing water quality, etc.

-   Knowledge: active listening reports, visitor behavior and
    perception, SICTUR bulletin, and tourism scientific journals, etc.

#### More Information

In addition to access via the [website](https://www.dataestur.es/),
Dataestur features an [API](https://www.dataestur.es/apidata/), or web
service, designed for data re-users or consumers to automatically obtain
data files published on the web.

Furthermore, Dataestur expands the information offered in different data
visualizations by publishing quarterly situation reports, available
under the
['Knowledge'](https://www.dataestur.es/conocimiento-turistico/)
category.
