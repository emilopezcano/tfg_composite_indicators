---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: UNWTO

The UNWTO source constitutes the Data Database of the UNWTO (World
Tourism Organization). It is, therefore, a source of **Data**.

Variables from the UNWTO are used to generate indicators that aim to
align with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### Register Design and Valid Variable Values

The variables used to calculate the indicators follow a register design
and valid values defined by the UNWTO in a PDF file titled
[*Methodological Notes to the Tourism Statistics Database, 2023
Edition*](https://www.e-unwto.org/doi/book/10.18111/9789284424160).

In this file, each record represents a variable that collects data on
tourists arriving in or departing from a country. The variable that
uniquely identifies each country is `C.`, and the one that represents
each variable collecting tourism data is `S.`

Regarding the `C.` variable, some countries have different or older
codes than those established in `ISO3n`:

| Old Code | Old Name               | Current Code | Current Name                  |
|-----------------|-----------------|-----------------|--------------------|
| 230      | Etiopía                | 231          | Etiopía                       |
| 280      | Alemania Occidental    | 276          | Alemania                      |
| 461      | Saba                   | 534          | Bonaire, San Eustaquio y Saba |
| 658      | Sint Eustatius         | 534          | Bonaire, San Eustaquio y Saba |
| 736      | Sudán                  | 729          | Sudán                         |
| 891      | Serbia y Montenegro    | 688          | Serbia                        |
| 886      | Yemen, República Árabe | 887          | Yemen                         |

The variable code is collected in the `S.` variable. The methodology
file contains the correspondence between the code and the variable
definition. Below is an example of this coding for variables related to
tourist arrivals by mode of transport.

| Code | Mode of Transport | Units  |
|------|-------------------|--------|
| 1.19 | Total             | ('000) |
| 1.20 | Aéreo             | ('000) |
| 1.21 | Acuático          | ('000) |
| 1.22 | Terrestre         | ('000) |
| 1.23 | Ferrocarril       | ('000) |
| 1.24 | Carretera         | ('000) |
| 1.25 | Otros             | ('000) |

#### Indicator Calculation

Additionally, the UNWTO also specifies the calculation for estimating
the indicators `average length of stay` and
`average expenditure per day`, for both inbound (national and
international) and outbound tourism.

`Average length of stay` reflects the total average duration of inbound
or outbound visitor trips (expressed in number of days). For inbound
tourism, total data is estimated using household surveys, and for
outbound tourism, border surveys or household information are used.
`Average expenditure per day` is the quotient calculated by dividing
total expenditure by the total number of days spent. In inbound tourism,
it is estimated using visitor surveys, and in outbound tourism, it is
estimated from border surveys or household information.

It also indicates how the indicator for tourism demand can be calculated
based on available information:

-   $\frac{1.2-inbound tourists + 2.2 domestic tourists}{population}$
-   $\frac{1.2-inbound tourists + 2.1 domestic visitors}{population}$
-   $\frac{1.2-inbound tourists}{population}$
-   $\frac{1.1-inbound visitors + 2.1 domestic visitors}{population}$
-   $\frac{1.1-inbound visitors + 2.2 domestic visitors}{population}$
-   $\frac{1.1-inbound visitors}{population}$

#### Restrictions

The UNWTO indicates a series of restrictions on the microdata files.

These restrictions are:

-   Data is only available up to 2022, and values are annual.

-   Each country calculates the same variable including different data.
    For example, in the variables `Arrivals by mode of transport`, some
    countries exclude national tourists residing abroad, while others
    include them.

#### Methodology and Questionnaire

The [UNWTO
website](https://www.e-unwto.org/doi/book/10.18111/9789284424160)
provides country-specific details on how variables are calculated,
highlighting differences and the source from which data is extracted.

Data download page:
<https://www.unwto.org/tourism-statistics/key-tourism-statistics>
