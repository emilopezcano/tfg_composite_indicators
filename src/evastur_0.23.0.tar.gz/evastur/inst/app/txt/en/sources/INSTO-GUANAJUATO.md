---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: Guanajuato

The Guanajuato source comprises the Data and Indicators Database of the State of
Guanajuato Tourism Observatory. It is, therefore, a source of
**Data and Indicators**. They are divided into the following four dimensions:

-   Economy

-   Destination Management

-   Society and Culture

-   Environment

#### More Information

More detailed information about the dimensions and indicators can be
found on the
[website](https://www.observatorioturistico.org/admin-oteg/reports/30/).
