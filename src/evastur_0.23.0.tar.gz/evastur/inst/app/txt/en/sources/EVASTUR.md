---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: EVASTUR

The EVASTUR source constitutes the Indicators Database of EVASTUR. It
is, therefore, a source of **Indicators**. It uses the three main
dimensions, based on the SF-MST framework:

-   Economic

-   Environmental

-   Social

EVASTUR variables generate indicators designed to align with known
sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).
