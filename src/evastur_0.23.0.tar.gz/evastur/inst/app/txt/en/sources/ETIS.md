---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: ETIS

The ETIS source comprises the Indicators Database of ETIS (European
Tourism Indicator System). It is, therefore, a source of **Indicators**.
It is based on 43 core indicators divided into four dimensions:

-   Destination Management

-   Social and Cultural Impact

-   Economic Value

-   Environmental Impact

Additionally, it includes the opportunity to analyze supplementary
indicators better adapted to the type or category of destination, or to
the tourist market these destinations serve or promote.

#### What is the European Tourism Indicator System

The European Tourism Indicator System (ETIS) is a management,
information, and monitoring tool specifically designed for tourism
destinations. It is built as a process driven and managed at the local
level to collect and analyze data with the overall objective of
evaluating tourism's impact on a destination.

ETIS's specific objective is to contribute to improving the sustainable
management of destinations. Its purpose is to help destinations and
stakeholders measure their sustainability management processes, allowing
them to monitor their performance and progress over time.

#### Why Apply the European Tourism Indicator System

ETIS represents a common methodology for sustainable destination
management. It is a highly effective management tool provided by the
European Commission.

An ETIS tool specifically developed for this purpose guides destinations
through the application process. Through an explanatory guide,
destinations can learn an effective procedure that ultimately leads to
the creation of the indicator system, starting with awareness,
stakeholder involvement, and defining responsibilities, then proceeding
to data collection and analysis of results to foster continuous
improvement.

#### More Information 

On the [European Union website](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es), you can find a PDF file
with more detailed information on the above, as well as an application
guide for the European Tourism Indicator System.

European Commission, Directorate-General for Internal Market, Industry,
Entrepreneurship and SMEs, The European Tourism Indicator System: ETIS
tool for sustainable destination management, Publications Office, 2017,
<https://data.europa.eu/doi/10.2873/671106>
