---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: Croatia

The Croatia source comprises the Data and Indicators Database of The Croatian
Sustainable Tourism Observatory. It is, therefore, a source of
**Data and Indicators**.

#### What is The Croatian Sustainable Tourism Observatory

The Canary Islands joined the UNWTO International Network of Sustainable
Tourism Observatories in October 2020.

The Croatian Sustainable Tourism Observatory (CROSTO) is hosted by the
Institute for Tourism in Zagreb, which is responsible for monitoring
sustainable tourism in the Adriatic Croatia. CROSTO advises local
communities on minimizing possible negative impacts of tourism
development and measures their economic benefits and energy, water and
waste control. The country's commitment to sustainability has been
emphasized in its Tourism Development Strategy 2020. The initiative aims
at fostering innovation in the framework of sustainable tourism.

#### Additional Information

You can find more detailed information about the above explanation and
the indicators on the [Tourism Institute's
website](https://www.iztzg.hr/en/) and the [INSTO
page](https://www.unwto.org/observatories/adriatic-coast-croatia).
