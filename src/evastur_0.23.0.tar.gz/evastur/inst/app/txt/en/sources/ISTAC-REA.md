---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: ISTAC-REA

The ISTAC-REA source constitutes the Data Database of REA (Water
Statistics Compilation). It is, therefore, a source of **Data**.

Variables from REA are used to generate indicators that aim to align
with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Water Statistics Compilation

The Water Statistics Compilation is produced by the Canary Islands
Institute of Statistics (ISTAC).

The Water Statistics Compilation provides biennial information on
various physical and economic measures of activities related to the
so-called integral water cycle, which includes water collection, supply,
and sanitation (sewerage and wastewater treatment) in the Canary
Islands.

#### More Information

Additional information related to the data is provided on the [ISTAC
website](https://www.gobiernodecanarias.org/istac/estadisticas/territorioymedioambiente/medioambiente/calidadyusosdelagua/C00043A.html).
