---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-AGUAS

The INE-AGUAS source comprises the Data Database for Water Use
Statistics, Water Supply and Sanitation Statistics, Mineral and Thermal
Water Statistics, Quantitative Status Monitoring of Groundwater, Bathing
Water Quality, Surface Water Status Monitoring, Drinking Water Quality,
and Chemical Status Monitoring of Groundwater. It is, therefore, a
source of **Data**.

The variables from INE-AGUAS are used to generate indicators that aim to
align with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### Statistical Operations Periodically Produced by INE

The Water Use Statistics and the Water Supply and Sanitation Statistics
are operations periodically carried out by INE.

The main objective of the Water Use Statistics is to study the
utilization of water resources in economic activity sectors
(agriculture, industry, services, etc.) or in specific branches of
economic activity.

The main objective of the Water Supply and Sanitation Statistics is to
quantify in physical units and value in economic terms activities
related to the so-called integral water cycle, which consists of water
supply and sanitation (sewerage and wastewater treatment). Furthermore,
it provides the necessary information for developing water satellite
accounts and meets the demand for this type of data from national and
international organizations, companies in the sector, and public
administrations.

More detailed information related to the data, including the
questionnaire and methodology, is also provided on the [INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176839&menu=metodologia&idp=1254735976602).

#### Operations Produced by Other National Statistical System Bodies

Mineral and Thermal Water Statistics, Quantitative Status Monitoring of
Groundwater, Bathing Water Quality, Surface Water Status Monitoring,
Drinking Water Quality, and Chemical Status Monitoring of Groundwater
are operations produced by other bodies within the national statistical
system.

The Mineral and Thermal Water Statistics are the responsibility of the
Ministry for Ecological Transition and Demographic Challenge -
Secretariat of State for Energy, aiming to understand the exploitation
of mineral and thermal waters.

The Quantitative Status Monitoring of Groundwater is the responsibility
of the Ministry for Ecological Transition and Demographic Challenge -
Secretariat of State for Environment, aiming to control water resources
stored in naturally recharged aquifers and their depletion (natural and
by extraction).

Bathing Water Quality is the responsibility of the Ministry of Health -
Secretariat of State for Health, aiming to develop an information system
related to bathing water quality and to know and disseminate the quality
of maritime and continental bathing water to assess its impact on the
health of the user population.

Surface Water Status Monitoring is the responsibility of the Ministry
for Ecological Transition and Demographic Challenge - Secretariat of
State for Environment, aiming to provide information on the status of
continental surface water bodies.

Drinking Water Quality is the responsibility of the Ministry of Health -
Secretariat of State for Health, aiming to develop an information system
related to the supply and quality control of drinking water and to know
and disseminate the quality of drinking water to assess its impact on
the health of the served population.

Chemical Status Monitoring of Groundwater is the responsibility of the
Ministry for Ecological Transition and Demographic Challenge -
Secretariat of State for Environment, aiming for general control of the
evolution of groundwater chemical quality.

More detailed information related to the data is also provided on the
[INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176839&menu=metodologia&idp=1254735976602).
