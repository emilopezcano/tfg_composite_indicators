---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-ECE

The INE-ECE source constitutes the Data Database of the Energy
Consumption Survey. It is, therefore, a source of **Data**.

Variables from the Energy Consumption Survey are used to generate
indicators that aim to align with known sustainable tourism indicator
systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Energy Consumption Survey

The Energy Consumption Survey is a statistical investigation whose
objective is to obtain information about the different types of fuels
used by industrial companies.

The survey covers extractive industries and manufacturing industry. The
study population consists of all companies with 20 or more employees
whose main activity is included in Sections B and C of the National
Classification of Economic Activities (CNAE-2009).

Until the 2021 reference year, the survey was conducted biennially (only
for odd reference years). Since 2022, the operation has become annual.

#### Methodology and Questionnaire

The methodology and questionnaire, which explain all data-related
information in greater detail, are also provided on the [INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736146240&menu=metodologia&idp=1254735576715).
