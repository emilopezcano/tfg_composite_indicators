---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: Barcelona

The Barcelona source comprises the Data and Indicators Database for the
Sustainable Tourism Indicator System. It is, therefore, a source of
**Data and Indicators**. It uses three main dimensions:

-   Environmental

-   Economic

-   Sociocultural

#### What is the OTB Sustainable Tourism Indicators System

Barcelona joined the UNWTO International Network of Sustainable
Tourism Observatories in October 2022.

A committee made up of the Barcelona Tourism Observatory, the CETT and
the University of Barcelona, has carried out a process of purification,
selection and transformation of the indicators with the aim of
configuring the OTB Sustainable Tourism Indicators System (SITS-OTB).
The validation of the content of the indicators has been based on expert
judgement, and on the identified indicators in the study of play of the
use of sustainable tourism indicators in Destination Barcelona.

#### More information

More detailed information about the above explanation, the methodology,
and the Sustainable Tourism indicators can be found on the [OTB
website](https://observatoriturisme.barcelona/en/) and the [INSTO page](https://www.unwto.org/observatories/barcelona-spain).
