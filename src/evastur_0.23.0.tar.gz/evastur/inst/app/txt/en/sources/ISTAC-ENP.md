---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: ISTAC-ENP

The ISTAC-ENP source constitutes the Data Database of ENP (Protected
Natural Areas Statisticss). It is, therefore, a source of **Data**.

Variables from ISTAC-ENP are used to generate indicators that aim to
align with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is Protected Natural Areas Statistics

Protected Natural Areas Statistics are produced by the Canary Islands
Institute of Statistics (ISTAC).

This statistic provides information about the Canary Islands Network of
Protected Natural Areas: location, area, declaration, protection
characteristics, management instruments, and processing status. It also
covers areas with specific protection granted by international or
supranational organizations: Sites of Community Importance (SCIs) and
Special Protection Areas for Birds (SPAs).

#### More Information

Additional information related to the data is provided on the [ISTAC
website](https://www.gobiernodecanarias.org/istac/operaciones/C00005A.html).
