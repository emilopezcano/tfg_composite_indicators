---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: SF-MST

The SF-MST source constitutes the Indicators Database of SF-MST
(Statistical Framework for Measuring the Sustainability of Tourism). It
is, therefore, a source of **Indicators**. It uses the three main
dimensions, based on the SF-MST framework:

-   Economic

-   Environmental

-   Social

#### What is the Statistical Framework for Measuring the Sustainability of Tourism

The Statistical Framework for Measuring the Sustainability of Tourism
(SF-MST) is a multi-purpose conceptual framework designed to support the
recording and reporting of tourism sustainability data.

Its objective is to organize data on the economic, environmental, and
social connections and effects of tourism in a holistic manner, taking
into account differences across geographical scales, from local to
national and international.

#### Why Apply the Statistical Framework for Measuring the Sustainability of Tourism

SF-MST provides a structure for organizing data and statistics using
common concepts, definitions, classifications, and reporting standards.
The importance of developing a common framework to support comparison is
very high to ensure progress towards more sustainable tourism.

Furthermore, it establishes a solid foundation for the design and
investment in integrated data solutions and technology that support the
collection and dissemination of tourism sustainability statistics across
multiple agencies.

#### More Information

More detailed information about the above explanation and the SF-MST
indicators can be found on the [SF-MST
page](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).
