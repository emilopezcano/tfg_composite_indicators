### Instrucciones

Aquí se incluye información sobre la fuente de indicadores o la fuente de datos.

1. Copia esta plantilla en un nuevo archivo con nombre source_id.md 
donde source_id es esta columna de la tabla dt_sources.

2. Borra esta sección de instrucciones.

3. Rellena las siguientes con toda la información que tengamos disponible para
que cualquiera pueda saber exactamente qué datos nos estamos trayendo y dónde
conseguir información adicional (metodología, encuesta, etc.)

4. Envía los cambios al repositorio

Normas de estilo:

- Utiliza estilo impersonal, nunca primera persona.


### Fuente: EVASTUR

La fuente EVASTUR constituye la Biblioteca de Indicadores de EVASTUR. 
Es por tanto una fuente de **Indicadores**.
Utiliza las tres dimensiones principales, basadas en el marco SF-MST:

- Económica
- Medioambiental
- Social

Los indicadores de EVASTUR buscarán acomodarse a alguno de los sistemas
de indicadores de turismo sostenible conocidos, en este orden:

1. Indicadores de [ETIS](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es), 
que son concretos.

2. Indicadores de [observatorios de INSTO](https://insto.unwto.org). Son concretos, basados en las temáticas 
propuestas en el libro de INSTO. 
Por ejemplo el [observatorio de Canarias](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/) tiene
un gran número de indicadores en los que fijarse.

3. Indicadores del [SF-MST](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

4. Indicadores del [libro de INSTO](https://www.e-unwto.org/doi/book/10.18111/9789284407262).








