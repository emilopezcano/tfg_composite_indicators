---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: World Bank

The World Bank source comprises the Data and Indicators Database of
World Bank Open Data. It is, therefore, a source of **Data and Indicators**.

The Data source is obtained through its ["Microdata
Library"](https://microdata.worldbank.org/index.php/home).

The Indicators source is acquired through the [World Development
Indicators -
WDI](https://datatopics.worldbank.org/world-development-indicators/),
which are organized according to six thematic areas:

-   Poverty and Inequality

-   People

-   Environment

-   Economy

-   States and Markets

-   Global Links

#### What is the Microdata Library

The Microdata Library is a collection of disaggregated datasets from the
World Bank and other international, regional, and national
organizations.

These datasets primarily consist of raw, individual-level data from
surveys, impact evaluations, and research studies.

#### What is the World Development Indicators (WDI)

The World Development Indicators is a compilation of relevant,
high-quality, and internationally comparable statistics about global
development and the fight against poverty. The database contains 1,400
time series indicators for 217 economies and more than 40 country
groups, with data for many indicators going back more than 50 years.

#### More information

More detailed information about the above explanation, as well as on microdata and World
Development Indicators (WDI) can be found on the [World Bank
website](https://data.worldbank.org/). Additionally, information
regarding data coverage, organization, and methodologies used is also
available.
