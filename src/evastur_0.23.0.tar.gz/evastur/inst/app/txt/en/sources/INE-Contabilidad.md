---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-Contabilidad

The INE-Contabilidad source comprises the Data Database of Annual
National Accounts of Spain: Main aggregates. It is, therefore, a source
of **Data**.

Variables from Annual National Accounts of Spain: Main aggregates are
used to generate indicators that aim to align with known sustainable
tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is Annual National Accounts of Spain: Main aggregates

Annual National Accounts of Spain: Main aggregates is a summary
statistic that provides the main aggregates of the national economy
(GDP, national income, and employment) resulting from the system of
national accounts.

It offers the measurement of GDP and each of its components, prepared
from the perspectives of supply, demand, and income. Estimates of
economic aggregates for supply and demand are offered at both current
prices and in volume terms.

It also includes the measurement of gross national income (GNI) and
gross national disposable income (GNDI), resulting from national
economic activity and income flows with the rest of the world.

Estimates of employment (in terms of employed persons, hours worked,
jobs, and full-time equivalent jobs) are also included.

#### Methodology

This statistical operation adopts the
[methodology](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736177057&menu=metodologia&idp=1254735576581)
contained in the European System of National and Regional Accounts (ESA
2010), just like the rest of the statistical operations that comprise
Spain's National Accounts, which ensures the international comparability
of its results.

The results correspond to the 2019 Statistical Revision (ESA 2010). In
the [Related Links
section](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736177057&menu=enlaces&idp=1254735576581),
you can consult information corresponding to previous accounting bases.

