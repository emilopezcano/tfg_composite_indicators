---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-CST

The INE-CST source comprises the Data Database of Spanish Tourism
Satellite Account. It's therefore a source of **Data**.

Variables from Spanish Tourism Satellite Account are used to generate
indicators that aim to align with known sustainable tourism indicator
systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is Spanish Tourism Satellite Account

Spanish Tourism Satellite Account (CSTE) is a summary statistic made up
of a set of accounts and tables. It's based on national accounting
principles and presents various economic parameters of tourism in Spain
for a given reference date. The current base year is 2010.

It essentially includes three types of elements:

-   Supply accounts and tables: These aim to characterize the production
    and cost structure of tourism businesses.

-   Demand tables: These aim to economically characterize different
    types of tourists, domestic versus international tourism, the types
    of goods and services demanded, etc.

-   Tables interrelating supply and demand: These allow for integrated
    measurements of tourism's contribution to the economy through macro
    variables like GDP, production, or employment.

#### Methodology

The methodology, which explains all data-related information in greater
detail, is also provided on the [INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736169169&menu=metodologia&idp=1254735576581).

