---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-ODS

The INE-SDG source constitutes the Data and Indicators Database of the SDGs
(Sustainable Development Goals). It is, therefore, a source of
**Data and Indicators**.

The 2030 Agenda for Sustainable Development comprises 17 goals and 169
targets. For their monitoring, 231 indicators were designed that can be
measured through the statistical data collected here. The update of
these indicators, which constitute a statistical operation included in
the current annual program, is continuous and includes information from
both INE and other official sources that will be progressively
incorporated.

#### The 17 Sustainable Development Goals

-   Goal 1: No Poverty

End poverty in all its forms everywhere.

-   Goal 2: Zero Hunger

End hunger, achieve food security and improved nutrition and promote
sustainable agriculture.

-   Goal 3: Good Health and Well-being

Ensure healthy lives and promote well-being for all at all ages.

-   Goal 4: Quality Education

Ensure inclusive and equitable quality education and promote lifelong
learning opportunities for all.

-   Goal 5: Gender Equality

Achieve gender equality and empower all women and girls.

-   Goal 6: Clean Water and Sanitation

Ensure availability and sustainable management of water and sanitation
for all.

-   Goal 7: Affordable and Clean Energy

Ensure access to affordable, reliable, sustainable and modern energy for
all.

-   Goal 8: Decent Work and Economic Growth

Promote sustained, inclusive and sustainable economic growth, full and
productive employment and decent work for all.

-   Goal 9: Industry, Innovation and Infrastructure

Build resilient infrastructure, promote inclusive and sustainable
industrialization and foster innovation.

-   Goal 10: Reduced Inequalities

Reduce inequality within and among countries.

-   Goal 11: Sustainable Cities and Communities

Make cities and human settlements inclusive, safe, resilient and
sustainable.

-   Goal 12: Responsible Consumption and Production

Ensure sustainable consumption and production patterns.

-   Goal 13: Climate Action

Take urgent action to combat climate change and its impacts.

-   Goal 14: Life Below Water

Conserve and sustainably use the oceans, seas and marine resources for
sustainable development.

-   Goal 15: Life on Land

Protect, restore and promote sustainable use of terrestrial ecosystems,
sustainably manage forests, combat desertification, and halt and reverse
land degradation and halt biodiversity loss.

-   Goal 16: Peace, Justice and Strong Institutions

Promote peaceful and inclusive societies for sustainable development.

-   Goal 17: Partnerships for the Goals

Strengthen the means of implementation and revitalize the Global
Partnership for Sustainable Development.

#### More Information

More detailed information about the above explanation and the SDG
indicators can be found on the [INE
website](https://www.ine.es/dyngs/ODS/en/index.htm).


