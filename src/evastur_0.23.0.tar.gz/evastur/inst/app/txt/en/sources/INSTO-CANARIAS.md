---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: Canarias

The Canarias source comprises the Data and Indicators Database of the Tourism
Observatory of the Canary Islands. It is, therefore, a source of
**Data and Indicators**.

#### What is the Tourism Observatory of the Canary Islands

The Canary Islands joined the UNWTO International Network of Sustainable
Tourism Observatories in October 2020.

The statistics from the Vice-Ministry of Tourism are produced by the
Tourism Observatory of the Canary Islands, which is the unit responsible
for studying and monitoring the Archipelago's tourism sector.

To do this, it uses a Tourism Information System which, shared by the
Canary Islands' public administrations, integrates relevant or
influential information on the islands' tourism sector.

The primary goal of the Tourism Observatory is to obtain the necessary
and timely information for effective decision-making and the rapid
implementation of precise corrective measures.

#### More information

More detailed information about the above explanation and the indicators
can be found on the [Canary Islands Government website](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/index.html)
and on the [INSTO page](https://www.unwto.org/observatories/canary-islands-spain).
