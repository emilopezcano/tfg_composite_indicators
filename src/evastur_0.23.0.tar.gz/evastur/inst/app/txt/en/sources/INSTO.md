---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INSTO

The INSTO source constitutes the Indicators Database of INSTO
(International Network of Sustainable Tourism Observatories). It is,
therefore, a source of **Indicators**. It identifies over 500 indicators
divided into more than 40 dimensions/thematic areas, but 11 have been
identified as mandatory:

-   Tourism Seasonality

-   Employment

-   Destination Economic Benefits

-   Governance

-   Local Satisfaction

-   Energy Management

-   Water Management

-   Wastewater Management

-   Solid Waste Management

-   Accessibility

-   Climate Action

These mandatory monitoring dimensions may vary, so it is recommended to
check the [INSTO page](https://insto.unwto.org/framework/) under the
*MANDATORY ISSUE AREAS* section.

In addition to covering the eleven mandatory dimensions mentioned,
observatories are encouraged to monitor other destination-specific
thematic areas that are more relevant to their destination. Additional
destination-specific thematic areas can be adjusted over time, if
necessary, based on the destination's needs.

The publication 'Sustainable Development Indicators for Tourist
Destinations: A Practical Guide' identifies over 500 indicators.
Initiatives such as the European Tourism Indicator System (ETIS), the
work carried out by the European Environment Agency (EEA), the Global
Sustainable Tourism Council (GSTC), the International Network of
Regional Economy, Mobility and Tourism (INRouTe), and the Measurement of
Sustainable Tourism (MST) have further contributed to the update and
reflection in this area. Continuous progress is expected in indicator
work and contributions to the debate within the INSTO network and with
interested institutions to provide observatories with reliable,
consistent, and relevant methodologies and operational guidelines.

#### INSTO Observatories

INSTO is an international network of sustainable tourism observatories
that presents its indicators on the [INSTO observatories
website](https://insto.unwto.org). The indicators they present are
specific, based on the themes proposed in the [INSTO
handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

For example, among the observatories located in Spain, [the Canary
Islands
observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
has a large number of indicators to refer to.

#### More Information

    More detailed information about the above explanation and the INSTO
indicators can be found in the [INSTO
handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).
