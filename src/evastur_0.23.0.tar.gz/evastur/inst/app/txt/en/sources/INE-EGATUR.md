---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-EGATUR

The INE-EGATUR source constitutes the Data Database of EGATUR
(International Tourism Expenditure Survey). It is, therefore, a source
of **Data**.

Variables from INE-EGATUR are used to generate indicators that aim to
align with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### Register Design and Valid Variable Values

The variables used to calculate the indicators follow a record design
and valid values defined by INE in an Excel file titled [*Register
design and valid variable
values*](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&idp=1254735576863#_tabs-1254736195390).

In this file, each record represents a tourist who finishes their trip
through Spain in the reference month. The variable that uniquely
identifies each record is A0_1.

#### Indicator Calculation

Furthermore, INE also specifies the calculation to be performed to
estimate the indicators for tourism expenditure, average expenditure per
person, and average trip duration.

To estimate tourism expenditure, the 'gastototal' variable must be used,
multiplied by the expansion factor of each record ('Factor_Egatur').
Average expenditure per person will be obtained as the quotient of
tourism expenditure divided by the number of tourists, calculated by
summing the 'Factor_Egatur' variable. The estimate of overnight stays,
resulting from multiplying the 'A13' variable by 'Factor_Egatur', is
used as the denominator for average daily expenditure, with tourism
expenditure being the numerator. It is also used in the estimation of
average trip duration, by dividing the number of tourists by the
estimated overnight stays.

#### Restrictions

INE indicates a series of restrictions on the microdata files.

These restrictions are:

-   Data from January 2025 onwards is provisional.

-   Microdata files associated with April and May 2020 are not available
    because the flow of international tourists and associated tourism
    expenditure destined for Spain were zero due to border closures
    determined by the State of Alarm.

#### Methodology and Questionnaire

The methodology and questionnaire, which explain all data-related
information in greater detail, are also provided on the [INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=metodologia&idp=1254735576863).
