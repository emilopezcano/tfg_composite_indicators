---
editor_options: 
  markdown: 
    wrap: 72
---<
---

### Fuente: INE-FRONTUR

The INE-FRONTUR source constitutes the Data Database of FRONTUR (Tourist
Movements at Borders). It is, therefore, a source of **Data**.

Variables from FRONTUR are used to generate indicators that aim to align
with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Tourist Movement on Borders (Frontur) Survey

Tourist Movement on Borders (Frontur) Survey primarily aims to provide
monthly and annual estimates of the number of non-resident visitors to
Spain (tourists and excursionists), as well as the main characteristics
of their trips (mode of entry, destination, country of residence,
motive, type of organization, etc.).

This operation has been disseminating results since October 2015,
continuing the Border Tourist Movements Survey (FRONTUR) previously
conducted by Turespaña until September 2015.

#### Register Design and Valid Variable Values 

The variables used to calculate
the indicators follow a record design and valid values defined by INE in
an Excel file titled [*Register design and valid variable values*](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176996&menu=resultados&idp=1254735576863#_tabs-1254736195382).

In this file, each record represents a tourist who concludes their trip
through Spain in the reference month. The variable that uniquely
identifies each record is A0_1.

#### Indicator Calculation 

Furthermore, INE also specifies the calculation to
be performed to estimate the number of travelers indicator.

By summing the expansion factor of each record ('Factor'), an estimate
of the number of travelers is obtained, which can be disaggregated based
on the other classification variables in the file:
tourists-excursionists, main destination, country of residence, mode of
entry, and type of accommodation.

#### Restrictions 

INE indicates a series of restrictions on the microdata
files.

These restrictions are:

- Data from January 2025 onwards are provisional.

- Microdata files associated with April and May 2020 are not available
because the flow of international tourists and associated tourism
expenditure to Spain was zero due to border closures determined by the
State of Alarm.

- As of March 2022, Russia is included in the "Rest of Europe" aggregate.

- As of January 2022, Turkey is added to the "Rest of Europe" group.

- As of July 2023, microdata from October 2015 to April 2023 has been
updated, distinguishing Ceuta and Melilla according to the record
design.

#### Methodology and Questionnaire 

The methodology and questionnaire, which
explain all data-related information in greater detail, are also
provided on the [INE website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=metodologia&idp=1254735576863).

