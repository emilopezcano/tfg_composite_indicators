---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-VTE

The INE-VTE source constitutes the Data Database of VTE (Measurement of
the number of tourist dwellings in Spain and their Capacity). It is,
therefore, a source of **Data**.

Variables from VTE are used to generate indicators that aim to align
with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Measurement of the number of tourist dwellings in Spain and their capacity

The Measurement of the number of tourist dwellings in Spain and their
capacity is an experimental statistic.

The main objective of this experimental statistic is to estimate the
number of tourist dwelling accommodations available in Spain, as well as
their capacity, to respond to the growing demand for information on this
topic.

To obtain the information, the web scraping technique is used, by which
software programs extract data from the three most used tourist
accommodation platforms in Spain. From the collected accommodations, an
initial selection of tourist dwellings is made in accordance with the
regulations in force in each autonomous community. For accommodations
without a license or with an incorrectly defined license, their
inclusion or exclusion will depend on other extracted variables such as
subtype and services provided. Subsequently, deduplication algorithms
are applied to eliminate dwellings that appear on more than one
platform.

#### Technical Project

The technical project, which explains all data-related information in
greater detail, is also provided on the [INE
website](https://www.ine.es/en/experimental/viv_turistica/experimental_viv_turistica.htm?L=1).

