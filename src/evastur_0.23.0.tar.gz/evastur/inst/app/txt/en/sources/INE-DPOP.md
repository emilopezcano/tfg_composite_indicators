---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-DPOP

The INE-DPOP source comprises the Data Database of the Annual Population
Census. It is, therefore, a source of **Data**.

Variables from the Annual Population Census are used to generate
indicators that aim to align with known sustainable tourism indicator
systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### Register Design and Valid Variable Values

The variables used to calculate the indicators follow a record design
and valid values defined by INE in an Excel file titled [*Register design
and valid variable
values*](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176992&menu=resultados&idp=1254735572981#_tabs-1254736195811).

#### Notices

INE provides a series of notices regarding the microdata files.

These notices are:

-   Compressed files are provided, ready for direct processing with R,
    SAS, SPSS, STATA, and any program using TXT or CSV versions.

-   As of January 2025, time series for Andorra have been included, with
    the "Rest of Europe" category simultaneously reduced.

#### Methodology

The methodology, which explains all data-related information in greater
detail, is also provided on the [INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176992&menu=metodologia&idp=1254735572981).
