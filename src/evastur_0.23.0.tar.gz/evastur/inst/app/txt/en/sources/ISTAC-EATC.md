---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: ISTAC-EATC

The ISTAC-EATC source constitutes the Data Database of EATC (Tourism
Accommodation Surveys). It is, therefore, a source of **Data**.

Variables from EATC are used to generate indicators that aim to align
with known sustainable tourism indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Tourism Accommodation Surveys

The Tourism Accommodation Surveys are conducted by the Canary Islands
Institute of Statistics (ISTAC).

The Tourism Accommodation Surveys provide monthly indicators on
capacity, occupancy, profitability, prices, revenue, and employment for
hotels and apartments in the Canary Islands, allowing for data
comparison among the islands' tourist municipalities.

#### Methodology and Questionnaire

The methodology and questionnaire for hotels, apartments, and vacation
homes, which explain all data-related information in greater detail, are
also provided on the [ISTAC website](http://gobiernodecanarias.org/istac/estadisticas/sectorservicios/hosteleriayturismo/oferta/C00065A.html). Additionally, for hotels and
apartments, a cartographic notebook with entities and tourist centers is
provided.

