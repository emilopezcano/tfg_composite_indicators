---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-EPA

The INE-EPA source constitutes the Data Database of the EAPS
(Economically Active Population Survey). It is, therefore, a source of
**Data**.

Variables from the Economically Active Population Survey are used to
generate indicators that aim to align with known sustainable tourism
indicator systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Economically Active Population Survey (EAPS)

The Economically Active Population Survey (EAPS)
has been conducted since 1964, with the current methodology dating from
2005.

It is a continuous and quarterly investigation aimed at households,
whose main purpose is to obtain data on the labor force and its various
categories (employed, unemployed), as well as the population outside the
labor market (inactive).

The initial sample consists of approximately 55,000 households per
quarter, equivalent to approximately 130,000 people.

#### Record Design and Valid Values 

The variables used to calculate
the indicators follow a record design and valid values defined by INE in
an Excel file titled [*Register design and valid values*](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176918&menu=resultados&idp=1254735976595#_tabs-1254736030639).

#### Notices 

INE provides a series of notices regarding the microdata files.

These notices are:

- Compressed files are provided, ready for direct processing with R, SAS,
SPSS, STATA, and any program using TXT or CSV versions.

- To obtain estimates for any quarter from 2021 to 2023 with the new 2021
Census population base, the microdata file for the corresponding quarter
and the annex with 2021 base factors for that same quarter must be used.
By cross-referencing both using the identification variable, which is
NVIVI, and using the factor from the annex, FACB2021, which is the 2021
population base expansion factor, instead of using the expansion factor
from the quarterly microdata file, FACTOREL, which corresponds to the
2011 base, the desired estimates will be obtained.

- The microdata files included in this section for free download have
their variables anonymized in a standard way. If the information
contained therein is insufficient, users can request an anonymized file
with greater disaggregation in some of the variables. When such
disaggregation is possible, an economic charge will be invoiced for the
study and programming time; additionally, the relevant terms of use will
need to be signed.

#### Methodology and Questionnaire 

The methodology and questionnaire, which
explain all data-related information in greater detail, are also
provided on the [INE website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736176918&menu=metodologia&idp=1254735976595).

