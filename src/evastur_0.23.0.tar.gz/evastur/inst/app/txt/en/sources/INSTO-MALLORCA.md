---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: Mallorca

The Mallorca source comprises the Data and Indicators Database of the Mallorca
Sustainable Tourism Observatory. It is, therefore, a source of
**Data and Indicators**. They are divided into the following four dimensions:

-   Destination Management

-   Economic Value

-   Sociocultural Impact

-   Environmental Impact

#### More Information

You can find more detailed information about the above explanation and
the indicators on the [website](https://www.stomallorca.com/en/data/).
