---
editor_options: 
  markdown: 
    wrap: 72
---

### Source: INE-EOH

The INE-EOH source constitutes the Data Database of the HOS (Hotel
Occupancy Survey). It is, therefore, a source of **Data**.

Variables from the Hotel Occupancy Survey are used to generate
indicators that aim to align with known sustainable tourism indicator
systems, in this order:

1.  [SF-MST
    Indicators](https://www.unwto.org/tourism-statistics/statistical-framework-for-measuring-the-sustainability-of-tourism).

2.  [ETIS
    Indicators](https://op.europa.eu/es/publication-detail/-/publication/4b90d965-eff8-11e5-8529-01aa75ed71a1/language-es),
    which are specific.

3.  Indicators from [INSTO Observatories](https://insto.unwto.org).
    These are specific and based on the themes proposed in the INSTO
    handbook. For instance, [the Canary Islands
    Observatory](https://www.gobiernodecanarias.org/turismo/estadisticas_y_estudios/)
    offers a large number of indicators to draw from.

4.  Indicators from the [INSTO
    handbook](https://www.e-unwto.org/doi/book/10.18111/9789284407262).

#### What is the Hotel Occupancy Survey

The Hotel Occupancy Survey provides information on travelers, overnight
stays, and average length of stay, distributed by country of residence
for foreign travelers or autonomous community of origin for Spanish
travelers, as well as the category of the establishments they occupy. It
also provides estimates of the number of open establishments, beds,
occupancy rates, and employment in the sector, by establishment
category.

#### Methodology and Questionnaire

The methodology and questionnaire, which explain all data-related
information in greater detail, are also provided on the [INE
website](https://www.ine.es/dyngs/INEbase/en/operacion.htm?c=Estadistica_C&cid=1254736177015&menu=metodologia&idp=1254735576863).
Additionally, it provides the list of municipalities included in each
tourist area, sampling fractions, and linking coefficients for
methodological changes and directory improvements.

