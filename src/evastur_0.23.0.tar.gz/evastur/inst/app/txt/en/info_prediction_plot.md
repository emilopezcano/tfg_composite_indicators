Prediction Sustainable Tourism Indicator and its dimensions for the selected autonomous community or selected INSTO destination,
according to the desired scaling method. Once the prediction is obtained, an intervention can be carried out to incriment the value of the first prediction made.
It is possible to choose the number of dimensions in which this intervention is performed. 
