## Display of indicators by geographical areas

In this tab you can compare values of a given indicator or a composite indicator between different geographic areas, among them and with their group of geographic areas.

If no geographic area is selected, only the series of the configured group of geographic areas is displayed. In the geographical area selector you can select the ones you want to compare, up to a maximum of 10.

If no indicator is selected, the series of the composite indicator of the selected dimension are displayed.

In the indicator selector, the indicators of the selected dimension are displayed. 
If the global dimension is selected, then all available indicators are displayed.
available. Only one indicator should be selected in this tab.

The title of the chart shows the title of the indicator (or dimension if no indicator is selected).

The legend shows the codes of the geographical areas, and the pop-up text shows its label together with the values of the axes (year and scaled value of the indicator) when hovering the mouse over the series.

The plot shows the **scaled** indicators according to the type and methods selected. You can view the series of the original values of an indicator by clicking on any point in the series (NOTE: if you close the original series, to view it again, click on a different point than the previous one).
If a composite indicator is being viewed, a message is displayed indicating that a composite indicator does not have an original scale.
