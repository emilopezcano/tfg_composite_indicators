The tourist areas selectable for the recommendation of a system of indicators belonging to an INSTO destination are shown.
The darker colors represent the tourist areas with higher values for the variable “Number of places available”. 
Click on an area to make the desired recommendation.
