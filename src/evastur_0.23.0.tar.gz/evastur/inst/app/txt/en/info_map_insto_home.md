Map to show the observatories analyzed.
