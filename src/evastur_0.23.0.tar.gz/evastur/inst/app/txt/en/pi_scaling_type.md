Select one of the scaling types (periods, destinations). For more details, see “i”.
