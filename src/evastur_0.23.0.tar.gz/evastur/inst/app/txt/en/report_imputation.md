Amelia II is a complete R package for multiple imputation of missing data. The package draws imputations of the missing values using a novel bootstrapping approach, the EMB (expectation-maximization with bootstrapping) algorithm. The EMB algorithm combines the classic EM algorithm with a bootstrap approach to take draws from this posterior. For each draw, we bootstrap the data to simulate estimation uncertainty and then run the EM algorithm to find the mode of the posterior for the bootstrapped data, which gives us fundamental uncertainty too.

The EM algorithm iterates between an E-step (which fills in the missing data, conditional on the current model parameter estimates) and an M-step (which estimates the model parameters, conditional on the current imputations) until convergence.

The E-step computes the expected value of the complete-data log likelihood given the observed data and the current parameter estimate. This process essentially estimates the most probable values for the missing data, resulting in a temporary, complete data set.

The M-step consists of maximizing the expectation computed in the E-step over the unknown parameter vector. The M-Step takes the complete data (observed plus estimated) and finds a new set of parameters that maximizes the likelihood of observing the actual data. We then set the current parameters to the new parameters. The two steps are repeated as necessary until the sequence of the new parameters converges. Indeed under very general circumstances convergence to a local maximum can be guaranteed.

The imputation model in Amelia assumes that the complete data (that is, both observed and unobserved) are multivariate normal. Also, assumes that the data are missing at random (MAR) or the simpler special case of missing completly at random (MCAR). This assumption means that the pattern of missingness only depends on the observed data, not the unobserved data. Amelia requires both the multivariate normality and the MAR assumption (or the simpler special case of MCAR).

Amelia II also has features to make valid and more accurate imputations for cross-sectional, time-series, and time-series-cross-section data, and allows the incorporation of observation and data-matrix-cell level prior information.

Detailed information can be found at the https://www.columbia.edu/\~mh2078/MachineLearningORFE/EM_Algorithm.pdf, Honaker, J., King, G., & Blackwell, M. (2011). Amelia II: A Program for Missing Data. Journal of Statistical Software, 45(7), 1–47. https://doi.org/10.18637/jss.v045.i07 and James Honaker and Gary King. 2010. “What to Do About Missing Values in Time Series Cross-Section Data”. American Journal of Political Science, 54, 3, Pp. 561-81. http://gking.harvard.edu/files/abs/pr-abs.shtml.

Prior to imputing missing values using Amelia, a series of adjustments and changes have been made:

1.  Variables with 99.7% missing values are discarded.
2.  A logarithmic transformation is performed on variables that do not follow a normal distribution (an essential requirement for the Amelia imputation method).
3.  Instead of running the Amelia algorithm once for all variables, it is executed once per variable.
4.  For each variable, the most correlated variables are selected. Selection starts with a 70% correlation. If the number of selected variables is less than 10, the correlation percentage is reduced to 60% and subsequently to 50%. If, despite these reductions, 10 variables are not reached, the 10 most correlated variables are selected without a correlation restriction.