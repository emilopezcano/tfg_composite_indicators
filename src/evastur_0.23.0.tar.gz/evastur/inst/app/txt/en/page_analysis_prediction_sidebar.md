### Indicator Prediction and Intervention

In this tab, a prediction is made for the multidimensional sustainable tourism indicator for a specific geographic area over the upcoming periods. The number of periods can be adjusted using the selection right sidebar.

The prediction can be performed using one of the methods selectable in the settings. To obtain the prediction of the multidimensional indicator, the indicators that make up each dimension are predicted first, and then the composite indicator is calculated using the configured weights for each indicator and dimension.

A **counterfactual analysis** can then be performed as explained below:

1. **Target selection**: Using the slider in the selection bar, the absolute increase desired in the global indicator is selected. The selectable values depend on the scaling method. For example, for the z-score method, a reasonable value is 0.1. The target is graphically displayed as an orange diamond in the prediction chart.

2. **First layer**: The necessary increases in each of the dimensions to achieve the target increase in the global indicator are obtained. If the optimization model does not find a solution, an informative message is displayed below the chart. If a solution is found, the required increases for each dimension are shown. Three different icons are used for each dimension:

    1. ✅ **No action needed**: The optimization model indicates that no change is required in this dimension. An arrow (⇡) denotes the direction of the change.
    2. 🛠️ **Feasible intervention**: The dimension needs to be modified and a feasible intervention exists.
    3. ⚠️ **Not feasible**: The model suggests an intervention for this dimension, but no feasible solution exists.

3. **Second layer**: Once the first layer solution is obtained, a dynamic indicator selector is displayed. This selector is automatically populated with all indicators belonging to the dimensions identified in the first layer. Users can select or deselect indicators to specify which ones are actionable.

    * The selectable indicators update reactively whenever the first layer solution changes (e.g., if the selected dimensions change).
    * The model continuously observes the selection: as soon as an indicator is selected or deselected, the required changes are recalculated and displayed.

    Then, an intervention table is displayed with the following columns:

    * **Indicator**: Name of the indicator.
    * **Intervention (scaled)**: Required increase in the scaled indicator to reach the target.
    * **Prediction without intervention**: Prediction of the indicator according to the prediction model, in its scale.
    * **Prediction after intervention**: Prediction of the indicator after applying the obtained intervention. To obtain it, the scaled intervention is added to the scaled prediction, and the result is unscaled.
    * **Required change**: The necessary intervention in the indicator's original scale.

> **IMPORTANT**: It is possible that no feasible solution is found for some dimensions. In this case, the dimensions without a feasible solution are displayed, and it should be noted that the global target would not be achieved.
