dim_selector_buttons_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("ui_rgb_dim"))
  )
}

dim_selector_buttons_server <- function(id, i18n, .source) {
  moduleServer(
    id,
    function(input, output, session) {
      
      ## [R] available_dims - Dimensions to explore ----
      available_dims <- reactive({
        res <- tryCatch({
          get_dims(lan = i18n()$get_translation_language(),
                   source = .source(),
                   global = TRUE)
        },
        error = function(e) {
          showNotification(paste0(
            cleanHTML(i18n()$t("Error al recuperar las dimensiones disponibles. Intenta recargar el dashboard y probar de nuevo")),
            " - ",
            e),
            type = "error")}
        )
        return(res)
      })
      
      
      ## rgb_dim ----
      output$ui_rgb_dim <- renderUI({
        req(available_dims())
        dims <- available_dims()
        safe_colors <- ifelse(
          is_valid_hex(dims$dimension_color),
          dims$dimension_color,
          "var(--bs-primary)"
        )
        invalid_mask <- !is_valid_hex(dims$dimension_color)
        if (any(invalid_mask)) {
          message("Invalid hex color for dimension(s): ",
                  paste(dims$dimension_id[invalid_mask], collapse = ", "),
                  ". Falling back to primary color.")
        }

        # Generate per-button CSS: <input> is a preceding sibling of <label class="btn">,
        # so we select input[value='...'] + .btn via the adjacent sibling combinator.
        css_rules <- paste(purrr::map2_chr(
          dims$dimension_id,
          safe_colors,
          function(dim_id, color) {
            paste0(
              ".dim-radio-group input[value='", dim_id, "'] + .btn {",
              " border-color: ", color, " !important;",
              " color: ", color, " !important;",
              " background-color: transparent !important; }",
              " .dim-radio-group input[value='", dim_id, "']:checked + .btn {",
              " background-color: ", color, " !important;",
              " border-color: ", color, " !important;",
              " color: #ffffff !important; }"
            )
          }
        ), collapse = "\n")

        div(
          class = "dim-radio-group",
          tags$style(HTML(css_rules)),
          radioGroupButtons(session$ns("rgb_dim"),
                            choices = setNames(dims$dimension_id,
                                               dims$dimension_label),
                            direction = "vertical",
                            width = "100%")
        )
      })
      
      return(reactive({input$rgb_dim}))
    }
  )
}

## Module app ----

dim_selector_buttons_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  translator <- getOption("evastur.translator")
  
  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    textInput("ti_source", "Source", "EVASTUR"),
    dim_selector_buttons_ui("dimsel1"),
    verbatimTextOutput("selected")
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    res <- dim_selector_buttons_server("dimsel1", i18n, reactive({input$ti_source}))
    
    output$selected <- renderText({res()})
  }
  
  shinyApp(ui, server)
  
}

## Run app ----
# dim_selector_buttons_app()