## Database related functions

#' Connect to database
#'
#' @param cshema database schema to connect
#'
#' @return Connection object
#' @export
#'
#' @examplesIf interactive
#' connect_stdb()
connect_stdb <- function(schema = NULL) {
  DBI::dbConnect(
    RPostgres::Postgres(),
    host = "gondor.etsii.urjc.es",
    dbname = "evastur_db",
    port = 5432,
    user = "evastur",
    password = Sys.getenv("PGPWD"),
    options = ifelse(
      is.null(schema),
      "",
      paste0("-c search_path=", schema, "old_model")
    )
  )
}

#' Collect database table into data.frame
#'
#' Collects a data from the database and returns a data.frame
#'
#' If `lang` is not NULL, the data are filtered by the `language` column
#'
#' @param con Connection object
#' @param dbtable Table name in the db
#' @param lang Language
#' @param i18n Translation object
#'
#' @return A data.frame filtered according with the arguments
#' @export
#'
#' @examplesIf interactive
#' db2df(con, "ind_sources", NULL)
db2df <- function(con = con, dbtable, lang = NULL, i18n) {
  if (is.null(lang)) {
    tbl(con, dbtable) |>
      collect()
  } else {
    if (!(lang %in% i18n$get_languages())) {
      stop(
        "The language '",
        lang,
        "' is not accepted by the application. Should be one of ",
        paste(i18n$get_languages(), collapse = "|")
      )
    } else {
      tbl(con, dbtable) |>
        filter(language == lang) |>
        collect()
    }
  }
}
