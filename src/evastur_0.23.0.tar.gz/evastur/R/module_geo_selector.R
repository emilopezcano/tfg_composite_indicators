## Module UI ----
geo_selector_ui <- function(id) {
  ns <- NS(id)
  tagList(
    ## Selected area of interest (country or area within country)
    uiOutput(ns("ui_pi_geo_selected"))
  )
}

## Module Server ----
## TODO: refactor avoid two arguments (lan is in i18n)

#' Geography selection module
#'
#' This module contains one input: the geographical selection for
#' indicators computation, visualization and analysis. It depends on
#' the inputs within the `geo_level_selector` module, i.e., the
#' scope and the group of geographies. It outputs a list with the selected
#' geography id an label, and the group label.
#'
#' Description of the objects within the server function of the model.
#'
#' **Inputs:**
#'
#' * `pi_geo_selected`: Selected geography, whose choices are the
#' geographies within the group. Can be length > 1 if multi = TRUE
#'
#' **Reactive Objects:**
#'
#' * `geo_group_label`: Label of the group, given the id provided as parameter.
#' * `geo_selected_label`: Label(s) of the selected geography(ies).
#'
#'
#' @param id Module instance id
#' @param i18n Language object
#' @param lan Current language
#' @param geo_scope Geographical scope
#' @param geo_group Geographies group
#' @param nuts_level_inner Inner NUTS level for filtering geographies
#' @param geo_selected Initial selected geography when the UI is first rendered.
#' @param multi Whether the input control can accept multiple selection or not
#' @param external_selection Reactive vector of geography IDs to dynamically
#'   update the selection from external components (e.g., map clicks). Unlike
#'   `geo_selected`, this triggers updates after the component is already
#'   initialized.
#' @param maxOptions Maximum number of geos that can be selected when
#'   `multi = TRUE`. Default is 10. If `Inf`, no limit is applied.
#'
#' @returns A list with the following elements:
#' * `pi_geo_selected` Selected geography
#' * `geo_selected_label` Label of the selected geography
#' * `geo_group_label` Label of the input group
#'
#' @examplesIf interactive
#' geo_selector_app()
geo_selector_server <- function(
  id,
  i18n,
  lan,
  geo_scope,
  geo_group,
  nuts_level_inner,
  geo_selected,
  multi = FALSE,
  external_selection = reactive(NULL),
  maxOptions = 10
) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- NS(id)

      ## [R] geo_group_label ----
      # Label of the group
      geo_group_label <- reactive({
        get_geo_group_label(lan(), geo_group())
      })

      ## [R] geo_selected_label ----
      geo_selected_label <- reactive({
        req(input$pi_geo_selected)
        get_geo_label(input$pi_geo_selected, lan(), geo_group())
      })

      ## [R] dfgeos ----
      dfgeos <- reactive({
        # req(lan(), geo_scope(), geo_group())
        req(geo_group_label())
        if (geo_scope() == "N") {
          nuts_level <- 0
        } else {
          nuts_level <- NULL
          # if(geo_group() == "INSTO"){
          #   nuts_level <- 99
          # } else{
          #   nuts_level <- 101
          # }
        }
        df <- get_geos(
          .nuts_level_group = nuts_level,
          .nuts_level_inner = nuts_level_inner(),
          lan = lan(),
          group = geo_group()
        )
        if (!is.null(df)) {
          df |>
            add_row(
              geo_id = "_TOTAL_",
              geo_label = paste("Total", geo_group_label()),
              .before = 1
            )
        }
      })

      ## [O] Update from external selection ----
      observeEvent(external_selection(), {
        if (!setequal(external_selection(), input$pi_geo_selected)) {
          updatePickerInput(
            session,
            "pi_geo_selected",
            selected = external_selection()
          )
        }
      }, ignoreNULL = FALSE)

      # pi_geo_selected ----
      # Picker input selection of geographical area of the country/group of countries
      output$ui_pi_geo_selected <- renderUI({
        req(lan())
        req(geo_scope())
        req(geo_group())
        req(dfgeos())

        df_geos <- dfgeos()

        if (geo_scope() == "S") {
          .label <- i18n()$t("Países")
        } else {
          .label <- get_nuts_label(
            level = session$userData$config()$geo_nuts_id,
            lan = lan(),
            loc = get_iso2_code(geo_group())
          )
        }
        if (is.null(geo_selected())) {
          .selected <- session$userData$config()$geo_nuts_selected
        } else {
          .selected <- geo_selected()
        }

        # For multi-selection: if a specific geo is selected (not _TOTAL_),
        .maxOptions <- if (multi) maxOptions else 1
        .show_select_all <- multi && (.maxOptions >= nrow(df_geos))

        input_element <- pickerInput(
          inputId = session$ns("pi_geo_selected"),
          label = .label,
          selected = .selected,
          choices = setNames(df_geos$geo_id, df_geos$geo_label),
          choicesOpt = list(subtext = df_geos$geo_id),
          multiple = multi,
          options = pickerOptions(
            maxOptions = if (is.infinite(.maxOptions)) NULL else .maxOptions,
            actionsBox = TRUE,
            container = "body",
            dropupAuto = FALSE,
            deselectAllText = i18n()$t("Borrar"),
            selectAllText = i18n()$t("Todos"),
            title = i18n()$t("Seleccione"),
            liveSearch = TRUE,
            liveSearchNormalize = TRUE,
            liveSearchPlaceholder = i18n()$t("Buscar"),
            noneSelectedText = i18n()$t("Nada seleccionado")
          )
        )

        # JavaScript to add class to the dropdown menu to hide "select all" button
        input_js <- NULL
        if (!.show_select_all) {
          js_code <- sprintf("
            $(document).one('shiny:bound', function(event) {
              if (event.target.id === '%s') {
                setTimeout(function() {
                  var $el = $('#' + event.target.id);
                  var picker = $el.data('selectpicker');
                  if (picker && picker.$menu) {
                    picker.$menu.parent().addClass('picker-only-clear');
                  }
                }, 50);
              }
            });
          ", session$ns("pi_geo_selected"))
          
          input_js <- tags$script(HTML(js_code))
        }

        tagList(
          input_element,
          input_js
        )
      })

      return(
        list(
          pi_geo_selected = reactive({
            input$pi_geo_selected
          }),
          geo_selected_label = geo_selected_label,
          geo_group_label = geo_group_label
        )
      )
    }
  )
}

## Module App ----

#' @export
geo_selector_app <- function(.multi = FALSE) {
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)
  translator <- getOption("evastur.translator")

  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    geo_level_selector_ui("geo_level_selector1"),
    uiOutput("ui_geo_selector1"),
    h3("Output from input in app"),
    verbatimTextOutput("scope"),
    verbatimTextOutput("group"),
    verbatimTextOutput("geo_selected"),
    verbatimTextOutput("geo_selected_label")
  )
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    output$ui_geo_selector1 <- renderUI({
      req(geo_level_selector_controls$rgb_geo_scope())
      req(geo_level_selector_controls$pi_geo_group())
      geo_selector_ui("geo_selector1")
    })

    geo_level_selector_controls <- geo_level_selector_server(
      "geo_level_selector1",
      i18n = i18n,
      lan = reactive({
        input$si_lan
      })
    )
    output$scope <- renderText({
      geo_level_selector_controls$rgb_geo_scope()
    })
    output$group <- renderText({
      geo_level_selector_controls$pi_geo_group()
    })

    geo_selector_control <- geo_selector_server(
      "geo_selector1",
      i18n = i18n,
      lan = reactive({
        input$si_lan
      }),
      geo_scope = geo_level_selector_controls$rgb_geo_scope,
      geo_group = geo_level_selector_controls$pi_geo_group,
      nuts_level_inner = geo_level_selector_controls$pi_nuts,
      geo_selected = reactive({
        NULL
      }),
      multi = .multi
    )
    output$geo_selected <- renderText({
      geo_selector_control$pi_geo_selected()
    })
    output$geo_selected_label <- renderText({
      c(
        geo_selector_control$geo_selected_label(),
        " - ",
        names(geo_selector_control$geo_selected_label())
      )
    })
  }
  shinyApp(ui, server, options = list(port = 3801))
}
