## Module for representing indicator values in a geomap

## Module UI ----
indicator_geomap_ui <- function(id) {
  ns <- NS(id)
  leafletOutput(ns("map_indicator"))
}

## Module server ----
indicator_geomap_server <- function(id, i18n, .data, bins, signif, legend_text, legend_prefix = "STI", initial_clicked = NULL) {
  moduleServer(
    id,
    function(input, output, session) {
      clicked_elements <- reactiveVal(character(0))

      # Sync initial_clicked changes to clicked_elements
      observe({
        if (!is.null(initial_clicked)) {
          clicked_elements(initial_clicked())
        }
      })

      output$map_indicator <- renderLeaflet({
        req(nrow(.data()) > 0)

        primary_color <- get_theme_color(
          session = session,
          bs_variable = "primary"
        )

        ## bounds ----
        bounds <- as.numeric(st_bbox(.data()))
        if (all(abs(bounds[c(1, 3)]) > 179)) {
          zoom1 <- 1
        } else {
          zoom1 <- NULL
        }
        ## Labels for polygons ----
        labels <- sprintf(
          "<strong>%s</strong>",
          .data()$geo_label
        ) |>
          lapply(htmltools::HTML)
        
        ## Render map ----
        m <- .data() |>
          leaflet() |>
          addProviderTiles(
            provider = providers$CartoDB.VoyagerLabelsUnder,
            options = list(noWrap = TRUE, minZoom = zoom1)
          ) |>
          addPolygons(
            layerId = ~geo_id,
            fillColor = primary_color,
            weight = 1,
            opacity = 1,
            color = "white",
            dashArray = "3",
            fillOpacity = 0.7,
            highlightOptions = highlightOptions(
              weight = 2,
              color = adjust_color(
                color = primary_color,
                color_type = "hex",
                factor = -0.4
              ),
              dashArray = "",
              fillOpacity = 0.7
            ),
            label = labels
          )
        
        # Explicitly add polygons during the first render
        m <- m |>
          map_add_polygons(
            data = .data(),
            selected_ids = clicked_elements(),
            hex_color = get_complementary_color(primary_color),
            factor = NULL
          )

        if (all(abs(bounds[c(1, 3)]) > 179)) {
          m |> fitBounds(bounds[1], bounds[2], bounds[3], bounds[4])
        } else {
          m |> flyToBounds(bounds[1], bounds[2], bounds[3], bounds[4])
        }
      })
      
      # Handle click events - manage clicked countries list
      observeEvent(input$map_indicator_shape_click$id, {
        geo_id <- input$map_indicator_shape_click$id
        current <- clicked_elements()
        if (geo_id %in% current) {
          clicked_elements(setdiff(current, geo_id))
        } else {
          clicked_elements(c(current, geo_id))
        }
      })

      # Update map highlighting based on clicked countries list
      observeEvent(
        clicked_elements(),
        {
          # We ignore the very first run of this observer to prevent
          # it from competing with the initial renderLeaflet
          req(input$map_indicator_shape_click, cancelOutput = FALSE)

          primary_color <- get_theme_color(
            session = session,
            bs_variable = "primary"
          )

          leafletProxy("map_indicator") |>
            clearGroup("selected") |>
            map_add_polygons(
              data = .data(),
              selected_ids = clicked_elements(),
              hex_color = get_complementary_color(primary_color),
              factor = NULL
            )
        },
        ignoreInit = TRUE
      )
      
      return(clicked_elements)
    }
  )
}

## Module app ----


## Data processing functions ----

#' Process STI data for map visualization
process_sti_data <- function(input, geo_level_selector_controls, dimension_control, nuts_level, inds, country_location, country_groups) {
  ## reqs 
  req(input$si_source)
  req(geo_level_selector_controls$rgb_geo_scope())
  req(geo_level_selector_controls$pi_geo_group())
  req(nuts_level())
  req(country_groups())
  if(geo_level_selector_controls$rgb_geo_scope() == "S" & geo_level_selector_controls$pi_geo_group() != "INSTO"){
    req(any(geo_level_selector_controls$pi_geo_group() == country_groups()))
  }
  
  dfind <- get_ft_data(
    data_type = "indicator",
    .nuts_level = nuts_level(),
    type_id = inds(),
    country = country_location(),
    .source_id = input$si_source,
    from_date = "2013-01-01",
    to_date = "2021-12-31"
  )
  
  suppressMessages({
    tindicators <- get_transformed_indicators(
      dfind,
      scaling_method = "zscore",
      scaling_type = "time",
      refvalueq = NULL,
      geo_total = geo_level_selector_controls$pi_geo_group()
    )
  })
  
  # Compute composite indicators
  if(geo_level_selector_controls$pi_geo_group() == "INSTO"){
    source <- "INSTO"
  } else {
    source <- input$si_source
  }
  
  tindicators |> compute_composite_indicator(selected_source = source)
}

#' Process indicator count data for map visualization
process_indicator_count_data <- function(input, geo_level_selector_controls, dimension_control, nuts_level, inds, country_location, country_groups) {
  ## reqs 
  req(input$si_source)
  req(geo_level_selector_controls$rgb_geo_scope())
  req(geo_level_selector_controls$pi_geo_group())
  req(nuts_level())
  req(country_groups())
  req(dimension_control$pi_dimension())
  if(geo_level_selector_controls$rgb_geo_scope() == "S" & geo_level_selector_controls$pi_geo_group() != "INSTO"){
    req(any(geo_level_selector_controls$pi_geo_group() == country_groups()))
  }
  
  dfind <- get_ft_data(
    data_type = "indicator",
    .nuts_level = nuts_level(),
    type_id = inds(),
    country = country_location(),
    .source_id = input$si_source,
    from_date = "2013-01-01",
    to_date = "2021-12-31"
  )
  
  get_indicators_count(
    dfind,
    geo_total = geo_level_selector_controls$pi_geo_group(),
    .dimension = dimension_control$pi_dimension()
  ) 
}

## Base app function ----
base_indicator_geomap_app <- function(data_processor, legend_prefix = "STI") {
  library(shiny)
  library(shinyWidgets)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(leaflet)
  
  translator <- getOption("evastur.translator")
  
  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    selectInput("si_source", "Source", c("EVASTUR", "INSTO")),
    geo_level_selector_ui("geo_level_selector1"),
    uiOutput("ui_geo_selector1"),
    dimension_selector_ui("dimension_selector"),
    custom_groups_selector_ui("custom_groups_selector"),
    indicator_geomap_ui("map1"),
    br(),
    clicked_areas_manager_ui("manager1"),
    reactableOutput("rt_mapdata")
  )
  
  server <- function(input, output, session) {
    session$userData$config <- reactiveVal(list(
      geo_scope = "S",
      geo_group_id = "EU28",
      geo_nuts_id = 101
    ))

    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    ## ui_geo_selector1 ----
    output$ui_geo_selector1 <- renderUI({
      req(geo_level_selector_controls$rgb_geo_scope())
      req(geo_level_selector_controls$pi_geo_group())
      geo_selector_ui("geo_selector1")
    })
    
    ## [M] geo_level_selector_controls ----
    geo_level_selector_controls <- geo_level_selector_server(
      "geo_level_selector1", 
      i18n = i18n, 
      lan = reactive({input$si_lan})
    )
    
    ## [M] geo_selector_control ----
    geo_selector_control <- geo_selector_server(
      "geo_selector1",
      i18n = i18n,
      lan = reactive({input$si_lan}),
      geo_scope = geo_level_selector_controls$rgb_geo_scope,
      geo_group = geo_level_selector_controls$pi_geo_group,
      nuts_level_inner = geo_level_selector_controls$pi_nuts,
      geo_selected = reactive({NULL})
    )
    
    ## [M] dimension_selector ----
    dimension_selector_control <- dimension_selector_server(
      "dimension_selector", 
      i18n = i18n, 
      lan = reactive({input$si_lan}),
      .source_id = reactive({input$si_source})
    )

    ## [M] custom_groups_selector ----
    custom_groups_selector_control <- custom_groups_selector_server(
      "custom_groups_selector",
      i18n = i18n,
      lan = reactive({input$si_lan})
    )
    
    ### [R] Nuts level depending on selection
    nuts_level <- reactive({
      req(geo_level_selector_controls$rgb_geo_scope())
      req(geo_level_selector_controls$pi_geo_group())
      if (geo_level_selector_controls$rgb_geo_scope() == "N"){
        .nuts_level <- geo_level_selector_controls$pi_nuts()
      } else {
        if (geo_level_selector_controls$pi_geo_group() == "INSTO"){
          .nuts_level <- 99
        } else {
          .nuts_level <- 0
        }
      }
    })
    
    ### [R] inds - Active indicators ----
    inds <- reactive({tbl(con2, "dt_indicators") |> 
        filter(indicator_active == TRUE) |> 
        pull(indicator_id)
    })
    
    ## [R] country_location ---- 
    country_location <- reactive({
      if(geo_level_selector_controls$rgb_geo_scope() == "N"){
        con2 |> 
          tbl("dt_geo") |> 
          filter(geo_id == geo_level_selector_controls$pi_geo_group()) |> 
          pull(iso2_code)
      } else{
        NULL
      }
    })
    
    ## [R] country_groups
    country_groups <- reactive({
      con2 |>
        tbl("bt_geo_group") |>
        distinct(geo_group_id) |>
        pull(geo_group_id)
    })
    
    ### [R] processed_data - processed indicators data ----
    processed_data <- reactive({
      data_processor(input, geo_level_selector_controls, dimension_selector_control, 
                    nuts_level, inds, country_location, country_groups)
    })
    
    ## [R] dmap Map data ----
    dmap <- reactive({
      req(processed_data())
      req(nrow(processed_data()) > 0)
      processed_data() |> 
        get_map_data(.date = "2022-01-01",
                      lan = input$si_lan,
                      type_id = dimension_selector_control$pi_dimension())
    })
    
    ## [M] indicator_geomap ---- 
    clicked_elements <- indicator_geomap_server("map1", i18n, .data = dmap,
                                          bins = reactive({getOption("evastur.map_bins")}),
                                          signif = reactive({getOption("evastur.signif")}),
                                          legend_text = dimension_selector_control$dimension_label,
                                          legend_prefix = legend_prefix)
    
    ## [M] clicked_areas_manager ----
    clicked_areas_result <- clicked_areas_manager_server("manager1", i18n, clicked_elements, dmap,
                                                         custom_groups_selector_control,
                                                         geo_level_selector_controls$pi_geo_group,
                                                         geo_selector_control$geo_group_label)
    
    ## rt_mapdata ----
    output$rt_mapdata <- renderReactable({
      dmap() |> reactable(language = get_rt_lang(input$si_lan))
    })
  }
  
  shinyApp(ui, server, options = list(port = 3800))
}

## App functions ----
indicator_geomap_app <- function() { base_indicator_geomap_app(process_sti_data, "STI") }
n_indicator_geomap_app <- function() { base_indicator_geomap_app(process_indicator_count_data, "Number Indicators") }

## Run apps ----
## COMMENT WHEN BUILDING OR LOADING
# indicator_geomap_app()    # STI values on map
# n_indicator_geomap_app()  # Indicator counts on map
