#' Server-side app code
#'
#' Internal function, called within app_run()
#'
#' @param input shiny input object
#' @param output shiny output object
#' @param session shiny session object
#'
#' @return a server object. Used as the server argument in a coll to shiny::shinyApp()
#' @export
#' @seealso [app_ui()]
#'
#' @examplesIf interactive()
#' library(bslib)
#' library(leaflet)
#' library(map)
#' library(plotly)
#' library(gt)
#' library(dplyr)
#' shiny::shinyApp(app_ui(), app_server)
app_server <- function(input, output, session) {
  # Configuration ----

  ## Set config ----
  ### Set default config ----
  session$userData$profile <- reactiveVal("default")
  session$userData$config <- reactiveVal(NULL)
  session$userData$config_theme <- reactiveVal(NULL)

  ### Ask for 'profile' param from url when loading the app ----
  session$sendCustomMessage(
    "readQueryString",
    list(param = "profile", inputId = "profile_param")
  )

  ### Update profile from querystring ----
  observeEvent(input$profile_param, {
    if (!is.null(input$profile_param)) {
      session$userData$profile(input$profile_param)
    }
  })

  ### Update config and save initial values ----
  observe({
    profile <- session$userData$profile()
    config <- get_app_config(profile)
    session$userData$config_db <- reactiveVal(config)
    session$userData$config(config)

    if (!is.null(config$theme_id)) {
      theme_config <- get_theme_config(config$theme_id)
      session$userData$config_theme(theme_config)
    }
  })

  ### txtprofile ----
  ## prints only when debugging
  output$txtprofile <- renderPrint({
    qs <- getQueryString()$debug
    req(qs)
    if (qs == 1) {
      print("session$userData$profile():")
      print(session$userData$profile())
      print("getQueryString():")
      print(getQueryString())
      print("as.list(session$userData$config()):")
      print(as.list(session$userData$config()))
    }
  })

  output$app_title <- renderText({
    session$userData$config()$app_title
  })

  output$ui_logo <- renderUI({
    cfg <- session$userData$config_theme()

    # Fallback
    logo_fallback <- "www/img/logoDephimatica.png"

    tryCatch(
      {
        logo_svg <- cfg$logo_svg[1]
        logo_bin_list <- cfg$logo_bin[[1]]

        if (!is.na(logo_svg)) {
          return(HTML(logo_svg))
        }

        if (is.raw(logo_bin_list)) {
          logo_base64 <- base64enc::base64encode(logo_bin_list)
          return(tags$img(
            src = paste0("data:image/png;base64,", logo_base64),
            class = "logo"
          ))
        }

        tags$img(src = logo_fallback, class = "logo")
      },
      error = function(e) {
        warning("Error loading logo: ", e$message, call. = FALSE)
        tags$img(src = logo_fallback, class = "logo")
      },
      warning = function(w) {
        warning("Warning loading logo: ", w$message, call. = FALSE)
        tags$img(src = logo_fallback, class = "logo")
      }
    )
  })
  ## Language & location ----

  ### Update lan in config ----
  observeEvent(input$pi_language, {
    session$userData$config(
      mutate(session$userData$config(), lang = input$pi_language)
    )
  })

  ### Initialize i18n object ----
  i18n <- getOption("evastur.translator")

  ### [R] Reactive i18n object ----
  i18n_r <- reactive({
    selected <- session$userData$config()$lang
    if (length(selected) > 0 && selected %in% i18n$get_languages()) {
      updatePickerInput(
        inputId = "pi_language",
        selected = session$userData$config()$lang
      )
      i18n$set_translation_language(selected)
    }
    i18n
  })

  ## [E] Update language from input ----
  observeEvent(input$pi_language, {
    shiny.i18n::update_lang(input$pi_language, session)
    i18n_r()$set_translation_language(input$pi_language)
  })

  # Modules ----
  ## [M] ui_geo_selector ----
  output$ui_geo_selector1 <- renderUI({
    req(session$userData$config())
    geo_selector_ui("geo_selector1")
  })

  ## [M] geo_selector_control ----
  geo_selector_control <- geo_selector_server(
    "geo_selector1",
    i18n = i18n_r,
    lan = reactive({
      input$pi_language
    }),
    geo_scope = reactive({
      session$userData$config()$geo_scope
    }),
    geo_group = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    nuts_level_inner = reactive({
      session$userData$config()$geo_nuts_id
    }),
    ## TODO: check if not needed arguments anymore, take from session object inside
    geo_selected = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_nuts_selected
      } else {
        session$userData$config()$geo_country_selected
      }
    })
  )

  ## [M] geo_selector_control2 ----
  ## For visualization, multiple
  geo_selector_control_multi <- geo_selector_server(
    "geo_selector2",
    i18n = i18n_r,
    lan = reactive({
      input$pi_language
    }),
    geo_scope = reactive({
      session$userData$config()$geo_scope
    }),
    geo_group = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    nuts_level_inner = reactive({
      session$userData$config()$geo_nuts_id
    }),
    geo_selected = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_nuts_selected
      } else {
        session$userData$config()$geo_country_selected
      }
    }),
    multi = TRUE
  )

  ## [M] custom_groups_selector ----
  custom_groups_selector_control <- custom_groups_selector_server(
    "custom_groups_selector",
    i18n = i18n_r,
    lan = reactive({
      input$pi_language
    }),
    last_modified = saved_custom_area$last_modified
  )

  ## [M] geo_level_selector ----
  geo_level_selector_controls <- geo_level_selector_server(
    "geo_level_selector_config",
    i18n = i18n_r,
    lan = reactive({
      input$pi_language
    }),
    last_modified = saved_custom_area$last_modified,
    vertical = TRUE
  )

  ## [M] dimension_selector -----
  dimension_selector_control <- dimension_selector_server(
    "dimension_selector_sidebar",
    i18n = i18n_r,
    lan = reactive({
      input$pi_language
    }),
    ## TODO: check if not needed arguments anymore, take from session object inside
    .source_id = reactive({
      session$userData$config()$source
    })
  )

  ## [M] dimension_selector buttons -----
  dim_selected <- dim_selector_buttons_server(
    "dimsel1",
    i18n_r,
    ## TODO: check if not needed arguments anymore, take from session object inside
    reactive({
      session$userData$config()$source
    })
  )

  ## [M] indicators_selector -----
  indicator_selector_output <- indicator_selector_server(
    "indicator_selector1",
    i18n = i18n_r,
    .source_id = reactive({
      session$userData$config()$source
    }),
    .dimension_id = dimension_selector_control$pi_dimension,
    multi = reactive({
      input$tabs_visualization2 == "tab_visualization_ind"
    }),
    only_inds = reactive({
      scaled_indicators() |>
        distinct(indicator_id) |>
        pull()
    })
  )

  ## [M] indicator_map  ----
  indicator_map <- indicator_map_server(
    "map1",
    i18n_r,
    .data = dmap_home,
    bins = reactive({
      session$userData$config()$map_bins
    }),
    signif = reactive({
      session$userData$config()$signif
    }),
    legend_text = dimension_selector_control$dimension_label
  )

  ## [O] Switch to selection tab when map is clicked ----
  observeEvent(
    list(
      session$userData$config()$geo_nuts_selected,
      session$userData$config()$geo_country_selected
    ),
    {
      # Switch to selection tab in right sidebar when geo selection changes from map
      bslib::nav_select(
        id = "tabs_sidebar",
        selected = "tab_selection",
        session = session
      )
    },
    ignoreInit = TRUE
  )

  ### [M] geo_map exploration - number indicators map ---
  # TODO: refactor this
  indicator_map_server(
    "geo_map",
    i18n_r,
    .data = dmap_exploration,
    bins = reactive({
      session$userData$config()$map_bins
    }),
    signif = reactive({
      session$userData$config()$signif
    }),
    legend_text = dimension_selector_control$dimension_label,
    legend_prefix = "Number indicators",
    enable_click = FALSE
  )

  ### [R] validated_geo_selection - ensures selected geo_ids exist in map data ----
  validated_geo_selection <- reactive({
    req(dmap_is_management())
    selected <- geo_selector_control_multi_controls$pi_geo_selected() %||%
      character(0)

    # If _TOTAL_ is selected, return all available geo_ids
    if ("_TOTAL_" %in% selected) {
      return(dmap_is_management()$geo_id)
    }

    # Only return geo_ids that exist in current map data
    available_ids <- dmap_is_management()$geo_id
    intersect(selected, available_ids)
  })

  ### [M] geo_map is_management - number indicators map ----
  # TODO: refactor this
  clicked_elements <- indicator_geomap_server(
    "geo_map_2",
    i18n_r,
    .data = dmap_is_management,
    bins = reactive({
      session$userData$config()$map_bins
    }),
    signif = reactive({
      session$userData$config()$signif
    }),
    legend_text = dimension_selector_control$dimension_label,
    legend_prefix = "Number indicators",
    initial_clicked = validated_geo_selection
  )

  ### [M] geo_area_manager - clicked areas management ----
  clicked_areas_result <- clicked_areas_manager_server(
    "geo_area_manager",
    i18n_r,
    clicked_elements,
    dmap_is_management,
    custom_groups_selector_control,
    reactive({
      custom_groups_selector_control$pi_custom_groups()
    }),
    reactive({
      req(custom_groups_selector_control$pi_custom_groups())
      get_geo_group_label(
        input$pi_language,
        custom_groups_selector_control$pi_custom_groups()
      )
    })
  )

  ### [M] indicator_series indicator_series Indicators Series ----
  indicator_series <- indicator_series_server(
    "series1",
    i18n_r,
    .data = dseries_home,
    signif = reactive({
      session$userData$config()$signif
    })
  )

  ## [M] mgt_var_server Variables management ----
  var_result <- mgt_var_server(
    "mgtvar1",
    i18n = i18n_r,
    .source = reactive(session$userData$config()$source),
    dim_selected,
    m_onlycustom,
    selected_custom_var = reactive(input$pi_custom_variables)
  )

  ## [O] ui_pi_custom_variables ----
  output$ui_pi_custom_variables <- renderUI({
    var_result$last_modified()
    lan <- i18n_r()$get_translation_language()
    vars_df <- tryCatch({
      con2 |>
        tbl("dt_variables") |>
        filter(variable_id %like% "VCUS%") |>
        inner_join(
          tbl(con2, "lt_variables") |> filter(variable_lang == lan),
          by = "variable_id"
        ) |>
        select(variable_id, variable_label) |>
        collect() |>
        add_row(
          variable_id = "_NONE_",
          variable_label = i18n_r()$t("Nada seleccionado"),
          .before = 1
        )
    }, error = function(e) NULL)
    req(!is.null(vars_df))
    pickerInput(
      inputId = "pi_custom_variables",
      label = i18n_r()$t("Variables personalizadas"),
      choices = setNames(vars_df$variable_id, vars_df$variable_label),
      selected = isolate(input$pi_custom_variables) %||% "_NONE_",
      options = pickerOptions(container = "body", dropupAuto = FALSE)
    )
  })

  ## [M] mgt_ind_server Indicators management ----
  ind_result <- mgt_ind_server(
    "mgtind1",
    i18n = i18n_r,
    .source = reactive(session$userData$config()$source),
    dim_selected,
    m_onlycustom,
    selected_custom_ind = reactive(input$pi_custom_indicators)
  )

  ## [O] ui_pi_custom_indicators ----
  output$ui_pi_custom_indicators <- renderUI({
    ind_result$last_modified()
    lan <- i18n_r()$get_translation_language()
    inds_df <- tryCatch({
      con2 |>
        tbl("dt_indicators") |>
        filter(indicator_id %like% "ICUS%") |>
        inner_join(
          tbl(con2, "lt_indicators") |> filter(indicator_lang == lan),
          by = "indicator_id"
        ) |>
        select(indicator_id, indicator_label) |>
        collect() |>
        add_row(
          indicator_id = "_NONE_",
          indicator_label = i18n_r()$t("Nada seleccionado"),
          .before = 1
        )
    }, error = function(e) NULL)
    req(!is.null(inds_df))
    pickerInput(
      inputId = "pi_custom_indicators",
      label = i18n_r()$t("Indicadores personalizados"),
      choices = setNames(inds_df$indicator_id, inds_df$indicator_label),
      selected = isolate(input$pi_custom_indicators) %||% "_NONE_",
      options = pickerOptions(container = "body", dropupAuto = FALSE)
    )
  })

  ## [M] mgd_dim_server Dimensions management ----
  mgt_dim_server(
    "mgtdim1",
    i18n = i18n_r,
    .source = reactive(session$userData$config()$source)
  )

  ### [M] mgt_geo_server Geographic groups management ----
  saved_custom_area <- mgt_geo_server(
    "mgtgeo1",
    i18n = i18n_r,
    m_onlycustom,
    selected_custom_area = custom_groups_selector_control$pi_custom_groups
  )

  ### [M] mgt_load_server Load data management ----
  mgt_load_res <- mgt_load_server("mgtload1", i18n = i18n_r)

  ## [M] mgt_update_server Load update data ----
  mgt_update_server(id = "mgt_update", i18n = i18n_r, con = con2)

  ## [M] onlycustom  ----
  m_onlycustom <- onlycustom_server("onlycustom1", i18n = i18n_r)

  ## [M] exp_sources ----
  exp_sources_server("sources1", i18n = i18n_r)

  ## [M] exp_indicators ----
  exp_indicators_server("expind1", i18n_r)

  ## [M] variables_plots ----
  variables_plots_server(
    "variables_plots1",
    .data = dfvar,
    .geo = geo_selector_control$pi_geo_selected,
    .date = reactive({
      paste0(input$pi_year, "-01-01")
    }),
    i18n = i18n_r,
    geolabel = geo_selector_control$geo_selected_label,
    varlabel = reactive({
      input$btn_var_plot
    })
  )

  ## [M] indicators_plots ----
  indicators_plots_server(
    "indicators_plots1",
    .data = dfind,
    .geo = geo_selector_control$pi_geo_selected,
    .date = reactive({
      paste0(input$pi_year, "-01-01")
    }),
    i18n = i18n_r,
    geolabel = geo_selector_control$geo_selected_label,
    indlabel = reactive({
      input$btn_ind_plot
    })
  )

  ## [M] documentation (ind) ----
  documentation_server(
    "docind",
    i18n = i18n_r,
    lan = reactive(input$pi_language),
    data_type = "indicator",
    type_id = reactive(input$btn_ind_doc),
    scope = reactive({
      session$userData$config()$geo_scope
    }),
    group = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    from_date = reactive({
      paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      )
    }),
    to_date = reactive({
      paste0(
        session$userData$config()$last_period,
        "-12-31"
      )
    }),
    ## TODO: check if the arguments group and group_label can be removed and use directly the session object within the module
    group_label = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    nuts_id = reactive({
      session$userData$config()$geo_nuts_id
    })
  )
  ## [M] documentation (var) ----
  documentation_server(
    "docvar",
    i18n = i18n_r,
    lan = reactive(input$pi_language),
    data_type = "variable",
    type_id = reactive(input$btn_var_doc),
    scope = reactive({
      session$userData$config()$geo_scope
    }),
    group = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    from_date = reactive({
      paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      )
    }),
    to_date = reactive({
      paste0(
        session$userData$config()$last_period,
        "-12-31"
      )
    }),
    group_label = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    nuts_id = reactive({
      session$userData$config()$geo_nuts_id
    })
  )

  ### [M] indicator_viz (ind) ----
  indicator_viz_ind <- indicator_viz_plot_server(
    "viz_ind",
    i18n_r,
    .data = scaled_indicators,
    signif = session$userData$config()$signif,
    comp_type = "within",
    dim = dimension_selector_control$pi_dimension,
    ind = indicator_selector_output$pi_indicator,
    geo = geo_selector_control$pi_geo_selected,
    geo_total = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    .source = reactive({
      session$userData$config()$source
    }),
    year = reactive({
      input$pi_year
    }),
    dimlabel = dimension_selector_control$dimension_label,
    indlabel = indicator_selector_output$indicator_name,
    geolabel = geo_selector_control$geo_selected_label,
    geo_totallabel = geo_selector_control$geo_group_label
  )

  ## [R] geo_multi ----
  # Needed to select total when no country is selected
  geo_multi <- reactive({
    if (is.null(geo_selector_control_multi$pi_geo_selected())) {
      res <- "_TOTAL_"
    } else {
      res <- geo_selector_control_multi$pi_geo_selected()
    }
    return(res)
  })
  ## [R] geolabel_multi ----
  # Needed to select total when no country is selected
  geolabel_multi <- reactive({
    geo_selector_control_multi$geo_selected_label()
  })

  ## [M] indicator_viz (geo) ----
  indicator_viz <- indicator_viz_plot_server(
    "viz_geo",
    i18n_r,
    .data = scaled_indicators,
    signif = session$userData$config()$signif,
    comp_type = "between",
    dim = dimension_selector_control$pi_dimension,
    ind = indicator_selector_output$pi_indicator,
    geo = geo_multi,
    geo_total = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    .source = reactive({
      session$userData$config()$source
    }),
    year = reactive({
      input$pi_year
    }),
    dimlabel = dimension_selector_control$dimension_label,
    indlabel = indicator_selector_output$indicator_name,
    geolabel = geolabel_multi,
    geo_totallabel = geo_selector_control$geo_group_label
  )

  ## [M] documentation sources ----
  documentation_server(
    "docsource",
    i18n = i18n_r,
    lan = reactive(input$pi_language),
    data_type = "source",
    type_id = reactive(input$btn_source_doc),
    ## TODO: check if the argument can be removed and use directly the session object within the module
    scope = reactive({
      session$userData$config()$geo_scope
    }),
    group = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    from_date = reactive({
      paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      )
    }),
    to_date = reactive({
      paste0(
        session$userData$config()$last_period,
        "-12-31"
      )
    }),
    group_label = reactive({
      if (session$userData$config()$geo_scope == "N") {
        session$userData$config()$geo_country_id
      } else {
        session$userData$config()$geo_group_id
      }
    }),
    nuts_id = reactive({
      session$userData$config()$geo_nuts_id
    })
  )

  ## [M] prediction_horizon ----
  prediction_horizon <- prediction_horizon_server(
    "prediction_horizon1",
    i18n = i18n_r,
    .data = predicted_indicators,
    scaling_method = reactive({
      session$userData$config()$scaling_method
    })
  )

  ## [M] interventions_controls ----
  intervention_controls <- intervention_controls_server(
    "intervention_controls1",
    i18n = i18n_r,
    .datanpred = composite_indicators,
    .datapred = predicted_indicators,
    .dataind = scaled_indicators,
    source = reactive({
      session$userData$config()$source
    }),
    .epsilon = prediction_horizon$slider_epsilon_intervention,
    geo = geo_selector_control$pi_geo_selected,
    .scaling_method = reactive({
      session$userData$config()$scaling_method
    })
  )

  ## [M] config1 ----
  config_server(
    "config1",
    i18n_r,
    profile = session$userData$profile
  )

  ## [M] home_pdf_download ----
  pdf_download_server(
    id = "home_pdf_download",
    rmd_template = "home_page.rmd",
    params = reactive({
      df <- composite_indicators()
      if (dimension_selector_control$pi_dimension() == "GLOBAL") {
        .global <- TRUE
        .dimension_id <- NULL
      } else {
        .global <- FALSE
        .dimension_id <- dimension_selector_control$pi_dimension()
      }
      if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
        .total <- TRUE
        .geo_id <- NULL
      } else {
        .total <- FALSE
        .geo_id <- geo_selector_control$pi_geo_selected()
      }

      list(
        map_primary_color = get_theme_color(
          session = session,
          bs_variable = "primary"
        ),

        map_params = list(
          data = dmap_home(),
          bins = session$userData$config()$map_bins,
          signif = session$userData$config()$signif,
          legend_text = dimension_selector_control$dimension_label(),
          map_indicator_shape_click_id = geo_selector_control$geo_selected(),
          year = input$pi_year,
          geo_group_label = geo_selector_control$geo_group_label()
        ),

        series_params = list(
          data = dseries_home(),
          signif = session$userData$config()$signif
        ),

        vbs_params = list(
          kpi_trend = round(
            kpi_trend(
              df,
              .total = .total,
              .global = .global,
              .geo_id = .geo_id,
              .dimension_id = .dimension_id
            ),
            2
          ),
          kpi_last = round(
            kpi_last(
              df,
              .total = .total,
              .global = .global,
              .geo_id = .geo_id,
              .dimension_id = .dimension_id
            ),
            2
          ),
          kpi_dist = round(
            kpi_dist(
              df,
              .total = .total,
              .global = .global,
              .geo_id = .geo_id,
              .dimension_id = .dimension_id
            ),
            2
          ),
          kpi_rank = kpi_rank(
            df,
            .total = .total,
            .global = .global,
            .geo_id = .geo_id,
            .dimension_id = .dimension_id
          ),
          kpi_rank_total = df |>
            filter(
              total == .total,
              global == .global,
              {
                if (!.total & !is.null(.geo_id)) {
                  geo_id == .geo_id
                } else {
                  TRUE
                }
              },
              {
                if (!.global & !is.null(.dimension_id)) {
                  dimension_id == .dimension_id
                } else {
                  TRUE
                }
              }
            ) |>
            arrange(date) |>
            slice_tail(n = 1) |>
            pull(date) |>
            (\(d) {
              df |>
                filter(date == d, total == .total, global == .global) |>
                nrow()
            })(),
          scaling_method = attr(df, "scaling_method"),
          dimension_label = dimension_selector_control$dimension_label(),
          geo_label = geo_selector_control$geo_selected_label(),
          last_year = max(year(as.Date(df$date)), na.rm = TRUE)
        ),

        app_title = session$userData$config()$app_title,
        header_color = get_theme_color(
          session = session,
          bs_variable = "primary"
        ),
        logo_path = prepare_logo_for_pdf(session)
      )
    }),
    filename_prefix = "evastur_home_report",
    i18n = i18n_r,
    output_format = "pdf_document"
  )

  ## [M] imputation_pdf_download ----
  pdf_download_server(
    id = "imputation_pdf_download",
    rmd_template = "imputation_report.rmd",
    params = reactive({
      list(
        imputation_params = list(
          data = imputation_data()
        ),
        app_title = session$userData$config()$app_title,
        header_color = get_theme_color(
          session = session,
          bs_variable = "primary"
        ),
        logo_path = prepare_logo_for_pdf(session),
        all_years = input$cb_imputation_all_years,
        geo_area = geo_selector_control$geo_selected_label(),
        geo_group = geo_selector_control$geo_group_label(),
        dimension = dimension_selector_control$dimension_label(),
        flags_explanation = imputation_flags_explanation(),
        imputation_names = imputation_names()
      )
    }),
    filename_prefix = "evastur_imputation_report",
    i18n = i18n_r,
    output_format = "pdf_document"
  )

  ## [M] "analysis_pdf_download ----
  pdf_download_server(
    id = "analysis_pdf_download",
    rmd_template = "analysis_page.rmd",
    params = reactive({
      list(
        plot_background_color = get_theme_color(
          session = session,
          bs_variable = "light"
        ),

        prediction_params = list(
          data = tryCatch(
            {
              if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
                get_series_data(
                  predicted_indicators()$dim,
                  total = TRUE,
                  .geo_id = NULL,
                  lan = input$pi_language,
                  source = session$userData$config()$source
                )
              } else {
                get_series_data(
                  predicted_indicators()$dim,
                  total = FALSE,
                  .geo_id = geo_selector_control$pi_geo_selected(),
                  lan = input$pi_language,
                  source = session$userData$config()$source
                )
              }
            },
            error = function(e) NULL
          ),
          historical_data = tryCatch(
            {
              dseries_home()
            },
            error = function(e) NULL
          ),
          target = tryCatch(
            {
              prediction_horizon$slider_epsilon_intervention()
            },
            error = function(e) NULL
          ),
          signif = session$userData$config()$signif
        ),
        intervention_params = list(
          data = tryCatch(
            {
              intervention_controls$res_intervention_step2()
            },
            error = function(e) NULL
          ),
          signif = session$userData$config()$signif,
          summary = tryCatch(
            {
              intervention_controls$res_intervention_step1()
            },
            error = function(e) NULL
          )
        ),

        app_title = session$userData$config()$app_title,
        header_color = get_theme_color(
          session = session,
          bs_variable = "primary"
        ),
        logo_path = prepare_logo_for_pdf(session)
      )
    }),
    filename_prefix = "evastur_analysis_report",
    i18n = i18n_r,
    output_format = "pdf_document"
  )

  ## [M] "viz_geo_pdf_download ----
  pdf_download_server(
    id = "viz_geo_pdf_download",
    rmd_template = "visualization_geo_page.rmd",
    params = reactive({
      list(
        plot_background_color = get_theme_color(
          session = session,
          bs_variable = "light"
        ),

        viz_params = list(
          data_ind = tryCatch(
            {
              if (!is.null(indicator_viz$data_ind())) {
                indicator_viz$data_ind()
              } else {
                NULL
              }
            },
            error = function(e) NULL
          ),
          data_group = tryCatch(
            {
              if (!is.null(indicator_viz$data_group())) {
                indicator_viz$data_group()
              } else {
                NULL
              }
            },
            error = function(e) NULL
          ),
          plot_title = tryCatch(
            {
              # Get plot title for geo comparison
              if (is.null(indicator_selector_output$pi_indicator())) {
                dimension_selector_control$dimension_label()
              } else {
                names(indicator_selector_output$indicator_name())[1]
              }
            },
            error = function(e) "Comparación Áreas Geográficas"
          ),
          geo_total = tryCatch(
            {
              geo_total_val <- geo_level_selector_controls$pi_geo_group()
              # If geo_total is NULL or empty, extract it from data_group
              if (is.null(geo_total_val) || geo_total_val == "") {
                if (
                  !is.null(indicator_viz$data_group()) &&
                    nrow(indicator_viz$data_group()) > 0
                ) {
                  geo_total_val <- unique(indicator_viz$data_group()$geo_id)[1]
                }
              }
              geo_total_val
            },
            error = function(e) {
              # Fallback: extract from data_group if available
              if (
                !is.null(indicator_viz$data_group()) &&
                  nrow(indicator_viz$data_group()) > 0
              ) {
                unique(indicator_viz$data_group()$geo_id)[1]
              } else {
                NULL
              }
            }
          ),
          geo_list = tryCatch(
            {
              geo_selector_control_multi$pi_geo_selected()
            },
            error = function(e) NULL
          ),
          dimension = tryCatch(
            {
              dimension_selector_control$pi_dimension()
            },
            error = function(e) NULL
          ),
          indicator = tryCatch(
            {
              indicator_selector_output$pi_indicator()
            },
            error = function(e) NULL
          ),
          source = tryCatch(
            {
              input$pi_source
            },
            error = function(e) NULL
          )
        ),

        app_title = session$userData$config()$app_title,
        header_color = get_theme_color(
          session = session,
          bs_variable = "primary"
        ),
        logo_path = prepare_logo_for_pdf(session)
      )
    }),
    filename_prefix = "evastur_viz_geo_report",
    i18n = i18n_r,
    output_format = "pdf_document"
  )

  ## [M] "viz_ind_pdf_download ----
  pdf_download_server(
    id = "viz_ind_pdf_download",
    rmd_template = "visualization_ind_page.rmd",
    params = reactive({
      list(
        plot_background_color = get_theme_color(
          session = session,
          bs_variable = "light"
        ),

        viz_params = list(
          data_ind = tryCatch(
            {
              if (!is.null(indicator_viz_ind$data_ind())) {
                indicator_viz_ind$data_ind()
              } else {
                NULL
              }
            },
            error = function(e) NULL
          ),
          data_group = tryCatch(
            {
              if (!is.null(indicator_viz_ind$data_group())) {
                indicator_viz_ind$data_group()
              } else {
                NULL
              }
            },
            error = function(e) NULL
          ),
          plot_title = tryCatch(
            {
              # Get plot title for indicator comparison
              if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
                geo_selector_control$geo_group_label()
              } else {
                geo_selector_control$geo_selected_label()
              }
            },
            error = function(e) "Comparación Indicadores"
          ),
          dimension = tryCatch(
            {
              dimension_selector_control$pi_dimension()
            },
            error = function(e) NULL
          ),
          ind_list = tryCatch(
            {
              indicator_selector_output$pi_indicator()
            },
            error = function(e) NULL
          ),
          geo_selected = tryCatch(
            {
              geo_selector_control$pi_geo_selected_label()
            },
            error = function(e) NULL
          ),
          source = tryCatch(
            {
              input$pi_source
            },
            error = function(e) NULL
          )
        ),

        app_title = session$userData$config()$app_title,
        header_color = get_theme_color(
          session = session,
          bs_variable = "primary"
        ),
        logo_path = prepare_logo_for_pdf(session)
      )
    }),
    filename_prefix = "evastur_viz_ind_report",
    i18n = i18n_r,
    output_format = "pdf_document"
  )

  ## [M] imputation ----
  impute_res <- imputation_server(
    id = "imputation1",
    df_input = df_var_to_impute,
    con = con2,
    method = "Amelia",
    options = list(m = 5, corr_values = c(0.8, 0.7, 0.5)),
    update_db = TRUE
  )
  # Reactive data ----
  ## [R] inds - Active indicators ----
  inds <- reactive({
    tbl(con2, "dt_indicators") |>
      filter(indicator_active == TRUE) |>
      pull(indicator_id)
  })

  ## [R] Nuts level depending on config ----
  nuts_level <- reactive({
    if (session$userData$config()$geo_scope == "N") {
      .nuts_level <- session$userData$config()$geo_nuts_id
    } else {
      if (session$userData$config()$geo_group_id == "INSTO") {
        .nuts_level <- 99
      } else {
        .nuts_level <- 0
      }
    }
  })

  ## [R] country_location ----
  country_location <- reactive({
    if (session$userData$config()$geo_scope == "N") {
      get_iso2_code(id = session$userData$config()$geo_country_id)
    } else {
      NULL
    }
  })

  ## [R] country_groups ----
  country_groups <- reactive({
    clicked_areas_result$last_modified()
    con2 |>
      tbl("bt_geo_group") |>
      distinct(geo_group_id) |>
      pull(geo_group_id)
  })

  ## [R] vars_for_computing ----
  # Variables for computing indicators
  vars_for_computing <- reactive({
    if (session$userData$config()$source == "INSTO") {
      selected_sources <- str_subset(source_vars(), "^INSTO")
    } else {
      selected_sources <- str_subset(source_vars(), "^INSTO", negate = TRUE)
    }
    all_vars <- vars()
    # Get variables data for the selection
    df_vars <- get_ft_data(
      data_type = "variable",
      .nuts_level = nuts_level(),
      type_id = all_vars,
      country = country_location(),
      .source_id = selected_sources,
      from_date = paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      ),
      to_date = paste0(session$userData$config()$last_period, "-12-31")
    )
    if (!session$userData$config()$use_imputed_values) {
      df_vars <- df_vars |>
        ## RESTORE NA VALUES
        mutate(
          variable_value = if_else(
            stringr::str_detect(variable_value_flags, "I") &
              stringr::str_detect(variable_value_notes, "EVASTOUR") &
              !is.na(stringr::str_detect(variable_value_flags, "I")) &
              !is.na(stringr::str_detect(variable_value_notes, "EVASTOUR")),
            NA_real_,
            variable_value
          )
        )
    }
    return(df_vars)
  })
  ## [R] computed_indicators ----
  computed_indicators <- reactive({
    req(mgt_load_res())
    req(session$userData$config())
    req(vars())
    req(inds())
    req(nuts_level())
    req(country_groups())
    req(source_vars())
    if (
      session$userData$config()$geo_scope == "S" &
        session$userData$config()$geo_group_id != "INSTO"
    ) {
      req(any(session$userData$config()$geo_group_id == country_groups()))
    }
    req(vars_for_computing())

    df_vars <- vars_for_computing()
    if (session$userData$config()$geo_scope == "N") {
      gtot <- session$userData$config()$geo_country_id
    } else {
      gtot <- session$userData$config()$geo_group_id
    }
    # Get indicators metadata (formulas, variables and aggregation functions)
    df_inds <- df_vars |>
      distinct(variable_id) |>
      pull() |>
      get_computable_inds() |>
      get_indicators_metadata()
    compute_indicators(
      df_inds,
      df_vars,
      .country = country_location(),
      .nuts_level = nuts_level(),
      .geo_group_id = gtot
    )
  })

  ## [R] imputation_data ----
  # Details of imputed data for computed indicators
  imputation_data <- reactive({
    req(computed_indicators())
    req(vars_for_computing())

    if (dimension_selector_control$pi_dimension() != "GLOBAL") {
      df0 <- scaled_indicators() |>
        filter(
          dimension_id == dimension_selector_control$pi_dimension()
        )
    } else {
      df0 <- scaled_indicators()
    }

    if (!input$cb_imputation_all_years) {
      df0 <- df0 |>
        filter(year(as.Date(date)) == input$pi_year)
    }

    if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
      ## Only details for individual areas
      df_ind <- df0 |>
        filter(total == FALSE)
    } else {
      ## Only selected area
      df_ind <- df0 |>
        filter(
          geo_id == geo_selector_control$pi_geo_selected()
        )
    }

    df_ind |>
      select(-source_id) |>
      inner_join(
        get_indicators_metadata(
          unique(df_ind$indicator_id),
          summarised = FALSE
        ),
        by = "indicator_id"
      ) |>
      inner_join(
        vars_for_computing(),
        by = c("variable_id", "geo_id", "date", "period_id")
      )
  })

  imputation_names <- reactive({
    req(imputation_data())
    used_vars <- imputation_data() |> distinct(variable_id) |> pull()
    used_inds <- imputation_data() |> distinct(indicator_id) |> pull()
    dfvars <- con2 |>
      tbl("lt_variables") |>
      filter(variable_id %in% used_vars, variable_lang == input$pi_language) |>
      select(variable_id, variable_name) |>
      collect()

    dfinds <- con2 |>
      tbl("lt_indicators") |>
      filter(
        indicator_id %in% used_inds,
        indicator_lang == input$pi_language
      ) |>
      select(indicator_id, indicator_name) |>
      collect()

    list(dfvars = dfvars, dfinds = dfinds)
  })

  ## [R] scaled_indicators - Scaled indicators data ----
  scaled_indicators <- reactive({
    req(mgt_load_res())
    req(session$userData$config())
    req(nuts_level())
    req(country_groups())
    req(inds())
    if (
      session$userData$config()$geo_scope == "S" &
        session$userData$config()$geo_group_id != "INSTO"
    ) {
      req(any(session$userData$config()$geo_group_id == country_groups()))
    }
    dfind2 <- computed_indicators()
    dfind <- get_ft_data(
      data_type = "indicator",
      .nuts_level = nuts_level(),
      type_id = inds(),
      country = country_location(),
      .source_id = session$userData$config()$source,
      from_date = paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      ),
      to_date = paste0(session$userData$config()$last_period, "-12-31")
    )
    if (session$userData$config()$geo_scope == "N") {
      gtot <- session$userData$config()$geo_country_id
    } else {
      gtot <- session$userData$config()$geo_group_id
    }
    suppressMessages({
      tindicators <- get_transformed_indicators(
        dfind2,
        scaling_method = session$userData$config()$scaling_method,
        scaling_type = session$userData$config()$scaling_type,
        refvalueq = {
          if (session$userData$config()$scaling_method == "refvalue") {
            session$userData$config()$refvalue_q
          } else {
            NULL
          }
        },
        geo_total = gtot
      )
    })
    return(tindicators)
  })

  ## [R] nuts_level_from_controls - NUTS level from geo_level_selector_controls ----
  nuts_level_from_controls <- reactive({
    req(geo_level_selector_controls$rgb_geo_scope())
    req(geo_level_selector_controls$pi_geo_group())
    if (geo_level_selector_controls$rgb_geo_scope() == "N") {
      req(geo_level_selector_controls$pi_nuts())
      .nuts_level <- geo_level_selector_controls$pi_nuts()
    } else {
      if (geo_level_selector_controls$pi_geo_group() == "INSTO") {
        .nuts_level <- 99
      } else {
        .nuts_level <- 0
      }
    }
  })

  ## [R] country_location_from_controls - Country location from geo_level_selector_controls ----
  country_location_from_controls <- reactive({
    req(geo_level_selector_controls$pi_geo_group())
    req(geo_level_selector_controls$rgb_geo_scope())
    if (geo_level_selector_controls$rgb_geo_scope() == "N") {
      get_iso2_code(id = geo_level_selector_controls$pi_geo_group())
    } else {
      NULL
    }
  })

  ## [R] geo_total_from_controls - Geographic total from geo_level_selector_controls ----
  geo_total_from_controls <- reactive({
    req(geo_level_selector_controls$rgb_geo_scope())
    req(geo_level_selector_controls$pi_geo_group())
    geo_level_selector_controls$pi_geo_group()
  })

  ## [M] geo_selector_control3 ----
  ## For area managenent, multiple
  geo_selector_control_multi_controls <- geo_selector_server(
    "geo_selector3",
    i18n = i18n_r,
    lan = reactive({
      input$pi_language
    }),
    geo_scope = reactive("S"),
    geo_group = reactive("WLD"),
    nuts_level_inner = reactive(0),
    geo_selected = reactive({
      selected_group_id <- custom_groups_selector_control$pi_custom_groups()

      if (!is.null(selected_group_id) && selected_group_id != "_NONE_") {
        # Get geo_id from custom group
        ids <- tbl(con2, "bt_geo_group") |>
          filter(geo_group_id == !!selected_group_id) |>
          pull(geo_id)

        return(ids)
      }

      # If no group, return empty character vector for no selection.
      # It also could be NULL to select all by default.
      return("")
    }),
    multi = TRUE,
    maxOptions = Inf,
    external_selection = clicked_elements
  )

  ## [R] count_indicators_from_controls - Count indicators using geo_level_selector_controls ----
  count_indicators_from_controls <- reactive({
    req(mgt_load_res())
    req(geo_level_selector_controls$rgb_geo_scope())
    req(dimension_selector_control$pi_dimension())
    req(clicked_areas_result$last_modified())
    req(nuts_level_from_controls())
    req(country_groups())
    req(inds())

    if (
      geo_level_selector_controls$rgb_geo_scope() == "S" &
        geo_level_selector_controls$pi_geo_group() != "INSTO"
    ) {
      req(any(geo_level_selector_controls$pi_geo_group() == country_groups()))
    }

    dfind <- get_ft_data(
      data_type = "indicator",
      .nuts_level = nuts_level_from_controls(),
      type_id = inds(),
      country = country_location_from_controls(),
      .source_id = session$userData$config()$source, # Keep config for source
      from_date = paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      ),
      to_date = paste0(session$userData$config()$last_period, "-12-31")
    )

    get_indicators_count(
      dfind,
      geo_total = geo_total_from_controls(),
      .dimension = dimension_selector_control$pi_dimension()
    )
  })

  ## [R] composite_indicators - Composite indicators data ----
  composite_indicators <- reactive({
    req(scaled_indicators())
    req(nrow(scaled_indicators()) > 0)
    if (session$userData$config()$geo_group_id == "INSTO") {
      source <- "INSTO"
    } else {
      source <- session$userData$config()$source
    }

    scaled_indicators() |>
      compute_composite_indicator(selected_source = source)
  })

  ## [R] dmap_home - Map home data ----

  dmap_home <- reactive({
    req(mgt_load_res())
    req(data_updated_at())
    req(input$pi_year)
    req(input$pi_language)
    req(dimension_selector_control$pi_dimension())
    req(composite_indicators())
    composite_indicators() |>
      get_map_data(
        .date = paste0(input$pi_year, "-01-01"),
        type_id = dimension_selector_control$pi_dimension(),
        lan = input$pi_language
      )
  })

  ## [R] dmap_exploration - Map exploration data ----
  dmap_exploration <- reactive({
    req(mgt_load_res())
    req(data_updated_at())
    req(input$pi_language)
    req(dimension_selector_control$pi_dimension())
    req(count_indicators_from_controls())
    count_indicators_from_controls() |>
      get_map_data(
        type_id = dimension_selector_control$pi_dimension(),
        lan = input$pi_language
      )
  })

  ## [R] dmap_is_management ----
  dmap_is_management <- reactive({
    req(mgt_load_res())
    req(data_updated_at())
    req(input$pi_year)
    req(input$pi_language)

    tbl(con2, "dt_geo") |>
      filter(nuts_level == 0) |>
      filter(!is.na(geometry)) |>
      select(geo_id, geometry) |>
      collect() |>
      mutate(geometry = sf::st_as_sfc(geometry)) |>
      sf::st_as_sf(crs = 4326) |>
      mutate(
        geo_label = get_geo_label(geo_id, lan = input$pi_language)
      )
  })

  ## [R] dseries_home - series home data----
  dseries_home <- reactive({
    req(mgt_load_res())
    req(data_updated_at())
    req(input$pi_language)
    req(geo_selector_control$pi_geo_selected())
    req(composite_indicators())
    if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
      totalgroup <- TRUE
      geo <- NULL
    } else {
      totalgroup <- FALSE
      geo <- geo_selector_control$pi_geo_selected()
    }
    composite_indicators() |>
      get_series_data(
        total = totalgroup,
        .geo_id = geo,
        lan = input$pi_language,
        source = session$userData$config()$source
      )
  })

  ## [R] dfvar ----
  ## only for the exploration tables

  selected_var_id <- reactiveVal(NULL)

  observeEvent(input$btn_var_data, {
    selected_var_id(input$btn_var_data)
  })

  observeEvent(input$btn_var_plot, {
    selected_var_id(input$btn_var_plot)
  })

  dfvar <- reactive({
    waiter::waiter_show(
      html = tagList(
        h3(
          i18n_r()$t("Cargando datos de variables..."),
          style = "color:white;"
        ),
        waiter::spin_1()
      )
    )

    on.exit(waiter::waiter_hide())

    req(selected_var_id())
    varid <- selected_var_id()
    af <- con2 |>
      tbl("dt_variables") |>
      select(variable_id, aggregation_id = variable_aggregation_geo) |>
      filter(variable_id == varid) |>
      inner_join(
        tbl(con2, "dt_aggregations"),
        by = c("aggregation_id" = "aggregation_id")
      ) |>
      pull(aggregation_rfunction)
    if (session$userData$config()$source == "INSTO") {
      selected_sources <- str_subset(source_vars(), "^INSTO")
    } else {
      selected_sources <- str_subset(source_vars(), "^INSTO", negate = TRUE)
    }

    if (session$userData$config()$geo_scope == "S") {
      group_id <- session$userData$config()$geo_group_id
      geos_in_total <- tbl(con2, "bt_geo_group") |>
        filter(geo_group_id == !!session$userData$config()$geo_group_id) |>
        pull(geo_id)
    } else if (session$userData$config()$geo_scope == "N") {
      # req(geo_level_selector_controls$pi_nuts())
      iso2code <- get_iso2_code(session$userData$config()$geo_country_id)
      group_id <- session$userData$config()$geo_country_id
      geos_in_total <- con2 |>
        tbl("dt_geo") |>
        filter(
          country_iso2_code == iso2code,
          nuts_level == !!session$userData$config()$geo_nuts_id
        ) |>
        pull(geo_id)
    }

    df0 <- get_ft_data(
      data_type = "variable",
      .nuts_level = nuts_level(),
      type_id = vars(),
      country = country_location(),
      .source_id = selected_sources,
      from_date = paste0(
        session$userData$config()$last_period -
          session$userData$config()$nperiods +
          1,
        "-01-01"
      ),
      to_date = paste0(session$userData$config()$last_period, "-12-31")
    ) |>
      filter(variable_id == varid, geo_id %in% geos_in_total) |>
      mutate(
        variable_value_flags = as.character(variable_value_flags),
        total = FALSE
      )

    df_total <- df0 |>
      aggregate_variable_by_geo(
        .variable_id = varid,
        aggregation_function = af,
        geo_group_id = group_id
      ) |>
      mutate(total = TRUE)
    df0 |>
      bind_rows(df_total) |>
      left_join(
        tbl(con2, "lt_geo") |>
          filter(geo_lang == input$pi_language) |>
          select(geo_id, geo_label) |>
          collect(),
        by = "geo_id"
      ) |>
      mutate(
        period = get_period(date, period_id),
        variable_prov = ifelse(variable_prov, "✔️", ""),
        variable_secret = ifelse(variable_secret, "✔️", "")
      )
  })

  ## [R] dfind ----
  ## Indicator data for exploration tables

  selected_ind_id <- reactiveVal(NULL)

  observeEvent(input$btn_ind_data, {
    selected_ind_id(input$btn_ind_data)
  })

  observeEvent(input$btn_ind_plot, {
    selected_ind_id(input$btn_ind_plot)
  })

  dfind <- reactive({
    req(selected_ind_id())
    indid <- selected_ind_id()
    scaled_indicators() |>
      filter(indicator_id == indid) |>
      left_join(
        tbl(con2, "lt_geo") |>
          filter(geo_lang == input$pi_language) |>
          select(geo_id, geo_label) |>
          collect(),
        by = "geo_id"
      ) |>
      mutate(period = get_period(date, period_id))
  })

  ## [R] predicted_indicators ----
  predicted_indicators <- reactive({
    req(geo_selector_control$pi_geo_selected())
    if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
      df <- scaled_indicators() |> filter(total)
    } else {
      df <- scaled_indicators() |>
        filter(geo_id == geo_selector_control$pi_geo_selected())
    }
    predict_indicators(
      df,
      h_pred = prediction_horizon$ni_hpred(),
      pred_method = session$userData$config()$pred_method,
      scaling_method = session$userData$config()$scaling_method,
      source = session$userData$config()$source
    )
  })

  # available_sources <- reactive({
  #   .negate <- ifelse(
  #     session$userData$config()$source == "INSTO",
  #     FALSE,
  #     TRUE
  #   )
  #   tbl(con2, "ft_variables") |>
  #   distinct(source_id) |>
  #   pull() |>
  #   str_subset("^INSTO", negate = .negate)
  # })

  ## [R] df_var_to_impute - Data for imputation ----
  df_var_to_impute <- reactive({
    get_ft_data(
      "variable",
      .nuts_level = nuts_level(),
      type_id = vars(),
      country = country_location(),
      .source_id = source_vars(),
      from_date = "1900-01-01",
      to_date = Sys.Date()
    )
  })

  ## [R] imputation_flags_explanation ----
  imputation_flags_explanation <- reactive({
    get_imputation_flags(imputation_data(), input$pi_language)
  })

  ## [O] window title
  observe({
    req(session$userData$config())
    session$sendCustomMessage(
      "update-title",
      paste(
        session$userData$config()$app_title,
        packageVersion("evastur"),
        ifelse(Sys.getenv("HOST") == "localhost", "- local DB", "")
      )
    )
  })

  # Reactive values ----

  ## config_loaded ----
  config_loaded <- reactiveVal(FALSE)

  # Sidebar ----

  ## [E] Toggle sidebar when needeed ----
  observeEvent(input$menu, {
    if (input$menu %in% c("page_help")) {
      # Hide sidebar when help page selected
      toggle_sidebar(id = "sidebar_right", open = FALSE)
    } else {
      # Show sidebar otherwise
      toggle_sidebar(id = "sidebar_right", open = TRUE)
    }
  })

  ## Information texts ----
  ## TODO: refactor in a module
  output$info_sidebar <- renderUI({
    req(input$pi_language)
    if (input$menu == "page_home_v2") {
      ### Home NEW----
      withMathJax(
        get_text("page_home_sidebar", i18n$get_translation_language())
      )
    } else if (input$menu == "page_exploration") {
      ### Exploration ----
      if (input$tabs_exploration == "tab_evastur_exploration") {
        get_text("page_exp_evastur_sidebar", i18n$get_translation_language())
      } else if (input$tabs_exploration == "tab_sources_exploration") {
        get_text("page_exp_source_sidebar", i18n$get_translation_language())
      } else if (input$tabs_exploration == "tab_indicators_exploration") {
        get_text("page_exp_ind_sidebar", i18n$get_translation_language())
      } else if (input$tabs_exploration == "tab_geographical_areas") {
        get_text("page_exp_geo_sidebar", i18n$get_translation_language())
      }
      ### Visualization ----
    } else if (input$menu == "page_visualization_v2") {
      if (input$tabs_visualization2 == "tab_visualization_geo") {
        withMathJax(
          get_text(
            "page_visualization_geo_sidebar",
            i18n$get_translation_language()
          )
        )
      } else if (input$tabs_visualization2 == "tab_visualization_ind") {
        withMathJax(
          get_text(
            "page_visualization_ind_sidebar",
            i18n$get_translation_language()
          )
        )
      }
    } else if (input$menu == "page_analysis_v2") {
      ### Analysis_new ----
      if (input$tabs_analysis2 == "tab_recommendation_analysis2") {
        get_text(
          "page_analysis_recommendation_sidebar2",
          i18n$get_translation_language()
        )
      } else if (input$tabs_analysis2 == "tab_prediction_analysis2") {
        withMathJax(get_text(
          "page_analysis_prediction_sidebar",
          i18n$get_translation_language()
        ))
      }
    } else if (input$menu == "page_management") {
      ### Management ----
      if (input$tabs_management == "tab_management_variables") {
        get_text("page_mgt_var", i18n$get_translation_language())
      } else if (input$tabs_management == "tab_management_indicators") {
        get_text("page_mgt_ind", i18n$get_translation_language())
      } else if (input$tabs_management == "tab_management_dimensions") {
        get_text("page_mgt_dim", i18n$get_translation_language())
      } else if (input$tabs_management == "tab_management_geo") {
        get_text("page_mgt_geo", i18n$get_translation_language())
      } else if (input$tabs_management == "tab_management_load") {
        get_text("page_mgt_load", i18n$get_translation_language())
      }
    } else if (input$menu == "page_data_update") {
      get_text("page_data_update", i18n$get_translation_language())
    } else if (input$menu == "page_config") {
      get_text("page_config", i18n$get_translation_language())
    } else if (input$menu == "page_help") {
      get_text("page_help", i18n$get_translation_language())
    }
  })

  ## Input controls ----

  ### Home v2 ----
  #### ui_pi_year ----
  output$ui_pi_year <- renderUI({
    req(composite_indicators())
    yearsdata <- composite_indicators() |>
      drop_na(value) |>
      distinct(date) |>
      mutate(date = str_sub(date, end = 4)) |>
      arrange(desc(date)) |>
      pull()
    pickerInput(
      inputId = "pi_year",
      label = i18n$t("Mostrar año"),
      choices = yearsdata,
      options = list(
        container = "body"
      )
    )
  })

  ### Exploration ----
  #### pi_evastur_source ----
  output$ui_pi_evastur_source <- renderUI({
    pickerInput(
      "pi_evastur_source",
      i18n$t("Fuente"),
      choices = setNames(
        evastur_sources_ind()$source_id,
        evastur_sources_ind()$source_label
      )
    )
  })

  #### [R] evastur sources of indicators ----

  evastur_sources_ind <- reactive({
    tbl(con2, "dt_sources") |>
      filter(source_type_id == "I") |>
      inner_join(
        tbl(con2, "lt_sources") |>
          filter(source_lang == input$pi_language),
        by = "source_id"
      ) |>
      arrange(source_order) |>
      collect()
  })

  # Pages ----

  ## Home page (NEW) ----

  ### Home map ----

  #### ui_header_map_home - Map title ----

  output$ui_header_map_home <- renderUI({
    ## TODO: better manage this toggle
    # if (!config_loaded()) {
    #   toggle_popover(id = "config_popover", show = TRUE)
    #   config_loaded(TRUE)
    # }
    req(input$pi_language)
    req(input$pi_year)
    text <- paste(
      i18n$t("Indicador de turismo sostenible"),
      input$pi_year,
      "-",
      geo_selector_control$geo_group_label()
    )
    # toggle_popover(id = "config_popover", show = FALSE)

    return(text)
  })

  #### Map info ----

  output$ui_info_map_home <- renderUI({
    req(input$pi_language)
    get_text("info_map_home", input$pi_language)
  })

  #### Map data ----

  output$rt_map_home_data <- renderReactable({
    req(dmap_home())
    dmap_home() |>
      st_drop_geometry() |>
      mutate(period = get_period(date, period_id)) |>
      select(geo_id, geo_label, period, value) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        class = "popup-data-table",
        defaultColDef = colDef(
          headerClass = "exploration-header-subtable" #,
        ),
        columns = list(
          geo_id = colDef(
            name = i18n$t("Código"),
            align = "center"
          ),
          geo_label = colDef(
            name = i18n$t("Nombre"),
            align = "left"
          ),
          period = colDef(
            name = i18n$t("Período"),
            align = "center"
          ),
          value = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif)
            )
          )
        )
      )
  })

  #### ui_header_map_exploration_data - Map exploration title ----
  output$ui_header_map_exploration_data <- renderUI({
    req(session$userData$config())
    req(input$pi_language)

    from_date <- paste0(
      session$userData$config()$last_period -
        session$userData$config()$nperiods +
        1,
      "-01-01"
    )
    to_date <- paste0(session$userData$config()$last_period, "-12-31")

    paste0(
      i18n$t("Datos Área"),
      " • ",
      from_date,
      " – ",
      to_date
    )
  })

  output$rt_map_exploration_data <- renderReactable({
    req(dmap_exploration())
    req(session$userData$config())
    dmap_exploration() |>
      st_drop_geometry() |>
      select(geo_id, geo_label, value) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        class = "exploration-tables",
        defaultColDef = colDef(
          headerClass = "exploration-header-subtable"
        ),
        columns = list(
          geo_id = colDef(
            name = i18n$t("Código"),
            align = "center"
          ),
          geo_label = colDef(
            name = i18n$t("Nombre"),
            align = "left"
          ),
          value = colDef(
            name = i18n$t("Número de indicadores"),
            align = "center",
            format = colFormat(separators = TRUE)
          )
        )
      )
  })

  #### rt_map_exploration_data_popup - For download popup (Datos Área) ----
  output$rt_map_exploration_data_popup <- renderReactable({
    req(dmap_exploration())
    req(session$userData$config())

    dmap_exploration() |>
      st_drop_geometry() |>
      select(geo_id, geo_label, value) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        defaultColDef = colDef(
          headerClass = "exploration-header-subtable"
        ),
        columns = list(
          geo_id = colDef(
            name = i18n$t("Código Área"),
            align = "center"
          ),
          geo_label = colDef(
            name = i18n$t("Área Geográfica"),
            align = "left"
          ),
          value = colDef(
            name = i18n$t("Número Indicadores"),
            align = "center",
            format = colFormat(separators = TRUE)
          )
        ),
        class = "popup-data-table"
      )
  })

  #### rt_map_exploration_map_popup - For map download popup (Indicadores Activos) ----
  output$rt_map_exploration_map_popup <- renderReactable({
    req(dmap_exploration())
    req(session$userData$config())

    dmap_exploration() |>
      st_drop_geometry() |>
      select(geo_id, geo_label, value) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        defaultColDef = colDef(
          headerClass = "exploration-header-subtable"
        ),
        columns = list(
          geo_id = colDef(
            name = i18n$t("Código Área"),
            align = "center"
          ),
          geo_label = colDef(
            name = i18n$t("Área Geográfica"),
            align = "left"
          ),
          value = colDef(
            name = i18n$t("Número Indicadores"),
            align = "center",
            format = colFormat(separators = TRUE)
          )
        ),
        class = "popup-data-table"
      )
  })

  #### dl_map_exploration_data ----
  output$ui_dl_map_exploration_data <- renderUI({
    req(session$userData$config())

    from_year <- session$userData$config()$last_period -
      session$userData$config()$nperiods +
      1
    to_year <- session$userData$config()$last_period

    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_map_exploration_data",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_map_exploration_data_popup',",
          "'IND_exp_geo_areas_",
          from_year,
          "_",
          to_year,
          ".csv')"
        )
      )
    )
  })

  #### dl_map_exploration_map ----
  output$ui_dl_map_exploration_map <- renderUI({
    req(session$userData$config())

    from_year <- session$userData$config()$last_period -
      session$userData$config()$nperiods +
      1
    to_year <- session$userData$config()$last_period

    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_map_exploration_map",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_map_exploration_map_popup',",
          "'IND_exp_geo_map_",
          from_year,
          "_",
          to_year,
          ".csv')"
        )
      )
    )
  })

  #### dl_map_data ----
  output$ui_dl_map_home_data <- renderUI({
    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_map_home_data",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_map_home_data',",
          "'STI_",
          dimension_selector_control$dimension_label(),
          "_",
          input$pi_year,
          "_",
          geo_selector_control$geo_group_label(),
          ".csv')"
        )
      )
    )
  })

  ### Home series ----

  #### ui_header_series_home - Series title ----

  output$ui_header_series_home <- renderUI({
    req(input$pi_language)
    req(geo_selector_control$geo_selected_label())
    paste(
      i18n$t("Indicador de turismo sostenible"),
      "-",
      geo_selector_control$geo_selected_label()
    )
  })

  #### Series info ----

  output$ui_info_series_home <- renderUI({
    req(input$pi_language)
    get_text("info_series_home", input$pi_language)
  })

  #### Series data ----

  output$rt_series_home_data <- renderReactable({
    dseries_home() |>
      mutate(period = get_period(date, period_id)) |>
      select(dimension_id, dimension_label, period, value) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        defaultColDef = colDef(
          headerClass = "exploration-header-subtable" #,
        ),
        columns = list(
          dimension_id = colDef(
            name = i18n$t("Código"),
            align = "center"
          ),
          dimension_label = colDef(
            name = i18n$t("Nombre"),
            align = "left"
          ),
          period = colDef(
            name = i18n$t("Período"),
            align = "center"
          ),
          value = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif)
            )
          )
        ),
        class = "popup-data-table"
      )
  })

  #### dl_series_home_data ----
  output$ui_dl_series_home_data <- renderUI({
    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_series_home_data",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_series_home_data',",
          "'STI_series",
          "_",
          geo_selector_control$geo_selected_label(),
          ".csv')"
        )
      )
    )
  })

  ### Value boxes home ----

  output$vbs_home <- renderUI({
    req(composite_indicators())
    req(dimension_selector_control$pi_dimension())
    req(geo_selector_control$pi_geo_selected())
    req(geo_selector_control$geo_selected_label())
    req(input$pi_year)
    df <- composite_indicators() |>
      drop_na(value) |> 
      filter(date <= paste0(input$pi_year, "-01-01"))
    if (dimension_selector_control$pi_dimension() == "GLOBAL") {
      .global <- TRUE
      .dimension_id <- NULL
    } else {
      .global <- FALSE
      .dimension_id <- dimension_selector_control$pi_dimension()
    }
    if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
      .total <- TRUE
      .geo_id <- NULL
    } else {
      .total <- FALSE
      .geo_id <- geo_selector_control$pi_geo_selected()
    }
    req(nrow(df) > 0)
    vbs <- c("trend", "last", "dist", "rank") |>
      map(
        ~ vbox_kpi(
          .data = df,
          kpi = .x,
          total = .total,
          global = .global,
          geo_id = .geo_id,
          dimension_id = .dimension_id,
          i18n = i18n_r()
        )
      )
    tagList(
      h5(
        i18n$t("Período seleccionado:"),
        max(year(as.Date(df$date)), na.rm = TRUE),
        "-",
        dimension_selector_control$dimension_label(),
        "-",
        geo_selector_control$geo_selected_label()
      ),
      layout_column_wrap(width = 1 / 4, fill = FALSE, !!!vbs)
    )
  })

  ## Exploration page ----

  ### EVASTUR indicators system ----

  #### info iss tab ----
  output$info_is_exploration <- renderUI({
    req(input$pi_language)
    get_text("info_is_exploration", input$pi_language)
  })

  #### IS tables ----
  ## TODO: show only spinner in the control, not full page
  output$ui_evastur_is <- renderUI({
    req(input$pi_language)
    waiter::waiter_show(
      html = tagList(
        h2(i18n$t("Cargando sistema de indicadores...")),
        waiter::spin_1()
      )
    )
    is_ui <- get_is_ui(
      source = session$userData$config()$source,
      language = input$pi_language,
      i18n,
      m_onlycustom()
    )
    waiter::waiter_hide()
    return(is_ui)
  })

  #### [E] button source doc ----
  observeEvent(input$btn_source_doc, {
    source_name <- con2 |>
      tbl("lt_sources") |>
      filter(
        source_id == input$btn_source_doc,
        source_lang == input$pi_language
      ) |>
      pull(source_name)

    sendSweetAlert(
      title = source_name,
      html = TRUE,
      text = withMathJax(div(
        documentation_ui("docsource"),
        class = "rtdoc"
      )),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  #### [E] button ind doc ----
  observeEvent(input$btn_ind_doc, {
    ind_name <- con2 |>
      tbl("lt_indicators") |>
      filter(
        indicator_id == input$btn_ind_doc,
        indicator_lang == input$pi_language
      ) |>
      pull(indicator_name)
    sendSweetAlert(
      title = ind_name,
      html = TRUE,
      text = withMathJax(div(
        documentation_ui("docind"),
        class = "rtdoc"
      )),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  #### [E] button var doc ----
  observeEvent(input$btn_var_doc, {
    var_name <- con2 |>
      tbl("lt_variables") |>
      filter(
        variable_id == input$btn_var_doc,
        variable_lang == input$pi_language
      ) |>
      pull(variable_name)
    sendSweetAlert(
      title = var_name,
      html = TRUE,
      text = withMathJax(div(
        documentation_ui("docvar"),
        class = "rtdoc"
      )),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  #### [E] button ind data ----
  shiny::observeEvent(input$btn_ind_data, {
    ind_name <- con2 |>
      tbl("lt_indicators") |>
      filter(
        indicator_id == input$btn_ind_data,
        indicator_lang == input$pi_language
      ) |>
      pull(indicator_name)

    ab_ft_ind <- if (nrow(dfind()) > 0) {
      div(
        style = "margin-top: 10px;",
        actionButton(
          inputId = "dl_ft_ind",
          label = i18n$t("Descargar"),
          width = "100%",
          icon = icon("download"),
          onclick = paste0(
            "Reactable.downloadDataCSV('rt_ft_ind',",
            "'indicator_values_",
            input$btn_ind_data,
            "_",
            geo_selector_control$geo_group_label(),
            ".csv')"
          )
        )
      )
    }

    shinyWidgets::sendSweetAlert(
      title = ind_name,
      html = TRUE,
      text = tagList(
        reactableOutput("rt_ft_ind"),
        ab_ft_ind
      ),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  #### rt_ft_ind ----
  output$rt_ft_ind <- renderReactable({
    df <- dfind()

    validate(
      need(nrow(df) > 0, i18n$t("No hay datos disponibles para mostrar."))
    )

    df |>
      select(
        period,
        # geo_id,
        geo_label,
        # geo_name,
        value_ori,
        value
      ) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        filterable = TRUE,
        defaultPageSize = 5,
        class = "exploration-tables",
        columns = list(
          period = colDef(
            name = i18n$t("Período")
          ),
          geo_label = colDef(
            name = i18n$t("Área geográfica")
          ),
          value_ori = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif),
              separators = TRUE
            ),
            filterable = FALSE
          ),
          value = colDef(
            name = i18n$t("Valor escalado"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif),
              separators = TRUE
            ),
            filterable = FALSE
          )
        )
      )
  })

  #### [R] vars Available variables ----
  vars <- reactive({
    tbl(con2, "bt_indicator_variable") |>
      semi_join(
        tbl(con2, "bt_indicator_source") |>
          filter(source_id == session$userData$config()$source),
        by = "indicator_id"
      ) |>
      pull(variable_id)
  })

  #### [R] source_vars Available sources ----
  source_vars <- reactive({
    tbl(con2, "ft_variables") |>
      distinct(source_id) |>
      pull()
  })

  #### [E] button var data ----

  shiny::observeEvent(input$btn_var_data, {
    var_name <- con2 |>
      tbl("lt_variables") |>
      filter(
        variable_id == input$btn_var_data,
        variable_lang == input$pi_language
      ) |>
      pull(variable_name)
    ab_ft_var <- if (nrow(dfvar()) > 0) {
      div(
        style = "margin-top: 10px;",
        actionButton(
          inputId = "dl_ft_var",
          label = i18n$t("Descargar"),
          width = "100%",
          icon = icon("download"),
          onclick = paste0(
            "Reactable.downloadDataCSV('rt_ft_var',",
            "'variables_values_",
            input$btn_var_data,
            # "_",
            # input$pi_year,
            "_",
            geo_selector_control$geo_group_label(),
            ".csv')"
          )
        )
      )
    }
    shinyWidgets::sendSweetAlert(
      title = var_name,
      html = TRUE,
      text = tagList(
        reactableOutput("rt_ft_var"),
        ab_ft_var
      ),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  #### rt_ft_var ----

  output$rt_ft_var <- renderReactable({
    df <- dfvar()

    validate(
      need(nrow(df) > 0, i18n$t("No hay datos disponibles para mostrar."))
    )

    df |>
      select(
        period,
        # date,
        # geo_id,
        geo_label,
        # geo_name,
        variable_value,
        source_units,
        source_id,
        variable_value_flags,
        variable_value_notes
        # variable_prov,
        # variable_secret #,
        #info)
      ) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        filterable = TRUE,
        defaultPageSize = 5,
        class = "exploration-tables",
        columns = list(
          period = colDef(
            name = i18n$t("Período")
          ),
          geo_label = colDef(
            name = i18n$t("Área geográfica")
          ),
          variable_value = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif),
              separators = TRUE
            ),
            filterable = FALSE,
          ),
          source_units = colDef(
            name = i18n$t("Unidades"),
            filterable = FALSE
          ),
          source_id = colDef(
            name = i18n$t("Fuente")
          ),
          # variable_prov = colDef(
          #   name = i18n$t("Provisional")
          # ),
          variable_value_flags = colDef(
            name = i18n$t("Estado")
          ),
          variable_value_notes = colDef(
            name = i18n$t("Notas")
          )
        )
      )
  })

  #### [E] button var plot ----
  shiny::observeEvent(input$btn_var_plot, {
    var_name <- con2 |>
      tbl("lt_variables") |>
      filter(
        variable_id == input$btn_var_plot,
        variable_lang == input$pi_language
      ) |>
      pull(variable_name)
    shinyWidgets::sendSweetAlert(
      title = var_name,
      html = TRUE,
      text = tagList(
        variables_plots_ui("variables_plots1")
      ),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  #### [E] button ind plot ----
  shiny::observeEvent(input$btn_ind_plot, {
    ind_name <- con2 |>
      tbl("lt_indicators") |>
      filter(
        indicator_id == input$btn_ind_plot,
        indicator_lang == input$pi_language
      ) |>
      pull(indicator_name)
    shinyWidgets::sendSweetAlert(
      title = ind_name,
      html = TRUE,
      text = tagList(
        indicators_plots_ui("indicators_plots1")
      ),
      width = 800,
      btn_labels = "Close",
      btn_colors = "var(--bs-primary)"
    )
  })

  ### Sources tab ----
  #### info sources tab ----
  output$info_sources_exploration <- renderUI({
    req(input$pi_language)
    get_text("info_sources_exploration", input$pi_language)
  })

  #### sources tab - reactable ----
  output$ind_sources <- renderReactable({
    req(input$pi_language)
    get_reactable_sources(
      con = con,
      i18n = i18n,
      primary_color = get_theme_color(
        session = session,
        bs_variable = "primary"
      )
    )
  })

  ### Indicators tab ----
  #### info indicators tab ----
  output$info_indicators_exploration <- renderUI({
    req(input$pi_language)
    get_text("info_indicators_exploration", input$pi_language)
  })

  #### Indicators tab reactable ----
  output$ind_indicators <- renderReactable({
    get_reactable_indicators(
      i18n = i18n,
      primary_color = get_theme_color(
        session = session,
        bs_variable = "primary"
      )
    )
  })

  ## Visualization page NEW ----

  #### info_viz_geo tab ----
  output$info_viz_geo <- renderUI({
    req(input$pi_language)
    get_text("info_viz_geo", input$pi_language)
  })

  #### info_viz_ind tab ----
  output$info_viz_ind <- renderUI({
    req(input$pi_language)
    get_text("info_viz_ind", input$pi_language)
  })

  #### viz_geo data table ----
  output$rt_viz_geo_data <- renderReactable({
    df_comparison <- indicator_viz$data_ind() # Individual areas (dashed lines)
    df_reference <- indicator_viz$data_group() # Total area (solid line)

    req(df_comparison)
    req(df_reference)

    if (is.list(df_comparison$period)) {
      df_comparison <- df_comparison |> mutate(period = as.character(period))
    }
    if (is.list(df_reference$period)) {
      df_reference <- df_reference |> mutate(period = as.character(period))
    }

    combined_data <- bind_rows(df_comparison, df_reference)

    combined_data |>
      select(any_of(c(
        "geo_id",
        "geo_label",
        "indicator_id",
        "indicator_label",
        "dimension_id",
        "period",
        "value"
      ))) |>
      arrange(period, geo_label) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        defaultColDef = colDef(headerClass = "exploration-header-subtable"),
        columns = list(
          geo_id = colDef(
            name = i18n$t("Código Área"),
            align = "center"
          ),
          geo_label = colDef(
            name = i18n$t("Nombre Área"),
            align = "left"
          ),
          indicator_id = colDef(
            name = i18n$t("Código Indicador"),
            align = "center"
          ),
          indicator_label = colDef(
            name = i18n$t("Nombre Indicador"),
            align = "left"
          ),
          dimension_id = colDef(
            name = i18n$t("Dimensión"),
            align = "center"
          ),
          period = colDef(
            name = i18n$t("Período"),
            align = "center"
          ),
          value = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif)
            )
          )
        ),
        class = "popup-data-table"
      )
  })

  #### dl_viz_geo_data ----
  output$ui_dl_viz_geo_data <- renderUI({
    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_viz_geo_data",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_viz_geo_data',",
          "'STI_viz_geo_comparison.csv')"
        )
      )
    )
  })

  #### viz_ind data table ----
  output$rt_viz_ind_data <- renderReactable({
    df_comparison <- indicator_viz_ind$data_ind()
    df_reference <- indicator_viz_ind$data_group()

    req(df_comparison)
    req(df_reference)

    if (is.list(df_comparison$period)) {
      df_comparison <- df_comparison |> mutate(period = as.character(period))
    }
    if (is.list(df_reference$period)) {
      df_reference <- df_reference |> mutate(period = as.character(period))
    }

    combined_data <- bind_rows(
      df_comparison |> mutate(tipo = i18n$t("Indicador")),
      df_reference |> mutate(tipo = i18n$t("Dimensión"))
    )

    combined_data |>
      select(any_of(c(
        "tipo",
        "geo_id",
        "geo_label",
        "indicator_id",
        "indicator_label",
        "dimension_id",
        "period",
        "value"
      ))) |>
      arrange(period, geo_label) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        defaultColDef = colDef(headerClass = "exploration-header-subtable"),
        columns = list(
          tipo = colDef(
            name = i18n$t("Tipo"),
            align = "center"
          ),
          geo_id = colDef(
            name = i18n$t("Código Área"),
            align = "center"
          ),
          geo_label = colDef(
            name = i18n$t("Nombre Área"),
            align = "left"
          ),
          indicator_id = colDef(
            name = i18n$t("Código Indicador"),
            align = "center"
          ),
          indicator_label = colDef(
            name = i18n$t("Nombre Indicador"),
            align = "left"
          ),
          dimension_id = colDef(
            name = i18n$t("Dimensión"),
            align = "center"
          ),
          period = colDef(
            name = i18n$t("Período"),
            align = "center"
          ),
          value = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif)
            )
          )
        ),
        class = "popup-data-table"
      )
  })

  #### dl_viz_ind_data ----
  output$ui_dl_viz_ind_data <- renderUI({
    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_viz_ind_data",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_viz_ind_data',",
          "'STI_viz_ind_comparison.csv')"
        )
      )
    )
  })

  ## Analysis page v2 ----

  #### Prediction plot header ----
  output$ui_header_series_pred <- renderUI({
    req(input$pi_language)
    req(geo_selector_control$geo_selected_label())
    paste(
      i18n$t("Predicciones del indicador"),
      "-",
      geo_selector_control$geo_selected_label()
    )
  })

  #### Prediction plot info ----
  output$info_prediction_plot2 <- renderUI({
    get_text("info_prediction_plot2", input$pi_language)
  })

  ### [R] sdatapred - Prediction series data ----
  sdatapred <- reactive({
    req(geo_selector_control$pi_geo_selected())

    if (geo_selector_control$pi_geo_selected() == "_TOTAL_") {
      totalgroup <- TRUE
      geo <- NULL
    } else {
      totalgroup <- FALSE
      geo <- geo_selector_control$pi_geo_selected()
    }

    get_series_data(
      predicted_indicators()$dim,
      total = totalgroup,
      .geo_id = geo,
      lan = input$pi_language,
      source = session$userData$config()$source
    )
  })

  #### Prediction plot ----
  output$plot_prediction2 <- renderPlotly({
    validate(
      need(
        nrow(sdatapred()) > 0,
        i18n$t(
          "No existen datos para hacer la predicción, revise la selección."
        )
      )
    )
    light_color <- get_theme_color(session = session, bs_variable = "light")
    p <- get_ci_ts_plot(
      .data = dseries_home(),
      predictions = sdatapred(),
      target = prediction_horizon$slider_epsilon_intervention(),
      i18n = i18n,
      background_color = light_color
    )
    p <- p +
      aes(customdata = dimension_label2)
    l <- list(
      font = list(
        family = "sans-serif",
        size = 10,
        itemwidth = 30,
        color = "black"
      ),
      bgcolor = "transparent",
      bordercolor = "transparent",
      y = -0.2,
      x = 0.5,
      orientation = "h",
      xanchor = 'center',
      borderwidth = 3,
      title = list(text = '')
    )
    ggplotly(p) |>
      layout(legend = l) |>
      style(
        hovertemplate = paste0(
          "<b>",
          i18n$t("Año"),
          ":</b> %{x}<br>",
          "<b>",
          i18n$t("Valor"),
          ":</b> %{y}<br>",
          "<b>",
          i18n$t("Dimensión"),
          ":</b> %{customdata}<extra></extra>"
        )
      ) |>
      plotly::config(displaylogo = FALSE)
  })

  #### rt_series_pred_data - Prediction series data table ----
  output$rt_series_pred_data <- renderReactable({
    req(dseries_home())

    # Get historical data
    historical_data <- dseries_home() |>
      mutate(
        period = get_period(date, period_id),
        value_type = i18n$t("Histórico")
      )

    # Get prediction data
    prediction_data <- sdatapred() |>
      mutate(
        period = get_period(date, period_id),
        value_type = i18n$t("Predicción")
      )

    # Combine both datasets
    bind_rows(historical_data, prediction_data) |>
      select(value_type, dimension_label, period, value) |>
      reactable(
        language = get_rt_lang(input$pi_language),
        defaultColDef = colDef(
          headerClass = "exploration-header-subtable"
        ),
        columns = list(
          value_type = colDef(
            name = i18n$t("Tipo"),
            align = "left"
          ),
          dimension_label = colDef(
            name = i18n$t("Dimensión"),
            align = "center"
          ),
          period = colDef(
            name = i18n$t("Período"),
            align = "center"
          ),
          value = colDef(
            name = i18n$t("Valor"),
            format = colFormat(
              digits = as.integer(session$userData$config()$signif)
            )
          )
        ),
        class = "popup-data-table"
      )
  })

  #### ui_dl_series_pred_data - Download button ----
  output$ui_dl_series_pred_data <- renderUI({
    req(geo_selector_control$geo_selected_label())

    div(
      style = "margin-top: 10px;",
      actionButton(
        inputId = "dl_series_pred_data",
        label = i18n$t("Descargar"),
        width = "100%",
        icon = icon("download"),
        onclick = paste0(
          "Reactable.downloadDataCSV('rt_series_pred_data',",
          "'STI_prediction_series_",
          geo_selector_control$geo_selected_label(),
          ".csv')"
        )
      )
    )
  })

  ### vbs_intervention2 ----
  output$vbs_intervention2 <- renderUI({
    .data <- intervention_controls$res_intervention_step1()

    if (is.null(.data)) {
      get_intervention_vbs(
        .data = .data,
        .unfeasible_dims = NULL,
        i18n = i18n
      )
    } else {
      req(intervention_controls$res_intervention_step2())

      get_intervention_vbs(
        .data = .data,
        .unfeasible_dims = attr(
          intervention_controls$res_intervention_step2(),
          "unfeasible_dims"
        )$name,
        i18n = i18n
      )
    }
  })

  ### Reactable intervention indicators v2 ----
  output$rt_intervention2 <- renderReactable({
    req(intervention_controls$res_intervention_step1())
    req(intervention_controls$res_intervention_step2())
    res2 <- intervention_controls$res_intervention_step2()
    unfeasible_dims <- attr(res2, "unfeasible_dims")

    req(
      nrow(res2) > 0 ||
        (!is.null(unfeasible_dims) && length(unfeasible_dims) > 0)
    )

    get_intervention_table(
      .data = res2,
      i18n = i18n,
      primary_color = get_theme_color(
        session = session,
        bs_variable = "primary"
      )
    )
  })

  ## page_experimental ----
  ### Experimental recommendation ----

  #### [R] Weights table ----
  recommendation_table <- reactive({
    etit2_1 <- meta_recomendation |>
      filter(Variable == "t2_1") |>
      pull(Etiqueta)
    etit2_2 <- meta_recomendation |>
      filter(Variable == "t2_2") |>
      pull(Etiqueta)
    etit3_1 <- meta_recomendation |>
      filter(Variable == "t3_1") |>
      pull(Etiqueta)
    etit4_1 <- meta_recomendation |>
      filter(Variable == "t4_1") |>
      pull(Etiqueta)
    etit4_2 <- meta_recomendation |>
      filter(Variable == "t4_2") |>
      pull(Etiqueta)
    etit4_3 <- meta_recomendation |>
      filter(Variable == "t4_3") |>
      pull(Etiqueta)
    etit5_1 <- meta_recomendation |>
      filter(Variable == "t5_1") |>
      pull(Etiqueta)
    etit6_1 <- meta_recomendation |>
      filter(Variable == "t6_1") |>
      pull(Etiqueta)
    etit7_1 <- meta_recomendation |>
      filter(Variable == "t7_1") |>
      pull(Etiqueta)
    etit8_1 <- meta_recomendation |>
      filter(Variable == "t8_1") |>
      pull(Etiqueta)
    etit9_1 <- meta_recomendation |>
      filter(Variable == "t9_1") |>
      pull(Etiqueta)
    etit10_1 <- meta_recomendation |>
      filter(Variable == "t10_1") |>
      pull(Etiqueta)
    etit11_1 <- meta_recomendation |>
      filter(Variable == "t11_1") |>
      pull(Etiqueta)
    etit12_1 <- meta_recomendation |>
      filter(Variable == "t12_1") |>
      pull(Etiqueta)
    ingresos_base <- meta_recomendation |>
      filter(Variable == "dato_base_ingreso") |>
      pull(Etiqueta)
    tarifa_base <- meta_recomendation |>
      filter(Variable == "dato_base_tarifa") |>
      pull(Etiqueta)
    tabla_recomendacion |>
      rename(
        !!etit2_1 := t2_1,
        !!etit2_2 := t2_2,
        !!etit3_1 := t3_1,
        !!etit4_1 := t4_1,
        !!etit4_2 := t4_2,
        !!etit4_3 := t4_3,
        !!etit5_1 := t5_1,
        !!etit6_1 := t6_1,
        !!etit7_1 := t7_1,
        !!etit8_1 := t8_1,
        !!etit9_1 := t9_1,
        !!etit10_1 := t10_1,
        !!etit11_1 := t11_1,
        !!etit12_1 := t12_1,
        !!ingresos_base := dato_base_ingreso,
        !!tarifa_base := dato_base_tarifa
      )
  })

  #### [R] Zonas INE ----
  zonas_ine_react <- reactive(
    zonas_ine |>
      unite(id, prov, id, sep = "", remove = TRUE)
  )

  #### Weights ----
  output$Pesos <- renderUI({
    slider_list <- lapply(1:29, function(i) {
      div(
        style = "display: flex; align-items: center;",
        span(
          style = "flex: 1; min-width: 150px;",
          colnames(recommendation_table())[i]
        ),
        numericInput(
          inputId = paste0("peso", i),
          label = NULL,
          value = slider_values()[i], # use reactives values with aim of save the weights
          min = 0,
          max = 10,
          width = 70
        )
      )
    })
    do.call(tagList, slider_list)
  })

  #### Recommendation map info ----
  output$info_zone_recommendation_analysis <- renderUI({
    get_text("info_zone_recommendation_analysis", input$pi_language)
  })

  #### Recommendation map ----
  output$mapa_zonas <- renderLeaflet({
    geometries_data <- map_data()
    req(nrow(geometries_data) > 0)

    labels <- sprintf(
      "<strong>%s</strong><br/>%g nº Plazas",
      geometries_data$Zona,
      geometries_data$`Número de plazas estimadas`
    ) %>%
      lapply(htmltools::HTML)

    bins <- c(
      0,
      10,
      20,
      50,
      100,
      200,
      500,
      1000,
      1500,
      2000,
      2500,
      3000,
      3500,
      4000,
      5000,
      5500,
      Inf
    )

    primary_color <- get_theme_color(session = session, bs_variable = "primary")
    color_palette <- create_color_palette(
      primary_color = primary_color,
      n = length(bins),
      range = 1
    )

    pal <- colorBin(
      palette = color_palette,
      domain = geometries_data$`Número de plazas estimadas`,
      bins = bins,
      na.color = "transparent"
    )
    geometries_data |>
      leaflet() |>
      addProviderTiles(
        provider = providers$CartoDB.VoyagerLabelsUnder,
      ) |>
      # setView( lng = -4, lat = 39, zoom = 5)
      addPolygons(
        layerId = ~Zona,
        fillColor = ~ pal(`Número de plazas estimadas`),
        weight = 1,
        opacity = 1,
        color = primary_color,
        dashArray = "3",
        fillOpacity = 0.7,
        highlightOptions = highlightOptions(
          weight = 2,
          color = adjust_color(
            color = primary_color,
            color_type = "hex",
            factor = -0.4
          ),
          dashArray = "",
          fillOpacity = 0.7,
          bringToFront = TRUE
        ),
        label = labels,
        labelOptions = labelOptions(
          style = list("font-weight" = "normal", padding = "3px 8px"),
          textsize = "15px",
          direction = "auto"
        )
      )
  })

  #### Recommendation result zone info ----
  output$info_recommendation_zone_selected <- renderUI({
    get_text("info_recommendation_zone_selected", input$pi_language)
  })

  #### Recommendation result info ----
  output$info_recommendation_result <- renderUI({
    get_text("info_recommendation_result", input$pi_language)
  })

  #### Recommendation result ----
  output$recommendation_result <- renderUI({
    map_selected <- input$mapa_zonas_shape_click$id
    if (is.null(map_selected) & input$calculo_rec == 0) {
      h6(
        i18n$t(
          "Pasa el ratón por encima de una de las zonas que se destacan en el mapa"
        ),
        style = "font-family: 'Roboto', sans-serif;"
      )
    } else {
      if (is.null(map_selected) == FALSE & input$calculo_rec == 0) {
        h6(
          i18n$t("Pulsa el botón de cálculo"),
          style = "font-family: 'Roboto', sans-serif;"
        )
      }
    }
  })

  #### Recommendation zone name ----
  output$zona_nombre <- renderUI({
    tags$div(
      tags$br(),
      HTML(paste0(
        "<b>",
        as.character(
          tabla <- matriz() |>
            filter(Zona == input$mapa_zonas_shape_click$id) |>
            select(Zona)
        ),
        "<b>"
      )),
      style = "text-align: center;font-family: 'Roboto', sans-serif;"
    )
  })

  #### Recommendation zone ----
  output$recomendacion <- renderUI({
    tags$div(
      tags$br(),
      HTML(paste0(
        "<b>",
        as.character(
          tabla <- matriz() |>
            filter(Zona == input$mapa_zonas_shape_click$id) |>
            select(Recomendacion)
        ),
        "<b>"
      )),
      style = "text-align: center;font-family: 'Roboto', sans-serif;"
    )
  })

  #### [R] Weights sliders ----
  slider_values <- reactive({
    # The first setting of the weights
    if (is.null(r_weights$values)) {
      rep(1, 29)
    } else {
      # After save one time the weights, use the saved values
      sapply(1:29, function(i) {
        input[[paste0("peso", i)]] # Siempre usa los valores actuales del input
      })
    }
  })

  #### [E] Weights modal ----
  observeEvent(input$showModal, {
    showModal(modalDialog(
      title = i18n$t("Modificación pesos"),
      tags$head(
        tags$style(
          type = "text/css",
          ".inline label{ display: table-cell; text-align: left; vertical-align: middle; } 
                 .inline .form-group{display: table-row;}"
        )
      ),
      tags$div(class = "inline", uiOutput("Pesos")),
      easyClose = FALSE,
      footer = tagList(
        # Let to close the modal window
        modalButton(i18n$t("Cerrar")),
        # Save the weights
        actionButton("save", i18n$t("Guardar"))
      )
    ))
  })

  #### [R] Weights calculation ----
  r_weights <- reactiveValues()

  #### [E] Weights save ----
  observeEvent(input$save, {
    r_weights$values <- sapply(1:29, function(i) {
      input[[paste0("peso", i)]]
    })
    r_weights$values
  })

  #### [E] Weights matriz ----
  matriz <- eventReactive(input$calculo_rec, {
    req(input$mapa_zonas_shape_click)
    matriz_distancia <- funcion_matriz_distancia(
      recommendation_table(),
      slider_values()
    )
    tabla <- matrix(0, ncol = 2, nrow = 41)
    matriz = matriz_distancia[7:47, 1:6]
    rec = 0
    for (i in 1:41) {
      z = sort(matriz[i, ], index.return = TRUE)
      if (z$x[1] >= 0.2) {
        tabla[i, 1] <- rownames(matriz)[i]
        tabla[i, 2] <- "NO HAY RECOMENDACIÓN"
      } else {
        num = length(z$ix[z$x <= z$x[1] * 1.05])
        tabla[i, 1] <- rownames(matriz)[i]
        for (j in 1:num) {
          ifelse(
            j == 1,
            rec <- names(z$x[1]),
            rec <- paste(rec, names(z$x[j]), sep = "<br/>")
          )
        }
        tabla[i, 2] <- rec
      }
    }

    tabla <- as.data.frame(tabla) |>
      rename(Zona = V1, Recomendacion = V2) |>
      arrange(Zona)
  })

  #### [R] geozonas ----
  geozonas <- reactive({
    geomunis <- esp_get_munic()
    geomunis |>
      inner_join(zonas_ine_react(), by = c("LAU_CODE" = "id")) |>
      st_as_sf() |>
      mutate(
        geometry = ifelse(
          !st_is_valid(geometry),
          st_make_valid(geometry),
          geometry
        )
      ) |>
      group_by(Zona) |>
      summarise(geometry = st_union(geometry), .groups = "drop") |>
      ungroup()
  })

  #### [R] map data ----
  map_data <- reactive({
    recommendation_table() |>
      mutate(Zona = row.names(recommendation_table())) |>
      inner_join(geozonas(), by = "Zona") |>
      relocate(Zona, geometry, .before = Pernoctaciones) |>
      st_as_sf()
  })

  ## page Data update ----

  ### [RV] data_updated ----
  data_updated_at <- reactiveVal("never")

  ### Modules events ----

  ### [O] mgt_load_res (module load) ----
  observeEvent(mgt_load_res(), {
    ## TODO: this doesn't refresh the home page data
    data_updated_at(mgt_load_res())
  })

  ## Help ----

  ### Help / About text in md ----
  output$ui_about_help_txt <- renderUI({
    req(input$pi_language)
    mdfile <- system.file(
      "app/txt",
      input$pi_language,
      "homepage.md",
      package = "evastur"
    )
    card_body(withMathJax(includeMarkdown(mdfile)))
  })

  ### Help / Manual iframe ----
  output$iframe_manual <- renderUI({
    req(input$pi_language)
    tags$iframe(
      seamless = 'seamless',
      src = paste0('www/user_manual_', input$pi_language, '.html'),
      class = 'manuals',
      frameBorder = 0
    )
  })
}
