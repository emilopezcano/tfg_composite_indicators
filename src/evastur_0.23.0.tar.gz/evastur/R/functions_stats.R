## Functions to compute statistics

#' Scale indicator values
#'
#'
#'
#' @param .data data frame with the values to scale
#' @param scaling_method one of zscore, refvalue, minmax
#' @param scaling_type one of geo, time
#' @param refvalueq quantile for the refvalue
#'
#' @returns a data.frame with the original value in column value_ori and the value column scaled
#' @export
#'
#' @examples
#' tbl(con2, "ft_indicators") |>
#' filter(indicator_id == "IECO0002", date == "2021-01-01") |>
#'   rename(value = indicator_value) |>
#'   inner_join(tbl(con2, "dt_indicators") |>
#'                select(indicator_id, indicator_direction),
#'              by = "indicator_id") |>
#'   collect() |>
#'   scale_indicator(scaling_method = "zscore",
#'                   scaling_type = "geo")
#' tbl(con2, "ft_indicators") |>
#' filter(indicator_id == "IECO0002", geo_id == "ES-CM") |>
#'   rename(value = indicator_value) |>
#'   inner_join(tbl(con2, "dt_indicators") |>
#'                select(indicator_id, indicator_direction),
#'              by = "indicator_id") |>
#'   collect() |>
#'   scale_indicator(scaling_method = "zscore",
#'                   scaling_type = "time")
#' tbl(con2, "ft_indicators") |>
#' filter(indicator_id %in% c("IECO0001", "IECO0002"), geo_id == "ES-CM") |>
#'   rename(value = indicator_value) |>
#'   inner_join(tbl(con2, "dt_indicators") |>
#'                select(indicator_id, indicator_direction),
#'              by = "indicator_id") |>
#'   collect() |>
#'   scale_indicator(scaling_method = "zscore",
#'                   scaling_type = "time") -> res
#'
#' tbl(con2, "ft_indicators") |>
#' filter(indicator_id == "ICUS0001", date == "2021-01-01") |>
#'   rename(value = indicator_value) |>
#'   inner_join(tbl(con2, "dt_indicators") |>
#'                select(indicator_id, indicator_direction),
#'              by = "indicator_id") |>
#'   collect() |>
#'   scale_indicator(scaling_method = "zscore",
#'                   scaling_type = "geo")
#'
#' tbl(con2, "ft_indicators") |>
#' filter(indicator_id == "ICUS0001", geo_id == "PRT") |>
#'   rename(value = indicator_value) |>
#'   inner_join(tbl(con2, "dt_indicators") |>
#'                select(indicator_id, indicator_direction),
#'              by = "indicator_id") |>
#'   collect() |>
#'   scale_indicator(scaling_method = "zscore",
#'                   scaling_type = "time")

scale_indicator <- function(.data, scaling_method, scaling_type, refvalueq) {
  scaled_df <- split(.data, .data$indicator_id) |>
    purrr::map(
      ~ {
        if (scaling_type == "geo") {
          df0 <- .x |>
            group_by(date)
        } else if (scaling_type == "time") {
          df0 <- .x |>
            group_by(geo_id)
        } else {
          stop("Incorrect scaling type ", scaling_type)
        }
        df1 <- df0 |>
          mutate(value_ori = value)
        if (scaling_method == "zscore") {
          df1 |>
            mutate(value = scale_zscore(value)) |>
            mutate(
              value = ifelse(indicator_direction == "-", value * (-1), value)
            ) |>
            ungroup()
        } else if (scaling_method == "minmax") {
          df1 |>
            mutate(value = scale_maxmin(value)) |>
            mutate(
              value = ifelse(indicator_direction == "-", 1 - value, value)
            ) |>
            ungroup()
        } else if (scaling_method == "refvalue") {
          ## TODO: implement refvalue from bt_indicator_source
          df1 |>
            mutate(value = scale_refvalue(value, q = refvalueq)) |>
            mutate(
              value = ifelse(indicator_direction == "-", 1 - (value - 1), value)
            ) |>
            ungroup()
        } else {
          stop("Incorrect scaling method ", scaling_method)
        }
      }
    ) |>
    bind_rows()
  return(structure(
    scaled_df,
    scaling_method = scaling_method,
    scaling_type = scaling_type
  ))
}

#' Scale values using the max-min method
#'
#' @param x vector of values
#'
#' @returns vector of scaled values
#' @export
#'
#' @examples
#' scale_maxmin(c(1:5, NA))
scale_maxmin <- function(x) {
  if (length(x) < 2) {
    warning("Not enough data for scaling")
    return(NA)
  }
  if (diff(range(x, na.rm = TRUE) == 0)) {
    warning(
      "Constant data, it is not possible to scale with the max-min method"
    )
    return(NA)
  }
  (x - min(x, na.rm = TRUE)) / diff(range(x, na.rm = TRUE))
}

#' Scale values using the zscore method
#'
#' @param x vector of values
#'
#' @returns vector of scaled values
#' @export
#'
#' @examples
#' scale_zscore(c(1:5, NA))
scale_zscore <- function(x) {
  if (length(x) < 2) {
    message("Not enough data for scaling")
    return(NA)
  }
  if (is.na(sd(x, na.rm = TRUE)) | is.nan(sd(x, na.rm = TRUE))) {
    message("Missing data, it is not possible to scale with the z-score method")
    return(NA)
  }
  if (sd(x, na.rm = TRUE) == 0) {
    message(
      "Constant data, it is not possible to scale with the z-score method"
    )
    return(NA)
  }
  (x - mean(x, na.rm = TRUE)) / sd(x, na.rm = TRUE)
}

#' Scale using the reference value method
#'
#' @param x vector of values
#' @param q quantile to get reference value
#' @param refvalue absolute reference value
#'
#' @returns vector of transformed values
#' @export
#'
#' @examples
#'
#' \dontrun{
#' scale_refvalue(c(1:5, NA))
#' scale_refvalue(c(1:5, NA), 2)
#' }
#' scale_refvalue(c(1:5, NA), 0.5)
scale_refvalue <- function(x, q = NULL, refvalue = NULL) {
  if (is.null(q) & is.null(refvalue)) {
    stop("One of q or refvalue are needed")
  }
  if (!is.null(q) & (q < 0 | q > 1)) {
    stop("q must be between 0 and 1")
  }
  if (is.null(refvalue)) {
    refvalue <- quantile(x, q, na.rm = TRUE)
  }
  return(structure(x / refvalue, refvalue = refvalue))
}


#' Compute composite indicators
#'
#' Computes the composite indicators for each dimension and the global one
#'
#' @param .data data.frame with scaled values by indicator
#' @param subdimension not implemented yet
#' @param selected_source selected source of indicators
#'
#' @returns a data.frame with a row per dimension (including global), period and
#' destination and the value of the composite indicator
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2014-01-01"
#' to_date <- "2023-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "PRT"
#' selected_group <- "WLD"
#' selected_date <- "2015-01-01"
#' to_date <- "2022-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = NULL,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#' cindicators <- compute_composite_indicator(tindicators,
#'    selected_source = "EVASTUR")
compute_composite_indicator <- function(
  .data,
  subdimension = FALSE,
  selected_source
) {
  if (!is.data.frame(.data) | nrow(.data) == 0) {
    message("No data for composite indicator")
    return(NULL)
  }
  dfdims <- tbl(con2, "bt_indicator_subdimension") |>
    filter(source_id == selected_source) |>
    inner_join(
      tbl(con2, "dt_dimensions") |>
        select(dimension_id, dimension_order, dimension_weight),
      by = "dimension_id"
    ) |>
    inner_join(
      tbl(con2, "dt_indicators") |>
        select(indicator_id, indicator_weight),
      by = "indicator_id"
    ) |>
    arrange(dimension_order) |>
    select(-subdimension_id, -source_id) |>
    collect()

  df0 <- .data |>
    inner_join(
      dfdims,
      by = c("indicator_id", "dimension_id")
    )
  if (subdimension == TRUE) {
    ## TODO: to be implemented
    stop("Not implemented yet")
  } else {
    dfdim <- df0 |>
      group_by(
        dimension_id,
        geo_id,
        total,
        date,
        period_id,
        dimension_weight
      ) |>
      summarise(
        value = weighted.mean(value, indicator_weight, na.rm = TRUE),
        .groups = "drop"
      ) |>
      mutate(global = FALSE)

    dfglobal <- dfdim |>
      group_by(geo_id, total, date, period_id) |>
      summarise(
        value = weighted.mean(value, dimension_weight, na.rm = TRUE),
        .groups = "drop"
      ) |>
      mutate(dimension_id = "GLOBAL", global = TRUE)

    df <- bind_rows(
      dfdim |>
        select(-dimension_weight),
      dfglobal
    )
  }
  return(
    structure(
      df,
      scaling_method = attr(.data, "scaling_method"),
      scaling_type = attr(.data, "scaling_type")
    )
  )
}


#' Trend of the last data in a series of indicators
#'
#' @param .data a data.frame with composite indicators
#' @param .total if TRUE, the total indicator is considered
#' @param .global if TRUE, the global indicator is considered
#' @param .geo_id if total  is FALSE, then a geography must be provided
#' @param .dimension_id  if .global is false, then a dimension must be provided
#'
#' @returns A value with the KPI
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#' kpi_trend(dfcomp, .total = TRUE, .global = TRUE)
#' kpi_trend(dfcomp, .total = FALSE, .global = TRUE,
#'   .geo_id = "ESP")
#' kpi_trend(dfcomp, .total = FALSE, .global = FALSE,
#'  .geo_id = "ESP", .dimension_id = "ECO")
kpi_trend <- function(
  .data,
  .total,
  .global,
  .geo_id = NULL,
  .dimension_id = NULL
) {
  .data |>
    filter(
      total == .total,
      global == .global,
      {
        if (!.total & !is.null(.geo_id)) {
          geo_id == .geo_id
        } else {
          TRUE
        }
      },
      {
        if (!.global & !is.null(.dimension_id)) {
          dimension_id == .dimension_id
        } else {
          TRUE
        }
      }
    ) |>
    arrange(date) |>
    slice_tail(n = 2) |>
    pull(value) |>
    diff()
}

#' Value of the last data in a series of indicators
#'
#' @param .data a data.frame with composite indicators
#' @param .total if TRUE, the total indicator is considered
#' @param .global if TRUE, the global indicator is considered
#' @param .geo_id if total  is FALSE, then a geography must be provided
#' @param .dimension_id  if .global is false, then a dimension must be provided
#'
#' @returns A value with the KPI
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#' kpi_last(dfcomp, .total = TRUE, .global = TRUE)
#' kpi_last(dfcomp, .total = FALSE, .global = TRUE,
#'   .geo_id = "ESP")
#' kpi_last(dfcomp, .total = FALSE, .global = FALSE,
#'  .geo_id = "ESP", .dimension_id = "ECO")
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "minmax",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#' kpi_last(dfcomp, .total = TRUE, .global = TRUE)

kpi_last <- function(
  .data,
  .total,
  .global,
  .geo_id = NULL,
  .dimension_id = NULL
) {
  .data |>
    filter(
      total == .total,
      global == .global,
      {
        if (!.total & !is.null(.geo_id)) {
          geo_id == .geo_id
        } else {
          TRUE
        }
      },
      {
        if (!.global & !is.null(.dimension_id)) {
          dimension_id == .dimension_id
        } else {
          TRUE
        }
      }
    ) |>
    arrange(date) |>
    slice_tail(n = 1) |>
    pull(value)
}

#' Position of the last data in a series of indicators
#'
#' @param .data a data.frame with composite indicators
#' @param .total if TRUE, the total indicator is considered
#' @param .global if TRUE, the global indicator is considered
#' @param .geo_id if total  is FALSE, then a geography must be provided
#' @param .dimension_id  if .global is false, then a dimension must be provided
#'
#' @returns A value with the KPI
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = "2022-12-31")
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#' kpi_rank(dfcomp, .total = TRUE, .global = TRUE)
#' kpi_rank(dfcomp, .total = FALSE, .global = TRUE,
#'   .geo_id = "ESP")
#' kpi_rank(dfcomp, .total = FALSE, .global = FALSE,
#'  .geo_id = "ESP", .dimension_id = "ECO")
#' kpi_rank(dfcomp, .total = FALSE, .global = FALSE,
#'  .geo_id = "RUS", .dimension_id = "ECO")
kpi_rank <- function(
  .data,
  .total,
  .global,
  .geo_id = NULL,
  .dimension_id = NULL
) {
  ranked_row <- .data |>
    filter(
      total == .total,
      global == .global,
      {
        if (!.total & !is.null(.geo_id)) {
          geo_id == .geo_id
        } else {
          TRUE
        }
      },
      {
        if (!.global & !is.null(.dimension_id)) {
          dimension_id == .dimension_id
        } else {
          TRUE
        }
      }
    ) |>
    arrange(desc(value)) |>
    tibble::rowid_to_column() |>
    arrange(date) |>
    slice_tail(n = 1)

  if (is.na(ranked_row$value)) {
    NA
  } else {
    ranked_row |>
      pull(rowid)
  }
}

#' Distance of the last data to its maximum in a series of indicators
#'
#' @param .data a data.frame with composite indicators
#' @param .total if TRUE, the total indicator is considered
#' @param .global if TRUE, the global indicator is considered
#' @param .geo_id if total  is FALSE, then a geography must be provided
#' @param .dimension_id  if .global is false, then a dimension must be provided
#'
#' @returns A value with the KPI
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#' kpi_dist(dfcomp, .total = TRUE, .global = TRUE)
#' kpi_dist(dfcomp, .total = FALSE, .global = TRUE,
#'   .geo_id = "ESP")
#' kpi_dist(dfcomp, .total = FALSE, .global = FALSE,
#'  .geo_id = "ESP", .dimension_id = "ECO")
kpi_dist <- function(
  .data,
  .total,
  .global,
  .geo_id = NULL,
  .dimension_id = NULL
) {
  df <- .data |>
    filter(
      total == .total,
      global == .global,
      {
        if (!.total & !is.null(.geo_id)) {
          geo_id == .geo_id
        } else {
          TRUE
        }
      },
      {
        if (!.global & !is.null(.dimension_id)) {
          dimension_id == .dimension_id
        } else {
          TRUE
        }
      }
    ) |>
    arrange(date)
  df |>
    slice_tail(n = 1) |>
    pull(value) -
    max(df$value)
}

#' Predict indicators
#'
#' Predict the indicators for a given time horizon.
#'
#' @note
#' The scaling_method argument is used just to control the bounds of the predictions.
#' The input .data should be already scaled.
#' If an indicator has no values for the last period(s), it is also predicted
#' for that period(s), in order to predict the new values in the coming periods.
#' Those predicted values for actual periods (i.e., periods that have values for
#' other indicators) are not included in the output.
#'
#' @param .data data frame with scaled indicators for several years and one
#' only geographical area, and including the dimension_id
#' @param h_pred prediction horizon
#' @param pred_method Prediction method. Currently accepting "auto.arima" or "ma"
#' @param scaling_method scaling type
#' @param source source of indicators, needed to compute composite indicators
#'
#' @return A list with two elements:
#' * ind: predictions of the individual indicators
#' * dim: predictions of the dimensions
#'
#' @export
#' @examplesIf interactive
#' inds <- con2 |>
#'   tbl("ft_indicators") |>
#'   distinct(indicator_id) |>
#'   pull()
#' dfind <- get_ft_data(
#'       data_type = "indicator",
#'       .nuts_level = 0,
#'       type_id = inds,
#'       # country = "ES",
#'       .source_id = "EVASTUR",
#'       from_date = "2013-01-01",
#'       to_date = "2022-12-31"
#'     )
#'     suppressMessages({
#'       tindicators <- get_transformed_indicators(
#'         dfind,
#'         scaling_method = "zscore",
#'         scaling_type = "time",
#'         refvalueq = NULL,
#'         geo_total = "WLD"
#'       )
#'     })
#' predict_indicators(tindicators |> filter(geo_id == "ESP"))
predict_indicators <- function(
  .data,
  h_pred = 3,
  pred_method = "auto.arima",
  scaling_method = "zscore",
  source = "EVASTUR"
) {
  if (!all(.data$period_id == "Y")) {
    warning("Prediction is only available for year periods")
    return(
      structure(tibble(), message = "Periods are not years", status = "error")
    )
  }
  if (any(is.na(.data$value))) {
    warning(
      "There are missing data for indicators: ",
      paste(
        .data |>
          filter(is.na(value)) |>
          distinct(indicator_id) |>
          pull(indicator_id),
        collapse = ", "
      )
    )
  }

  geo_id <- .data |> distinct(geo_id) |> pull()
  if (length(geo_id) > 1) {
    warning("Prediction is only available for one geographical area")
    return(structure(tibble(), message = "Periods are not years"))
  }

  # use year periods
  .data <- .data |>
    mutate(period = lubridate::year(date))

  ## identify last year in the df
  last_period <- max(.data$period)

  # make predictions for all indicators with values in the input .data
  inds <- .data |>
    group_by(indicator_id, dimension_id) |>
    summarize(allna = all(is.na(value))) |>
    filter(!allna)
  data_ind_pred <- map2(
    inds$indicator_id,
    inds$dimension_id,
    ~ {
      ## default prediction horizon is 3
      h_pred_aux <- h_pred

      # make time series data
      ts_data <- .data |>
        filter(indicator_id == .x) |>
        select(value, period) |>
        arrange(period)
      ts_data <- ts(ts_data$value, start = ts_data$period[1], frequency = 1)
      ## check if last year of dimension is the same as in the whole df
      if (max(time(ts_data)) < last_period) {
        h_pred_aux <- h_pred_aux + (last_period - max(time(ts_data)))
      }
      ## fit prediction model
      if (pred_method == "auto.arima") {
        fit_arima <- forecast::auto.arima(ts_data)
      } else if (pred_method == "ma") {
        d <- ceiling(0.3 * length(ts_data))
        fit_arima <- arima(ts_data, order = c(0, 0, d))
      } else {
        stop("Prediction method not accepted")
      }
      # Forecast the next years
      forecast_arima <- forecast::forecast(fit_arima, h = h_pred_aux)
      istotal <- .data |> slice(1) |> pull(total)
      ## df forecast
      tibble::tibble(
        indicator_id = .x,
        dimension_id = .y,
        geo_id = geo_id,
        period = as.numeric(time(forecast_arima$mean)),
        value = as.numeric(forecast_arima$mean),
        period_id = "Y",
        total = istotal
      ) |>
        mutate(date = paste0(period, "-01-01"))
    }
  ) |>
    bind_rows() |>
    filter(year(as.Date(date)) > last_period)

  ## TODO: check if use MA or autoarima
  ## decide d parameter
  # n_years <- length(ts_data)
  # d <- ceiling(0.3*n_years)

  # ## fit MA model
  # fit_arima <- arima(ts_data, order = c(0, 0, d))

  ## fix if prediction exceeds theorical limits
  ## TODO: check this assumptions
  if (scaling_method == "zscore") {
    data_ind_pred$value[data_ind_pred$value < -4] <- -4
    data_ind_pred$value[data_ind_pred$value > 4] <- 4
  } else if (scaling_method == "minmax") {
    data_ind_pred$value[data_ind_pred$value < 0] <- 0
    data_ind_pred$value[data_ind_pred$value > 1] <- 1
  } else if (scaling_method == "refvalue") {
    data_ind_pred$value[data_ind_pred$value < 0] <- 0
    data_ind_pred$value[data_ind_pred$value > 100] <- 100
  }

  ## Compute composite indicators predictions
  data_dimen_pred <- compute_composite_indicator(
    data_ind_pred |> filter(year(as.Date(date)) > last_period),
    selected_source = source
  )

  ## Return a list with indicators and dimensions predictions
  return(list(ind = data_ind_pred, dim = data_dimen_pred))
}

#' Compute counterfactuals
#'
#' Given a dataset with past data and predicted data, returns the needed intervention to reach a change.
#'
#' @param .data data.frame with both the actual and predicted data. It can contain
#' dimension values (first layer) or indicators data (second layer)
#' @param year year to get the target.
#' @param epsilon target as increment of the target year.
#' @param mu_l Minimum number of dimensions/indicators to modify.
#' @param mu_u Maximum number of dimensions/indicators to modify.
#' @param m optimization parameter
#' @param k optimization parameter
#' @param scaling_method Scaling method. It is used just to set maximum values.
#' @param layer Optimization layer: 1 = dimensions, 2 = indicators.
#' @param var_no_modify vector with the variables that cannot be modified.
#'
#' @return A data.frame with the values of the dimensions/variables that reach the target.
#' @export
#'
#' @examples
#'
#' inds <- con2 |>
#' tbl("ft_indicators") |>
#' distinct(indicator_id) |>
#' pull()
#' dfind <- get_ft_data(
#' data_type = "indicator",
#' .nuts_level = 0,
#' type_id = inds,
#' # country = "ES",
#' .source_id = "EVASTUR",
#' from_date = "2013-01-01",
#' to_date = "2022-12-31"
#' )
#' suppressMessages({
#' tindicators <- get_transformed_indicators(
#'   dfind,
#'   scaling_method = "zscore",
#'   scaling_type = "time",
#'   refvalueq = NULL,
#'   geo_total = "WLD"
#' )
#' })
#' cindicators <- compute_composite_indicator(
#' tindicators,
#' selected_source = "EVASTUR"
#' ) |>
#' filter(total)
#' predicted_indicators <- predict_indicators(
#' # tindicators |> filter(geo_id == "ESP")
#' tindicators |> filter(total)
#' )
#' datadim <- .data <- bind_rows(cindicators, predicted_indicators$dim) |>
#'   filter(dimension_id != "GLOBAL")
#' compute_intervention(datadim, 2023, 0.1, 1, 3)
compute_intervention <- function(
  .data,
  year,
  epsilon,
  mu_l,
  mu_u,
  m = 50000,
  k = 0,
  scaling_method = "zscore",
  layer = 1,
  var_no_modify = NULL
) {
  # fix max_incr_porc and max_value depending on scaling_method
  switch(
    scaling_method,
    "minmax" = {
      max_incr_porc <- 0.3
      max_value <- 1
    },
    "refvalue" = {
      max_incr_porc <- 0.6
      max_value <- 2
    },
    "zscore" = {
      max_incr_porc <- 0.3
      max_value <- 3
    }
  )

  # fix column names depending on the layer
  type <- ifelse(layer == 1, "dimension", "indicator")
  var_interest <- paste(type, "id", sep = "_")
  wcolumn <- paste(type, "weight", sep = "_")
  lcolumn <- paste(type, "label", sep = "_")
  ncolumn <- paste(type, "name", sep = "_")

  # extract predicted year data
  data_pred <- .data |>
    filter(year(as.Date(date)) == year)

  data_npred <- .data |>
    filter(year(as.Date(date)) < year)

  # values of year selected
  X_year <- data_pred |> pull(value)

  # variables for counterfactuals
  variables <- data_pred |> pull(all_of(var_interest))

  # Number of variables
  p <- length(variables)

  ### identify which variables cannot be modified
  # first, check if the input dimension/indicador does not exist in the dataset
  var_no_modify_unknown <- var_no_modify[!(var_no_modify %in% variables)]
  if (length(var_no_modify_unknown) != 0) {
    warning(paste0(
      "'",
      var_no_modify_unknown,
      "' is not a ",
      tolower(var_interest),
      " of the dataset."
    ))

    # definitive var_no_modify_unknown
    var_no_modify <- var_no_modify[var_no_modify %in% variables]
  }

  ## error if none variable can be modified
  if (length(var_no_modify) == length(variables)) {
    warning(paste0(
      "no ",
      tolower(var_interest),
      " can be modified according to parameter var_no_modify."
    ))
    return(res = NULL)
  }

  ## get index of variables that cannot be modified
  index_var_no_modify <- c(1:p)[variables %in% var_no_modify]

  ## get index of variables that can be modified
  index_var_modify <- c(1:p)[!(variables %in% var_no_modify)]

  # get std of every dimension until the year selected
  std_vector <- data_npred |>
    select(-date, -period_id) |>
    group_by(across(all_of(var_interest))) |>
    summarise(sd = sd(value, na.rm = TRUE)) |>
    arrange(match(across(all_of(var_interest)), variables)) |>
    pull(sd)

  # Handle NA values in std_vector (occurs when insufficient historical data)
  # Replace NA with mean of non-NA values, or a small default if all are NA
  if (any(is.na(std_vector))) {
    mean_sd <- mean(std_vector, na.rm = TRUE)
    # If all values are NA, use a small default value
    if (is.na(mean_sd) || mean_sd == 0) {
      mean_sd <- 0.1
    }
    std_vector[is.na(std_vector)] <- mean_sd
  }

  ## define max_incr for each dimension
  max_incr <- max_incr_porc * std_vector

  # weights to compute global
  ## TODO: FIX, USE ACTUAL WEIGHTS
  # weight_v = rep(1 / p, p)
  weight_v <- data_pred |> pull(all_of(wcolumn))
  weight_v <- weight_v / sum(weight_v)

  # Create the optimization model
  model <- MIPModel() |>
    # Define continuous variables beta[j] for j in 1 to p
    add_variable(beta[j], j = 1:p, type = "continuous") |>
    # betas are positive
    set_bounds(beta[j], lb = 0, j = 1:p) |>

    # Define binary variables delta[j] for j in 1 to p
    add_variable(delta[j], j = 1:p, type = "binary") |>

    ## add contrains of variables to not modify
    add_constraint(beta[j] == 0, j = index_var_no_modify) |>
    add_constraint(delta[j] == 0, j = index_var_no_modify) |>

    # variables to modify: Add constraints for each beta and delta variable
    add_constraint(beta[j] <= max_incr[j], j = index_var_modify) |>
    add_constraint((-m * delta[j]) <= beta[j], j = index_var_modify) |>
    add_constraint(beta[j] <= (m * delta[j]), j = index_var_modify) |>
    add_constraint(beta[j] + X_year[j] <= max_value, j = 1:p) |>
    add_constraint(beta[j] >= 0.01 * delta[j], j = index_var_modify) |>

    # Add constraints for the sum of delta variables
    add_constraint(sum_expr(delta[j], j = 1:p) <= mu_u) |>
    add_constraint(sum_expr(delta[j], j = 1:p) >= mu_l) |>

    # Add epsilon constraint
    add_constraint(
      sum_expr(
        (X_year[j] + beta[j]) * weight_v[j] - (X_year[j] * weight_v[j]),
        j = 1:p
      ) >=
        epsilon
    ) |>

    # Define the objective function (minimizing beta values and adding penalty term k * sum(delta))
    set_objective(
      sum_expr(beta[j], j = 1:p) + k * sum_expr(delta[j], j = 1:p),
      sense = "min"
    )

  # Solve the model using the glpk solver
  result <- solve_model(model, with_ROI(solver = "symphony"))

  # check in factible solution
  status <- result$status

  # Extract results
  if (status == "success") {
    beta_values <- get_solution(result, beta[j])
    # Combine beta and delta into a dataframe
    res <- data.frame(
      var = variables,
      beta = beta_values$value,
      col = data_pred |> pull(dimension_color),
      label = data_pred |> pull(all_of(lcolumn)),
      name = data_pred |> pull(all_of(ncolumn))
    )
  } else {
    res = NULL
  }

  # Return results and increase
  return(res)
}

#' Compute the intervention in layer 2
#'
#' After computing the interventions in layer 1 (dimensions), this function
#' gets the interventions for each individual indicator, possibly removing some
#' of them
#'
#' @param counterfactual_dimen  Result of the intervention computation for layer 1
#' (dimendions)
#' @param data_npred data.frame with the composite indicators series used for the prediction.
#' @param data_pred List with the predictions, both the individual indicators and the
#' composite indicators. It is used to get the codes of the available dimensions.
#' @param data_ind_original Indicators data in its original scale
#' @param actionable_indicators Indicators suitable to be actioned
#' @param .scaling_method Scaling method used in the transformations
#' @param lan Language
#' @source Source of indicators
#'
#' @returns a data.frame with an attribute `unfeasible_dims` which is a
#' named vector with the dimensions that couldn't reach a solution.
#' @export
#'
#' @examples
#' inds <- con2 |>
#'   tbl("ft_indicators") |>
#'   distinct(indicator_id) |>
#'   pull()
#' dfind <- get_ft_data(
#'   data_type = "indicator",
#'   .nuts_level = 0,
#'   type_id = inds,
#'    country = "ES",
#'   .source_id = "EVASTUR",
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' )
#' suppressMessages({
#'   tindicators <- get_transformed_indicators(
#'     dfind,
#'     scaling_method = "zscore",
#'     scaling_type = "time",
#'     refvalueq = NULL,
#'     geo_total = "WLD"
#'   )
#' })
#' cindicators <- compute_composite_indicator(
#'   tindicators,
#'   selected_source = "EVASTUR"
#' ) |>
#'   filter(total)
#' predicted_indicators <- predict_indicators(
#'    #' tindicators |> filter(geo_id == "ESP")
#'   tindicators |> filter(total)
#' )
#' pred_dim <- predicted_indicators$dim
#' pred_ind <- predicted_indicators$ind
#' datadim <- bind_rows(cindicators, pred_dim) |>
#'   filter(dimension_id != "GLOBAL") |>
#'   inner_join(
#'     con2 |>
#'       tbl("dt_dimensions") |>
#'       inner_join(
#'         tbl(con2, "bt_source_subdimension") |>
#'           distinct(source_id, dimension_id) |>
#'           filter(source_id == "EVASTUR"),
#'         by = "dimension_id"
#'       ) |>
#'       select(dimension_id, dimension_weight, dimension_color) |>
#'       inner_join(
#'         tbl(con2, "lt_dimensions") |>
#'           filter(dimension_lang == "es") |>
#'           select(dimension_id, dimension_label, dimension_name),
#'         by = "dimension_id"
#'       ) |>
#'       collect(),
#'     by = "dimension_id"
#'   )
#'  # intervention <- compute_intervention(datadim, 2023, 0.3, 1, 3)
#' intervention <- compute_intervention(datadim, 2023, 0.17, 1, 3)
#'  # intervention <- compute_intervention(datadim, 2023, 0.1, 1, 3)
#' dims_int <- intervention |>
#'   filter(beta != 0) |>
#'   pull(var)
#' inds_int <- predicted_indicators$ind |>
#'   distinct(indicator_id, dimension_id) |>
#'   filter(dimension_id %in% dims_int) |>
#'   pull(indicator_id)
#' dataind <- bind_rows(tindicators, pred_ind) |>
#'   filter(dimension_id == "ECO") |>
#'   inner_join(
#'     con2 |>
#'       tbl("dt_indicators") |>
#'       select(indicator_id, indicator_weight) |>
#'       collect(),
#'     by = "indicator_id"
#'   ) |>
#'   inner_join(
#'     con2 |>
#'       tbl("dt_dimensions") |>
#'       inner_join(
#'         tbl(con2, "bt_source_subdimension") |>
#'           distinct(source_id, dimension_id) |>
#'           filter(source_id == "EVASTUR"),
#'         by = "dimension_id"
#'       ) |>
#'       select(dimension_id, dimension_weight, dimension_color) |>
#'       collect(),
#'     by = "dimension_id"
#'   ) |>
#'   inner_join(
#'     tbl(con2, "lt_indicators") |>
#'       filter(indicator_lang == "es") |>
#'       select(indicator_id, indicator_label, indicator_name) |>
#'       collect(),
#'     by = "indicator_id"
#'   )
#' intl2 <- get_intervention_layer2(
#'   counterfactual_dimen = intervention,
#'   data_npred = cindicators,
#'   data_pred = predicted_indicators,
#'   data_ind_original = tindicators,
#'   actionable_indicators = inds_int,
#'   .scaling_method = "zscore",
#'   lan = "es",
#'   source = "EVASTUR"
#' )
get_intervention_layer2 <- function(
  counterfactual_dimen,
  data_npred,
  data_pred,
  data_ind_original,
  actionable_indicators,
  .scaling_method,
  lan,
  source
) {
  ## Initialise unfeasible dims
  df_unfeasible_dims <- tibble::tibble(
    var = character(),
    name = character(),
    color = character()
  )

  ## check which dimensions need to be modified
  dimensions_modified <- counterfactual_dimen$var[
    counterfactual_dimen$beta != 0
  ]

  ## initialite df to store counterfactuals at indicator level
  df_counterfactual_ind <- tibble::tibble()

  ## loop over each of the dimensions to modify
  for (dimension in dimensions_modified) {
    ## bind indicators values and predictions
    dataind <- bind_rows(data_ind_original, data_pred$ind) |>
      filter(dimension_id == dimension) |>
      ## TODO: Check if there is a more effective way outside the function
      inner_join(
        con2 |>
          tbl("dt_indicators") |>
          select(indicator_id, indicator_weight) |>
          collect(),
        by = "indicator_id"
      ) |>
      inner_join(
        con2 |>
          tbl("dt_dimensions") |>
          inner_join(
            tbl(con2, "bt_source_subdimension") |>
              distinct(source_id, dimension_id) |>
              filter(source_id == source),
            by = "dimension_id"
          ) |>
          select(dimension_id, dimension_weight, dimension_color) |>
          collect(),
        by = "dimension_id"
      ) |>
      inner_join(
        tbl(con2, "lt_indicators") |>
          filter(indicator_lang == lan) |>
          select(indicator_id, indicator_label, indicator_name) |>
          collect(),
        by = "indicator_id"
      )

    year_selected <- min(year(as.Date(data_pred$dim$date)))
    epsilon <- counterfactual_dimen$beta[counterfactual_dimen$var == dimension]
    indicator_candidates <- dataind |>
      distinct(indicator_id) |>
      pull()
    var_no_modify <- setdiff(indicator_candidates, actionable_indicators)
    mu_u <- length(indicator_candidates) - length(var_no_modify)

    if (mu_u <= 0) {
      df_unfeasible_dims <- dplyr::bind_rows(
        df_unfeasible_dims,
        tibble::tibble(
          var = dimension,
          name = unique(dataind$dimension_id),
          color = unique(dataind$dimension_color)
        )
      )
      message(paste0(
        "No hay indicadores accionables en la dimensión ",
        dimension
      ))
      next # Saltar al siguiente dimension
    }

    ## compute counterfactual
    counterfactual_ind <- compute_intervention(
      .data = dataind,
      year = year_selected,
      epsilon = epsilon,
      mu_l = 1,
      mu_u = mu_u,
      m = 50000,
      k = 0,
      scaling_method = .scaling_method,
      layer = 2,
      var_no_modify = var_no_modify
    )

    ## if there is solution in counterfactuals
    if (
      !is.null(counterfactual_ind) && nrow(as_tibble(counterfactual_ind)) > 0
    ) {
      ## transform the increment achieved to Value
      values_pred <- dataind |>
        filter(year(as.Date(date)) == year_selected) |>
        pull(value)
      counterfactual_ind_value <- values_pred + counterfactual_ind$beta

      ## add values pred and values counterfactual to df
      counterfactual_ind$value_pred <- values_pred
      counterfactual_ind$value_counterfactual <- counterfactual_ind_value

      ## save achieved counterfactual
      counterfactual_ind$Dimension <- dimension
      df_counterfactual_ind <- dplyr::bind_rows(
        df_counterfactual_ind,
        counterfactual_ind
      )
    } else {
      df_unfeasible_dims <- dplyr::bind_rows(
        df_unfeasible_dims,
        tibble::tibble(
          var = dimension,
          name = unique(dataind$dimension_id),
          color = unique(dataind$dimension_color)
        )
      )

      ## TODO: return message to app??
      message(paste0(
        "No hay ninguna intervención en los indicadores que alcance el cambio deseado en la dimensión ",
        dimension
      ))
    }
  }

  ## if there is solution in counterfactuals, complete the df for solution
  if (nrow(df_counterfactual_ind) > 0) {
    df_counterfactual_ind <- df_counterfactual_ind |>
      select(Dimension, everything())

    ## get unscaled values
    df_counterfactual_ind_unscaled <- unscale_intervention(
      df_to_unscale = df_counterfactual_ind,
      data_ind_original = data_ind_original,
      scale_selection = .scaling_method,
      base_value_t = 100
    )

    ## select only those rows with beta != 0
    df_counterfactual_ind_unscaled <- df_counterfactual_ind_unscaled[
      df_counterfactual_ind_unscaled$beta != 0,
    ]

    res_counterfactual_ind <- df_counterfactual_ind_unscaled
  } else {
    res_counterfactual_ind <- tibble::tibble()
  }

  attr_unfeasible <- df_unfeasible_dims |>
    tibble::column_to_rownames("var") |>
    as.list()

  structure(
    res_counterfactual_ind,
    unfeasible_dims = attr_unfeasible
  )
}

#' Unscale values of intervention results
#'
#' Given the results of the layer 2 intevention, i.e., for indicators,
#' this function returns the unscaled values of the indicators to intervine,
#' along with the scaled and unscaled intervention values.
#'
#'
#' @param df_to_unscale A data.frame with the structure of the result of get_intervention_layer2().
#' @param data_ind_original A data.frame with the original indicators values.
#' @param scale_selection The applied scaling method.
#' @param base_value_t Base value for that scaling method.
#'
#' @return A data.frame with the scaled and unscaled values.
#' @export
#'
#' @examples
#' inds <- con2 |>
#'    tbl("ft_indicators") |>
#'    distinct(indicator_id) |>
#'    pull()
#'  dfind <- get_ft_data(
#'    data_type = "indicator",
#'    .nuts_level = 0,
#'    type_id = inds,
#'     country = "ES",
#'    .source_id = "EVASTUR",
#'    from_date = "2013-01-01",
#'    to_date = "2022-12-31"
#'  )
#'  suppressMessages({
#'    tindicators <- get_transformed_indicators(
#'      dfind,
#'      scaling_method = "zscore",
#'      scaling_type = "time",
#'      refvalueq = NULL,
#'      geo_total = "WLD"
#'    )
#'  })
#'  cindicators <- compute_composite_indicator(
#'    tindicators,
#'    selected_source = "EVASTUR"
#'  ) |>
#'    filter(total)
#'  predicted_indicators <- predict_indicators(
#'     #' tindicators |> filter(geo_id == "ESP")
#'    tindicators |> filter(total)
#'  )
#'  pred_dim <- predicted_indicators$dim
#'  pred_ind <- predicted_indicators$ind
#'  datadim <- bind_rows(cindicators, pred_dim) |>
#'    filter(dimension_id != "GLOBAL") |>
#'    inner_join(
#'      con2 |>
#'        tbl("dt_dimensions") |>
#'        inner_join(
#'          tbl(con2, "bt_source_subdimension") |>
#'            distinct(source_id, dimension_id) |>
#'            filter(source_id == "EVASTUR"),
#'          by = "dimension_id"
#'        ) |>
#'        select(dimension_id, dimension_weight, dimension_color) |>
#'        inner_join(
#'          tbl(con2, "lt_dimensions") |>
#'            filter(dimension_lang == "es") |>
#'            select(dimension_id, dimension_label, dimension_name),
#'          by = "dimension_id"
#'        ) |>
#'        collect(),
#'      by = "dimension_id"
#'    )
#'  intervention <- compute_intervention(datadim, 2023, 0.17, 1, 3)
#'  dims_int <- intervention |>
#'    filter(beta != 0) |>
#'    pull(var)
#'  inds_int <- predicted_indicators$ind |>
#'    distinct(indicator_id, dimension_id) |>
#'    filter(dimension_id %in% dims_int) |>
#'    pull(indicator_id)
#'  dataind <- bind_rows(tindicators, pred_ind) |>
#'    filter(dimension_id == "ECO") |>
#'    inner_join(
#'      con2 |>
#'        tbl("dt_indicators") |>
#'        select(indicator_id, indicator_weight) |>
#'        collect(),
#'      by = "indicator_id"
#'    ) |>
#'    inner_join(
#'      con2 |>
#'        tbl("dt_dimensions") |>
#'        inner_join(
#'          tbl(con2, "bt_source_subdimension") |>
#'            distinct(source_id, dimension_id) |>
#'            filter(source_id == "EVASTUR"),
#'          by = "dimension_id"
#'        ) |>
#'        select(dimension_id, dimension_weight, dimension_color) |>
#'        collect(),
#'      by = "dimension_id"
#'    ) |>
#'    inner_join(
#'      tbl(con2, "lt_indicators") |>
#'        filter(indicator_lang == "es") |>
#'        select(indicator_id, indicator_label, indicator_name) |>
#'        collect(),
#'      by = "indicator_id"
#'    )

#'    intl2 <- get_intervention_layer2(
#'     counterfactual_dimen = intervention,
#'     data_npred = cindicators,
#'     data_pred = predicted_indicators,
#'     data_ind_original = tindicators,
#'     actionable_indicators = inds_int,
#'     .scaling_method = "zscore",
#'     lan = "es",
#'     source = "EVASTUR"
#'   )

#'  unscale_intervention(intl2,
#'   tindicators,
#'   "zscore",
#'   base_value_t = 100)
unscale_intervention <- function(
  df_to_unscale,
  data_ind_original,
  scale_selection,
  base_value_t = 100
) {
  ## TODO: use base_value_t by indicator in unscale_intervention
  ## list of indicators in the df_to_unscale
  indicators <- df_to_unscale$var

  ## initialize vectors to store unscale_values
  unscaled_values_pred <- c()
  unscaled_values_counterfactual <- c()

  ## loop over vars to get unscaled values
  for (indicator in indicators) {
    ## extract indicator from the two dataframes implied in the function
    df_to_unscale_indicador <- df_to_unscale |> filter(var == indicator)
    data_ind_original_indicator <- data_ind_original |>
      filter(indicator_id == indicator)

    ## extract values to unscale
    value_pred <- df_to_unscale_indicador$value_pred
    value_counterfactual <- df_to_unscale_indicador$value_counterfactual

    ## extract direction
    dir <- unique(data_ind_original_indicator$indicator_direction)

    ## unscale depending on the scaling method selected
    if (scale_selection == "zscore") {
      ## reverse if needed depending on the sign
      value_pred <- case_when(
        dir == "-" ~ -1 * value_pred,
        dir == "+" ~ value_pred
      )
      value_counterfactual <- case_when(
        dir == "-" ~ -1 * value_counterfactual,
        dir == "+" ~ value_counterfactual
      )

      ## unscale
      mean <- mean(data_ind_original_indicator$value_ori, na.rm = TRUE)
      sd <- sd(data_ind_original_indicator$value_ori, na.rm = TRUE)
      unscaled_value_pred <- value_pred * sd + mean
      unscaled_value_counterfactual <- value_counterfactual * sd + mean
    } else if (scale_selection == "minmax") {
      ## reverse if needed depending on the sign
      value_pred <- case_when(
        dir == "-" ~ 1 - value_pred,
        dir == "+" ~ value_pred
      )
      value_counterfactual <- case_when(
        dir == "-" ~ 1 - value_counterfactual,
        dir == "+" ~ value_counterfactual
      )

      ## unscale
      max <- max(data_ind_original_indicator$value_ori, na.rm = TRUE)
      min <- min(data_ind_original_indicator$value_ori, na.rm = TRUE)
      unscaled_value_pred <- value_pred * (max - min) + min
      unscaled_value_counterfactual <- value_counterfactual * (max - min) + min
    } else if (scale_selection == "refvalue") {
      ## reverse if needed depending on the sign
      value_pred <- case_when(
        dir == "-" ~ base_value_t - value_pred,
        dir == "+" ~ value_pred
      )
      value_counterfactual <- case_when(
        dir == "-" ~ base_value_t - value_counterfactual,
        dir == "+" ~ value_counterfactual
      )

      ## unscale
      max <- max(data_ind_original_indicator$value_ori, na.rm = TRUE)
      unscaled_value_pred <- value_pred * max / base_value_t
      unscaled_value_counterfactual <- value_counterfactual * max / base_value_t
    }

    ## add value to unscaled values vectors
    unscaled_values_pred <- c(unscaled_values_pred, unscaled_value_pred)
    unscaled_values_counterfactual <- c(
      unscaled_values_counterfactual,
      unscaled_value_counterfactual
    )
  }

  ## add unscaled values to df_to_unscale
  df_to_unscale$unscaled_value_pred <- unscaled_values_pred
  df_to_unscale$unscaled_value_counterfactual <- unscaled_values_counterfactual

  return(df_to_unscale)
}

#' Statistical mode
#'
#' Function to calculate the statistical mode, that is, the most frequent value. In case of tie, it returns the (rounded) median of the most frequent values
#'
#'
#' @param x
#'
#' @returns Statistical mode
#' @export
#'
#' @examples
#' x <- c(1,2,3,4)
#' mode_stat(x)
#' x <- c(1)
#' mode_stat(x)
#' x <- c(1,1,3,4)
#' mode_stat(x)
#' x <- c(1,1,3,3)
#' mode_stat(x)
mode_stat <- function(x) {
  unique_x <- unique(x)
  freqs <- tabulate(match(x, unique_x))
  max_freq <- max(freqs)
  most_common <- unique_x[freqs == max_freq]
  round(median(most_common))
}

#' Transform data according to period_id desired
#'
#' This functions takes variable data and aggregate (if possible) to a given destination period
#' from an origin period, for example, from months to years.
#'
#' @param variable_data Data frame from df_input filtered according to the indicator to compute and already aggregated by geo
#' @param .period_id Desired aggregation period (parent)
#' @param origin_period_id Period of origin of the data (children)
#' @param required_obs Number of children observations needed
#'
#' @return Transformed data
#' @export
#'
#' @examples
#' \dontrun{
#' dvar_nuts0 <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 0,
#'   type_id = "VVOL0001",
#'   from_date = "2013-01-01",
#'   .source_id = NULL,
#'   to_date = "2022-01-01"
#' )
#' filter_variable_data_by_period(
#'   variable_data = dvar_nuts0,
#'   .period_id = "Y",
#'   origin_period_id = "Y",
#'   1
#' )
#' dvar_nuts2 <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 2,
#'   country = "ES",
#'   type_id = "VVOL0001",
#'   from_date = "2013-01-01",
#'   .source_id = NULL,
#'   to_date = "2022-01-01"
#' )
#' filter_variable_data_by_period(
#'   variable_data = dvar_nuts2,
#'   .period_id = "Y",
#'   origin_period_id = "M",
#'   required_obs = 12
#' )
#' }
filter_variable_data_by_period <- function(
  variable_data,
  .period_id,
  origin_period_id,
  required_obs
) {
  # Format date as first day of selected period (.period_id)
  filter_variable_data <- variable_data |>
    mutate(
      date = case_when(
        .period_id == "Y" ~ floor_date(as_date(date), "year"),
        .period_id == "S" ~ {
          month <- month(as_date(date))
          semester_start_month <- if_else(month <= 6, 1, 7)
          make_date(year(as_date(date)), semester_start_month, 1)
        },
        .period_id == "Q" ~ floor_date(as_date(date), "quarter"),
        .period_id == "M" ~ floor_date(as_date(date), "month")
      ),
      period_id = .period_id
    )

  # Do we have the required observations by group?
  counts <- filter_variable_data |>
    group_by(variable_id, date, geo_id) |>
    summarise(n_obs = n(), .groups = "drop") |>
    mutate(.missing = n_obs < required_obs)

  # If for one variable there is no information of all required time periods,
  # the rest of its values
  # for that period are set to NA
  filter_variable_data |>
    left_join(
      counts |> select(variable_id, date, geo_id, .missing),
      by = c("variable_id", "date", "geo_id")
    ) |>
    mutate(
      variable_value = ifelse(.missing, NA, variable_value)
    ) |>
    select(-.missing)
}

#' Compute STI indicators
#'
#' This function computes the value of the indicators using the formula and
#' the data of the variables that build the indicator.
#'
#' @param dfind df from DB containing indicators metadata.
#' @param dfvar df from DB containing variables, geo_id, date, source_id.
#' It is used to compute the indicator
#' @param .period_id target period for computing the indicator (e.g., year, quarter)
#' @param .country ISO2 code of the country if scope is national
#' @param .nuts_level NUTS level
#'
#' @returns dataframe with the computed indicators
#' @export
#'
#' @examples
#' \dontrun{
#' all_vars <- tbl(con2, "bt_indicator_variable") |>
#'   semi_join(
#'     tbl(con2, "bt_indicator_source") |>
#'       filter(source_id == "EVASTUR"),
#'     by = "indicator_id"
#'   ) |>
#'   pull(variable_id)
#' df_vars <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 0,
#'   type_id = all_vars,
#'   country = NULL,
#'   .source_id = NULL,
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' )
#' df_inds <- df_vars |>
#'   distinct(variable_id) |>
#'   pull() |>
#'   get_computable_inds() |>
#'   get_indicators_metadata()
#' compute_indicators(df_inds, df_vars)
#' }
compute_indicators <- function(
  dfind,
  dfvar,
  .period_id = "Y",
  .country = NULL,
  .nuts_level = 0,
  .geo_group_id = "WLD"
) {
  1:nrow(dfind) |>
    map(
      ~ {
        dfind_row <- dfind |> slice(.x)
        indicator_data <- list(
          indicator_formula = dfind_row |> pull(indicator_formula),
          variable_names = dfind_row |> pull(vars) |> purrr::pluck(1),
          funs_geo = dfind_row |> pull(funs_geo) |> purrr::pluck(1),
          funs_time = dfind_row |> pull(funs_time) |> purrr::pluck(1)
        )

        # Keep rows in df_input containing the variables defining the desired indicator to compute
        variable_data <- dfvar |>
          filter(variable_id %in% indicator_data$variable_names) |>
          # If there are more than one source per combination of variable_id, date, period_id and geo_id
          # We combine them using the mean
          group_by(variable_id, date, period_id, geo_id) |>
          summarise(
            variable_value = mean(variable_value, na.rm = TRUE),
            .groups = "drop"
          ) |>
          mutate(total = FALSE)
        # We get the number of required observations from bt_periods table
        origin_period_id <- variable_data$period_id[1] # Assuming the period_id is the same for all geo_id
        required_obs <- get_bt_periods_parents() |>
          filter(period_id == origin_period_id, period_parent == .period_id) |>
          pull(n_periods)
        if (length(required_obs) == 0) {
          stop(
            "There is no correspondence between origin_period_id and .period_id."
          )
        }
        # Aggregate data by geo_id: Get total of geo_ids
        aggregated_variables_geo <- map2(
          indicator_data$variable_names,
          indicator_data$funs_geo,
          ~ aggregate_variable_by_geo(
            variable_data,
            .x,
            .y,
            geo_group_id = .geo_group_id
          )
        ) |>
          bind_rows() |>
          mutate(total = TRUE)
        # Join total value with individual geo values
        variable_data_with_total <- bind_rows(
          variable_data,
          aggregated_variables_geo
        )

        ## Transform the date according to the period_id
        filtered_data <- filter_variable_data_by_period(
          variable_data_with_total,
          .period_id,
          origin_period_id,
          required_obs
        )

        # Aggregate data by period_id
        aggregated_variables_time <- map2(
          indicator_data$variable_names,
          indicator_data$funs_time,
          ~ aggregate_variable_by_time(filtered_data, .x, .y)
        ) |>
          bind_rows()
        # Compute indicator value
        compute_indicator_value(
          aggregated_variables_time,
          dfind_row$indicator_id,
          indicator_data$indicator_formula
        ) |>
          mutate(
            source_id = "EVASTUR",
            period_id = .period_id,
            date = as.character(date)
          ) |>
          select(
            indicator_id,
            date,
            period_id,
            geo_id,
            indicator_value,
            source_id,
            total
          )
      }
    ) |>
    bind_rows() |>
    structure(country = .country, nuts_level = .nuts_level)
}

#' Aggregate the values of the variables by geo
#'
#' @param variable_data data.frame with variable values
#' @param variable_id Variable to aggregate
#' @param aggregation_function Function to use for aggregation
#' @param geo_group_id Id of the aggregation geographical area
#'
#' @returns dataframe with the aggregated value by geo of the variable
#' @export
#'
#' @examples
#' df_vars <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 0,
#'   type_id = "VVOL0001",
#'   country = NULL,
#'   .source_id = NULL,
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' )
#' aggregate_variable_by_geo(
#'   variable_data = df_vars,
#'   "VVOL0001",
#'   aggregation_function = "sum",
#'  geo_group_id = 'WLD'
#' )
aggregate_variable_by_geo <- function(
  variable_data,
  .variable_id,
  aggregation_function,
  geo_group_id
) {
  variable_data |>
    filter(variable_id == .variable_id) |>
    group_by(date, period_id, variable_id) |>
    summarise(
      variable_value = match.fun(aggregation_function)(
        variable_value,
        na.rm = TRUE
      ), # Once the imputation function is made, set to FALSE
      geo_id = geo_group_id,
      .groups = "drop"
    )
}

#' Aggregate the value of the variables by time period
#'
#' @param variable_data data.frame with variable values.
#' @param variable_id Code of the variable to aggregate.
#' @param aggregation_function Function to use for aggregation
#'
#' @returns dataframe with the aggregated values of the variable by time period
#' @export
#'
#' @examples
#' #' df_vars <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 2,
#'   type_id = "VVOL0001",
#'   country = "ES",
#'   .source_id = NULL,
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' )
#' aggregate_variable_by_time(
#'   variable_data = df_vars,
#'   "VVOL0001",
#'   aggregation_function = "mean"
#' )
aggregate_variable_by_time <- function(
  variable_data,
  .variable_id,
  aggregation_function
) {
  variable_data |>
    filter(variable_id == .variable_id) |>
    group_by(date, geo_id, variable_id, total) |>
    summarise(
      variable_value = match.fun(aggregation_function)(variable_value),
      .groups = "drop"
    )
}

#' Compute indicator value
#'
#' @param aggregated_variables Variable data aggregated by geo and time
#' @param .indicator_id Indicator ID to be computed
#' @param indicator_formula Formula for the computation of the indicator via variable values
#' @param source_id_value Source ID for consistency with old ft_indicators table
#' and possible filters
#'
#' @returns data.frame with the value of the indicator and all the associated data
#' @export
#'
#' @examples
#' df_ag <- df_vars <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 2,
#'   type_id = c("VVOL0001", "VGAS0001"),
#'   country = "ES",
#'   .source_id = NULL,
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' ) |>
#'   aggregate_variable_by_time(
#'     c("VVOL0001", "VGAS0001"),
#'     aggregation_function = "mean"
#'   )
#' compute_indicator_value(
#'   aggregated_variables = df_ag,
#'   .indicator_id = "IECO0001",
#'   indicator_formula = "VGAS0001/VVOL0001"
#' )
compute_indicator_value <- function(
  aggregated_variables,
  .indicator_id,
  indicator_formula,
  source_id_value = 'EVASTUR'
) {
  wide_format <- aggregated_variables |>
    select(date, geo_id, variable_value, variable_id, total) |>
    pivot_wider(names_from = variable_id, values_from = variable_value) |>
    mutate(
      indicator_id = .indicator_id,
      indicator_value = eval(parse(text = indicator_formula))
    ) |>
    ungroup()

  wide_format <- wide_format |>
    mutate(.source_id = source_id_value) # Add .source_id column

  return(wide_format)
}

#' Impute a single column using Amelia
#'
#' This function imputes missing values in a specified column of a data frame using the Amelia package. It selects the most correlated variables to use as predictors for the imputation process, performs logarithmic transformations on specified variables if needed, and calculates the overimputation R2 value to assess the quality of the imputation.
#'
#' @param df_base the transpose of the original data frame, retaining only the variable values, date, and geolocation (NUTS) identifiers.
#' @param col_name the name of the variable to be imputed
#' @param log_vars a list with the variables that need a logarithm transformation
#' @param options list of options for specifying the values of correlation and the number of imputed datasets to be created by Amelia
#'
#' @returns data frame with the imputed variable and 3 attributes
#'
#' @export
#'
#' @examples
#' \dontrun{
#' df_input <- get_ft_data(
#'   data_type = "variable",
#'   .nuts_level = 2,
#'   type_id = "VVOL0001",
#'   country = "ES",
#'   .source_id = NULL,
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' ) |>
#'   select(geo_id, date, variable_id, variable_value) |>
#'   pivot_wider(names_from = variable_id, values_from = variable_value)
#'
#' log_vars <- c("VVOL0001")
#' options <- list(
#'   corr_values = c(0.8, 0.6, 0.4),
#'   m = 5
#' )
#' imputed_column <- impute_col(
#'   df_base = df_input,
#'   col_name = "VVOL0001",
#'   log_vars = log_vars,
#'   options = options
#' )  
#' }
impute_col <- function(df_base, col_name, log_vars, options) {
  if (!is.numeric(df_base[[col_name]])) {
    # return(structure(df_base[[col_name]], method = "Skipped-No numeric", R2 = NA, timestamp = Sys.time(), correlation = ""))
    return(structure(
      df_base[[col_name]],
      method = "Skipped-No numeric",
      R2 = NA,
      timestamp = Sys.time()
    ))
  }

  # Step 3.1: for each column choose the most correlated vars

  corr_matrix <- df_base |>
    select(where(is.numeric)) |>
    cor(use = "pairwise.complete.obs")

  ordered_corr <- sort(abs(corr_matrix[col_name, ]), decreasing = TRUE)

  corr_values <- sort(options$corr_values, decreasing = TRUE)
  corr_vars <- names(ordered_corr[1:10])

  if (all(!is.na(corr_values) & corr_values >= 0 & corr_values <= 1)) {
    for (v in corr_values) {
      cnt <- sum(ordered_corr > v, na.rm = TRUE)
      if (cnt >= 10) {
        corr_vars <- names(ordered_corr[
          ordered_corr > v & !is.na(ordered_corr)
        ])
      }
    }
  } else {
    warning("Los valores han de estar entre 0 y 1")
  }

  ### to try if the correlation between vars is related with the value of R2
  # if(sum(ordered_corr > options$v1) >= 10){
  #   corr_group <- "high"
  #   corr_vars <- names(ordered_corr[ordered_corr > options$v1])
  # } else if(sum(ordered_corr > options$v2) >= 10){
  #   corr_group <- "medium"
  #   corr_vars <- names(ordered_corr[ordered_corr > options$v2])
  # } else {
  #   corr_group <- "low"
  #   corr_vars <- names(ordered_corr[1:10])
  # }

  # sanitize corr_vars: remove NA/empty and keep only columns present in df_base
  corr_vars <- corr_vars[!is.na(corr_vars) & nzchar(corr_vars)]
  corr_vars <- intersect(corr_vars, names(df_base))
  # fallback: if no correlated vars remain, pick up to 10 numeric predictors (excluding target)
  if (length(corr_vars) == 0) {
    candidate <- setdiff(names(df_base)[sapply(df_base, is.numeric)], col_name)
    corr_vars <- head(candidate, 10)
  }
  # safe select: any_of tolerates missing names
  df_corr_vars <- df_base |>
    dplyr::select(geo_id, date, dplyr::any_of(corr_vars))

  # Step 3.2: Delete completely empty rows

  df_clean_input <- df_corr_vars |>
    filter(if_any(-c(geo_id, date), ~ !is.na(.))) |>
    as.data.frame()

  if (any(is.na(df_clean_input[[col_name]]))) {
    # Step 3.3: run the algorithm

    ## Indicate which vars need log transformation
    trans_vars <- log_vars[log_vars %in% intersect(log_vars, corr_vars)]

    if (!purrr::is_empty(trans_vars)) {
      imputation_amelia <- Amelia::amelia(
        df_clean_input,
        m = options$m,
        ts = "date",
        cs = "geo_id",
        logs = trans_vars,
        p2s = 0,
        empri = 0.015 * nrow(df_clean_input),
        print.imputations = FALSE,
        max.resample = 50
      )
    } else {
      imputation_amelia <- Amelia::amelia(
        df_clean_input,
        m = options$m,
        ts = "date",
        cs = "geo_id",
        p2s = 0,
        empri = 0.015 * nrow(df_clean_input),
        print.imputations = FALSE,
        max.resample = 50
      )
    }

    # Step 3.4: Calculate Overimputation R2
    pdf(NULL)
    on.exit(dev.off())

    precision <- Amelia::overimpute(imputation_amelia, var = col_name)

    on.exit()
    dev.off()

    value_r2 <- round(cor(precision$orig, precision$mean.overimputed)^2, 3)

    # Step 3.5: Create the final imputed dataset with the m imputed datasets created by Amelia

    options(scipen = 999)

    # 3.5.1. each of the final imputed data is the result of the mean of the m imputed data
    df_imp_mean <- imputation_amelia$imputations |>
      map(~ select(.x, all_of(c("geo_id", "date", col_name)))) |>
      bind_rows() |>
      group_by(geo_id, date) |>
      summarise(imp_value = mean(!!sym(col_name)), .groups = "drop")

    # 3.5.2. replace de NAs from the original dataset with the imputed data
    df_imp_col <- df_base |>
      left_join(df_imp_mean, by = c("geo_id" = "geo_id", "date" = "date")) |>
      mutate("{col_name}" := coalesce(!!sym(col_name), imp_value)) |>
      pull(!!sym(col_name))

    #return(structure(df_imp_col, method = "Amelia", R2 = value_r2, timestamp = Sys.time(), correlation = corr_group))
    return(structure(
      df_imp_col,
      method = "Amelia",
      R2 = value_r2,
      timestamp = Sys.time()
    ))
  } else {
    ## no variables with missing data

    df_imp_col <- df_base |>
      pull(!!sym(col_name))

    #return(structure(df_imp_col, method = "No method-No NAs", R2 = NA, timestamp = Sys.time(), correlation = corr_group))
    return(structure(
      df_imp_col,
      method = "No method-No NAs",
      R2 = NA,
      timestamp = Sys.time()
    ))
  }
}


#' Impute missing values in a data frame using specified method
#' 
#' This function imputes missing values in a data frame using the specified method (e.g., Amelia). It first reshapes the data frame to have variables as columns, filters out variables with excessive missing data, and then applies the imputation method to each variable individually. The function returns a list containing the imputed data frame and a summary of the imputation results for each variable.
#'
#' @param .data data frame with the variable original values from geolocation (NUTS), source and date selected
#' @param method method used for imputing the NAs of the original data frame. Choose between Amelia, etc
#' @param options list of options for specifying the values of correlation and the number of imputed datasets to be created by Amelia
#'
#' @returns a list of two data frames, the first one is the original data frame with the NAs imputed and the second one contains for each variable the overimputation R2 value, the method used, a timestamp and the level of correlation
#'
#' @export
#'
#' @examples
#' selected_nuts <- 0
#' selected_source <- "UNWTO-STATS"
#' selected_date <- "2017-01-01"
#' selected_to_date <- "2022-01-01"
#'
#' vars <- tbl(con2, "dt_variables") |>
#' pull(variable_id)
#'
#' df_var_ini <- get_ft_data("variable",
#'                           .nuts_level = selected_nuts,
#'                           type_id = vars,
#'                           .source_id = selected_source,
#'                           from_date = selected_date,
#'                           to_date = selected_to_date)
#'
#' list_dfs_imp <- impute_vars(
#'   df_var_ini,
#'   method = "Amelia",
#'   options = list(m = 5, corr_values = c(0.8, 0.7, 0.5))
#' )
#' 
#' selected_nuts <- 2
#' selected_location <- "ES"
#' selected_date <- "2017-01-01"
#' selected_to_date <- "2022-01-01"
#'
#' vars <- tbl(con2, "dt_variables") |>
#'   pull(variable_id)
#'
#' selected_source <- tbl(con2, "ft_variables") |>
#'   distinct(source_id) |>
#'   pull() |> str_subset("^INSTO", negate = TRUE)
#'
#' df_var_ini <- get_ft_data("variable",
#'                           .nuts_level = selected_nuts,
#'                           type_id = vars,
#'                           country = selected_location,
#'                           .source_id = selected_source,
#'                           from_date = selected_date,
#'                           to_date = selected_to_date)
#'
#' list_dfs_imp <- impute_vars(
#'   df_var_ini,
#'   method = "Amelia",
#'   options = list(m = 5, corr_values = c(0.8, 0.7, 0.5))
#' )
impute_vars <- function(.data, method, options) {
  df_t_vars <- .data |>
    mutate(
      geo_id = as.factor(geo_id),
      date = as.Date(date, format = "%Y-%m-%d")
    ) |>
    pivot_wider(
      id_cols = c("geo_id", "date", "period_id", "source_id"),
      names_from = "variable_id",
      values_from = "variable_value"
    ) |>
    as.data.frame()

  # Step 1: Delete the variables with a 99.7% of missing data

  df_vars_filter <- df_t_vars |>
    select(
      where(~ !is.numeric(.x)),
      where(~ is.numeric(.x) & sum(is.na(.x)) / length(.x) <= 0.997)
    )

  # safe missing-data check: build summary and test explicitly (avoid NA)
  miss_summary <- naniar::miss_var_summary(df_vars_filter)
  has_missing <- (nrow(miss_summary) > 0) &&
    any(miss_summary$n_miss > 0, na.rm = TRUE)
  if (has_missing) {
    if (method == "Amelia") {
      # Step 2: select which vars need log transformation

      log_vars <- c()
      for (i in 5:length(df_vars_filter)) {
        vals <- df_vars_filter[[i]]
        vals <- vals[!is.na(vals)]
        # need at least a few observations for skew/kurt to be meaningful
        if (length(vals) >= 3) {
          asymmetry <- e1071::skewness(vals, na.rm = TRUE)
          curtosis <- e1071::kurtosis(vals, na.rm = TRUE)
          cond <- !is.na(asymmetry) &&
            !is.na(curtosis) &&
            (asymmetry < -1 || asymmetry > 1 || curtosis < 2 || curtosis > 4)
          if (cond) {
            log_vars <- c(log_vars, names(df_vars_filter)[[i]])
          }
        }
      }

      # Step 3: Create the final dataset with the imputed values

      df_t_vars_original <- df_vars_filter
      ## Numeric columns
      numeric_vars <- names(df_t_vars_original)[sapply(
        df_t_vars_original,
        is.numeric
      )]

      ### List with every imputed variable
      list_imp_columns <- numeric_vars |>
        purrr::set_names(nm = numeric_vars) |>
        map(
          .f = ~ impute_col(
            col_name = .x,
            df_base = df_t_vars_original,
            log_vars = log_vars,
            options = options
          )
        )

      df_new_imp <- as_tibble(list_imp_columns)

      # Join th imputed variables in one final dataset
      df_values <- df_t_vars_original |>
        select(-all_of(numeric_vars)) |>
        bind_cols(df_new_imp)

      # Step 4: Create a dataset with the Overimputation R2 value, the method used for every variable and a timestamp

      df_variables <- list_imp_columns |>
        purrr::map_dfr(
          .f = ~ tibble(
            R2_overimpute = attr(.x, "R2"),
            Method = attr(.x, "method"),
            Timestamp = attr(.x, "timestamp")
            #Correlation = attr(.x, "correlation")
          ),
          .id = "variable"
        )

      return(list(df_values = df_values, df_variables = df_variables))
    } else {
      ### other imputation methods
    }
  } else {
    ## no variables with missing data after delete variables with 99.7% of missing data
    return(df_t_vars)
  }
}
