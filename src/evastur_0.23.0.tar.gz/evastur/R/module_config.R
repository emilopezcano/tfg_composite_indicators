## Module for managing configuration

config_ui <- function(id, i18n) {
  ns <- NS(id)
  tagList(
    waiter::useWaiter(),
    h2(i18n$t("Configuración de la aplicación")),
    uiOutput(ns("ui_pi_profile"), inline = TRUE),
    hr(),
    navset_card_tab(
      id = ns("config_tabs"),
      nav_panel(
        value = "config_tab_work_params",
        title = i18n$t("Parámetros de trabajo"),
        icon = icon("globe"),
        fluidRow(
          column(
            width = 6,
            # Scope - radio buttons
            fluidRow(
              column(
                width = 8,
                uiOutput(ns("geo_level_selector_config2-ui_rgb_geo_scope"))
              ),
              column(
                width = 4,
                uiOutput(ns("ui_default_geo_scope"))
              )
            ),
            # Country / Country group - picker input
            fluidRow(
              column(
                width = 8,
                uiOutput(ns("geo_level_selector_config2-ui_pi_geo_group"))
              ),
              column(
                width = 4,
                uiOutput(ns("ui_default_geo_group"))
              )
            ),
            # Territorial units - picker input
            fluidRow(
              column(
                width = 8,
                uiOutput(ns("geo_level_selector_config2-ui_pi_nuts"))
              ),
              column(
                width = 4,
                uiOutput(ns("ui_default_geo_nuts"))
              )
            ),
            # Geo selector
            fluidRow(
              column(
                width = 8,
                geo_selector_ui(ns("geo_selector2"))
              ),
              column(
                width = 4,
                uiOutput(ns("ui_default_geo_selected"))
              )
            )
          ),
          column(
            width = 6,
            uiOutput(ns("ui_ni_nperiods")),
            uiOutput(ns("ui_ni_last_period"))
          ),
        )
      ),
      nav_panel(
        value = "config_tab_computation_params",
        title = i18n$t("Parámetros de cálculos"),
        icon = icon("calculator"),
        fluidRow(
          column(
            width = 6,
            uiOutput(ns("ui_pi_scaling_type")),
            uiOutput(ns("ui_pi_scaling")),
            uiOutput(ns("ui_pi_pred_method"))
          ),
          column(
            width = 6,
            uiOutput(ns("ui_si_use_imputed_values"))
          )
        ),
      ),
      nav_panel(
        value = "config_tab_visual_params",
        title = i18n$t("Parámetros de aspecto visual"),
        icon = icon("palette"),
        fluidRow(
          column(
            width = 6,
            uiOutput(ns("ui_ni_signif")),
            uiOutput(ns("ui_ni_map_bins")),
            uiOutput(ns("ui_theme_picker"))
          )
        )
      ),
      nav_panel(
        value = "config_tab_app_params",
        title = i18n$t("Parámetros de aplicación"),
        icon = icon("cog"),
        fluidRow(
          column(
            width = 6,
            uiOutput(ns("ui_ti_app_title")),
            hr(),
            uiOutput(ns("ui_pi_source"))
          ),
          column(
            width = 6,
            actionButton(
              ns("ab_load"),
              label = i18n$t("Volver a cargar perfil"),
              icon = icon("folder-open")
            ),
            uiOutput(ns("ui_ab_save")),
            uiOutput(ns("ui_ab_delete")),
            uiOutput(ns("ui_ti_profile"))
          )
        )
      )
    )
  )
}

#' Configuration module
#'
#' @param id Module instance id
#' @param i18n Language object
#' @param profile Configuration profile
#'
#' @returns A list with the element result equal to TRUE
#'
#' @export
#' @examplesIf interactive
#' config_app()
config_server <- function(id, i18n, profile) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns

      ## ui_geo_selector1 ----
      geo_selector_ui(ns("geo_selector1"))

      ## geo_scope, geo_group_id, geo_nuts_id, geo_country_id ----
      ### [M] geo_level_selector_controls ----
      geo_level_selector_controls <- geo_level_selector_server(
        "geo_level_selector_config2",
        i18n = i18n,
        lan = reactive({
          i18n()$get_translation_language()
        })
      )

      ## [R] geo_selected ----
      geo_selected <- reactive({
        if (session$userData$config()$geo_scope == "N") {
          session$userData$config()$geo_nuts_selected
        } else {
          session$userData$config()$geo_country_selected
        }
      })
      ## [M] geo_selector_control ----
      geo_selector_control <- geo_selector_server(
        "geo_selector2",
        i18n = i18n,
        lan = reactive({
          i18n()$get_translation_language()
        }),
        geo_scope = reactive({
          session$userData$config()$geo_scope
        }),
        geo_group = reactive({
          ifelse(
            session$userData$config()$geo_scope == "N",
            session$userData$config()$geo_country_id,
            session$userData$config()$geo_group_id
          )
        }),
        nuts_level_inner = reactive({
          session$userData$config()$geo_nuts_id
        }),
        geo_selected = geo_selected
      )

      ## ui_default_geo_scope ----
      output$ui_default_geo_scope <- renderUI({
        div(
          class = "defaultvals",
          session$userData$config_db()$geo_scope
        )
      })

      ## ui_default_geo_group ----
      output$ui_default_geo_group <- renderUI({
        div(
          class = "defaultvals",
          ifelse(
            session$userData$config_db()$geo_scope == "N",
            session$userData$config_db()$geo_country_id,
            session$userData$config_db()$geo_group_id
          )
        )
      })

      ## ui_default_geo_nuts ----
      output$ui_default_geo_nuts <- renderUI({
        div(
          class = "defaultvals",
          ifelse(
            session$userData$config_db()$geo_scope == "N",
            session$userData$config_db()$geo_nuts_id,
            ""
          )
        )
      })

      ## ui_default_geo_selected ----
      output$ui_default_geo_selected <- renderUI({
        div(
          class = "defaultvals",
          ifelse(
            session$userData$config_db()$geo_scope == "N",
            session$userData$config_db()$geo_nuts_selected,
            session$userData$config_db()$geo_country_selected
          )
        )
      })

      ### [O] geo_level_selector_controls$rgb_geo_scope ----
      observeEvent(geo_level_selector_controls$rgb_geo_scope(), {
        session$userData$config(mutate(
          session$userData$config(),
          geo_scope = geo_level_selector_controls$rgb_geo_scope()
        ))
      })

      ### [O] geo_level_selector_controls$pi_geo_group ----
      observeEvent(geo_level_selector_controls$pi_geo_group(), {
        if (session$userData$config()$geo_scope == "S") {
          session$userData$config(mutate(
            session$userData$config(),
            geo_group_id = geo_level_selector_controls$pi_geo_group()
          ))
          if(geo_level_selector_controls$pi_geo_group() == "INSTO") {
            sel = "INSTO"
          } else {
            sel = "EVASTUR"
          }
          session$userData$config(mutate(
            session$userData$config(),
            source = sel
          ))
          updatePickerInput(inputId = "pi_source", selected = sel)
        } else if (session$userData$config()$geo_scope == "N") {
          session$userData$config(mutate(
            session$userData$config(),
            geo_country_id = geo_level_selector_controls$pi_geo_group()
          ))
        }
        #   if (geo_level_selector_controls$pi_geo_group() == "INSTO") {
        #     sel = "INSTO"
        #   } else {
        #     sel = "EVASTUR"
        #   }
        #      session$userData$config(mutate(
        #       session$userData$config(),
        #       source = sel
        #     ))
        #   updatePickerInput(inputId = "pi_source", selected = sel)
      })

      ### [O] geo_selector_control$pi_geo_selected ----
      observeEvent(geo_selector_control$pi_geo_selected(), {
        if (session$userData$config()$geo_scope == "S") {
          session$userData$config(mutate(
            session$userData$config(),
            geo_country_selected = geo_selector_control$pi_geo_selected()
          ))
        } else if (session$userData$config()$geo_scope == "N") {
          session$userData$config(mutate(
            session$userData$config(),
            geo_nuts_selected = geo_selector_control$pi_geo_selected()
          ))
        }
      })

      ### [O] geo_level_selector_controls$pi_nuts ----
      observeEvent(geo_level_selector_controls$pi_nuts(), {
        session$userData$config(mutate(
          session$userData$config(),
          geo_nuts_id = geo_level_selector_controls$pi_nuts()
        ))
      })

      ## ui_profile ----
      output$ui_pi_profile <- renderUI({
        pickerInput(
          ns("pi_profile"),
          label = i18n()$t("Perfil"),
          choices = con2 |> tbl("ct_app") |> pull(profile_id),
          selected = session$userData$config()$profile_id
        )
      })

      ## [O] ui_profile ----
      observeEvent(input$pi_profile, {
        session$userData$profile(input$pi_profile)
      })

      ## ui_ti_profile ----
      output$ui_ti_profile <- renderUI({
        textInput(
          ns("ti_profile"),
          label = "",
          value = input$pi_profile
        ) |>
          tooltip(
            i18n()$t("Cambiar nombre para crear un nuevo perfil"),
            options = list(trigger = "hover")
          )
      })

      ## nperiods ----
      ### ni_nperiods ----
      output$ui_ni_nperiods <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              numericInput(
                inputId = ns("ni_nperiods"),
                label = i18n()$t("Número de periodos"),
                value = session$userData$config()$nperiods
              ),
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                # style = "height: 100%; display: flex; align-items: flex-end; min-height: 70px; color:gray; font-style: italic;",
                session$userData$config_db()$nperiods
              )
            )
          )
        )
      })

      ### [O] ni_nperiods ----
      observeEvent(input$ni_nperiods, {
        waiter::waiter_show(
          html = tagList(
            h4(i18n()$t("Actualizando configuración...")),
            waiter::spin_1()
          )
        )
        session$userData$config(mutate(
          session$userData$config(),
          nperiods = input$ni_nperiods
        ))
        # Schedule hide after reactive updates complete
        observe({
          invalidateLater(500, session)
          isolate(waiter::waiter_hide())
        })
      })

      ## last_period ----
      ### ni_last_period ----
      output$ui_ni_last_period <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              numericInput(
                inputId = ns("ni_last_period"),
                label = i18n()$t("Último periodo"),
                value = session$userData$config()$last_period
              ),
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$last_period
              )
            )
          )
        )
      })

      ### [O] ni_last_period ----
      observeEvent(input$ni_last_period, {
        waiter::waiter_show(
          html = tagList(
            h4(i18n()$t("Actualizando configuración...")),
            waiter::spin_1()
          )
        )
        session$userData$config(mutate(
          session$userData$config(),
          last_period = input$ni_last_period
        ))
        # Schedule hide after reactive updates complete
        observe({
          invalidateLater(500, session)
          isolate(waiter::waiter_hide())
        })
      })

      ## source ----
      ### pi_source ----
      output$ui_pi_source <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              pickerInput(
                ns("pi_source"),
                label = i18n()$t("Fuente"),
                choices = get_available_sources(),
                selected = session$userData$config()$source
              ),
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$source
              )
            )
          )
        )
      })

      ### [O] pi_source ----
      observeEvent(input$pi_source, {
        session$userData$config(mutate(
          session$userData$config(),
          source = input$pi_source
        ))
      })

      ## app_title ----
      ### ui_ti_app_title ----
      output$ui_ti_app_title <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              textInput(
                inputId = ns("ti_app_title"),
                label = i18n()$t("Título app"),
                value = session$userData$config()$app_title
              )
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                # style = "height: 100%; display: flex; align-items: flex-end; min-height: 70px; color:gray; font-style: italic;",
                session$userData$config_db()$app_title
              )
            )
          )
        )
      })
      ### [R] ti_app_title_debounced ----
      ti_app_title_debounced <- reactive({
        input$ti_app_title
      }) |>
        debounce(1000)

      ### [O] ti_app_title ----
      observeEvent(ti_app_title_debounced(), {
        session$userData$config(mutate(
          session$userData$config(),
          app_title = ti_app_title_debounced()
        ))
      })

      ## scaling_method ----
      ### pi_scaling - Scaling method ----
      output$ui_pi_scaling <- renderUI({
        scaling_methods <- c("zscore", "minmax", "refvalue")
        names(scaling_methods) <- c(
          i18n()$t("z score"),
          i18n()$t("Min-Max"),
          i18n()$t("Valor referencia")
        )
        tagList(
          fluidRow(
            column(
              width = 8,
              pickerInput(
                inputId = ns("pi_scaling"),
                label = i18n()$t("Método de escalado"),
                choices = scaling_methods,
                selected = session$userData$config()$scaling_method
              ) |>
                tooltip(
                  get_text("pi_scaling", i18n()$get_translation_language()),
                  options = list(trigger = "hover")
                )
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$scaling_method
              )
            )
          )
        )
      })

      ### [O] pi_scaling ----
      observeEvent(input$pi_scaling, {
        session$userData$config(mutate(
          session$userData$config(),
          scaling_method = input$pi_scaling
        ))
      })

      ## scaling_type ----
      ### pi_scaling_type - Scaling type ----
      output$ui_pi_scaling_type <- renderUI({
        scaling_types <- c("time", "geo")
        names(scaling_types) <- c(i18n()$t("Periodos"), i18n()$t("Destinos"))
        tagList(
          fluidRow(
            column(
              width = 8,
              pickerInput(
                inputId = ns("pi_scaling_type"),
                label = i18n()$t("Tipo de escalado"),
                choices = scaling_types,
                selected = session$userData$config()$scaling_type
              ) |>
                tooltip(
                  get_text(
                    "pi_scaling_type",
                    i18n()$get_translation_language()
                  ),
                  options = list(trigger = "hover")
                )
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$scaling_type
              )
            )
          )
        )
      })

      ### [O] pi_scaling_type ----
      observeEvent(input$pi_scaling_type, {
        session$userData$config(mutate(
          session$userData$config(),
          scaling_type = input$pi_scaling_type
        ))
      })

      ## pred_method ----
      ### pi_pred_method ----
      output$ui_pi_pred_method <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              pickerInput(
                ns("pi_pred_method"),
                label = i18n()$t("Método de predicción"),
                choices = setNames(
                  c("ma", "auto.arima"),
                  c(
                    cleanHTML(i18n()$t("Media móvil")),
                    cleanHTML(i18n()$t("Autoarima"))
                  )
                ),
                selected = session$userData$config()$pred_method
              ),
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$pred_method
              )
            )
          )
        )
      })

      ### [O] pi_pred_method ----
      observeEvent(input$pi_pred_method, {
        session$userData$config(mutate(
          session$userData$config(),
          pred_method = input$pi_pred_method
        ))
      })

      ## signif ----
      ### ni_signif ----
      output$ui_ni_signif <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              numericInput(
                inputId = ns("ni_signif"),
                label = i18n()$t("Cifras decimales"),
                value = session$userData$config()$signif,
                min = 0,
                max = 4
              )
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$signif
              )
            )
          )
        )
      })

      ### [O] ni_signif ----
      observeEvent(input$ni_signif, {
        waiter::waiter_show(
          html = tagList(
            h4(i18n()$t("Actualizando configuración...")),
            waiter::spin_1()
          )
        )
        session$userData$config(mutate(
          session$userData$config(),
          signif = input$ni_signif
        ))
        # Schedule hide after reactive updates complete
        observe({
          invalidateLater(500, session)
          isolate(waiter::waiter_hide())
        })
      })

      ## map_bins ----
      ### ni_map_bins ----
      output$ui_ni_map_bins <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              numericInput(
                inputId = ns("ni_map_bins"),
                label = i18n()$t("Número de intervalos (mapas)"),
                value = session$userData$config()$map_bins,
                min = 2,
                max = 10
              )
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$map_bins
              )
            )
          )
        )
      })

      ### [O] ni_map_bins ----
      observeEvent(input$ni_map_bins, {
        waiter::waiter_show(
          html = tagList(
            h4(i18n()$t("Actualizando configuración...")),
            waiter::spin_1()
          )
        )
        session$userData$config(mutate(
          session$userData$config(),
          map_bins = input$ni_map_bins
        ))
        # Schedule hide after reactive updates complete
        observe({
          invalidateLater(500, session)
          isolate(waiter::waiter_hide())
        })
      })

      ## [R] Available themes ----
      themes_db <- reactive({
        con2 |>
          tbl("ct_themes") |>
          select(theme_id, theme_original_name, primary_hex, light_hex) |>
          collect() |>
          arrange(theme_original_name)
      })

      # ui_theme_picker ----
      output$ui_theme_picker <- renderUI({
        req(themes_db())

        themes <- themes_db()

        tagList(
          fluidRow(
            column(
              width = 8,
              pickerInput(
                inputId = ns("pi_theme"),
                label = i18n()$t("Tema de color"),
                choices = setNames(themes$theme_id, themes$theme_original_name),
                selected = session$userData$config()$theme_id,
                choicesOpt = list(
                  subtext = themes$primary_hex,
                  style = paste0(
                    "background-color:",
                    themes$primary_hex,
                    ";",
                    "color: var(--bs-light);"
                  )
                ),
                width = "100%"
              ) |>
                tagAppendAttributes(class = "compact-picker-input")
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$theme_id
              )
            )
          )
        )
      })

      # [O] Change theme in session$userData
      observeEvent(input$pi_theme, {
        req(input$pi_theme)

        theme_sel <- input$pi_theme
        session$userData$config(mutate(
          session$userData$config(),
          theme_id = theme_sel
        ))

        theme_config <- get_theme_config(theme_sel)
        session$userData$config_theme(theme_config)
      })

      ## [O] Change theme in app
      observe({
        req(session$userData$config())
        req(session$userData$config()$theme_id)

        if (is.null(session$userData$config_theme())) {
          theme_config <- get_theme_config(session$userData$config()$theme_id)
          session$userData$config_theme(theme_config)
        }

        theme_config <- session$userData$config_theme()
        req(theme_config)

        theme_primary <- theme_config$primary_hex %||% "#6B8A7A" # fallback
        theme_light <- theme_config$light_hex %||% "#F2F6FF" # fallback

        new_theme <- mytheme() |>
          bs_theme_update(
            fg = theme_light,
            bg = theme_primary,
            navbar_bg = theme_primary,
            "card-bg" = theme_light,
            primary = theme_primary,
            secondary = theme_primary,
            light = theme_light
          )

        session$setCurrentTheme(new_theme)
      })

      ## [O] ab_load ----
      observeEvent(input$ab_load, {
        session$userData$config(session$userData$config_db())
        showNotification(i18n()$t("Configuración inicial cargada."))
      })

      ## ab_save ----
      output$ui_ab_save <- renderUI({
        req(input$pi_profile)
        changes <- colnames(session$userData$config_db()) |>
          map_lgl(
            ~ {
              session$userData$config()[.x] != session$userData$config_db()[.x]
            }
          ) |>
          any()
        if (input$pi_profile == "default") {
          req(input$ti_profile != "default")
          req(input$ti_profile != "")
        } else {
          req(changes)
        }
        actionButton(
          ns("ab_save"),
          label = i18n()$t("Guardar perfil"),
          icon = icon("floppy-disk")
        )
      })

      ## ab_delete ----
      output$ui_ab_delete <- renderUI({
        req(input$pi_profile)
        req(input$pi_profile != "default")
        actionButton(
          ns("ab_delete"),
          label = i18n()$t("Eliminar perfil"),
          icon = icon("trash"),
          class = "btn-outline-danger"
        )
      })

      ## [O] ab_delete ----
      observeEvent(input$ab_delete, {
        confirmSweetAlert(
          session = session,
          inputId = ns("csa_confirm_delete"),
          title = i18n()$t("¿Está seguro/a?"),
          text = i18n()$t(
            "Esta acción eliminará el perfil permanentemente de la base de datos."
          ),
          type = "warning",
          btn_labels = c(i18n()$t("Cancelar"), i18n()$t("Sí, eliminar")),
          danger_mode = TRUE
        )
      })

      ## [O] ab_save ----
      observeEvent(input$ab_save, {
        confirmSweetAlert(
          session = session,
          inputId = ns("csa_confirm_save"),
          title = i18n()$t("¿Está seguro/a?"),
          text = i18n()$t(
            "Esta acción actualizará la configuración en la base de datos."
          ),
          type = "warning",
          btn_labels = c(i18n()$t("Cancelar"), i18n()$t("Sí, actualizar")),
          danger_mode = TRUE
        )
      })

      ## [O] csa_confirm_delete ----
      observeEvent(input$csa_confirm_delete, {
        if (isTRUE(input$csa_confirm_delete)) {
          profile_to_delete <- input$pi_profile
          strsql <- paste0(
            "DELETE FROM ct_app WHERE profile_id='",
            profile_to_delete,
            "'"
          )
          print("#### strsql (DELETE)")
          print(strsql)
          tryCatch(
            {
              DBI::dbExecute(con2, strsql)
              # Switch to default profile after deletion
              session$userData$profile("default")
              # Reload configuration
              config <- get_app_config("default")
              session$userData$config_db(config)
              session$userData$config(config)
              # Update UI
              updatePickerInput(inputId = "pi_profile", selected = "default")
              showNotification(
                i18n()$t("Perfil eliminado correctamente"),
                type = "message"
              )
            },
            error = function(e) {
              showNotification(
                paste(i18n()$t("Error al eliminar el perfil:"), e$message),
                type = "error"
              )
              warning("Error deleting profile: ", e)
            }
          )
        }
      })

      ## [O] csa_confirm_save ----
      observeEvent(input$csa_confirm_save, {
        if (isTRUE(input$csa_confirm_save)) {
          df_config <- session$userData$config()
          if (input$pi_profile == input$ti_profile) {
            newvals <- colnames(df_config) |>
              map_chr(
                ~ {
                  change <- df_config[.x] != session$userData$config_db()[.x]
                  if (change) {
                    paste0(.x, "='", df_config[.x], "'")
                  } else {
                    NA
                  }
                }
              )
            newvals <- newvals[!is.na(newvals)]
            if (length(newvals) > 0 & input$pi_profile == input$ti_profile) {
              strsql <- paste0(
                "UPDATE ct_app SET ",
                paste(newvals, collapse = ", "),
                " WHERE profile_id='",
                input$pi_profile,
                "'"
              )
            } else {
              strsql <- ""
              showNotification(i18n()$t(
                "No hay ningún cambio en la configuración"
              ))
            }
          } else {
            strsql <- paste0(
              "INSERT INTO ct_app VALUES ('",
              input$ti_profile,
              "', '",
              paste(
                session$userData$config() |> select(-profile_id),
                collapse = "', '"
              ),
              "')"
            )
          }
          print("#### strsql")
          print(strsql)
          tryCatch(
            {
              DBI::dbExecute(con2, strsql)
              if (input$ti_profile != "") {
                newprof <- input$ti_profile
              } else {
                newprof <- "default"
              }
              session$userData$profile(newprof)
              session$userData$config_db(session$userData$config())
              updatePickerInput(inputId = "pi_profile", selected = newprof)
              showNotification(i18n()$t(
                "Configuración actualizada en la base de datos"
              ))
            },
            error = function(e) {
              showNotification(
                span(
                  i18n()$t("Error, no se pudo actualizar:", e)
                ),
                type = "error"
              )
              warning("Error updating config: ", e)
            }
          )
        }
      })

      ## si_use_imputed_values ----
      output$ui_si_use_imputed_values <- renderUI({
        tagList(
          fluidRow(
            column(
              width = 8,
              p(i18n()$t("Usar valores imputados")),
              checkboxInput(
                inputId = ns("si_use_imputed_values"),
                label = i18n()$t("Usar valores imputados"),
                value = session$userData$config()$use_imputed_values
              )
            #   switchInput(
            #     inputId = ns("si_use_imputed_values"),
            #     value = TRUE
            #     # label = i18n()$t("Usar valores imputados"),
            #     # onLabel = i18n()$t("Sí"),
            #     # offLabel = i18n()$t("No")
            #   )
            ),
            column(
              width = 4,
              div(
                class = "defaultvals",
                session$userData$config_db()$use_imputed_values
              )
            )
          )
        )
      })
      ### [O] si_use_imputed_values ----
      observeEvent(input$si_use_imputed_values, {
        waiter::waiter_show(
          html = tagList(
            h4(i18n()$t("Actualizando configuración...")),
            waiter::spin_1()
          )
        )
        session$userData$config(mutate(
          session$userData$config(),
          use_imputed_values = input$si_use_imputed_values
        ))
        # Schedule hide after reactive updates complete
        observe({
          invalidateLater(500, session)
          isolate(waiter::waiter_hide())
        })
      })

      # return of module ----
      return(list(
        result = reactive({
          TRUE
        })
      ))
    }
  )
}

#' @export
config_app <- function() {
  library(shiny)
  library(bslib)
  # library(evastur)
  # devtools::load_all()

  i18n <- getOption("evastur.translator")

  ui <- page_sidebar(
    tags$script(HTML(
      "
    Shiny.addCustomMessageHandler('readQueryString', function(message) {
      var params = new URLSearchParams(window.location.search);
      var valor = params.get(message.param);
      Shiny.setInputValue(message.inputId, valor);
    });
  "
    )),
    tags$script(HTML(
      "
        Shiny.addCustomMessageHandler('update-title', function(message) {
          document.title = message;
        });
      "
    )),

    window_title = "",
    title = textOutput("app_title"),
    language_pickerInput(i18n),
    config_ui("config1", i18n),
    verbatimTextOutput("txtprofile")
  )

  server <- function(input, output, session) {
    i18n <- getOption("evastur.translator")
    i18n_r <- reactive({
      selected <- session$userData$config()$lang
      if (length(selected) > 0 && selected %in% i18n$get_languages()) {
        updatePickerInput(
          inputId = "pi_language",
          selected = session$userData$config()$lang
        )
        i18n$set_translation_language(selected)
      }
      i18n
    })

    session$userData$profile <- reactiveVal("default")
    session$userData$config <- reactiveVal(NULL)
    session$userData$config_db <- reactiveVal(NULL)
    session$userData$config_theme <- reactiveVal(NULL)

    ### Update config and save initial values ----
    observe({
      profile <- session$userData$profile()
      config <- get_app_config(profile)
      session$userData$config_db <- reactiveVal(config)
      session$userData$config(config)
    })

    session$sendCustomMessage(
      "readQueryString",
      list(param = "profile", inputId = "profile_param")
    )

    observeEvent(input$profile_param, {
      if (!is.null(input$profile_param)) {
        session$userData$profile(input$profile_param)
      }
    })

    output$txtprofile <- renderPrint({
      print("session$userData$profile():")
      print(session$userData$profile())
      print("getQueryString():")
      print(getQueryString())
      print("as.list(session$userData$config()):")
      print(as.list(session$userData$config()))
    })

    config_server(
      "config1",
      i18n_r,
      profile = session$userData$profile
    )

    observe({
      req(session$userData$config())
      session$sendCustomMessage(
        "update-title",
        session$userData$config()$app_title
      )
    })

    output$app_title <- renderText({
      session$userData$config()$app_title
    })
  }

  shinyApp(ui, server, options = list(port = 3838))
}
