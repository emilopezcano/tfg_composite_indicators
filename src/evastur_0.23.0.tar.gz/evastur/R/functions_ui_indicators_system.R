## TODO: refactor in modules

#' Get indicators system UI
#'
#' Returns the UI output for the indicators system tab in exploration
#'
#' @param source source of indicators
#' @param language translation language
#' @param i18n object for translations
#' @param onlycustom if TRUE, only custom indicators are shown
#'
#' @returns An accordion object
#' @export
#'
#' @examplesIf interactive
#' get_is_ui("EVASTUR", "en", getOption("evastur.translator"), onlycustom = FALSE)
get_is_ui <- function(source, language, i18n, onlycustom) {
  df_subdimen <- get_df_dimen(source, language)
  df_dimen <- df_subdimen |>
    distinct(dimension_id, dimension_name, dimension_order, dimension_color) |>
    arrange(dimension_order)
  accordion(
    id = "ac_evastur_si",
    open = FALSE,
    1:nrow(df_dimen) |>
      map(
        ~ {
          df_ind <- get_df_ind(
            source,
            df_dimen$dimension_id[.x],
            language,
            onlycustom
          ) #|>
          #filter(indicator_active == TRUE)
          accordion_panel(
            title = span(
              df_dimen$dimension_name[.x],
              style = "font-family: 'Roboto', sans-serif;"
            ),
            icon = span(
              icon("circle", class = "fas"),
              style = paste0("color:", df_dimen$dimension_color[.x])
            ),

            value = paste0("acp_", df_dimen$dimension_id[.x]),
            class = "accordion-body-tables",
            df_ind |>
              arrange(subdimension_order, indicator_order) |>
              select(
                subdimension_label,
                indicator_name,
                indicator_direction,
                indicator_weight,
                indicator_refvalue,
                indicator_formula,
                indicator_description,
                indicator_active,
                indicator_label,
                indicator_id
              ) |>
              mutate(
                indicator_id_data = indicator_id,
                indicator_plot = indicator_id
              ) |>
              reactable(
                language = get_rt_lang(language),
                class = "exploration-tables",
                groupBy = "subdimension_label",
                defaultColDef = colDef(
                  headerClass = "exploration-header-subtable" #,
                ),
                rowStyle = function(index) {
                  if (!(df_ind |> slice(index) |> pull(indicator_active))) {
                    list(color = "#CCC")
                  }
                },
                columns = list(
                  ## indicator_active ----
                  indicator_active = colDef(
                    name = "",
                    minWidth = 30,
                    html = TRUE,
                    cell = function(value) {
                      if (!value) {
                        as.character(tooltip(
                          bs_icon(
                            "exclamation-triangle",
                            class = "text-danger"
                          ),
                          i18n$t("Desactivado")
                        ))
                      } else {
                        ""
                      }
                    }
                  ),
                  ## indicator_weight ----
                  indicator_weight = colDef(
                    name = i18n$t("Peso"),
                    minWidth = 75,
                    html = TRUE,
                    cell = function(value, index) {
                      basis <- df_ind |>
                        slice(index) |>
                        pull(indicator_weight_basis)

                      if (!is.na(basis)) {
                        info <- as.character(tooltip(
                          bs_icon("question-circle"),
                          basis
                        ))
                      } else {
                        info <- ""
                      }
                      paste0(value, info)
                    }
                  ),
                  ## indicator_direction ----
                  indicator_direction = colDef(
                    name = i18n$t("Sentido"),
                    align = "center"
                  ),
                  ## indicator_id ----
                  indicator_id = colDef(
                    name = "",
                    minWidth = 30,
                    sortable = FALSE,
                    html = TRUE,
                    cell = function(value) {
                      rt_doc_button(
                        nav_id = "btn_ind_doc",
                        nav_value = value,
                        i18n
                      )
                    }
                  ),
                  ## indicator_id_data ----
                  indicator_id_data = colDef(
                    name = "",
                    minWidth = 30,
                    sortable = FALSE,
                    html = TRUE,
                    cell = function(value) {
                      rt_doc_button(
                        nav_id = "btn_ind_data",
                        nav_value = value,
                        i18n
                      )
                    }
                  ),
                  ## subdimension_label ----
                  subdimension_label = colDef(
                    name = i18n$t("Subdimensión"),
                    minWidth = 150
                  ),
                  ## indicator_name ----
                  indicator_name = colDef(
                    name = i18n$t("Indicador"),
                    minWidth = 300
                  ),
                  ## indicator_refvalue ----
                  indicator_refvalue = colDef(
                    name = i18n$t("Valor Ref.")
                  ),
                  ## indicator_formula ----
                  indicator_formula = colDef(
                    name = i18n$t("Fórmula"),
                    style = "font-size:0.8em;",
                    # style = "font-family:monospace",
                    cell = function(index) {
                      i18n$t("Expandir")
                    },
                    details = function(index) {
                      df_var <- get_df_var(
                        df_ind$indicator_id[index],
                        language
                      ) |>
                        arrange(variable_order) |>
                        mutate(
                          variable_doc = variable_id,
                          variable_data = variable_id,
                          variable_plot = variable_id
                        )
                      ind_row <- df_ind |> slice(index)
                      tagList(
                        div(
                          paste(
                            ind_row$indicator_id,
                            ind_row$indicator_formula,
                            sep = " = "
                          ),
                          class = "formula-computer"
                        ),
                        div(
                          class = "frame-subtable",
                          df_var |>
                            select(
                              variable_id,
                              variable_name,
                              # variable_label,
                              # variable_aggregation_geo,
                              # variable_aggregation_time,
                              variable_description,
                              variable_doc,
                              variable_data,
                              variable_plot
                            ) |>
                            reactable(
                              language = get_rt_lang(language),
                              class = "exploration-tables",
                              defaultColDef = colDef(
                                headerClass = "exploration-header-subtable",
                              ),
                              columns = list(
                                ### variable_id ----
                                variable_id = colDef(
                                  name = i18n$t("Código"),
                                  maxWidth = 300,
                                ),
                                # #### unit_label ----
                                # unit_label = colDef(
                                #   name = i18n$t("Unidades")
                                # ),
                                variable_aggregation_time = colDef(
                                  name = i18n$t(
                                    "Operación de agregado temporal"
                                  ),
                                  maxWidth = 300,
                                ),
                                variable_aggregation_geo = colDef(
                                  name = i18n$t(
                                    "Operación de agregado espacial"
                                  ),
                                  maxWidth = 300,
                                ),
                                variable_name = colDef(
                                  name = "Variable",
                                  minWidth = 400
                                ),
                                variable_description = colDef(
                                  name = "",
                                  maxWidth = 30,
                                  html = TRUE,
                                  cell = function(value, index) {
                                    as.character(
                                      tooltip(
                                        bs_icon("info-circle"),
                                        paste0(
                                          df_var$variable_label[index],
                                          ": ",
                                          value
                                        )
                                      )
                                    )
                                  }
                                ),
                                variable_doc = colDef(
                                  name = "",
                                  minWidth = 30,
                                  sortable = FALSE,
                                  html = TRUE,
                                  cell = function(value, index) {
                                    rt_doc_button(
                                      nav_id = "btn_var_doc",
                                      nav_value = value,
                                      i18n
                                    )
                                  }
                                ),
                                variable_data = colDef(
                                  name = "",
                                  minWidth = 30,
                                  sortable = FALSE,
                                  html = TRUE,
                                  cell = function(value, index) {
                                    rt_doc_button(
                                      nav_id = "btn_var_data",
                                      nav_value = value,
                                      i18n
                                    )
                                  }
                                ),
                                variable_plot = colDef(
                                  name = "",
                                  minWidth = 30,
                                  sortable = FALSE,
                                  html = TRUE,
                                  cell = function(value, index) {
                                    rt_doc_button(
                                      nav_id = "btn_var_plot",
                                      nav_value = value,
                                      i18n
                                    )
                                  }
                                )
                                #
                                # variable_order = colDef(
                                #   name = ""
                                # )
                              )
                            )
                        )
                      )
                    }
                  ),
                  indicator_description = colDef(
                    name = "",
                    maxWidth = 30,
                    html = TRUE,
                    cell = function(value, index) {
                      as.character(tooltip(
                        bs_icon("info-circle"),
                        paste0(
                          "[",
                          df_ind$indicator_id[index],
                          "] ",
                          df_ind$indicator_label[index],
                          ": ",
                          value
                        )
                      ))
                    }
                  ),
                  indicator_label = colDef(
                    show = FALSE
                  ),
                  indicator_plot = colDef(
                    name = "",
                    minWidth = 30,
                    sortable = FALSE,
                    html = TRUE,
                    cell = function(value, index) {
                      rt_doc_button(
                        nav_id = "btn_ind_plot",
                        nav_value = value,
                        i18n
                      )
                    }
                  )
                )
              )
          )
        }
      )
  )
}


#' Get dimensions (and subdimensions) data.frame for indicator system explorer
#'
#' @param source source_id for indicators
#' @param language language for translations
#'
#' @returns a data.frame
#' @export
#'
#' @examples
#' get_df_dimen("EVASTUR", "en")
#' get_df_dimen("INSTO", "en")
get_df_dimen <- function(source, language) {
  tbl(con2, "dt_dimensions") |>
    inner_join(
      tbl(con2, "lt_dimensions") |>
        filter(dimension_lang == language),
      by = "dimension_id"
    ) |>
    inner_join(tbl(con2, "dt_subdimensions"), by = "dimension_id") |>
    inner_join(
      tbl(con2, "lt_subdimensions") |>
        filter(subdimension_lang == language),
      by = c("dimension_id", "subdimension_id")
    ) |>
    inner_join(
      tbl(con2, "bt_source_subdimension"),
      by = c("dimension_id", "subdimension_id")
    ) |>
    filter(source_id == source) |>
    arrange(dimension_order, subdimension_order) |>
    collect()
}


#' Get indicators data.frame by source, dimension, and language
#'
#' @param source Source of indicators.
#' @param dimension Dimension code.
#' @param language Language code.
#' @param onlycus Whether to get only customised indicators.
#'
#' @returns A data.frame with the indicators data for the selected source and dimension.
#' @export
#'
#' @examples
#' df_ind <- get_df_ind("EVASTUR", "ECO", "en", FALSE)
get_df_ind <- function(source, dimension, language, onlycus) {
  tbl0 <- tbl(con2, "dt_indicators") |>
    left_join(
      tbl(con2, "lt_indicators") |>
        filter(indicator_lang == language),
      by = c("indicator_id")
    ) |>
    inner_join(tbl(con2, "bt_indicator_subdimension"), by = "indicator_id") |>
    inner_join(
      tbl(con2, "dt_subdimensions"),
      by = c("dimension_id", "subdimension_id")
    ) |>
    inner_join(
      tbl(con2, "lt_subdimensions") |>
        filter(subdimension_lang == language),
      by = c("dimension_id", "subdimension_id")
    ) |>
    inner_join(
      tbl(con2, "bt_indicator_source"),
      by = c("indicator_id", "source_id")
    ) |>
    filter(source_id == source, dimension_id == dimension)
  if (onlycus) {
    tbl0 <- tbl0 |>
      filter(indicator_id %like% paste0("ICUS%"))
  }

  tbl0 |>
    arrange(subdimension_order, indicator_order) |>
    collect()
}

#' Get variables data.frame
#'
#' Filtered by indicators that use those variables
#'
#' @param .indicator_id code of the indicator
#' @param language Language for translations
#'
#' @return A data.frame with variables info
#' @export
#'
#' @examples
#' get_df_var("IECO0006", "en")
get_df_var <- function(.indicator_id, language) {
  tbl(con2, "dt_variables") |>
    left_join(
      tbl(con2, "lt_variables") |>
        filter(variable_lang == language),
      by = c("variable_id")
    ) |>
    inner_join(tbl(con2, "bt_indicator_variable"), by = c("variable_id")) |>
    filter(indicator_id == .indicator_id) |>
    arrange(variable_id) |>
    collect()
}


#' Button for action in reactable row
#'
#' @param nav_id row id
#' @param nav_value row value
#'
#' @return A reactable object
#' @export
#'
#' @examplesIf interactive
#' rt_doc_button(nav_id = "btn_ind_doc",
#'               nav_value = "IECO0001", getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' rt_doc_button(nav_id = "btn_var_plot",
#'               nav_value = "VGAS0001", getOption("evastur.translator")) |>
#'   htmltools::html_print()
rt_doc_button <- function(nav_id, nav_value, i18n) {
  if (str_sub(nav_id, -3L) == "doc") {
    stricon <- "file-text"
    strtitle <- "Documentación de"
    strtooltip <- "Documentación/Metodología"
  } else if (str_sub(nav_id, -4L) == "data") {
    stricon <- "database"
    strtitle <- "Datos de"
    strtooltip <- "Datos"
  } else if (str_sub(nav_id, -4L) == "plot") {
    stricon <- "graph-up"
    strtitle <- "Gráfico de"
    strtooltip <- "Gráfico"
  }
  as.character(
    tags$div(
      bs_icon(stricon) |>
        tooltip(i18n$t(strtooltip)),
      onClick = sprintf(
        "Shiny.setInputValue('%s', '%s', {priority: 'event'})",
        nav_id,
        nav_value
      ),
      title = paste(i18n$t(strtitle), nav_value, sep = " ")
    )
  )
}

#' Get indicators data data.frame
#'
#' @param .indicator_id Indicator code
#' @param language language for the geo name
#' @param fgeo filter by geo
#'
#' @returns a data.frame with indicators info
#' @export
#'
#' @examples
#' get_df_ft_indicators(.indicator_id = "ISOC0001", language = "es", fgeo = NULL)
get_df_ft_indicators <- function(.indicator_id, language, fgeo = NULL) {
  tbl0 <- tbl(con2, "ft_indicators") |>
    filter(indicator_id == .indicator_id) |>
    select(-indicator_id, -indicator_ts) |>
    inner_join(
      tbl(con2, "lt_geo") |>
        filter(geo_lang == language) |>
        select(geo_id, geo_name),
      by = "geo_id"
    )
  if (!is.null(fgeo)) {
    tbl0 <- tbl0 |>
      filter(geo_name == fgeo)
  }
  tbl0 |>
    arrange(desc(date)) |>
    collect()
}

#' Get variables data data.frame
#'
#' @param .variable_id Variable code
#' @param language language for the geo name
#' @param fgeo filter by geo
#'
#' @returns a data.frame with variables data
#' @export
#'
#' @examples
#' get_df_ft_variables(.variable_id = "VVOL0001", language = "es", "Canarias")
get_df_ft_variables <- function(.variable_id, language, fgeo) {
  tbl0 <- tbl(con2, "ft_variables") |>
    filter(variable_id == .variable_id) |>
    select(-variable_id, -variable_ts) |>
    inner_join(
      tbl(con2, "lt_geo") |>
        filter(geo_lang == language) |>
        select(geo_id, geo_name),
      by = "geo_id"
    )
  if (!is.null(fgeo)) {
    tbl0 <- tbl0 |>
      filter(geo_name == fgeo)
  }
  tbl0 |>
    arrange(desc(date)) |>
    collect()
}
