#' Data homepage indicators
#' 
#' Value of the indicators 
#' 
"datos_inicio_indicadores"

#' Meta_data censal indicators
#' 
#' Metadata from censal variables
#' 
"Meta_secc_censal"

#' Recomendation table
#' 
#' Table with tourist zone variables distances
#' 
"tabla_recomendacion"

#' Spending indicators
#' 
#' Data.frame with spending indicators
#' 
"ind_gasto"

#' Geometries of indicators destinies
#' 
#' Geometries of indicators destinies
#' 
"sources_geo"

#' Zones ID
#' 
#' ID diccionary of tourist zones
#' 
"zonas_ine"

#' Communities indicators
#' 
#' Indicators from spanish communities
#' 
"ind_com"

#' Homepage data
#' 
#' Data used in the homepage
#' 
"datos_inicio"

#' 
#' 
#' Codes and descriptions of indicators subdimensions
#' 
"datos_indicadores"

