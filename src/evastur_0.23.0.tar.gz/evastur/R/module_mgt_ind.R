## Module to manage customized indicators

## Module UI ----
mgt_ind_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(
      class = "search-input-cont",
      uiOutput(ns("ui_si_label")),
      searchInput(
        inputId = ns("si_new_indicator"),
        label = NULL,
        placeholder = "",
        btnSearch = icon("search"),
        btnReset = icon("remove"),
        width = "100%"
      )
    ),
    accordion(
      id = ns("ac_indform"),
      open = FALSE,
      multiple = FALSE,
      accordion_panel(
        title = textOutput(ns("txt_newindicator")),
        value = ns("acp_indform"),
        mgt_ind_form_ui(ns("mgt_ind_form_ui_new"))
      ),
      accordion_panel(
        title = textOutput(ns("txt_existingindicators")),
        value = ns("acp_indfound"),
        uiOutput(ns("ui_ab_edit")),
        uiOutput(ns("ui_card_ind"))
      )
    )
  )
}

#' Indicators management module
#'
#' Module to manage the indicators of a dimension, allowing to edit
#' the weight of the indicators in the calculation of the composite
#' indicator of the dimension, and to add new custom indicators to the dimension.
#' Indicators can be also deactivated.
#'
#' @param id instance id
#' @param i18n translation object
#' @param .source Source of the indicators (e.g., EVASTUR)
#' @param dim Selected dimension for which the indicators are managed. This is used to filter the indicators
#' that belong to
#' @param onlycustom Logical value indicating whether to manage only custom indicators.
#' @param selected_custom_ind Reactive value with the selected custom indicator id.
#'
#' @returns The server module object
#'
#' @export
#' @examples
#' mgt_ind_app()
mgt_ind_server <- function(id, i18n, .source, dim, onlycustom, selected_custom_ind = reactive(NULL)) {
  ## Module server ----
  moduleServer(
    id,
    function(input, output, session) {
      ## [M] Module form ----
      form_result <- mgt_ind_form_server("mgt_ind_form_ui_new", i18n, .source, selected_custom_ind)

      ## [O] ui_card_ind ----
      output$ui_card_ind <- renderUI({
        req(df_matching_inds())
        card(
          reactableOutput(session$ns("rt_indicators"))
        )
      })

      ## [O] Open accordion when a custom indicator is selected ----
      observeEvent(selected_custom_ind(), {
        req(selected_custom_ind(), selected_custom_ind() != "_NONE_")
        accordion_panel_set("ac_indform", values = session$ns("acp_indform"))
      }, ignoreInit = TRUE)

      ## [RV] row_selected ----
      row_selected <- reactive({
        # IMPORTANT: getReactableState() needs the unnamespaced id of the reactable
        # Using ns() will cause the reactive to not update when a row is selected
        getReactableState("rt_indicators", "selected")
      })

      ## ui_ab_edit ----
      output$ui_ab_edit <- renderUI({
        req(df_matching_inds())

        row <- row_selected()

        actionButton(
          inputId = session$ns("ab_edit"),
          label = i18n()$t("Editar peso y estado"),
          icon = icon("edit"),
          width = "100%",
          disabled = if (is.null(row_selected())) TRUE else FALSE,
          class = "btn-light mb-3"
        )
      })

      ## edit validation ----
      iv <- InputValidator$new()
      iv$add_rule("ti_weight_basis", sv_required(message = "*"))
      iv$add_rule("ni_weight", sv_required(message = "*"))
      iv$enable()

      observeEvent(input$ab_edit, {
        req(row_selected())

        indrow <- df_matching_inds() |>
          slice(row_selected())
        values$modal_status <- 0
        values$weight <- indrow |> pull(indicator_weight)
        wbasis <- indrow |>
          pull(indicator_weight_basis)
        showModal(
          modalDialog(
            title = i18n()$t("Cambiar peso"),
            p(
              indrow |>
                pull(indicator_name)
            ),
            checkboxInput(
              inputId = session$ns("cbi_active"),
              label = i18n()$t("Activo"),
              value = indrow |> pull(indicator_active)
            ),
            numericInputIcon(
              session$ns("ni_weight"),
              label = span(
                cleanHTML(i18n()$t("Peso")),
                tooltip(
                  bs_icon("info-circle"),
                  title = "info",
                  i18n()$t(
                    "Peso del indicador en el cálculo del indicador compuesto de la dimensión"
                  )
                ),
                options = list(trigger = "hover")
              ),
              value = values$weight,
              icon = list(NULL, icon("weight-hanging"))
            ),
            textAreaInput(
              inputId = session$ns("ti_weight_basis"),
              label = span(
                cleanHTML(i18n()$t("Justificación peso")),
                tooltip(
                  bs_icon("info-circle"),
                  title = "info",
                  i18n()$t(
                    "Explicación que justifique la asignación del peso del indicador en el indicador compuesto de su dimensión"
                  )
                ),
                options = list(trigger = "hover")
              ),
              value = ifelse(is.na(wbasis), "", wbasis),
              height = "200px",
              width = "400px"
            ),
            easyClose = TRUE,
            footer = actionButton(session$ns("ab_save"), i18n()$t("Guardar"))
          )
        )
      })

      ## [RVs] Values to change ----
      values <- reactiveValues(modal_status = -1)

      ## [O] ab_save ----
      observeEvent(input$ab_save, {
        if (!iv$is_valid()) {
          showNotification(i18n()$t("Datos incompletos"), type = "error")
        } else {
          values$modal_status <- 1
          removeModal()
        }
      })

      ## [O] modal_closed ----
      observeEvent(values$modal_status, {
        if (values$modal_status == 1) {
          user <- Sys.info()["user"]
          selected_ind <- df_matching_inds() |>
            slice(row_selected()) |>
            pull(indicator_id)
          active <- input$cbi_active
          strsql <- "UPDATE dt_indicators 
                     SET indicator_weight = ?, 
                         indicator_weight_basis = ?, 
                         indicator_weight_user = ?, 
                         indicator_active = ? 
                     WHERE indicator_id = ?"
          tryCatch(
            {
              DBI::dbExecute(
                con2,
                strsql,
                params = list(
                  input$ni_weight,
                  input$ti_weight_basis,
                  user,
                  active,
                  selected_ind
                )
              )
              edit_count(edit_count() + 1)
              showNotification(i18n()$t("Peso actualizado"))
            },
            error = function(e) {
              showNotification(
                paste0(cleanHTML(i18n()$t("Error actualizando peso y estado")), ": ", e, " (", strsql, ")"),
                duration = NULL,
                type = "error"
              )
            }
          )
        }
      })

      ## ui_si_label - Render translated label with tooltip ----
      output$ui_si_label <- renderUI({
        lan <- i18n()$get_translation_language()
        span(
          cleanHTML(i18n()$t("Buscar indicadores")),
          tooltip(
            bs_icon("info-circle"),
            title = "info",
            get_text("info_new_indicator", lan)
          ),
          options = list(trigger = "hover")
        )
      })

      ## update_si_new_indicator - Update search input placeholder ----
      observe({
        updateSearchInput(
          session = session,
          inputId = "si_new_indicator",
          placeholder = cleanHTML(
            i18n()$t("Busque un indicador existente o cree uno nuevo")
          )
        )
      })

      ## txt_newindicator ----
      output$txt_newindicator <- renderText({
        i18n()$t("Crear/Modificar indicador")
      })

      ## txt_existingindicators ----
      output$txt_existingindicators <- renderText({
        i18n()$t("Indicadores disponibles")
      })

      ## [RV] edit_count ----
      edit_count <- reactiveVal(0)

      ## [RV] search_performed ----
      search_performed <- reactiveVal(FALSE)

      ## [RV] df_matching_inds ----
      df_matching_inds <- reactiveVal(NULL)

      ## [F] fetch_matching_inds ----
      fetch_matching_inds <- function() {
        req(dim())
        req(!is.null(onlycustom()))

        search_term <- input$si_new_indicator
        lan <- i18n()$get_translation_language()

        tbl0 <- tbl(con2, "v_indicators_select_all") |>
          filter(
            indicator_lang == lan,
            source_id == !!.source()
          )

        if (nzchar(search_term)) {
          # Escape wildcards % and _ to treat them as literal characters
          escaped_term <- gsub("([%_])", "\\\\\\1", search_term)
          pattern <- paste0("%", escaped_term, "%")
          safe_pattern <- DBI::dbQuoteString(con2, pattern)
          tbl0 <- tbl0 |>
            filter(sql(paste0("indicator_name ILIKE ", safe_pattern, " ESCAPE '\\' OR indicator_id ILIKE ", safe_pattern, " ESCAPE '\\'")))
        }

        tbl0 <- tbl0 |>
          inner_join(
            tbl(con2, "dt_dimensions") |>
              select(dimension_id, dimension_color),
            by = "dimension_id"
          ) |>
          arrange(indicator_order, indicator_name) |>
          select(
            dimension_label,
            dimension_color,
            indicator_id,
            indicator_name,
            indicator_description,
            indicator_weight,
            indicator_weight_basis,
            indicator_direction,
            indicator_formula,
            indicator_active
          )

        if (onlycustom()) {
          tbl0 <- tbl0 |>
            filter(indicator_id %like% paste0("ICUS%"))
        }

        indsdim <- inds_in_dim(dim(), .source())
        df <- tbl0 |>
          filter(indicator_id %in% indsdim) |>
          collect()

        return(df)
      }

      observeEvent(input$si_new_indicator_search, {
        search_performed(TRUE)
        accordion_panel_set("ac_indform", values = session$ns("acp_indfound"))
        df_matching_inds(fetch_matching_inds())
      })

      observeEvent(input$si_new_indicator_reset, {
        search_performed(FALSE)
        df_matching_inds(NULL)
        accordion_panel_close("ac_indform", session$ns("acp_indfound"))
      })

      # Update results when filters change, but only if search has been performed
      observe({
        req(search_performed())
        # Triggers
        dim(); onlycustom(); edit_count(); form_result$last_modified()
        
        df_matching_inds(fetch_matching_inds())
      })
      ## ui_ab_new_ind ----
      output$ui_ab_new_ind <- renderUI({
        actionButton(
          inputId = session$ns("ab_new_ind"),
          label = i18n()$t("Crear nuevo"),
          disabled = TRUE
        )
      })

      ### rt_indicators - Reactable matching indicators ----
      output$rt_indicators <- renderReactable({
        df <- df_matching_inds()
        if (is.null(df)) return(NULL)
        dfrt <- df
        dfrt |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            onClick = "select",
            selection = "single",
            theme = reactableTheme(
              rowSelectedStyle = list(
                backgroundColor = "var(--bs-primary)",
                color = "var(--bs-light)",
                boxShadow = "inset 2px 0 0 0 var(--bs-primary)"
              )
            ),
            # details = function(index){
            #   weight_basis <- dfrt |>
            #     slice(index) |>
            #     pull(indicator_weight_basis)
            #   layout_columns(col_widths = c(6,6),
            #                  div(p(i18n()$t("Formula"))),
            #                  div(p(strong(i18n()$t("Weight basis"))),
            #                      p(weight_basis),
            #                  )
            #   )
            # },
            columns = list(
              indicator_description = colDef(
                name = "",
                html = TRUE,
                minWidth = 25,
                cell = function(value, index) {
                  as.character(tooltip(bs_icon("info-circle"), value))
                }
              ),
              indicator_id = colDef(
                name = i18n()$t("Código"),
                minWidth = 100,
                filterable = TRUE
              ),
              indicator_name = colDef(
                name = i18n()$t("Nombre"),
                minWidth = 400
              ),
              indicator_weight = colDef(
                name = i18n()$t("Peso"),
                minWidth = 75,
                html = TRUE,
                cell = function(value, index) {
                  basis <- dfrt |>
                    slice(index) |>
                    pull(indicator_weight_basis)

                  if (!is.na(basis)) {
                    info <- as.character(tooltip(
                      bs_icon("question-circle"),
                      basis
                    ))
                  } else {
                    info <- ""
                  }
                  paste0(value, info)
                }
              ),
              indicator_weight_basis = colDef(
                show = FALSE
              ),
              indicator_direction = colDef(
                name = i18n()$t("Sentido"),
                minWidth = 80,
                align = "center"
              ),
              indicator_formula = colDef(
                name = i18n()$t("Fórmula")
              ),
              dimension_label = colDef(show = FALSE),
              dimension_color = colDef(
                name = "",
                maxWidth = 50,
                html = TRUE,
                cell = function(value, index) {
                  .style = paste0("color:", value)
                  .title = dfrt |>
                    slice(index) |>
                    pull(dimension_label)
                  span(
                    icon("circle", class = "fas"),
                    style = .style,
                    title = .title
                  )
                }
              ),
              indicator_active = colDef(
                name = i18n()$t("Activo"),
                minWidth = 80,
                align = "center",
                cell = function(value, index) {
                  if (value) {
                    icon("check", class = "fas", title = i18n()$t("Sí"))
                  } else {
                    icon("xmark", class = "fas", title = i18n()$t("No"))
                  }
                })
            )
          )
      })

      ## Return ----
      return(
        list(
          last_modified = form_result$last_modified
        )
      )
    }
  )
}

## Module app ----

mgt_ind_app <- function() {
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  library(reactable)
  translator <- getOption("evastur.translator")

  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    textInput("ti_source", "Source", "EVASTUR"),
    checkboxInput("cbi_onlycustom", "Only custom"),
    dim_selector_buttons_ui("dimsel1"),
    mgt_ind_ui("ind1"),
  )

  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    dim_selected <- dim_selector_buttons_server(
      "dimsel1",
      i18n,
      reactive({
        input$ti_source
      })
    )

    mgt_ind_server(
      "ind1",
      i18n,
      reactive({
        input$ti_source
      }),
      dim_selected,
      reactive({
        input$cbi_onlycustom
      })
    )
  }

  shinyApp(ui, server)
}
