.onLoad <- function(libname, pkgname) {
  resources <- system.file("app/www", package = "evastur")
  addResourcePath("www", resources)

  op <- options()
  op.evastur <- list(
    evastur.app_title = "EVASTUR",
    evastur.signif = 2,
    evastur.map_bins = 5,
    evastur.aggregation_function = "median",
    evastur.refvalue_q = 0.95,
    evastur.translator = suppressWarnings(
      shiny.i18n::Translator$new(
        translation_csvs_path = system.file(
          "app",
          "translations",
          package = "evastur"
        )
      )
      # Warning message:
      #   In load_local_config(translation_csv_config) :
      #   You didn't specify config translation yaml file. Default settings are used.
    ),
    # evastur.default_lang = Sys.getenv("DEFAULT_LANGUAGE", unset = "es")
    evastur.default_lang = "en",
    evastur.default_location = "ES", # ISO2 CODE
    ## TODO: revmove this option when finishing refactoring
    evastur.default_geo = "España",

    ## This three options must be consistent
    evastur.default_geo_scope = "S",
    evastur.default_geo_group_id = "WLD",
    evastur.default_geo_country_id = "ESP",
    evastur.default_geo_country_selected = "_TOTAL_",
    evastur.default_geo_insto_selected = "_TOTAL_",
    evastur.default_geo_nuts_id = 2,
    evastur.default_geo_nuts_selected = "_TOTAL_",

    # Whether to include or not the current period in filters
    evastur.include_current_year = FALSE,
    # Number of periods for the filter in series
    evastur.nperiods = 10,
    evastur.insto_year_lower_bound = 2009,
    # ShinyProxy admin group name (empty string = no admin group configured)
    evastur.admin_group = Sys.getenv("EVASTUR_ADMIN_GROUP", unset = "")
  )
  toset <- !(names(op.evastur) %in% names(op))
  if (any(toset)) {
    options(op.evastur[toset])
  }

  ## Old data model ----

  con_is_up <- DBI::dbCanConnect(
    RPostgres::Postgres(),
    host = Sys.getenv("HOST"),
    dbname = "evastur_db",
    port = 5432,
    user = "evastur",
    password = Sys.getenv("PGPWD"),
    options = "-c search_path=old_model"
  )

  if (con_is_up) {
    con <<- DBI::dbConnect(
      RPostgres::Postgres(),
      host = Sys.getenv("HOST"),
      dbname = "evastur_db",
      port = 5432,
      user = "evastur",
      password = Sys.getenv("PGPWD"),
      options = "-c search_path=old_model"
    )
  } else {
    warning("Could not connect to PostgreSQL v1 database!!")
    con <<- NULL
  }

  ## New data model ----

  con2_is_up <- DBI::dbCanConnect(
    RPostgres::Postgres(),
    host = Sys.getenv("HOST"),
    dbname = "evastur_db",
    port = 5432,
    user = "evastur",
    password = Sys.getenv("PGPWD")
  )

  if (con2_is_up) {
    con2 <<- DBI::dbConnect(
      RPostgres::Postgres(),
      host = Sys.getenv("HOST"),
      dbname = "evastur_db",
      port = 5432,
      user = "evastur",
      password = Sys.getenv("PGPWD")
    )
  } else {
    warning("Could not connect to PostgreSQL v2 database!!")
    con2 <<- NULL
  }

  invisible()
}
