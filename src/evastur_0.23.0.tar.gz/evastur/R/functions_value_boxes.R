#' get_intervention_vbs(intervention, getOption("evastur.translator"))
get_intervention_vbs <- function(.data, .unfeasible_dims = NULL, i18n) {
  if (is.null(.data)) {
    return(
      p(
        span(bsicons::bs_icon("exclamation-diamond"), style = "color:orange"),
        i18n$t("No se ha encontrado solución factible")
      )
    )
  }
  
  vbs <- 1:nrow(.data) |>
    purrr::map(
      ~ {
        is_unfeasible <- .data$var[.x] %in% .unfeasible_dims

        if (is_unfeasible) {
          .icon <- "exclamation-triangle"
          .arrow <- "⇡"
          .class <- "vb-titles vb-unfeasible"
        } else if (.data$beta[.x] != 0) {
          .icon <- "tools"
          .arrow <- "⇡"
          .class <- "vb-titles"
        } else {
          .icon <- "check-square"
          .arrow <- ""
          .class <- "vb-titles"
        }
        value_box(
          title = .data$label[.x],
          value = paste(.arrow, format(round(.data$beta[.x], 3), nsmall = 3)),
          showcase = span(
            bs_icon(.icon, size = "50px"),
            style = paste0("color:", .data$col[.x])
          ),
          max_height = "150px",
          class = .class
        )
      }
    )

  layout_column_wrap(width = 1 / 3, fill = FALSE, !!!vbs)
}
