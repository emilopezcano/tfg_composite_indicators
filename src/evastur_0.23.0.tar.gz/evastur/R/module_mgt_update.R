## Module for checking and updating data sources

## Module UI ----
mgt_update_ui <- function(id) {
  ns <- NS(id)
  tagList(
    reactableOutput(ns("rt_sources_update"))
  )
}

## Module server ----

#' Data-source checking and updating module
#'
#' This module allows reviewing and updating the status of external data
#' sources used in the system. It presents a table listing all available
#' sources together with their metadata (latest data, last update and last
#' checking date) and provides controls to trigger status checks and, when
#' applicable, data-update procedures.
#'
#' **Only data sources with `ida_id == 4` display the binoculars button.**
#' These represent sources with **fully automated ETL pipelines**. Other sources
#' are shown for reference but do **not** allow automated checking or updates
#' from this module.
#'
#' The module performs the following tasks:
#'
#' * Displays a table with all active sources of type *variables* or *base*.
#' * Allows triggering a metadata check for a given source (via a binoculars
#'   button embedded in the table).
#' * Updates the source metadata in the database (last checking and last
#'   source update).
#' * Shows a summary dialog indicating whether new data are available.
#' * Provides an option to run the ETL pipeline for that source with primary
#'   style if new data may exist or danger color otherwise.
#'
#' @note
#' The module requires a translation object `i18n` to internationalise the UI
#' labels.  
#' The database connection `con2` must allow both reading and writing source
#' metadata.  
#' The availability check, metadata updating and ETL operations rely on backend
#' helper functions defined in `R/functions_etl.R`.
#'
#' @param id Module instance id.
#' @param i18n Translation object used to generate the UI labels.
#' @param con2 Database connection or pool used to query and update the metadata.
#'
#' @return
#' This module is intended for its side-effects. It registers observers and
#' outputs that:
#'
#' * render the table of sources,
#' * update metadata when a source is checked,
#' * and optionally execute the ETL procedure when new data are detected.
#'
#' @seealso
#' Helper functions used in this module:
#' * [etl_append_source()]
#' * [get_source_last_available()]
#' * [update_source_last_available()]
#' * [update_source_last_checking()]
#'
#' These are defined in `R/functions_etl.R`.
#'
#' @export
#'
#' @examplesIf interactive
#' mgt_update_app()
mgt_update_server <- function(id, i18n, con2) {
  moduleServer(
    id,
    function(input, output, session) {
      
      ## Reactive value to trigger data refresh ----
      data_updated_at <- reactiveVal(Sys.time())
      
      ## [R] dfsources_update ----
      dfsources_update <- reactive({
        req(data_updated_at())
        
        # Get language from i18n
        lan <- i18n()$get_translation_language()
        
        dfsources <- con2 |>
          tbl("dt_sources") |>
          filter(source_type_id %in% c("V", "B")) |>
          inner_join(
            con2 |>
              tbl("lt_sources") |>
              filter(source_lang == !!lan) |>
              select(source_id, source_label, source_name),
            by = "source_id"
          ) |>
          inner_join(
            con2 |>
              tbl("ft_variables") |>
              group_by(source_id) |>
              summarise(last_data = max(date, na.rm = TRUE), .groups = "drop"),
            by = "source_id"
          ) |>
          arrange(source_order) |>
          select(
            source_label,
            source_name,
            last_data,
            source_last_available,
            source_last_update,
            source_last_checking,
            source_id,
            ida_id
          ) |>
          collect() |>
          mutate(
            source_last_available = substr(source_last_available, 1, 10),
            source_last_update = substr(source_last_update, 1, 10),
            source_last_checking = substr(source_last_checking, 1, 10)
          )
      })
      
      ## rt_sources_update ----
      output$rt_sources_update <- renderReactable({
        dfsources_update() |>
          select(-source_last_available) |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            columns = list(
              source_label = colDef(
                name = i18n()$t("Etiqueta"),
                maxWidth = 150
              ),
              source_name = colDef(
                name = i18n()$t("Nombre"),
                minWidth = 200
              ),
              last_data = colDef(
                name = i18n()$t("Últimos datos en la base de datos")
              ),
              source_last_update = colDef(
                name = i18n()$t("Última actualización desde la fuente")
              ),
              source_last_checking = colDef(
                name = i18n()$t("Última comprobación de la fuente")
              ),
              source_id = colDef(
                name = "",
                html = TRUE,
                maxWidth = 30,
                cell = function(value, index) {
                  ida <- dfsources_update() |> slice(index) |> pull(ida_id)
                  if (!is.na(ida) && ida == 4) {
                    rt_check_source_button(
                      module_id = id,
                      nav_id = "btn_source_update",
                      nav_value = value
                    )
                  }
                }
              ),
              ida_id = colDef(
                show = FALSE
              )
            )
          )
      })
      
      ## [E] btn_source_update ----
      observeEvent(input$btn_source_update, {
        source <- input$btn_source_update

        if (!update_source_last_checking(source)) {
          showNotification(
            paste(
              i18n()$t(
                "Error al actualizar la fecha de la última comprobación de"
              ),
              source
            ),
            type = "error"
          )
        }

        # Get current source data from database
        source_data <- dfsources_update() |>
          filter(source_id == source)

        source_last_update_db <- source_data |> pull(source_last_update)
        source_last_available_db <- source_data |> pull(source_last_available)
        source_info <- source_data |> select(source_label, source_name)

        # Show "checking last available" notification (this can take time)
        last_available_notification <- showNotification(
          paste(
            i18n()$t("Comprobando última fecha disponible de datos para"),
            source,
            "..."
          ),
          duration = NULL,
          closeButton = FALSE,
          type = "message"
        )

        # Update last_available from the source (may take a while)
        scraped_date <- get_source_last_available(source = source)
        removeNotification(last_available_notification)

        # Only update DB if we got a valid date string
        if (!is.null(scraped_date) && !is.na(scraped_date)) {
          if (!update_source_last_available(source, scraped_date)) {
            showNotification(
              "Error al actualizar la última fecha disponible de datos",
              type = "error"
            )
          }
        }
        
        # Refresh table after updating metadata
        data_updated_at(Sys.time())
        
        # Build dialog content
        if (is.null(scraped_date)) {
          # ERROR case: an actual error occurred
          .title <- paste0("E R R O R - ", source)
          .text <- i18n()$t(
            "No se pudo obtener la fecha de datos disponibles. Verifique la fuente o contacte con servicio de mantenimiento."
          )
        } else {
          # Both NA and valid date cases show source info
          .title <- source_info |> paste(collapse = " - ")
          has_new_data <- FALSE

          if (is.na(scraped_date)) {
            # Source doesn't provide a date
            update_message <- div(
              class = "alert alert-info",
              style = "margin: 15px 0; padding: 10px;",
              icon("info-circle"),
              " ",
              i18n()$t("Esta fuente no informa sobre su fecha de última actualización.")
            )
            has_new_data <- TRUE  # Suggest loading
          } else if (is.na(source_last_available_db) || is.na(source_last_update_db)) {
            # Some information missing - uncertain
            update_message <- div(
              class = "alert alert-info",
              style = "margin: 15px 0; padding: 10px;",
              icon("question-circle"),
              " ",
              i18n()$t("No se dispone de información histórica completa. Puede intentar cargar los datos.")
            )
            has_new_data <- TRUE
          } else if (scraped_date == source_last_available_db) {
            # Same source update date as stored in DB - no new data from source
            update_message <- div(
              class = "alert alert-info",
              style = "margin: 15px 0; padding: 10px;",
              icon("info-circle"),
              " ",
              i18n()$t("La fuente indica la misma fecha de actualización que la última vez. Es posible que no haya datos nuevos.")
            )
          } else if (scraped_date <= source_last_update_db) {
            # Source update date is older or equal to when we last loaded data
            update_message <- div(
              class = "alert alert-warning",
              style = "margin: 15px 0; padding: 10px;",
              icon("exclamation-triangle"),
              " ",
              i18n()$t("La fecha de actualización de la fuente no es posterior a la última carga. Puede que no haya datos nuevos.")
            )
          } else {
            # Likely has new data!
            has_new_data <- TRUE
            update_message <- div(
              class = "alert alert-success",
              style = "margin: 15px 0; padding: 10px;",
              icon("check-circle"),
              " ",
              i18n()$t("¡La fuente ha sido actualizada! Hay datos nuevos disponibles para cargar.")
            )
          }
          
          .text <- div(
            if (!is.na(scraped_date)) {
              tagList(
                h4(i18n()$t("Fecha de actualización de la fuente")),
                p(strong(as.Date(scraped_date)), style = "font-size: 1.2em;")
              )
            },
            
            if (!is.na(source_last_update_db)) {
              p(
                style = "color: #666; margin-top: 10px;",
                i18n()$t("Última carga de datos realizada el"),
                " ",
                strong(as.Date(source_last_update_db))
              )
            },
            
            update_message,
            
            actionButton(
              inputId = session$ns("ab_etl_source_vars"),
              label = i18n()$t("Cargar datos disponibles"),
              icon = icon("database"),
              class = if (has_new_data) "btn-primary" else "btn-danger"
            )
          )
        }
        
        sendSweetAlert(
          title = .title,
          html = TRUE,
          text = .text,
          width = 800,
          btn_labels = NA
        )
      })
      
      ## [E] ab_etl_source_vars ----
      observeEvent(input$ab_etl_source_vars, {
        source <- input$btn_source_update
        
        # Get last date in database for this source
        source_info <- dfsources_update() |>
          filter(source_id == source) |>
          select(source_label)
        
        # Show loading notification
        loading_id <- showNotification(
          paste0(
            i18n()$t("Actualizando datos de variables de"),
            " ",
            source_info$source_label,
            "..."
          ),
          duration = NULL,
          type = "message",
          closeButton = FALSE
        )
        
        # Run ETL
        etl_success <- tryCatch(
          {
            etl_append_source(source = source)
          },
          error = function(e) {
            showNotification(
              paste0(i18n()$t("Error al actualizar datos"), ": ", e$message),
              type = "error",
              duration = 10
            )
            FALSE
          }
        )
        
        # Remove loading notification
        removeNotification(loading_id)
        
        # Show result and update if successful
        if (etl_success) {
          showNotification(
            paste0(
              i18n()$t("Datos de variables de"),
              " ",
              source_info$source_label,
              " ",
              i18n()$t("actualizados")
            ),
            type = "message",
            duration = 5
          )
          data_updated_at(Sys.time())
          closeSweetAlert()
        } else {
          showNotification(
            i18n()$t("No se pudieron actualizar los datos. Revise los mensajes de error."),
            type = "error",
            duration = 10
          )
        }
      })
      
    }
  )
}

#' Internal helper: button for checking a data source
#'
#' This helper generates the HTML button (binoculars icon) used inside the
#' reactable table to trigger the checking of a data source's metadata.
#'
#' @param module_id Module namespace (optional). If provided, it is used to
#'   namespace the input id sent back to Shiny.
#' @param nav_id Input id used to send the value back to the server.
#' @param nav_value Value corresponding to the source id for that row. This is
#'   the value passed to the server when the button is clicked.
#'
#' @return A character string containing HTML for inserting into a reactable cell.
#'
#' @keywords internal
#'
#' @examplesIf interactive
#' rt_check_source_button(
#'   module_id = NULL,
#'   nav_id = "btn_source_update",
#'   nav_value = "UNWTO-STATS"
#' )
rt_check_source_button <- function(module_id = NULL, nav_id, nav_value) {
  ns <- NS(module_id)

  # enviamos directamente el valor correcto
  str_onclick <- sprintf(
    "Shiny.setInputValue('%s', '%s', {priority: 'event'})",
    ns(nav_id),
    nav_value
  )

  as.character(
    tags$div(
      id = ns(paste0("btn_", nav_value)),
      bs_icon("binoculars-fill"),
      onClick = str_onclick,
      title = nav_value,
      style = "cursor: pointer;"
    )
  )
}

## Module app ----
mgt_update_app <- function() {
  library(shiny)
  library(shinyWidgets)
  devtools::load_all()
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  library(reactable)
  translator <- getOption("evastur.translator")

  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    mgt_update_ui("update1")
  )

  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    ## Call module
    mgt_update_server("update1", i18n, con2)
  }

  shinyApp(ui, server, options = list(port = 3800))
}
