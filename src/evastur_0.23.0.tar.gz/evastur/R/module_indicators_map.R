## Module for representing indicator values in a map

## Module UI ----
indicator_map_ui <- function(id) {
  ns <- NS(id)
  tagList(
    leafletOutput(ns("map_indicator"))
  )
}

## Module server ----
indicator_map_server <- function(id, i18n, .data, bins, signif, legend_text, legend_prefix = "STI", enable_click = TRUE) {
  moduleServer(
    id,
    function(input, output, session) {

      ## [O] map_indicator_shape_click
      if (enable_click) {
        observeEvent(input$map_indicator_shape_click$id, {
          if (session$userData$config()$geo_scope == "N") {
            session$userData$config(mutate(
              session$userData$config(),
              geo_nuts_selected = input$map_indicator_shape_click$id
            ))
          } else {
            session$userData$config(mutate(
              session$userData$config(),
              geo_country_selected = input$map_indicator_shape_click$id
            ))
          }
        })
        click_id_reactive <- reactive({ input$map_indicator_shape_click$id })
      } else {
        click_id_reactive <- reactive({ NULL })
      }

      ## map_indicator ----
      output$map_indicator <- renderLeaflet({
        req(nrow(.data()) > 0)

        if (session$userData$config()$geo_scope == "N") {
          geo_selected <- session$userData$config()$geo_nuts_selected
        } else {
          geo_selected <- session$userData$config()$geo_country_selected
        }
        selected_data <- .data() |>
          filter(geo_id == geo_selected)

        primary_color <- get_theme_color(
          session = session,
          bs_variable = "primary"
        ) %||%
          "#6B8A7A" # fallback

        create_map(
          .data(),
          click_id_reactive(),
          bins(),
          signif(),
          legend_text(),
          legend_prefix,
          i18n(),
          enable_click,
          primary_color
        )
      })

      return(click_id_reactive)
    }
  )
}

#' Create Leaflet Map
#'
#' @param .data Data frame with map data
#' @param map_indicator_shape_click_id ID of clicked shape
#' @param bins Number of bins for color palette
#' @param signif Number of significant digits for rounding
#' @param legend_text Text for legend
#' @param legend_prefix Prefix for legend title
#' @param i18n Internationalization object
#' @param enable_click Logical, whether to enable polygon clicking (default TRUE)
#' @param primary_color Primary color for palette (default "#6B8A7A")
#'
#' @returns Leaflet map object
#' @export
#'
#' @examples
#' \dontrun{
#' create_map()
#' }
create_map <- function(
  .data,
  map_indicator_shape_click_id,
  bins,
  signif,
  legend_text,
  legend_prefix,
  i18n,
  enable_click = TRUE,
  primary_color = "#6B8A7A"
) {
  req(nrow(.data) > 0)

  color_palette <- create_color_palette(primary_color = primary_color)

  ## bounds ----
  bounds <- as.numeric(st_bbox(.data))
  if (all(abs(bounds[c(1, 3)]) > 179)) {
    zoom1 <- 1
  } else {
    zoom1 <- NULL
  }

  ## Labels for polygons ----
  labels <- sprintf(
    paste0("<strong>%s</strong><br/>", legend_prefix, " %s: %s"),
    .data$geo_label,
    legend_text,
    replace_na(
      scales::label_number(accuracy = 0.01, scale_cut = scales::cut_short_scale())(.data$value),
      i18n$t("No disponible")
    )
  ) |>
    lapply(htmltools::HTML)

  ## Palette ----
  value_range <- range(.data$value, na.rm = TRUE)

  # Most common case first - values have variation
  if (diff(value_range) > 0) {
    quartiles <- quantile(
      .data$value,
      probs = seq(0, 1, 1 / bins),
      na.rm = TRUE
    )
    if (anyDuplicated(quartiles) > 0) {
      .bins <- 2
    } else {
      .bins <- quartiles
    }

    pal <- colorBin(
      palette = color_palette,
      domain = .data$value,
      bins = .bins,
      na.color = "transparent"
    )
  } else {
    # Edge case - all values identical
    pal <- colorFactor(
      palette = primary_color,
      domain = .data$value,
      na.color = "transparent"
    )
  }

  ## Render map ----
  m <- .data |>
    leaflet() |>
    addProviderTiles(
      provider = providers$CartoDB.VoyagerLabelsUnder,
      options = list(noWrap = TRUE, minZoom = zoom1)
    )

  # Add polygons conditionally based on enable_click
  if (enable_click) {
    m <- m |>
      addPolygons(
        layerId = ~geo_id,
        fillColor = ~ pal(value),
        weight = 1,
        opacity = 1,
        color = primary_color,
        dashArray = "3",
        fillOpacity = 0.7,
        highlightOptions = highlightOptions(
          weight = 2,
          color = adjust_color(
            color = primary_color,
            color_type = "hex",
            factor = -0.4
          ),
          dashArray = "",
          fillOpacity = 0.7,
          bringToFront = TRUE
        ),
        label = labels
      )
  } else {
    m <- m |>
      addPolygons(
        fillColor = ~ pal(value),
        weight = 1,
        opacity = 1,
        color = primary_color,
        dashArray = "3",
        fillOpacity = 0.7,
        label = labels
      )
  }

  m <- m |>
    addLegend(
      position = "bottomright",
      title = paste(legend_prefix, "-", legend_text),
      pal = pal,
      values = ~value,
      na.label = NULL,
      opacity = 0.7
    ) |>
    flyToBounds(bounds[1], bounds[2], bounds[3], bounds[4])

  if (!is.null(map_indicator_shape_click_id)) {
    selected_data <- .data |>
      filter(geo_id == map_indicator_shape_click_id)
    complementary_color <- get_complementary_color(primary_color)
    m <- m |>
      addPolygons(
        data = selected_data,
        color = complementary_color,
        weight = 2,
        opacity = 1,
        fillColor = complementary_color,
        fillOpacity = 0.5,
        fill = TRUE
      )
  }
  m
}

## Module app ----

## Data processing functions ----

#' Process STI data for map visualization
process_sti_data <- function(input, geo_level_selector_controls, dimension_control, nuts_level, inds, country_location, country_groups) {
  ## reqs 
  req(input$si_source)
  req(geo_level_selector_controls$rgb_geo_scope())
  req(geo_level_selector_controls$pi_geo_group())
  req(nuts_level())
  req(country_groups())
  if(geo_level_selector_controls$rgb_geo_scope() == "S" & geo_level_selector_controls$pi_geo_group() != "INSTO"){
    req(any(geo_level_selector_controls$pi_geo_group() == country_groups()))
  }
  
  dfind <- get_ft_data(
    data_type = "indicator",
    .nuts_level = nuts_level(),
    type_id = inds(),
    country = country_location(),
    .source_id = input$si_source,
    from_date = "2013-01-01",
    to_date = "2022-12-31"
  )
  
  suppressMessages({
    tindicators <- get_transformed_indicators(
      dfind,
      scaling_method = "zscore",
      scaling_type = "time",
      refvalueq = NULL,
      geo_total = geo_level_selector_controls$pi_geo_group()
    )
  })
  
  # Compute composite indicators
  if(geo_level_selector_controls$pi_geo_group() == "INSTO"){
    source <- "INSTO"
  } else {
    source <- input$si_source
  }
  
  tindicators |> compute_composite_indicator(selected_source = source)
}

#' Process indicator count data for map visualization
process_indicator_count_data <- function(input, geo_level_selector_controls, dimension_control, nuts_level, inds, country_location, country_groups) {
  ## reqs 
  req(input$si_source)
  req(geo_level_selector_controls$rgb_geo_scope())
  req(geo_level_selector_controls$pi_geo_group())
  req(nuts_level())
  req(country_groups())
  req(dimension_control$pi_dimension())
  if(geo_level_selector_controls$rgb_geo_scope() == "S" & geo_level_selector_controls$pi_geo_group() != "INSTO"){
    req(any(geo_level_selector_controls$pi_geo_group() == country_groups()))
  }
  
  dfind <- get_ft_data(
    data_type = "indicator",
    .nuts_level = nuts_level(),
    type_id = inds(),
    country = country_location(),
    .source_id = input$si_source,
    from_date = "2013-01-01",
    to_date = "2022-12-31"
  )
  
  get_indicators_count(
    dfind,
    geo_total = geo_level_selector_controls$pi_geo_group(),
    .dimension = dimension_control$pi_dimension()
  )
}

## Base app function ----
base_indicator_map_app <- function(data_processor, legend_prefix = "STI") {
  library(shiny)
  library(shinyWidgets)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(leaflet)

  translator <- getOption("evastur.translator")

  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    selectInput("si_source", "Source", c("EVASTUR", "INSTO")),
    geo_level_selector_ui("geo_level_selector1"),
    uiOutput("ui_geo_selector1"),
    dimension_selector_ui("dimension_selector"),
    verbatimTextOutput("clicked"),
    indicator_map_ui("map1"),
    reactableOutput("rt_mapdata")
  )
  
  server <- function(input, output, session) {
    session$userData$config <- reactiveVal(list(
      geo_scope = "S",
      geo_group_id = "EU28",
      geo_country_selected = "ES",
      geo_nuts_id = 101
    ))

    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    ## ui_geo_selector1 ----
    output$ui_geo_selector1 <- renderUI({
      req(geo_level_selector_controls$rgb_geo_scope())
      req(geo_level_selector_controls$pi_geo_group())
      geo_selector_ui("geo_selector1")
    })

    ## [M] geo_level_selector_controls ----
    geo_level_selector_controls <- geo_level_selector_server(
      "geo_level_selector1",
      i18n = i18n,
      lan = reactive({
        input$si_lan
      })
    )

    geo_clicked <- reactive({
      if (is.null(indicator_map())) {
        NULL
      } else {
        indicator_map()
      }
    })

    ## [M] geo_selector_control ----
    geo_selector_control <- geo_selector_server(
      "geo_selector1",
      i18n = i18n,
      lan = reactive({
        input$si_lan
      }),
      geo_scope = geo_level_selector_controls$rgb_geo_scope,
      geo_group = geo_level_selector_controls$pi_geo_group,
      nuts_level_inner = geo_level_selector_controls$pi_nuts,
      geo_selected = geo_clicked
    )

    ## [M] dimension_selector ----
    dimension_selector_control <- dimension_selector_server(
      "dimension_selector",
      i18n = i18n,
      lan = reactive({
        input$si_lan
      }),
      .source_id = reactive({
        input$si_source
      })
    )

    ## clicked ----
    output$clicked <- renderText({
      req(indicator_map())
      indicator_map()
    })

    ### [R] Nuts level depending on selection
    nuts_level <- reactive({
      req(geo_level_selector_controls$rgb_geo_scope())
      req(geo_level_selector_controls$pi_geo_group())

      if (geo_level_selector_controls$rgb_geo_scope() == "N") {
        .nuts_level <- session$userData$config()$geo_nuts_id
      } else {
        if (geo_level_selector_controls$pi_geo_group() == "INSTO") {
          .nuts_level <- 99
        } else {
          .nuts_level <- 0
        }
      }
    })

    ### [R] inds - Active indicators ----
    inds <- reactive({
      tbl(con2, "dt_indicators") |>
        filter(indicator_active == TRUE) |>
        pull(indicator_id)
    })

    ## [R] country_location ----
    country_location <- reactive({
      if (geo_level_selector_controls$rgb_geo_scope() == "N") {
        con2 |>
          tbl("dt_geo") |>
          filter(geo_id == geo_level_selector_controls$pi_geo_group()) |>
          pull(iso2_code)
      } else {
        NULL
      }
    })

    ## [R] country_groups
    country_groups <- reactive({
      con2 |>
        tbl("bt_geo_group") |>
        distinct(geo_group_id) |>
        pull(geo_group_id)
    })

    
    ### [R] processed_data - processed indicators data ----
    processed_data <- reactive({
      data_processor(input, geo_level_selector_controls, dimension_selector_control, 
                    nuts_level, inds, country_location, country_groups)

    })

    ## [R] dmap Map data ----
    dmap <- reactive({
      req(processed_data())
      req(nrow(processed_data()) > 0)
      processed_data() |> 
        get_map_data(.date = "2022-01-01",
                      lan = input$si_lan,
                      type_id = dimension_selector_control$pi_dimension())
    })
    
    ## [M] indicator_map ---- 
    indicator_map <- indicator_map_server("map1", i18n, .data = dmap,
                                          bins = reactive({getOption("evastur.map_bins")}),
                                          signif = reactive({getOption("evastur.signif")}),
                                          legend_text = dimension_selector_control$dimension_label,
                                          legend_prefix = legend_prefix)
    

    ## rt_mapdata ----
    output$rt_mapdata <- renderReactable({
      dmap() |> reactable(language = get_rt_lang(input$si_lan))
    })
  }
  shinyApp(ui, server, options = list(port = 3800))
}

## App functions ----
indicator_map_app <- function() { base_indicator_map_app(process_sti_data, "STI") }
n_indicator_map_app <- function() { base_indicator_map_app(process_indicator_count_data, "Number Indicators") }

## Run apps ----
## COMMENT WHEN BUILDING OR LOADING
# indicator_map_app()    # STI values on map
# n_indicator_map_app()  # Indicator counts on map
