#' Get specific period
#'
#' @param date date in ISO format
#' @param period_id period (Y, M, D, ...)
#'
#' @returns a character vector with the formatted period
#' @export
#'
#' @examples
#' get_period("2022-01-01", "Y")
#' get_period("2022-01-01", "M")
get_period <- Vectorize(
  function(date, period_id){
    if(period_id == "Y"){
      format(as.Date(date), "%Y")
    } else if(period_id == "M"){
      format(as.Date(date), "%Y-%m")
    } else if(period_id == "Q"){
      paste0(format(as.Date(date), "%Y"), "-Q", lubridate::quarter(as.Date(date)))
    } else {
      as.character(date)
    }
  }
)

#' Convert arithmetic expressions to LaTeX equations
#'
#' This function takes a character vector of arithmetic expressions involving
#' addition (`+`), subtraction (`-`), multiplication (`*`), and division (`/`)
#' and converts them into LaTeX math equations. It automatically formats
#' fractions with `\\frac{}` and replaces `*` with `\\cdot`. Parentheses
#' are kept only when needed to preserve mathematical grouping.
#'
#' The result is wrapped in `$$...$$` for display math mode.
#' Handles `NA` values gracefully.
#' Credits: https://chatgpt.com/share/680682dd-e950-8007-8729-a55b0bb0edfa
#'
#' @param expr_vector A character vector of arithmetic expressions.
#'
#' @return A character vector of LaTeX expressions, with the same length as `expr_vector`.
#'         If an input element is `NA`, the corresponding output is also `NA`.
#'
#' @examples
#' transform_to_latex_clean(c(
#'   "V1/(V2+V3)*100",
#'   "(A+B)/(C+D+E)*100",
#'   NA,
#'   "X*Y/Z"
#' ))
#'
#' @importFrom stringr str_detect str_replace_all str_split str_sub str_starts str_ends
#' @export
formula_to_latex <- function(expr_vector) {
  vapply(expr_vector, function(expr) {
    if (is.na(expr)) return(NA_character_)  # Handle NA input
    
    expr <- gsub("\\s+", "", expr)  # Remove all whitespace
    
    # Separate left and right sides of equality
    lhs <- NULL
    if (str_detect(expr, "=")) {
      parts <- str_split(expr, "=", n = 2)[[1]]
      lhs <- parts[1]
      expr <- parts[2]
    }
    
    # Remove unnecessary outer parentheses if not needed
    strip_outer_parens <- function(x) {
      if (str_starts(x, "\\(") && str_ends(x, "\\)")) {
        inner <- str_sub(x, 2, -2)
        if (!str_detect(inner, "[*/]")) return(inner)
      }
      return(x)
    }
    
    # Decide if parentheses are needed
    needs_brackets <- function(x) {
      str_detect(x, "[+\\-*/]")
    }
    
    # Format fraction
    clean_frac <- function(match) {
      parts <- str_split(match, "/", n = 2)[[1]]
      num <- parts[1]
      den <- parts[2]
      
      num <- strip_outer_parens(num)
      den <- strip_outer_parens(den)
      
      num_latex <- if (needs_brackets(num)) paste0("\\left(", num, "\\right)") else num
      den_latex <- if (needs_brackets(den)) paste0("\\left(", den, "\\right)") else den
      
      paste0("\\frac{", num_latex, "}{", den_latex, "}")
    }
    
    # Replace fractions iteratively
    pattern <- "([^*/()]+|\\([^()]+\\))/([^*/()]+|\\([^()]+\\))"
    while (str_detect(expr, pattern)) {
      expr <- str_replace_all(expr, pattern, clean_frac)
    }
    
    # Replace multiplication
    expr <- str_replace_all(expr, "\\*", " \\\\cdot ")
    
    # Remove unnecessary parentheses around \frac
    expr <- str_replace_all(expr, "\\(\\\\frac\\{[^{}]+\\}\\{[^{}]+\\}\\)", 
                            function(x) str_sub(x, 2, -2))
    
    # Prepend left-hand side if present
    if (!is.null(lhs)) {
      expr <- paste0(lhs, " = ", expr)
    }
    
    # Wrap in display math delimiters
    expr <- paste0("$$", expr, "$$")
    return(expr)
  }, character(1))
}

