exp_sources_ui <- function(id) {
  ns <- NS(id)
  tagList(
  reactableOutput(ns("rt_sources"))
  )
}

exp_sources_server <- function(id, i18n) {
  moduleServer(
    id,
    function(input, output, session) {
      df_sources <- reactive({
        lan <- i18n()$get_translation_language()
        con2 |> 
          tbl("v_sources_select") |> 
          filter(source_lang == lan,
                 source_type_id %in% c("V", "B")) |> 
          select(source_url, source_name,
                 source_label, source_description, 
                 ida_label, ida_color,
                 ida_description,
                 source_id) |> 
          collect()
      })
      output$rt_sources <- renderReactable({
        df_sources() |> 
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            columns = list(
              ## indicator_id ----
              source_id = colDef(
                name = "",
                minWidth = 30,
                sortable = FALSE, 
                html = TRUE,
                cell = function(value){
                  rt_doc_button(nav_id = "btn_source_doc", 
                                nav_value = value, i18n())
                }
              ),
              source_url = colDef(
                show = FALSE
              ),
              source_name = colDef(
                name = i18n()$t("Fuente"),
                filterable = TRUE
              ),
              source_label = colDef(
                name = "",
                html = TRUE,
                maxWidth = 200,
                filterable = TRUE,
                cell = function(value, index){
                  as.character(a(href = df_sources()$source_url[index], 
                                 target = "_blank",
                                 value))
                }),
              source_description = colDef(
                name = "",
                html = TRUE,
                maxWidth = 40,
                cell = function(value, index){
                  as.character(tooltip(bs_icon("info-circle"),
                                       value))
                }
              ),
              ida_label = colDef(
                name = "IDA",
                # headerClass = "ida-header",
                align = "center",
                html = TRUE,
                maxWidth = 100,
                filterable = TRUE,
                style = function(value, index){
                  list(color = df_sources()$ida_color[index],
                       fontWeight = "bold")
                },
                cell = function(value, index){
                  span(ifelse(is.na(value), "", value), 
                       title = df_sources()$ida_description[index])
                }
              ),
              ida_color = colDef(
                show = FALSE
              ),
              ida_description = colDef(
                show = FALSE
              )
              
            )
          )
      })
    }
  )
}


exp_sources_app <- function(){
  
library(shiny)
devtools::load_all()
translator <- getOption("evastur.translator")

ui <- fluidPage(
  selectInput("si_lan", "Language", c("en", "es", "fr")),
  exp_sources_ui("sources1")
)

server <- function(input, output, session) {
  i18n <- reactive({
    selected <- input$si_lan
    if (length(selected) > 0 && selected %in% translator$get_languages()) {
      translator$set_translation_language(selected)
    }
    translator
  })
  
  exp_sources_server("sources1", i18n = i18n)
}

shinyApp(ui, server, options = list(port = 3800))

}

# exp_sources_app()