## Module for the columns of a new variable

## Module UI ----
mgt_var_form_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("var_form"))
  )
  
}

## Module server ----
mgt_var_form_server <- function(id, i18n, selected_custom_var = reactive(NULL)) {
  moduleServer(
    id,
    function(input, output, session) {

      last_modified <- reactiveVal(0)

      iv <- InputValidator$new()
      iv$add_rule("ti_variable_name", 
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$add_rule("ti_variable_label", 
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$add_rule("tai_variable_des", 
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$add_rule("pi_variable_units", 
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$add_rule("pi_variable_period", 
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$enable()

      ## [R] is_edit_mode ----
      is_edit_mode <- reactive({
        sel <- selected_custom_var()
        !is.null(sel) && nchar(sel) > 0 && sel != "_NONE_"
      })

      ## [RV] new_id ----
      new_id <- reactiveVal({
        next_id("variable", "VCUS")
      })

      ## [RVs] desired_values – holds pre-fill data for create/edit mode ----
      desired_values <- reactiveValues(
        name        = "",
        label       = "",
        description = "",
        units       = "",
        period      = ""
      )

      ## [RV] item_user_cre – owner of currently selected record ----
      item_user_cre <- reactiveVal("")

      ## [O] Load or reset form when selection changes ----
      observeEvent(selected_custom_var(), {
        sel <- selected_custom_var()
        if (!is.null(sel) && nchar(sel) > 0 && sel != "_NONE_") {
          # Edit mode: load existing data
          new_id(sel)
          lan <- i18n()$get_translation_language()
          tryCatch({
            lt_row <- con2 |>
              tbl("lt_variables") |>
              filter(variable_id == !!sel, variable_lang == lan) |>
              collect()
            dt_row <- con2 |>
              tbl("dt_variables") |>
              filter(variable_id == !!sel) |>
              select(variable_id, user_cre) |>
              collect()
            bt_row <- con2 |>
              tbl("bt_variable_source") |>
              filter(variable_id == !!sel, source_id == "CUSTOM") |>
              select(variable_id, source_units, period_id) |>
              collect()

            if (nrow(lt_row) > 0) {
              desired_values$name  <- lt_row$variable_name[1]
              desired_values$label <- lt_row$variable_label[1]
              desired_values$description   <- lt_row$variable_description[1]
            }
            if (nrow(bt_row) > 0 && !is.na(bt_row$source_units[1])) {
              desired_values$units  <- bt_row$source_units[1]
            } else {
              desired_values$units  <- ""
            }
            if (nrow(dt_row) > 0) {
              item_user_cre(dt_row$user_cre[1])
            } else {
              item_user_cre("")
            }
            if (nrow(bt_row) > 0 && !is.na(bt_row$period_id[1])) {
              desired_values$period <- bt_row$period_id[1]
            } else {
              desired_values$period <- ""
            }
          }, error = function(e) {
            showNotification(paste0(i18n()$t("Error cargando variable"), ": ", e$message),
                             type = "error")
          })
        } else {
          # Create mode: reset to defaults
          new_id(next_id("variable", "VCUS"))
          desired_values$name   <- ""
          desired_values$label  <- ""
          desired_values$description    <- ""
          desired_values$units  <- ""
          desired_values$period <- ""
          item_user_cre("")
        }
      }, ignoreNULL = FALSE)

      ## [O] form_header ----
      output$form_header <- renderUI({
        p(
          if (is_edit_mode()) i18n()$t("Editar") else i18n()$t("Crear"),
          ": ",
          strong(new_id())
        )
      })

      ## [O] save_button_label ----
      output$save_button_label <- renderUI({
        if (is_edit_mode()) i18n()$t("Actualizar") else i18n()$t("Crear")
      })

      ## [O] delete_button_label ----
      output$delete_button_label <- renderUI({
        i18n()$t("Eliminar")
      })

      ## [O] show_delete ----
      output$show_delete <- reactive({ is_edit_mode() })
      outputOptions(output, "show_delete", suspendWhenHidden = FALSE)

      output$var_form <- renderUI({
        req(new_id())
        lan <- i18n()$get_translation_language()
        unit_ids <- con2 |> 
          tbl("v_units_select") |> 
          filter(unit_lang == lan) |> 
          select(unit_id, unit_label) |> 
          collect() |> 
          add_row(unit_id = "", 
                  unit_label = cleanHTML(i18n()$t("Selecciona una")), 
                  .before = 1)

        period_ids <- tryCatch({
          con2 |>
            tbl("dt_periods") |>
            inner_join(
              tbl(con2, "lt_periods") |> filter(period_lang == lan),
              by = "period_id"
            ) |>
            select(period_id, period_label, period_order) |>
            arrange(period_order) |>
            collect() |>
            add_row(
              period_id    = "",
              period_label = cleanHTML(i18n()$t("Selecciona una")),
              period_order = 0L,
              .before = 1
            )
        }, error = function(e) {
          tibble(period_id = character(0), period_label = character(0),
                 period_order = integer(0))
        })

        tagList(
          layout_columns(
            col_widths = c(6, 6),
            card(
              uiOutput(session$ns("form_header")),
              textInputIcon(session$ns("ti_variable_name"), 
                            width = "100%",
                            label = span(cleanHTML(i18n()$t("Nombre")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Nombre completo (una frase)")
                                         ),
                                         options = list(trigger = "hover")
                            ),
                            value = desired_values$name,
                            icon = list(NULL, icon("at"))),
              textInputIcon(session$ns("ti_variable_label"), 
                            width = "100%",
                            label = span(cleanHTML(i18n()$t("Etiqueta")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Nombre corto (una o pocas palabras)")
                                         ),
                                         options = list(trigger = "hover")
                            ),
                            value = desired_values$label,
                            icon = list(NULL, icon("tag"))),
              layout_columns(
                col_widths = c(6, 6),
                pickerInput(session$ns("pi_variable_units"), 
                            width = "100%",
                            label = i18n()$t("Unidades"),
                            choices = setNames(unit_ids$unit_id,
                                               unit_ids$unit_label),
                            selected = desired_values$units,
                            options = list(container = "body")
                ),
                pickerInput(session$ns("pi_variable_period"),
                            width = "100%",
                            label = span(cleanHTML(i18n()$t("Periodo")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Periodo de recolección del dato")
                                         ),
                                         options = list(trigger = "hover")
                            ),
                            choices = setNames(period_ids$period_id,
                                               period_ids$period_label),
                            selected = desired_values$period,
                            options = list(container = "body")
                )
              )
            ),
            card(
              textAreaInput(session$ns("tai_variable_des"), 
                            label = span(cleanHTML(i18n()$t("Descripción")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Descripción completa (un párrafo)")
                                         ),
                                         options = list(trigger = "hover")
                            ),
                            value = desired_values$description,
                            height = "192px",
                            width = "100%"),
              div(
                style = "display: flex; gap: 10px; width: 100%; align-items: stretch;",
                div(
                  style = "flex: 70; min-width: 0;",
                  actionButton(session$ns("ab_save_var"),
                               label = uiOutput(session$ns("save_button_label"), inline = TRUE),
                               icon = if (is_edit_mode()) icon("floppy-disk") else icon("plus"),
                               width = "100%")
                ),
                conditionalPanel(
                  condition = "output.show_delete",
                  ns = session$ns,
                  style = "flex: 30; min-width: 0; display: flex;",
                  actionButton(
                    session$ns("ab_delete_var"),
                    label = uiOutput(session$ns("delete_button_label"), inline = TRUE),
                    icon = icon("trash-can"),
                    width = "100%",
                    class = "btn-outline-danger"
                  )
                )
              )
            )
          )
        )
      })
      
      
      
      ## [O] ab_save_var ----
      observeEvent(input$ab_save_var, {
        if (!iv$is_valid()) {
          showNotification(i18n()$t("Datos incompletos"),
                           type = "error")
        } else {
          # Permission check
          if (!can_edit_item(item_user_cre())) {
            showNotification(i18n()$t("No tienes permisos para editar este elemento"),
                             type = "error")
            return(NULL)
          }

          period_val <- if (is.null(input$pi_variable_period) ||
                            nchar(input$pi_variable_period) == 0) {
            NA_character_
          } else {
            input$pi_variable_period
          }

          if (is_edit_mode()) {
            # UPDATE existing variable
            lan <- i18n()$get_translation_language()
            tryCatch({
              tbl(con2, "lt_variables") |>
                rows_update(
                  tibble(
                    variable_id    = new_id(),
                    variable_lang  = lan,
                    variable_name  = input$ti_variable_name,
                    variable_label = input$ti_variable_label,
                    variable_description = input$tai_variable_des
                  ),
                  by = c("variable_id", "variable_lang"),
                  in_place = TRUE,
                  copy = TRUE,
                  unmatched = "ignore"
                )
              tbl(con2, "bt_variable_source") |>
                rows_update(
                  tibble(
                    variable_id  = new_id(),
                    source_id    = "CUSTOM",
                    source_units = input$pi_variable_units,
                    period_id    = period_val
                  ),
                  by = c("variable_id", "source_id"),
                  in_place = TRUE,
                  copy = TRUE,
                  unmatched = "ignore"
                )
              last_modified(Sys.time())
              sendSweetAlert(title = i18n()$t("Actualizar"),
                             text = i18n()$t("Variable actualizada"),
                             type = "success")
            }, error = function(e) {
              showNotification(paste0(i18n()$t("Se ha producido un error al actualizar la variable"),
                                      ": ", e$message), duration = NULL, type = "error")
            })
          } else {
            # INSERT new variable
            current_user <- Sys.getenv("SHINYPROXY_USERNAME", unset = Sys.info()[["user"]])
            tryCatch({
              tbl(con2, "dt_variables") |>
                rows_insert(
                  tibble(
                    variable_id           = new_id(),
                    variable_comments     = "Created by user",
                    variable_original_name = input$ti_variable_name,
                    user_cre              = current_user,
                    ts_cre                = Sys.time()
                  ),
                  by = "variable_id",
                  conflict = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              purrr::walk(i18n()$get_languages(), function(lan_code) {
                tbl(con2, "lt_variables") |>
                  rows_upsert(
                    tibble(
                      variable_id          = new_id(),
                      variable_lang        = lan_code,
                      variable_name        = input$ti_variable_name,
                      variable_label       = input$ti_variable_label,
                      variable_description = input$tai_variable_des
                    ),
                    by = c("variable_id", "variable_lang"),
                    in_place = TRUE,
                    copy = TRUE
                  )
              })
              tbl(con2, "bt_variable_source") |>
                rows_insert(
                  tibble(
                    variable_id       = new_id(),
                    source_id         = "CUSTOM",
                    source_units      = input$pi_variable_units,
                    units_factor_mult = 1,
                    period_id         = period_val
                  ),
                  by = c("variable_id", "source_id"),
                  conflict = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              new_id(next_id("variable", "VCUS"))
              last_modified(Sys.time())
              sendSweetAlert(title = i18n()$t("Guardar"),
                             text = i18n()$t("Variable guardada"),
                             type = "success")
            }, error = function(e) {
              showNotification(paste0(i18n()$t("Se ha producido un error al añadir la variable"),
                                      ": ", e$message), duration = NULL, type = "error")
            })
          }
        }
      })


      ## [O] ab_delete_var ----
      observeEvent(input$ab_delete_var, {
        confirmSweetAlert(
          session = session,
          inputId = "confirm_delete_var",
          title = paste0(
            i18n()$t("¿Está seguro/a de eliminar"),
            " ",
            new_id(),
            "?"
          ),
          text = i18n()$t("Los datos serán eliminados y no se podrán restaurar."),
          type = "warning",
          btn_labels = c(i18n()$t("Cancelar"), i18n()$t("Eliminar")),
          btn_colors = c(get_theme_color(session, "primary"), get_theme_color(session, "danger")),
          html = FALSE
        )
      })

      ## [O] confirm_delete_var ----
      observeEvent(input$confirm_delete_var, {
        req(input$confirm_delete_var)

        vid <- new_id()
        tryCatch({
          DBI::dbWithTransaction(con2, {
            DBI::dbExecute(con2, "DELETE FROM ft_variables WHERE variable_id = $1", params = list(vid))
            DBI::dbExecute(con2, "DELETE FROM bt_indicator_variable WHERE variable_id = $1", params = list(vid))
            DBI::dbExecute(con2, "DELETE FROM bt_variable_source WHERE variable_id = $1", params = list(vid))
            DBI::dbExecute(con2, "DELETE FROM lt_variables WHERE variable_id = $1", params = list(vid))
            DBI::dbExecute(con2, "DELETE FROM dt_variables WHERE variable_id = $1", params = list(vid))
          })
          last_modified(Sys.time())
          sendSweetAlert(
            session = session,
            title = i18n()$t("Eliminado"),
            text = i18n()$t("Variable eliminada correctamente"),
            type = "success"
          )
          # Reset form fields
          updateTextInput(session, "ti_variable_name", value = "")
          updateTextInput(session, "ti_variable_label", value = "")
          updateTextAreaInput(session, "tai_variable_des", value = "")
        }, error = function(e) {
          showNotification(
            paste0(i18n()$t("Error al eliminar la variable"), ": ", e$message),
            duration = NULL,
            type = "error"
          )
        })
      })

      ## Return ----
      return(
        list(
          last_modified = last_modified
        )
      )
    }
  )
}

## Module app ----

mgt_var_form_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  translator <- getOption("evastur.translator")
  
  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    mgt_var_form_ui("varform1"),
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    mgt_var_form_server("varform1", i18n)
  }
  
  shinyApp(ui, server)
  
}

## Run app ----
# mgt_var_form_app()
