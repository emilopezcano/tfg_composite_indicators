## Global functions ----

#' ETL processes for a source
#'
#' Runs the whole ETL process from downloading to loading
#'
#' @param source source_id
#' @param .last_date last date in the database (optional). If NULL, all data is
#' processed.
#'
#' @returns TRUE if success
#' @export
#'
#' @examplesIf interactive()
#' # Process only new data after a specific date
#' etl_append_source(source = "UNWTO-STATS", .last_date = "2021-01-01")
#'
#' # Process all available data
#' etl_append_source(source = "UNWTO-STATS")
#' etl_append_source(source = "WB-DATA")
#' etl_append_source(source = "DATAESTUR")
#' etl_append_source(source = "INE-EGATUR")
#' etl_append_source(source = "INE-FRONTUR")
#' etl_append_source(source = "INE-ETR")
etl_append_source <- function(source, .last_date = NULL) {
  # Get data based on source
  df_data <- if (source == "UNWTO-STATS") {
    links <- unwto_download_links()
    res <- unwto_download_files(links)
    get_unwto_df(res$excel_files)
  } else if (source == "WB-DATA") {
    wb_indicators <- tbl(con2, "bt_variable_source") |>
      filter(source_id == "WB-DATA") |>
      select(source_varname) |>
      collect() |>
      pull(source_varname)
    wb_get_data(wb_indicators)
  } else if (source == "DATAESTUR") {
    dataestur_variables <- tbl(con2, "bt_variable_source") |>
      filter(source_id == "DATAESTUR") |>
      select(source_varname) |>
      collect() |>
      pull(source_varname)
    dataestur_get_data(variables = dataestur_variables)
  } else if (source == "INE-EGATUR") {
    ine_egatur_get_data()
  } else if (source == "INE-FRONTUR") {
    ine_frontur_get_data()
  } else if (source == "INE-ETR") {
    ine_etr_get_data()
  } else {
    warning("The source '", source, "' is not managed by any ETL process.")
    return(FALSE)
  }

  # Filter data by date if provided
  if (!is.null(.last_date)) {
    df_data <- df_data |>
      filter(date > .last_date)
    message("Filtered data to records after ", .last_date)
  } else {
    message("Processing all available data (no date filter)")
  }

  # Check if there's data to process
  if (nrow(df_data) == 0) {
    # Update source_last_update timestamp
    update_source_last_update(source)
    message("No new records to append")
    return(TRUE)
  }

  # Upsert to ft_variables table
  append_result <- append_fact_table(
    .data = df_data,
    table_name = "ft_variables",
    key_cols = c("variable_id", "date", "period_id", "geo_id", "source_id"),
    value_col = "variable_value"
  )

  if (append_result$error) {
    warning(
      "Failed to append data for source '",
      source,
      "': ",
      append_result$message
    )
    return(FALSE)
  }

  # Update source_last_update timestamp
  update_source_last_update(source)

  return(TRUE)
}

#' Append fact tables with upsert logic
#'
#' Inserts new rows and updates existing rows only for non-NA values.
#' This prevents overwriting existing data with missing values from new data files.
#'
#' @param .data data.frame with the new records
#' @param table_name name of the fact table to update
#' @param key_cols character vector of primary key column names
#' @param value_col name of the value column (e.g., "variable_value", "indicator_value")
#'
#' @return A list with two elements: error (TRUE or FALSE) and message (error message if any)
#' @export
#'
#' @examplesIf interactive()
#' res <- unwto_download_files(unwto_download_links())
#' df_unwto <- get_unwto_df(res$excel_files)
#' append_fact_table(
#'   .data = df_unwto,
#'   table_name = "ft_variables",
#'   key_cols = c("variable_id", "date", "period_id", "geo_id"),
#'   value_col = "variable_value"
#' )
append_fact_table <- function(.data, table_name, key_cols, value_col) {
  tryCatch(
    {
      # Step 1: Insert new records (conflict = "ignore" means skip if exists)
      rows_insert(
        tbl(con2, table_name),
        .data,
        by = key_cols,
        conflict = "ignore",
        in_place = TRUE,
        copy = TRUE
      )

      # Step 2: Identify which records need updating
      # Get existing records from database for the keys in .data
      existing_data <- tbl(con2, table_name) |>
        semi_join(
          .data |> select(all_of(key_cols)),
          by = key_cols,
          copy = TRUE
        ) |>
        select(all_of(c(key_cols, value_col))) |>
        collect() |>
        rename(old_value = !!sym(value_col))

      # Calculate how many records already existed (potential updates)
      n_existing <- nrow(existing_data)
      n_total <- nrow(.data)
      n_inserted <- n_total - n_existing

      # Join with new data to compare values
      data_to_update <- .data |>
        inner_join(existing_data, by = key_cols) |>
        mutate(
          new_value_na = is.na(.data[[value_col]]) |
            .data[[value_col]] == "" |
            is.null(.data[[value_col]]),
          old_value_na = is.na(old_value) | old_value == "" | is.null(old_value)
        ) |>
        # Only update if:
        # 1. New value is NOT NA (normal update with data)
        # 2. Both values are NA (to update flags, timestamps, etc.)
        # DO NOT update if database has a value but new is NA (keep existing data)
        filter(!new_value_na | (new_value_na & old_value_na)) |>
        select(-old_value, -new_value_na, -old_value_na)

      n_to_update <- nrow(data_to_update)
      n_skipped <- n_existing - n_to_update

      # Step 3: Update filtered records (if any)
      if (n_to_update > 0) {
        rows_update(
          tbl(con2, table_name),
          data_to_update,
          by = key_cols,
          in_place = TRUE,
          unmatched = "ignore",
          copy = TRUE
        )
      }

      # Build informative message
      parts <- character()
      if (n_inserted > 0) {
        parts <- c(parts, glue("{n_inserted} inserted"))
      }
      if (n_to_update > 0) {
        parts <- c(parts, glue("{n_to_update} updated"))
      }
      if (n_skipped > 0) {
        parts <- c(
          parts,
          glue("{n_skipped} skipped (would overwrite existing values)")
        )
      }

      message(
        glue(
          "Successfully processed {n_total} records to {table_name}: {paste(parts, collapse = ', ')}"
        )
      )

      list(error = FALSE, message = "")
    },
    error = function(e) {
      warning(e$message, conditionMessage(e$parent))
      list(error = TRUE, message = e$message)
    }
  )
}

#' Fill missing time periods with NULL values
#'
#' This function ensures that all `geo_id`s within the same `variable_id` have
#' a uniform and continuous time coverage.
#'
#' The time range (min and max date) is calculated **per variable_id**. This
#' means that if any `geo_id` has data for a specific period (e.g., 2023), all
#' other `geo_id`s belonging to the same `variable_id` will be expanded to
#' include that period, even if their original data ended earlier.
#'
#' Missing periods are filled with `NA` values. The `variable_value_flags`
#' column is updated (or created) as a list-column, adding the flag `"O"`
#' (Observation missing) to all generated rows.
#'
#' @param .data A data.frame containing at least the columns:
#'   - variable_id
#'   - geo_id
#'   - date (a character string parsable as a Date)
#'   - variable_value_flags (optional; will be created as a list if missing)
#' @param period The time unit for completion: `"Y"` for year, `"M"` for
#'   month or `"Q" for quarter.
#'
#' @return A data.frame where every `geo_id` for a given `variable_id` share
#'   the same start and end date. New rows will have:
#'   - `value`: `NA`
#'   - `variable_value_flags`: A list containing the element `"O"`.
#' @export
#'
#' @examples
#' df_y <- data.frame(
#'   variable_id = 1,
#'   geo_id = c("ES", "ES", "FR"),
#'   date = c("2021-01-01", "2022-01-01", "2023-01-01"),
#'   value = c(10, 20, 30)
#' )
#' fill_missing_periods(df_y, period = "Y")
#'
#' df_m <- data.frame(
#'   variable_id = 2,
#'   geo_id = 100,
#'   date = c("2021-01-01", "2021-03-01"),
#'   value = c(1, 3)
#' )
#' fill_missing_periods(df_m, period = "M")
#'
#' df_q <- data.frame(
#'   variable_id = 2,
#'   geo_id = 100,
#'   date = c("2021-03-01", "2021-09-01"),
#'   value = c(1, 3)
#' )
#' fill_missing_periods(df_q, period = "Q")
fill_missing_periods <- function(.data, period = "Y") {
  if (nrow(.data) == 0) {
    return(.data)
  }

  # Get period name for messages
  config <- list(
    "Y" = list(name = "year", by = 1),
    "M" = list(name = "month", by = "month"),
    "Q" = list(name = "quarter", by = "3 months")
  )

  conf <- config[[period]]

  if (is.null(conf)) {
    warning(glue("Unsupported period '{period}'. No filling performed."))
    return(.data)
  }

  period_name <- conf$name
  by_unit <- conf$by

  message(glue("Filling missing {period_name}s with NULL values..."))
  original_rows <- nrow(.data)

  # Group by variable and geography and add helper columns
  result <- .data |>
    mutate(
      date_obj = as.Date(date),
      variable_value_flags = if ("variable_value_flags" %in% names(.data)) {
        variable_value_flags
      } else {
        vector("list", n())
      },
      .is_original = TRUE
    ) |>
    group_by(variable_id) |>
    mutate(
      # Get date range of the variable (the same for all geo_id)
      v_min_date = min(date_obj, na.rm = TRUE),
      v_max_date = max(date_obj, na.rm = TRUE),
      .is_original = TRUE
    )

  # Complete time series based on period
  if (period == "Y") {
    result <- result |>
      mutate(year = as.integer(format(date_obj, "%Y"))) |>
      group_by(variable_id, geo_id) |>
      complete(
        year = seq(
          as.integer(format(min(v_min_date), "%Y")),
          as.integer(format(max(v_max_date), "%Y")),
          by = by_unit
        )
      ) |>
      mutate(
        date = if_else(
          is.na(date),
          format(as.Date(paste0(year, "-01-01")), "%Y-%m-%d"),
          date
        )
      ) |>
      select(-year)
  } else {
    # Case for "M" (1 month) y "Q" (3 months)
    result <- result |>
      group_by(variable_id, geo_id) |>
      complete(
        date_obj = seq.Date(
          min(v_min_date),
          max(v_max_date),
          by = by_unit
        )
      ) |>
      mutate(date = as.character(date_obj))
  }

  result <- result |>
    mutate(
      variable_value_flags = if_else(
        is.na(.is_original),
        list(c("O")),
        variable_value_flags
      )
    ) |>
    ungroup() |>
    select(-date_obj, -.is_original, -v_min_date, -v_max_date)

  filled_rows <- nrow(result) - original_rows

  if (filled_rows > 0) {
    message(glue(
      "Filled {filled_rows} missing {period_name}-rows (total: {nrow(result)})"
    ))
  } else {
    message(glue("No missing {period_name}s to fill."))
  }

  return(result)
}

#' Update source last update timestamp
#'
#' Updates the source_last_update column in dt_sources table
#' after successful ETL execution
#'
#' @param source_id Character. Source identifier (e.g., "UNWTO-STATS")
#'
#' @return TRUE if successful, FALSE otherwise
#' @export
#'
#' @examplesIf interactive()
#' update_source_last_update("UNWTO-STATS")
update_source_last_update <- function(source_id) {
  tryCatch(
    {
      # Direct UPDATE query - only touches source_last_update column
      rows_affected <- DBI::dbExecute(
        con2,
        "UPDATE dt_sources SET source_last_update = NOW() WHERE source_id = $1",
        params = list(source_id)
      )

      if (rows_affected == 0) {
        warning("Source '", source_id, "' not found in dt_sources")
        return(FALSE)
      }

      message("Updated source_last_update for ", source_id)
      return(TRUE)
    },
    error = function(e) {
      warning("Failed to update source timestamp: ", e$message)
      return(FALSE)
    }
  )
}

#' Update source last checking timestamp
#'
#' Updates the source_last_checking column in dt_sources table
#' when a user checks the source (clicks binoculars)
#'
#' @param source_id Character. Source identifier (e.g., "UNWTO-STATS")
#'
#' @return TRUE if successful, FALSE otherwise
#' @export
#'
#' @examplesIf interactive()
#' update_source_last_checking("UNWTO-STATS")
update_source_last_checking <- function(source_id) {
  tryCatch(
    {
      # Direct UPDATE query - only touches source_last_checking column
      rows_affected <- DBI::dbExecute(
        con2,
        "UPDATE dt_sources SET source_last_checking = NOW() WHERE source_id = $1",
        params = list(source_id)
      )

      if (rows_affected == 0) {
        warning("Source '", source_id, "' not found in dt_sources")
        return(FALSE)
      }

      message("Updated source_last_checking for ", source_id)
      return(TRUE)
    },
    error = function(e) {
      warning("Failed to update source checking timestamp: ", e$message)
      return(FALSE)
    }
  )
}

#' Update source last available timestamp
#'
#' Updates the source_last_available column in dt_sources table
#' with the date scraped from the source website
#'
#' @param source_id Character. Source identifier (e.g., "UNWTO-STATS")
#' @param timestamp Character. Timestamp scraped from source (PostgreSQL format)
#'
#' @return TRUE if successful, FALSE otherwise
#' @export
#'
#' @examplesIf interactive()
#' update_source_last_available("UNWTO-STATS", "2025-11-01 00:00:00.000000+00")
update_source_last_available <- function(source_id, timestamp) {
  tryCatch(
    {
      # Validate timestamp is not NA
      if (is.na(timestamp)) {
        warning("Cannot update source_last_available with NA timestamp")
        return(FALSE)
      }

      # Direct UPDATE query - only touches source_last_available column
      rows_affected <- DBI::dbExecute(
        con2,
        "UPDATE dt_sources SET source_last_available = $1 WHERE source_id = $2",
        params = list(timestamp, source_id)
      )

      if (rows_affected == 0) {
        warning("Source '", source_id, "' not found in dt_sources")
        return(FALSE)
      }

      message(
        "Updated source_last_available for ",
        source_id,
        " to ",
        timestamp
      )
      return(TRUE)
    },
    error = function(e) {
      warning("Failed to update source last available: ", e$message)
      return(FALSE)
    }
  )
}

#' Get last available date from source
#'
#' Retrieves the most recent available date from a supported data source.
#'
#' @param source Source ID (e.g., "UNWTO-STATS", "WB-DATA").
#'
#' @return
#' A character string representing a PostgreSQL timestamp
#' (`"YYYY-mm-dd HH:MM:SS.000000+00"`) when the source provides a valid
#' last available or last data update date.
#'
#' Returns **NA** when the source is implemented but does not publish a
#' last-available timestamp (e.g., DATAESTUR).
#'
#' Returns **NULL** when the source is not supported or an error occurs during
#' retrieval (failure).
#'
#' @details
#' This function distinguishes three cases:
#'
#' - **Valid timestamp (character)** → The source successfully returned the last
#'   available date.
#'
#' - **NA** → The source exists and is implemented, but it does not provide a
#'   “last available” timestamp.
#'
#' - **NULL** → The source is unknown, not implemented, or an error was thrown
#'   while retrieving the value.
#'
#' @export
#'
#' @examples
#' get_source_last_available("UNWTO-STATS")
#' get_source_last_available("WB-DATA")
#' get_source_last_available("DATAESTUR")
#' get_source_last_available("UNKNOWN-SOURCE")
get_source_last_available <- function(source) {
  tryCatch(
    {
      if (source == "UNWTO-STATS") {
        unwto_source_last_available()
      } else if (source == "WB-DATA") {
        wb_source_last_available()
      } else if (source == "DATAESTUR") {
        dataestur_source_last_available()
      } else if (source == "INE-EGATUR") {
        ine_source_last_available(source_id = source)
      } else if (source == "INE-FRONTUR") {
        ine_source_last_available(source_id = source)
      } else if (source == "INE-ETR") {
        ine_source_last_available(source_id = source)
      } else {
        warning(
          "The source '",
          source,
          "' does not have last_available checking implemented."
        )
        NULL
      }
    },
    error = function(e) {
      warning(
        "Error checking last available for source '",
        source,
        "': ",
        e$message
      )
      NULL
    }
  )
}

## UNWTO ----

#' Get UNWTO bulk download links
#'
#' @param url URL for UN Tourism statistics database
#' @return Character vector of bulk download URLs
#' @export
#'
#' @examplesIf interactive()
#' links <- unwto_download_links()
unwto_download_links <- function(
  url = "https://www.untourism.int/tourism-statistics/tourism-statistics-database"
) {
  message("Searching for bulk download links...")

  res <- url |>
    read_html() |>
    html_nodes(xpath = "//a[contains(text(), 'Bulk data download')]") |>
    html_attr("href")

  message("Found ", length(res), " bulk download link(s)")
  res
}

#' Get UNWTO "latest available" line
#'
#' @param url URL for UN Tourism statistics database
#' @return Character scalar with parsed timestamp in PostgreSQL format (YYYY-MM-DD HH:MM:SS.microseconds+TZ), or NA if parsing fails
#' @export
#'
#' @examplesIf interactive()
#' unwto_source_last_available()
unwto_source_last_available <- function(
  url = "https://www.untourism.int/tourism-statistics/tourism-statistics-database"
) {
  message("Searching for date last available data...")

  timestamp <- tryCatch(
    {
      # Scrape and extract date string
      node <- url |>
        read_html() |>
        html_node(
          xpath = "//strong[contains(., 'The latest update took place')]"
        )

      if (inherits(node, "xml_missing")) {
        stop("Date element not found in UNWTO page (xml_missing)")
      }

      date_str <- node |>
        html_text2() |>
        str_extract("\\d{1,2}\\s+[A-Za-z]+\\s+\\d{4}")

      if (is.na(date_str)) {
        stop("Error extracting date string from element ", date_str)
      }

      # Parse and format as PostgreSQL timestamp
      parsed <- parse_date_time(
        date_str,
        orders = c("d B Y", "d b Y"),
        quiet = TRUE,
        tz = "UTC"
      )
      if (is.na(parsed)) {
        stop("Error parsing date from string ", date_str)
      }
      paste0(format(parsed, "%Y-%m-%d %H:%M:%S", tz = "UTC"), ".000000+00")
    },
    error = function(e) {
      warning("Failed to parse UNWTO date: ", e$message)
      NA_character_
    }
  )

  message(glue("UNWTO last updated: {timestamp}"))
  timestamp
}

#' Download and extract UNWTO ZIP files
#'
#' @param links character vector with ZIP download URLs
#'
#' @returns List with excel_files (paths)
#' @export
#'
#' @examplesIf interactive()
#' links <- unwto_download_links()
#' res <- unwto_download_files(links)
unwto_download_files <- function(links) {
  message("Downloading and extracting bulk ZIP files...")

  destination_path <- tempdir()

  excel_files <- c()
  for (link in links) {
    zip_file <- file.path(destination_path, basename(link))

    message("Downloading: ", basename(link))
    tryCatch(
      {
        download.file(link, zip_file, mode = "wb", quiet = TRUE)

        message("Extracting: ", basename(link))
        archive_extract(zip_file, dir = destination_path)

        # Find Excel files recursively in extracted content (files are in subfolders)
        extracted <- list.files(
          destination_path,
          pattern = "\\.xlsx$",
          full.names = TRUE,
          recursive = TRUE
        )
        excel_files <- c(excel_files, extracted)
      },
      error = function(e) {
        warning("Failed to download/extract ", link, ": ", e$message)
      }
    )
  }

  message("Extracted ", length(excel_files), " Excel file(s)")

  list(
    excel_files = excel_files,
    destination_path = destination_path
  )
}


#' Parse flags from FootNote and return flags + cleaned notes
#'
#' This helper extracts known flag codes from a long text (e.g. FootNote).
#'
#' Recognised mappings:
#'  - "Break in series" -> "B"
#'  - "Provisional data" / "Provisional" -> "P"
#'  - "Estimate" / "Estimated" -> "E"
#'  - "Imputed" -> "I"
#'  - "Confidential" -> "C"
#'
#' @param note Character scalar; full FootNote text (may contain multiple sentences)
#' @return A list with two elements:
#'   - flags: character vector of flag codes (may be length 0)
#'   - notes: remaining text after removing recognised flag phrases (NA_character_ if none)
#' @export
parse_flags_notes <- function(note) {
  patterns <- list(
    B = c("break in series"),
    P = c("provisional data", "provisional"),
    E = c("estimate", "estimated"),
    I = c("imputed"),
    C = c("confidential")
  )

  # Normalise and split sentences. Remove empty pieces.
  if (is.na(note) || !nzchar(trimws(as.character(note)))) {
    return(list(flags = character(0), notes = NA_character_))
  }

  phrases <- unlist(strsplit(as.character(note), "\\.\\s*"))
  phrases <- trimws(phrases)
  phrases <- phrases[phrases != ""]

  flags_found <- character(0)
  remaining_phrases <- character(0)

  for (ph in phrases) {
    matched <- FALSE
    lc <- tolower(ph)
    for (code in names(patterns)) {
      for (pat in patterns[[code]]) {
        if (grepl(pat, lc, fixed = TRUE)) {
          flags_found <- c(flags_found, code)
          matched <- TRUE
          break
        }
      }
      if (matched) break
    }
    if (!matched) {
      remaining_phrases <- c(remaining_phrases, ph)
    }
  }

  flags_found <- unique(flags_found)
  remaining_text <- if (length(remaining_phrases) == 0) {
    NA_character_
  } else {
    paste(remaining_phrases, collapse = ". ")
  }

  list(flags = flags_found, notes = remaining_text)
}

#' Convert R character vector of flags to Postgres array literal
#'
#' This helper function takes a character vector of flags and formats it as a
#' PostgreSQL array literal (e.g., `"{A,B}"`). It handles `NULL`, empty vectors,
#' and `NA` values by returning `NA_character_`. It also ensures all flags are
#' uppercase, trimmed of whitespace, and that empty strings or "NA" strings are
#' ignored.
#'
#' @param x A character vector (possibly length 0) or `NA`.
#'
#' @return A character scalar representing a PostgreSQL array literal
#'   (e.g., `"{A,B}"`) or `NA_character_` if no valid flags are provided.
#' @export
#'
#' @examples
#' flags_to_pg_array(c("p", "e"))
#' flags_to_pg_array(c(" A ", "b"))
#' flags_to_pg_array(character(0))
#' flags_to_pg_array(NA)
flags_to_pg_array <- function(x) {
  # x is expected to be a character vector (possibly length 0) or NA
  if (is.null(x) || length(x) == 0) {
    return(NA_character_)
  }
  # sometimes x might be atomic scalar "NA" or NA_character_
  if (all(is.na(x))) {
    return(NA_character_)
  }
  vals <- as.character(x)
  vals <- toupper(trimws(vals))
  vals <- vals[!is.na(vals) & vals != "" & vals != "NA"]
  if (length(vals) == 0) {
    return(NA_character_)
  }
  paste0("{", paste(vals, collapse = ","), "}")
}

#' Load and consolidate UNWTO bulk download Excel files
#'
#' @param excel_files character vector of Excel file paths
#' @returns consolidated data.frame
#' @export
#'
get_unwto_df <- function(excel_files) {
  message("Loading Excel files (sheet 2)...")

  df_list <- purrr::map(
    seq_along(excel_files),
    ~ {
      message(
        "File ",
        .x,
        "/",
        length(excel_files),
        ": ",
        basename(excel_files[.x])
      )
      df <- readxl::read_excel(excel_files[.x], sheet = 2, col_types = "text")

      # Apply column name standardization
      df <- df |>
        dplyr::rename_with(
          ~ dplyr::case_when(
            .x == "indicator_code" ~ "source_varname",
            .x == "SeriesCode" ~ "source_varname",
            .x == "reporter_area_code" ~ "country_code",
            .x == "GeoAreaCode" ~ "country_code",
            .x == "reporter_area_label" ~ "country_name",
            .x == "GeoAreaName" ~ "country_name",
            .x == "TimePeriod" ~ "year",
            .x == "Value" ~ "variable_value",
            .x == "value" ~ "variable_value",
            .x == "flag" ~ "variable_value_flags",
            .x == "notes" ~ "variable_value_notes",
            .x == "FootNote" ~ "variable_value_notes",
            TRUE ~ .x
          )
        ) |>
        dplyr::mutate(
          country_code = sprintf("%03d", as.numeric(country_code)),
          year = as.numeric(year),
          source_varname = as.character(source_varname),
          variable_value = as.numeric(variable_value)
        )

      # Determine which scenario we're in
      has_flag_col <- "variable_value_flags" %in% names(df)
      has_notes_col <- "variable_value_notes" %in% names(df)

      if (has_flag_col && has_notes_col) {
        # Scenario 1: Both flag and notes columns exist
        # Parse flags as comma-separated list, keep notes as-is
        df <- df |>
          dplyr::mutate(
            variable_value_flags = purrr::map(
              variable_value_flags,
              ~ {
                if (is.na(.x) || !nzchar(trimws(as.character(.x)))) {
                  character(0)
                } else {
                  parts <- unlist(strsplit(as.character(.x), ","))
                  parts <- toupper(trimws(parts))
                  parts[parts != "" & parts != "NA"]
                }
              }
            ),
            variable_value_notes = dplyr::if_else(
              is.na(variable_value_notes) |
                !nzchar(trimws(as.character(variable_value_notes))),
              NA_character_,
              as.character(variable_value_notes)
            )
          )
      } else if (has_notes_col) {
        # Scenario 2: Only FootNote/notes column exists
        # Parse FootNote to extract flags and cleaned notes
        df <- df |>
          dplyr::mutate(
            .tmp = purrr::map(variable_value_notes, parse_flags_notes),
            variable_value_flags = purrr::map(.tmp, "flags"),
            variable_value_notes = purrr::map_chr(.tmp, "notes")
          ) |>
          dplyr::select(-.tmp)
      } else {
        # Neither column exists - create empty ones
        df$variable_value_flags <- list(character(0))
        df$variable_value_notes <- NA_character_
      }

      df |>
        dplyr::select(
          country_code,
          country_name,
          year,
          source_varname,
          variable_value,
          variable_value_flags,
          variable_value_notes
        )
    }
  )

  # Combine all files into one tibble
  df_all <- dplyr::bind_rows(df_list)

  # Add date column from year
  df_all <- df_all |>
    dplyr::mutate(
      date = as.character(as.Date(paste0(year, "-01-01")))
    ) |>
    dplyr::select(-year)

  # Load variable mapping from database and map source_varname -> variable_id
  vars_map <- tbl(con2, "bt_variable_source") |>
    filter(source_id == "UNWTO-STATS") |>
    select(variable_id, source_varname, units_factor_mult) |>
    collect()

  unmapped_vars <- setdiff(
    unique(df_all$source_varname),
    vars_map$source_varname
  )

  if (length(unmapped_vars) > 0) {
    warning(glue(
      "⚠️ {length(unmapped_vars)} variables not found in 'bt_variable_source': {paste(unmapped_vars, collapse = ', ')}"
    ))
  }

  # Inner join to keep only known variables and apply units factor
  df_all <- df_all |>
    dplyr::inner_join(vars_map, by = "source_varname") |>
    dplyr::mutate(
      variable_value = variable_value * units_factor_mult
    ) |>
    dplyr::select(-source_varname, -units_factor_mult)

  # Map country_code (ISO3 numeric) -> geo_id via dt_geo table (direct join)
  geo_map <- tbl(con2, "dt_geo") |>
    select(geo_id, country_code) |>
    collect()

  df_all <- df_all |>
    dplyr::left_join(geo_map, by = "country_code")

  unmatched <- df_all |> filter(is.na(geo_id))

  if (nrow(unmatched) > 0) {
    missing_info <- unmatched |>
      distinct(country_code, country_name) |>
      arrange(country_name)

    missing_pairs <- paste0(
      missing_info$country_name,
      " (",
      missing_info$country_code,
      ")"
    )

    warning(glue(
      "⚠️ {nrow(missing_info)} countries without correspondence in 'dt_geo': {paste(missing_pairs, collapse = ', ')}"
    ))
  }

  df_all <- df_all |>
    # filter(!is.na(geo_id)) |>
    select(-country_code, -country_name)

  df_all <- fill_missing_periods(df_all, period = "Y")

  # Add required columns and format flags
  df_all |>
    dplyr::mutate(
      variable_value_flags = purrr::map_chr(
        variable_value_flags,
        flags_to_pg_array
      )
    ) |>
    dplyr::mutate(
      period_id = "Y",
      source_id = "UNWTO-STATS",
      variable_ts = Sys.time(),
      variable_prov = FALSE,
      variable_secret = FALSE,
      user_cre = NA_character_,
      imputed = FALSE,
      imputation_method = NA_character_
    ) |>
    dplyr::select(
      variable_id,
      date,
      period_id,
      geo_id,
      variable_value,
      variable_ts,
      source_id,
      variable_prov,
      variable_secret,
      user_cre,
      imputed,
      imputation_method,
      variable_value_flags,
      variable_value_notes
    )
}

## World Bank ----

#' Get World Bank API last update date
#'
#' Queries the World Bank API to check the last update timestamp.
#' Returns a PostgreSQL-friendly UTC timestamp, e.g.
#' `"2024-01-01 00:00:00.000000+00"`.
#'
#' If no indicator is provided, the function will query all World Bank
#' indicators registered in `bt_variable_source` with `source_id = "WB-DATA"`
#' and return the most recent timestamp.
#'
#' @param indicator World Bank indicator code (e.g., "SP.POP.TOTL").
#'
#' @return A character string with PostgreSQL timestamp
#' (`YYYY-mm-dd HH:MM:SS.000000+00`), or NULL on failure.
#' @export
#'
#' @examplesIf interactive()
#' wb_source_last_available()
#' wb_source_last_available("SP.POP.TOTL")
wb_source_last_available <- function(indicator = NULL) {
  message(
    "Checking last available for source 'WB-DATA': Not supported by the source."
  )
  return(NA_character_)
  # Not found a way in new Data360 API. Waiting support answer.

  # # Case 1: Check all indicators in bt_variable_source
  # if (is.null(indicator)) {
  #   wb_indicators <- tbl(con2, "bt_variable_source") |>
  #     filter(source_id == "WB-DATA") |>
  #     select(source_varname) |>
  #     collect() |>
  #     pull(source_varname)

  #   if (length(wb_indicators) == 0) {
  #     warning("No World Bank indicators found in bt_variable_source")
  #     return(NULL)
  #   }

  #   message(glue("Checking {length(wb_indicators)} World Bank indicators"))

  #   # Check each indicator and get the most recent date
  #   dates <- purrr::map(wb_indicators, function(ind) {
  #     wb_source_last_available(indicator = ind)
  #   })

  #   # Filter out NAs and get the maximum date
  #   valid_dates <- unlist(dates[!is.na(dates)])

  #   if (length(valid_dates) == 0) {
  #     warning("No valid dates retrieved from World Bank API")
  #     return(NULL)
  #   }

  #   parsed_dates <- as.POSIXct(valid_dates, tz = "UTC")
  #   max_date <- max(parsed_dates, na.rm = TRUE)
  #   result <- paste0(
  #     format(max_date, "%Y-%m-%d %H:%M:%S", tz = "UTC"),
  #     ".000000+00"
  #   )

  #   message(glue(
  #     "Most recent World Bank update across all indicators: {max_date}"
  #   ))
  #   return(result)
  # }

  # # Case 2: Query single indicator
  # message(glue(
  #   "Checking World Bank API last update date for \"{indicator}\""
  # ))

  # url <- glue(
  #   "https://api.worldbank.org/v2/country/all/indicator/{indicator}?format=json&per_page=1"
  # )

  # tryCatch(
  #   {
  #     response <- jsonlite::fromJSON(url)

  #     # The first element contains metadata
  #     metadata <- response[[1]]
  #     api_date <- metadata$lastupdated
  #     parsed_date <- as.POSIXct(api_date, tz = "UTC")

  #     timestamp <- paste0(
  #       format(parsed_date, "%Y-%m-%d %H:%M:%S", tz = "UTC"),
  #       ".000000+00"
  #     )

  #     message(glue(
  #       "World Bank API \"{indicator}\" last updated: {api_date}"
  #     ))

  #     return(timestamp)
  #   },
  #   error = function(e) {
  #     warning("Failed to check World Bank API update status: ", e$message)
  #     return(NULL)
  #   }
  # )
}

#' Fetch data from World Bank API for a single indicator
#'
#' @param indicator World Bank indicator code
#'
#' @return data.frame with raw API data
#' @export
#'
#' @examplesIf interactive()
#' wb_fetch_indicator("WB_WDI_SL_TLF_TOTL_IN")
wb_fetch_indicator <- function(indicator) {
  message(glue("Fetching data for indicator \"{indicator}\""))

  # Extract DATABASE_ID
  # Pattern: ID is like WB_WDI_SL_TLF_TOTL_IN -> DATABASE_ID is WB_WDI
  # We take everything up to the second underscore
  parts <- strsplit(indicator, "_")[[1]]

  if (length(parts) < 2) {
    warning(glue(
      "Invalid indicator format '{indicator}'. Cannot extract DATABASE_ID."
    ))
    return(data.frame())
  }

  database_id <- paste(parts[1], parts[2], sep = "_")

  all_data <- list()
  skip <- 0
  limit <- 1000 # Fixed per page limit in API definition

  repeat {
    url <- glue(
      "https://data360api.worldbank.org/data360/data?DATABASE_ID={database_id}&INDICATOR={indicator}&skip={skip}"
    )

    tryCatch(
      {
        response <- httr::GET(
          url,
          httr::add_headers(accept = "application/json")
        )

        if (httr::http_error(response)) {
          warning(glue(
            "Failed to fetch data for {indicator}: {httr::http_status(response)$reason}"
          ))
          break
        }

        content <- httr::content(response, as = "text", encoding = "UTF-8")
        json_res <- jsonlite::fromJSON(content)

        # Structure: { count: 8216, value: [...] }
        data <- json_res$value
        total_count <- json_res$count

        if (is.null(data) || length(data) == 0) {
          break
        }

        all_data[[length(all_data) + 1]] <- data

        skip <- skip + limit

        if (!is.null(total_count) && skip >= total_count) {
          break
        }
        # Safety break if total_count is missing but we got less than limit
        if (nrow(data) < limit) {
          break
        }
      },
      error = function(e) {
        warning(glue(
          "Failed to fetch data for {indicator}: {e$message}"
        ))
        break
      }
    )
  }

  if (length(all_data) == 0) {
    warning(glue("No data retrieved for indicator {indicator}"))
    return(data.frame())
  }

  # Combine all pages
  dplyr::bind_rows(all_data)
}

#' Process World Bank data into standard format
#'
#' @param indicators Character vector of World Bank indicator codes
#'
#' @return data.frame in standard format for ft_variables table
#' @export
#'
#' @examplesIf interactive()
#' wb_get_data(c("WB_WDI_SL_TLF_TOTL_IN"))
wb_get_data <- function(indicators) {
  message("Fetching World Bank data...")

  # Fetch data from all indicators
  df_list <- purrr::map(indicators, wb_fetch_indicator)

  # Combine all indicators
  df_all <- dplyr::bind_rows(df_list)

  if (nrow(df_all) == 0) {
    warning("No data retrieved from World Bank API")
    return(data.frame())
  }

  message(glue(
    "Retrieved {nrow(df_all)} total records from World Bank API"
  ))

  # Standardize column names and extract needed fields
  # New API returns: OBS_VALUE, OBS_STATUS, INDICATOR, REF_AREA, TIME_PERIOD
  df_all <- df_all |>
    dplyr::mutate(
      source_varname = INDICATOR,
      country_code = REF_AREA,
      year = as.numeric(TIME_PERIOD),
      variable_value = as.numeric(OBS_VALUE),
      variable_value_flags = purrr::map(OBS_STATUS, function(x) {
        if (!is.na(x) && nzchar(trimws(x))) {
          toupper(trimws(x))
        } else {
          character(0)
        }
      })
    ) |>
    dplyr::select(
      source_varname,
      country_code,
      year,
      variable_value,
      variable_value_flags
    )

  # Add date column from year
  df_all <- df_all |>
    dplyr::mutate(
      date = as.character(as.Date(paste0(year, "-01-01")))
    ) |>
    dplyr::select(-year)

  # Load variable mapping from database
  vars_map <- tbl(con2, "bt_variable_source") |>
    filter(source_id == "WB-DATA") |>
    select(variable_id, source_varname, units_factor_mult) |>
    collect()

  unmapped_vars <- setdiff(
    unique(df_all$source_varname),
    vars_map$source_varname
  )

  if (length(unmapped_vars) > 0) {
    warning(glue(
      "⚠️ {length(unmapped_vars)} variables not found in 'bt_variable_source': {paste(unmapped_vars, collapse = ', ')}"
    ))
  }

  # Inner join to keep only known variables and apply units factor
  df_all <- df_all |>
    inner_join(vars_map, by = "source_varname") |>
    mutate(
      variable_value = variable_value * units_factor_mult
    ) |>
    select(-source_varname, -units_factor_mult)

  # Map country_code (ISO3) -> geo_id via dt_geo table
  # In dt_geo, geo_id IS the ISO3 code, so we just check which codes exist
  geo_map <- tbl(con2, "dt_geo") |>
    filter(nuts_level == 0) |>
    select(geo_id) |>
    collect() |>
    rename(country_code = geo_id)

  # Check for unmatched country codes before joining
  unmatched_codes <- setdiff(unique(df_all$country_code), geo_map$country_code)

  if (length(unmatched_codes) > 0) {
    warning(glue(
      "⚠️ {length(unmatched_codes)} country codes/aggregates from WB ignored: {paste(unmatched_codes, collapse = ', ')}"
    ))
  }

  # Rename country_code to geo_id (they are the same: ISO3)
  df_all <- df_all |>
    inner_join(geo_map, by = "country_code") |>
    rename(geo_id = country_code)

  df_all <- fill_missing_periods(df_all, period = "Y")

  # Add required columns
  df_all |>
    mutate(
      variable_value_flags = purrr::map_chr(
        variable_value_flags,
        flags_to_pg_array
      ),
      period_id = "Y",
      source_id = "WB-DATA",
      variable_ts = Sys.time(),
      variable_prov = FALSE,
      variable_secret = FALSE,
      user_cre = NA_character_,
      imputed = FALSE,
      imputation_method = NA_character_,
      variable_value_notes = NA_character_
    ) |>
    select(
      variable_id,
      date,
      period_id,
      geo_id,
      variable_value,
      variable_ts,
      source_id,
      variable_prov,
      variable_secret,
      user_cre,
      imputed,
      imputation_method,
      variable_value_flags,
      variable_value_notes
    )
}

## Dataestur ----

#' Fetch raw data from Dataestur API
#'
#' This function performs a GET request to the Dataestur API. It includes a
#' resilient retry strategy using `purrr::insistently`. If the API returns
#' a 429 (Too Many Requests) or a generic HTTP error, the function will
#' automatically wait and retry the request before giving up.
#'
#' @param endpoint API endpoint (e.g., `"IND_SATISFACCION_PERCEPCION_DL"`)
#' @param filters URL filters (e.g., `"CCAA=Todos&Provincia=Todos"`)
#' @param retry_pause Time in seconds to wait between retries. Default is 5.
#' @param retry_max Maximum number of attempts (including the first one).
#'   Default is 10.
#'
#' @return A data frame with raw data from the API
#' @export
dataestur_fetch_data <- function(
  endpoint,
  url_filters,
  retry_pause = 5,
  retry_max = 10
) {
  url_base <- glue("https://dataestur.azure-api.net/API-SEGITTUR-v1/{endpoint}")

  fetch_safely <- purrr::insistently(
    function(url, query) {
      res <- httr::GET(url, query = query)
      if (httr::status_code(res) == 429) {
        stop("Rate limit exceeded (429 Too Many Requests)")
      } else if (httr::http_error(res)) {
        stop(glue("HTTP Error: {httr::http_status(res)$reason}"))
      }
      res
    },
    rate = purrr::rate_delay(pause = retry_pause, max_times = retry_max)
  )

  # Helper to process a single set of filters
  fetch_single <- function(current_filters) {
    message(glue(
      "Fetching data from Dataestur API \"{endpoint}\" with filters \"{current_filters}\""
    ))

    query_list <- list()
    if (
      !is.null(current_filters) &&
        !is.na(current_filters) &&
        current_filters != ""
    ) {
      params <- strsplit(current_filters, "&")[[1]]
      for (p in params) {
        kv <- strsplit(p, "=")[[1]]
        if (length(kv) == 2) {
          query_list[[kv[1]]] <- kv[2]
        } else if (length(kv) == 1) {
          query_list[[kv[1]]] <- ""
        }
      }
    }

    response <- tryCatch(
      {
        fetch_safely(url = url_base, query = query_list)
      },
      error = function(e) {
        warning(glue("Failed to retrieve data from Dataestur API: {e$message}"))
        return(NULL)
      }
    )

    if (is.null(response)) {
      return(NULL)
    }

    content_type <- httr::headers(response)$`content-type`
    raw_content <- httr::content(response, "raw")

    if (length(raw_content) == 0) {
      return(NULL)
    }

    if (grepl("excel|spreadsheetml", content_type, ignore.case = TRUE)) {
      message("Detected Excel format")
      tmp <- tempfile(fileext = ".xlsx")
      writeBin(raw_content, tmp)
      df_raw <- readxl::read_excel(tmp)
      unlink(tmp)
    } else {
      message("Detected CSV format")
      # Get raw content and fix encoding issue (likely latin1 -> UTF-8)
      csv_content <- iconv(
        rawToChar(raw_content),
        from = "latin1",
        to = "UTF-8"
      )

      # Remove the BOM (Byte Order Mark) if it exists at the beginning of the file
      if (startsWith(csv_content, "\uFEFF")) {
        csv_content <- substring(csv_content, 2)
      }

      df_raw <- readr::read_csv2(
        csv_content,
        col_types = cols(
          .default = col_character(),
          AÑO = col_integer(),
          MES = col_integer()
        ),
        # Be explicit about spanish locale to handle decimals correctly
        locale = locale(decimal_mark = ",")
      )

      safe_numeric_conversion <- function(x) {
        # If not character, don't modify it
        if (!is.character(x)) {
          return(x)
        }

        # Remove trailing white spaces
        x_clean <- trimws(x)

        # Select only non-NA values
        non_na_values <- x_clean[!is.na(x_clean)]
        if (length(non_na_values) == 0) {
          return(x)
        } # Empty column

        # REGEX: Do all the values appear to be purely positive numbers?
        # Accepts: digits and optional decimal part (dot or comma followed by more digits)
        # Doesn't accept: "Hotel 3 estrellas", "Andalucía", etc.
        is_numeric_pattern <- all(grepl(
          "^[0-9]+([\\.,][0-9]+)?$",
          non_na_values
        ))

        if (is_numeric_pattern) {
          # Replace comma separator for spanish files
          return(suppressWarnings(as.numeric(gsub(",", ".", x_clean))))
        }

        # If not a pure number, return original comma
        return(x)
      }

      # Convert all columns that look like numbers to double, except AÑO and MES
      df_raw <- df_raw |>
        mutate(across(
          !any_of(c("AÑO", "MES")),
          safe_numeric_conversion
        ))
    }

    if (!is.null(df_raw)) {
      message(glue("Successfully fetched {nrow(df_raw)} rows"))
    }

    df_raw
  }

  is_iterating <- !is.null(url_filters) &&
    grepl("CCAA=\\{ITERATE\\}", url_filters)

  if (is_iterating) {
    comunidades <- c(
      "Andalucía",
      "Aragón",
      "Canarias",
      "Cantabria",
      "Castilla - La Mancha",
      "Castilla y León",
      "Cataluña",
      "Ceuta",
      "Comunidad Foral de Navarra",
      "Comunidad Valenciana",
      "Comunitat Valenciana",
      "Comunidad de Madrid",
      "Extremadura",
      "Galicia",
      "Islas Baleares",
      "Illes Balears",
      "La Rioja",
      "Melilla",
      "País Vasco",
      "Principado de Asturias",
      "Región de Murcia",
      "Nacional",
      "Total Nacional"
    )

    message("Iterating through regional placeholder {ITERATE}")

    list_dfs <- purrr::map(comunidades, function(comunidad) {
      current_filter <- sub("\\{ITERATE\\}", comunidad, url_filters)
      fetch_single(current_filter)
    })

    df_combined <- dplyr::bind_rows(
      purrr::keep(list_dfs, ~ nrow(.x) > 0)
    )
    message(glue(
      "Successfully combined {nrow(df_combined)} rows from iteration"
    ))
    return(df_combined)
  } else {
    return(fetch_single(url_filters))
  }
}

#' Process raw Dataestur data into database format
#'
#' @param df Raw data frame from dataestur_fetch_data()
#' @param target_var The name of the variable to extract
#' @param data_filters Dplyr filter string
#' @param source_varname Original variable string from DB
#' @param source Source ID (default: `"DATAESTUR"`)
#'
#' @return A processed data frame ready for database insertion
#' @export
#'
#' @examplesIf interactive()
#' df_raw <- dataestur_fetch_data(
#'   endpoint = "PRECIOS_ALOJAMIENTOS_HOTELEROS_DL",
#'   url_filters = "CCAA=Todos&Provincia=Todos"
#' )
#'
#' data <- dataestur_process_data(
#'   df = df_raw,
#'   target_var = "PRECIO_CHECK-IN_ENTRE_SEMANA",
#'   data_filters = "CATEGORIA_ALOJAMIENTO == \"Hotel 3 Estrellas\", PERIODO_ANTELACION == \"2 Semanas\"",
#'   source_varname = "PRECIOS_ALOJAMIENTOS_HOTELEROS_DL : PRECIO_CHECK-IN_ENTRE_SEMANA : CCAA=Todos&Provincia=Todos : CATEGORIA_ALOJAMIENTO == \"Hotel 3 Estrellas\", PERIODO_ANTELACION == \"2 Semanas\"",
#'   source = "DATAESTUR"
#' )
dataestur_process_data <- function(
  df,
  target_var,
  data_filters,
  source_varname,
  source = "DATAESTUR"
) {
  if (is.null(df) || nrow(df) == 0) {
    warning("No data to process")
    return(data.frame())
  }

  if (!is.character(source) || length(source) != 1 || is.na(source)) {
    warning("Parameter 'source' must be a string.")
    return(data.frame())
  }

  message(glue(
    "Processing data from Dataestur API for variable \"{target_var}\" with filters \"{data_filters}\""
  ))

  # Variable mapping and scaling
  vars_map <- tbl(con2, "bt_variable_source") |>
    filter(source_id == !!source) |>
    filter(source_varname == !!source_varname) |>
    select(variable_id, source_varname, units_factor_mult, period_id) |>
    inner_join(
      dplyr::tbl(con2, "dt_variables") |>
        select(variable_id, variable_aggregation_geo),
      by = "variable_id"
    ) |>
    left_join(
      dplyr::tbl(con2, "dt_aggregations") |>
        select(aggregation_id, geo_agg_fun = aggregation_rfunction),
      by = c("variable_aggregation_geo" = "aggregation_id")
    ) |>
    collect()

  if (nrow(vars_map) == 0) {
    warning("Variable mapping not found in database for ", source_varname)
    return(data.frame())
  }

  cols <- names(df)

  has_year <- "AÑO" %in% cols
  has_month <- "MES" %in% cols

  if (has_year && has_month) {
    df <- df %>%
      mutate(
        date = paste0(AÑO, "-", sprintf("%02d", as.integer(MES)), "-01")
      )
  } else if (has_year) {
    df <- df %>%
      mutate(
        date = paste0(AÑO, "-01-01")
      )
  }

  # Update cols after mutation
  cols <- names(df)

  if (!("date" %in% cols) && "time" %in% cols) {
    df <- df |> rename(date = time)
  } else if (!("date" %in% cols)) {
    warning("No date or time column found in data for \"", source_varname, "\"")
    return(data.frame())
  }

  # Apply data_filter
  if (!is.na(data_filters) && data_filters != "") {
    tryCatch({
      filter_text <- paste0("dplyr::when_all(", data_filters, ")")
      df <- dplyr::filter(df, eval(parse(text = filter_text)))
    })
  }

  if (nrow(df) == 0) {
    warning(
      "No rows remaining after applying data filters for \"",
      source_varname,
      "\""
    )
    return(data.frame())
  }

  if (!(target_var %in% cols)) {
    warning("Target variable ", target_var, " not found in data")
    return(data.frame())
  }

  # Geography handling
  has_prov <- "PROVINCIA" %in% cols
  has_ccaa <- "CCAA" %in% cols

  if (!has_prov && !has_ccaa) {
    data_final <- df |>
      mutate(
        geo_id = "ESP",
        variable_value = as.numeric(!!sym(target_var))
      ) |>
      select(date, geo_id, variable_value)
  } else {
    geo_map <- dplyr::tbl(con2, "dt_geo") |>
      select(geo_id, geo_original_name, nuts_level) |>
      collect()

    # Create empty columns to avoid errors in case_when()
    if (!has_prov) {
      df$PROVINCIA <- NA_character_
    }
    if (!has_ccaa) {
      df$CCAA <- NA_character_
    }

    data_mapped <- df |>
      mutate(
        geo_name = case_when(
          has_prov ~ PROVINCIA,
          has_ccaa ~ CCAA,
          TRUE ~ "Spain"
        ),
        expected_nuts = case_when(
          has_prov ~ 3,
          has_ccaa ~ 2,
          TRUE ~ 0
        ),
        geo_name = if_else(
          geo_name %in% c("Nacional", "Total Nacional", "Spain"),
          "Spain",
          geo_name
        ),
        # TODO: add new table with geo names
        geo_name = case_match(
          geo_name,
          # CCAA
          "Comunidad de Madrid" ~ "Madrid, Comunidad de",
          "Comunidad Foral de Navarra" ~ "Navarra, Comunidad Foral de",
          "Comunidad Valenciana" ~ "Comunitat Valenciana",
          "Islas Baleares" ~ "Balears, Illes",
          "La Rioja" ~ "Rioja, La",
          "Principado de Asturias" ~ "Asturias, Principado de",
          "Región de Murcia" ~ "Murcia, Región de",
          # Provinces
          "Las Palmas" ~ "Palmas, Las",
          "A Coruña" ~ "Coruña, A",
          "Illes Balears" ~ "Balears, Illes",
          .default = geo_name
        ),
        expected_nuts = if_else(geo_name == "Spain", 0, expected_nuts)
      ) |>
      left_join(
        geo_map,
        by = c("geo_name" = "geo_original_name", "expected_nuts" = "nuts_level")
      )

    unmatched_geos <- data_mapped |>
      filter(is.na(geo_id)) |>
      distinct(geo_name)

    if (nrow(unmatched_geos) > 0) {
      warning(glue(
        "⚠️ Variable '{source_varname}': {nrow(unmatched_geos)} geographic areas from Dataestur not found in 'dt_geo' and will be ignored: {paste(unmatched_geos$geo_name, collapse = ', ')}"
      ))
    }

    data_final <- data_mapped |>
      filter(!is.na(geo_id)) |>
      rename(variable_value = !!sym(target_var)) |>
      mutate(variable_value = as.numeric(variable_value)) |>
      select(date, geo_id, variable_value)

    # Apply aggregation if necessary for multiple rows matching the same geo_id/date
    if (!is.na(vars_map$geo_agg_fun[1])) {
      data_final <- data_final |>
        group_by(date, geo_id) |>
        summarise(
          variable_value = do.call(
            what = get(vars_map$geo_agg_fun[1]),
            args = list(variable_value, na.rm = TRUE)
          ),
          .groups = "drop"
        )
    } else {
      data_final <- data_final |> distinct(date, geo_id, .keep_all = TRUE)
    }
  }

  data_final <- data_final |>
    mutate(
      variable_id = vars_map$variable_id[1],
      variable_value = variable_value * vars_map$units_factor_mult[1],
      variable_value_flags = list(character(0))
    ) |>
    select(
      variable_id,
      date,
      geo_id,
      variable_value,
      variable_value_flags
    )

  data_filled <- fill_missing_periods(
    data_final,
    period = vars_map$period_id[1]
  )

  # Add Final DB Columns
  data_filled |>
    mutate(
      period_id = vars_map$period_id[1],
      variable_ts = Sys.time(),
      source_id = source,
      variable_prov = FALSE,
      variable_secret = FALSE,
      user_cre = NA_character_,
      imputed = FALSE,
      imputation_method = NA_character_,
      variable_value_flags = purrr::map_chr(
        variable_value_flags,
        flags_to_pg_array
      ),
      variable_value_notes = NA_character_
    ) |>
    select(
      variable_id,
      date,
      period_id,
      geo_id,
      variable_value,
      variable_ts,
      source_id,
      variable_prov,
      variable_secret,
      user_cre,
      imputed,
      imputation_method,
      variable_value_flags,
      variable_value_notes
    )
}

#' Get processed Dataestur data (wrapper function)
#'
#' @param variables Character vector. Items in format `"ENDPOINT : VARIABLE : URL_FILTERS : DATA_FILTERS"`
#' @param source Source ID (default: `"DATAESTUR"`)
#'
#' @return A processed data frame ready for database insertion
#' @export
#'
#' @examplesIf interactive()
#' dataestur_variables <- tbl(con2, "bt_variable_source") |>
#'   filter(source_id == "DATAESTUR") |>
#'   select(source_varname) |>
#'   collect() |>
#'   pull(source_varname)
#'
#' data <- dataestur_get_data(variables = dataestur_variables[31])
dataestur_get_data <- function(
  variables,
  source = "DATAESTUR"
) {
  if (length(variables) == 0) {
    warning("No variables provided to dataestur_get_data")
    return(data.frame())
  }

  # Parse variables
  var_info <- tibble(source_varname = variables) |>
    tidyr::separate(
      source_varname,
      into = c("endpoint", "target_var", "url_filters", "data_filters"),
      sep = " : ",
      remove = FALSE,
      fill = "right"
    ) |>
    mutate(across(
      c(endpoint, target_var, url_filters, data_filters),
      trimws
    )) |>
    mutate(
      is_incomplete = when_any(
        is.na(endpoint),
        is.na(target_var),
        is.na(url_filters),
        is.na(data_filters)
      )
    )

  var_missing <- var_info |> filter(is_incomplete)
  var_valid <- var_info |>
    filter_out(is_incomplete) |>
    select(-is_incomplete)

  if (nrow(var_missing) > 0) {
    warning(
      "⚠️ ",
      nrow(var_missing),
      " variables ignored due to incomplete parameters: ",
      var_missing |>
        mutate(
          target_var = tidyr::replace_na(target_var, "Unknown/Incomplete")
        ) |>
        count(target_var) |>
        mutate(
          label = if_else(n > 1, paste0(target_var, " (", n, ")"), target_var)
        ) |>
        pull(label) |>
        paste(collapse = ", ")
    )
  }

  if (nrow(var_valid) == 0) {
    warning("No valid variables to process.")
    return(data.frame())
  }

  # Group by endpoint and filters to avoid redundant downloads
  groups <- var_valid |>
    group_by(endpoint, url_filters) |>
    group_split()

  # Process each group
  purrr::map_df(groups, function(grp) {
    # Fetch once for this group
    df_raw <- dataestur_fetch_data(
      endpoint = grp$endpoint[1],
      url_filters = grp$url_filters[1]
    )

    if (is.null(df_raw)) {
      return(NULL)
    }

    # Process with the subset of variables for this group
    purrr::map_df(seq_len(nrow(grp)), function(i) {
      dataestur_process_data(
        df = df_raw,
        target_var = grp$target_var[i],
        data_filters = grp$data_filters[i],
        source_varname = grp$source_varname[i],
        source = source
      )
    })
  })
}

#' Get Dataestur last update date
#'
#' @return NA_character_ as this source does not provide this information yet.
#' @export
dataestur_source_last_available <- function() {
  message(
    "Checking last available for source 'DATAESTUR': Not supported by the source."
  )
  return(NA_character_)
}

## INE-EGATUR ----

#' Get last available definitive date for INE source
#'
#' Returns the maximum date where the data is NOT flagged as provisional ('P').
#' Used to determine the starting point for ETL updates, allowing re-processing
#' of provisional periods.
#'
#' @param source_id Character. Source identifier (e.g., "INE-EGATUR").
#' @param variable_ids Vector. Optional list of variable_ids to filter the query.
#'
#' @return A Date object representing the last definitive data point, or NULL if none found.
#' @export
#'
#' @examplesIf interactive()
#' ine_last_definitive_data("INE-EGATUR")
#' ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
#' )
ine_last_definitive_data <- function(source_id, variable_ids = NULL) {
  tryCatch(
    {
      # Prepare variables text for messages
      vars_info <- ""
      if (!is.null(variable_ids)) {
        vars_str <- paste(variable_ids, collapse = ", ")
        vars_info <- glue(" (vars: {vars_str})")
      }

      message(glue(
        "Checking last definitive date for source '{source_id}'{vars_info}..."
      ))

      query <- tbl(con2, "ft_variables") |>
        filter(source_id == !!source_id)

      if (!is.null(variable_ids)) {
        query <- query |>
          filter(variable_id %in% !!variable_ids)
      }

      # Query database for the max date where flag does NOT contain 'P'
      last_date_df <- query |>
        filter(
          is.na(variable_value_flags) |
            !sql("'P' = ANY(variable_value_flags)")
        ) |>
        summarise(max_date = max(date, na.rm = TRUE)) |>
        collect()

      last_date <- last_date_df$max_date[1]

      if (is.na(last_date)) {
        message(glue("No definitive data found for '{source_id}'{vars_info}."))
        return(NULL)
      }

      message(glue(
        "Last definitive date for '{source_id}'{vars_info}: {last_date}"
      ))
      return(as.Date(last_date))
    },
    error = function(e) {
      stop(
        "Error checking last definitive date for '",
        source_id,
        "': ",
        e$message
      )
    }
  )
}

#' Get INE bulk download links
#'
#' Scrapes the INE microdata page to find available dataset files.
#'
#' @param url URL for INE microdata page (e.g., EGATUR or FRONTUR).
#' @param last_date Date. Only datasets newer than this date will be returned.
#' @param from_dropdown Boolean. If TRUE, parses <option> tags (e.g. EGATUR Turistas).
#' If FALSE, parses <a> tags (e.g. EGATUR Excursionistas).
#' @param frequency Character. `"M"` (monthly, default) or `"Y"` (yearly).
#' Controls how dates are parsed and filtered.
#'
#' @return A data.frame with columns `dates` (Date) and `links` (character).
#' @export
#'
#' @examplesIf interactive()
#' egatur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&secc=1254736195390&idp=1254735576863#_tabs-1254736195390"
#'
#' # EGATUR Tourists
#' egatur_tourists_last_date <- ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
#' )
#' egatur_tourists_links <- ine_download_links(
#'   url = egatur_url,
#'   last_date = egatur_tourists_last_date
#' )
#'
#' # EGATUR Excursionists
#' egatur_excursionists_last_date <- ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0002", "VVOL0005")
#' )
#' egatur_excursionists_links <- ine_download_links(
#'   url = egatur_url,
#'   last_date = egatur_excursionists_last_date,
#'   from_dropdown = FALSE,
#'   frequency = "Y"
#' )
ine_download_links <- function(
  url,
  last_date,
  from_dropdown = TRUE,
  frequency = "M"
) {
  message("Searching for INE download links...")

  webpage <- tryCatch(
    {
      read_html(url)
    },
    error = function(e) {
      stop("Failed to read INE URL: ", url, " - ", e$message)
    }
  )

  if (is.null(webpage)) {
    stop("The webpage is not available")
  }

  df <- data.frame(dates_txt = character(), links = character())

  if (from_dropdown) {
    # Extract <option> elements
    links <- webpage |>
      html_nodes("option") |>
      html_attr("value")

    names <- webpage |>
      html_nodes("option") |>
      html_text()

    # Remove the first option (usually "Select..." placeholder)
    if (length(links) > 1) {
      links <- links[-1]
      names <- names[-1]
    } else {
      warning("No download options found (or only one placeholder).")
      return(data.frame(dates = as.Date(character()), links = character()))
    }

    df <- data.frame(dates_txt = names, links = links)
  } else {
    # Extract <a> elements (links in paragraphs)
    links <- webpage |>
      html_nodes("a") |>
      html_attr("href")

    names <- webpage |>
      html_nodes("a") |>
      html_text()

    # Basic filtering to avoid irrelevant menu links
    # For yearly frequency, we expect "Año YYYY" in text.
    if (frequency == "Y") {
      mask <- stringr::str_detect(names, "Año \\d{4}") & !is.na(links)
      df <- data.frame(dates_txt = names[mask], links = links[mask])
    } else {
      warning("Unsupported yearly frequency for links in paragraphs.")
      return(data.frame(dates = as.Date(character()), links = character()))
    }
  }

  if (nrow(df) == 0) {
    message("No potential links found.")
    return(data.frame(dates = as.Date(character()), links = character()))
  }

  # --- Parse dates ---
  if (frequency == "M") {
    # Parse: "Enero 2023" -> "1Enero 2023" -> dmy()
    # Using locale "es_ES.UTF-8" as requested.
    df_sorted <- df |>
      mutate(
        dates = dmy(paste0("1", dates_txt), locale = "es_ES.UTF-8")
      ) |>
      filter(!is.na(dates)) |>
      arrange(desc(dates))

    # Filter logic (Monthly)
    if (is.null(last_date)) {
      df_date_selected <- df_sorted
    } else {
      # We want dates > last_date
      if (nrow(df_sorted) > 0 && df_sorted$dates[1] <= last_date) {
        message(
          "The dataset is already updated (Latest: ",
          df_sorted$dates[1],
          ")."
        )
        return(data.frame(dates = as.Date(character()), links = character()))
      }
      df_date_selected <- df_sorted |>
        filter(dates > last_date)
    }
  } else if (frequency == "Y") {
    # Parse: "Año 2023" -> 2023 -> 2023-01-01
    df_sorted <- df |>
      mutate(
        year = as.integer(stringr::str_extract(dates_txt, "\\d{4}")),
        dates = as.Date(paste0(year, "-01-01"))
      ) |>
      filter(!is.na(year)) |>
      arrange(desc(dates))

    # Filter logic (Yearly)
    if (is.null(last_date)) {
      df_date_selected <- df_sorted
    } else {
      last_year <- as.integer(format(last_date, "%Y"))
      last_month <- as.integer(format(last_date, "%m"))

      # If we have definitive data for December, we consider the year complete
      # and look for the next year. Otherwise, we might need more months from
      # the current year.
      cutoff_year <- if (last_month == 12) last_year + 1 else last_year

      # Keep if file_year >= cutoff_year
      df_date_selected <- df_sorted |>
        filter(year >= cutoff_year)

      if (nrow(df_date_selected) == 0) {
        message(
          "The dataset is already updated (Latest year: ",
          df_sorted$year[1],
          ")."
        )
      }
    }
  } else {
    stop("Unknown frequency: ", frequency)
  }

  if (nrow(df_date_selected) == 0) {
    message("No new files to download.")
    return(data.frame(dates = as.Date(character()), links = character()))
  }

  # Prepend domain to links if relative
  # (INE links are often relative)
  df_date_selected |>
    mutate(
      links = if_else(
        startsWith(links, "https://www.ine.es"),
        links,
        paste0("https://www.ine.es", links)
      )
    ) |>
    select(dates, links)
}

#' Download and extract INE ZIP files
#'
#' Downloads the ZIP files from the links provided, extracts them into dated
#' subdirectories within a main temporary directory, and returns the path to
#' this main directory.
#'
#' @param df_links data.frame with columns `dates` and `links` (from
#' `ine_download_links`)
#'
#' @return Character string: path to the main directory where files were
#' downloaded and extracted.
#' @export
#'
#' @examplesIf interactive()
#' egatur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&secc=1254736195390&idp=1254735576863#_tabs-1254736195390"
#' egatur_tourists_last_date <- ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
#' )
#' egatur_tourists_links <- ine_download_links(
#'   url = egatur_url,
#'   last_date = egatur_tourists_last_date
#' )
#' ine_download_files(df_links = egatur_tourists_links)
ine_download_files <- function(df_links) {
  message("Searching for INE download links...")
  # Create a main temporary directory for all downloads and extractions for this
  # batch
  # This directory will contain subdirectories for each date's extracted files
  main_extract_dir <- file.path(
    tempdir(),
    paste0("ine_downloads_", format(Sys.time(), "%Y%m%d%H%M%S"))
  )
  if (!dir.exists(main_extract_dir)) {
    dir.create(main_extract_dir)
  }

  if (nrow(df_links) == 0) {
    message("No links provided to download.")
    return(main_extract_dir) # Return the created temp dir, even if empty
  }

  for (i in seq_len(nrow(df_links))) {
    link <- df_links$links[i]
    date <- df_links$dates[i]

    zip_basename <- basename(link)
    zip_file_path <- file.path(main_extract_dir, zip_basename)

    message(glue("Downloading ({i}/{nrow(df_links)}): {zip_basename}"))

    tryCatch(
      {
        # Download the ZIP file
        download.file(link, zip_file_path, mode = "wb", quiet = TRUE)

        # Create a specific sub-directory for this date's extracted contents
        # This preserves original internal filenames and avoids conflicts
        extract_subdir <- file.path(main_extract_dir, format(date, "%Y%m%d"))
        if (!dir.exists(extract_subdir)) {
          dir.create(extract_subdir)
        }

        # Extract the ZIP file contents into the date-specific subdirectory
        archive_extract(zip_file_path, dir = extract_subdir)

        # Do not delete the ZIP file as per user request to keep original names (implying no cleanup)
        message(glue("Extracted to: {extract_subdir}"))
      },
      error = function(e) {
        warning("Failed to download/extract ", link, ": ", e$message)
        # Attempt to clean up corrupted zip file if download failed
        if (file.exists(zip_file_path)) unlink(zip_file_path)
      }
    )
  }

  message(
    "All INE files processed. Extracted contents are in: ",
    main_extract_dir
  )
  return(main_extract_dir)
}

#' Read and concatenate INE extracted data files
#'
#' Searches a specified directory for files matching a prefix and extension,
#' reads their content (assumed to be semicolon-separated), and concatenates
#' them into a single raw data frame. Column names are always read from the
#' first row of each file. Their types are specified via `col_types` parameter.
#'
#' @param extract_dir Character string: Path to the directory containing extracted files.
#' @param file_name_pattern Character string or NULL: Text that the filename must contain to be selected.
#'   If NULL (default), no filtering is applied and all files with the specified extension are read.
#' @param extension Character string: File extension (e.g., "txt"). Defaults to "txt".
#' @param col_types `readr::cols()` specification or NULL: Passed directly to
#' `readr::read_csv2`. If `NULL` (default), column types are automatically
#' inferred. Provide a `readr::cols()` specification for explicit type
#' definitions (e.g.,
#' `readr::cols(col1 = readr::col_character(), col2 = readr::col_integer())`).
#' @param decimal_mark Character string: Decimal mark used in the files
#' @param date_from_columns Boolean. If TRUE, tries to create `mm_aaaa` from
#'   `MES` and `ANYO` columns if they exist and `mm_aaaa` is missing.
#'   **This method has priority over `date_from_filename`.**
#' @param date_from_filename Boolean. If TRUE, tries to extract MMYY from filename
#'   and create `mm_aaaa` column if missing. Assumes format `..._MMYY.txt`.
#'   **This method is only used if `date_from_columns` fails or is FALSE.**
#'
#' @section Date Creation Priority:
#' The function creates the `mm_aaaa` column following this priority order:
#' \enumerate{
#'   \item If `mm_aaaa` already exists in the data, **no action is taken**.
#'   \item If `date_from_columns = TRUE` and both `MES` and `ANYO` columns exist,
#'         `mm_aaaa` is created by combining them (format: MMYYYY).
#'   \item If the above fails and `date_from_filename = TRUE`, `mm_aaaa` is
#'         extracted from the filename pattern `..._MMYY.txt`.
#'   \item If none of the above apply, no `mm_aaaa` column is created.
#' }
#'
#' @return A data.frame containing the concatenated raw data from all matching
#' files.
#' @export
#'
#' @examplesIf interactive()
#' egatur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&secc=1254736195390&idp=1254735576863#_tabs-1254736195390"
#' egatur_tourists_last_date <- ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
#' )
#' egatur_tourists_links <- ine_download_links(
#'   url = egatur_url,
#'   last_date = egatur_tourists_last_date
#' )
#' egatur_tourists_temp_dir <- ine_download_files(df_links = egatur_tourists_links)
#' egatur_tourists_col_types <- readr::cols(
#'   mm_aaaa = readr::col_character(),
#'   A0 = readr::col_integer(),
#'   A0_1 = readr::col_character(),
#'   A0_7 = readr::col_double(),
#'   A1 = readr::col_integer(),
#'   pais = readr::col_character(),
#'   ccaa = readr::col_character(),
#'   A13 = readr::col_integer(),
#'   aloja = readr::col_integer(),
#'   motivo = readr::col_integer(),
#'   A16 = readr::col_integer(),
#'   gastototal = readr::col_double(),
#'   factoregatur = readr::col_double()
#' )
#' ine_read_and_concatenate_files(
#'   extract_dir = temp_ine_dir,
#'   file_name_pattern = "tur",
#'   extension = "txt",
#'   col_types = egatur_tourists_col_types,
#'   decimal_mark = "."
#' )
ine_read_and_concatenate_files <- function(
  extract_dir,
  file_name_pattern = NULL,
  extension = "txt",
  col_types = NULL,
  decimal_mark = ".",
  date_from_columns = FALSE,
  date_from_filename = FALSE
) {
  # Build message based on whether pattern is provided
  if (!is.null(file_name_pattern)) {
    message(glue(
      "Searching for files matching pattern '{file_name_pattern}' with extension '.{extension}' in '{extract_dir}'..."
    ))
  } else {
    message(glue(
      "Searching for all files with extension '.{extension}' in '{extract_dir}'..."
    ))
  }

  # List all files recursively in the extraction directory
  all_files <- list.files(
    path = extract_dir,
    pattern = paste0("\\.", extension, "$"),
    full.names = TRUE,
    recursive = TRUE
  )

  # Filter files by the provided pattern (only if pattern is not NULL)
  if (!is.null(file_name_pattern)) {
    matching_files <- all_files[stringr::str_detect(
      all_files,
      file_name_pattern
    )]
  } else {
    matching_files <- all_files
  }

  if (length(matching_files) == 0) {
    message("No matching files found.")
    return(data.frame())
  }

  message(glue(
    "Found {length(matching_files)} matching files. Reading contents..."
  ))

  # Read and concatenate files
  df_list <- lapply(matching_files, function(file_path) {
    message(glue("  Reading: {basename(file_path)}"))
    df <- readr::read_delim(
      file_path,
      delim = ";",
      col_names = TRUE,
      col_types = col_types,
      locale = readr::locale(
        decimal_mark = decimal_mark
      ),
      show_col_types = FALSE
    )

    # Check for parsing problems immediately
    probs <- readr::problems(df)
    if (nrow(probs) > 0) {
      message(glue(
        "⚠️  WARNING: {nrow(probs)} parsing issues found in '{basename(file_path)}'. Showing first 5:"
      ))
      print(head(probs, 5))
    }

    # Only create mm_aaaa if it doesn't already exist
    if (!"mm_aaaa" %in% names(df)) {
      # Priority 1: Extract from MES and ANYO columns if requested and available
      if (date_from_columns && all(c("MES", "ANYO") %in% names(df))) {
        df <- df |>
          dplyr::mutate(
            mm_aaaa = paste0(
              stringr::str_pad(as.character(MES), 2, pad = "0"),
              as.character(ANYO)
            )
          )
      } else if (date_from_filename) {
        # Priority 2: Extract from filename if requested and columns method wasn't used
        # Expected format: "something_MMYY.txt"
        # We split by "_" and take the last part (MMYY.txt), then remove extension
        parts <- unlist(strsplit(basename(file_path), "_"))
        date_part_with_ext <- tail(parts, 1)
        date_val <- unlist(strsplit(date_part_with_ext, "\\."))[1]

        # If date_val is 4 digits (MMYY):
        if (nchar(date_val) == 4) {
          mm <- substr(date_val, 1, 2)
          yy <- substr(date_val, 3, 4)
          date_val <- paste0(mm, "20", yy)
        }

        df$mm_aaaa <- date_val
      }
    }

    return(df)
  })

  # Combine all data frames into one
  # bind_rows handles different columns by filling missing ones with NA
  df_combined <- dplyr::bind_rows(df_list)

  message(glue("Successfully read and combined {nrow(df_combined)} rows."))
  return(df_combined)
}

#' Map INE code column to `geo_id` for NUTS 2 level
#'
#' Join a data.frame that contains an INE code column (e.g. `"geo_id_ine"`)
#' to the `dt_geo` table to obtain the corresponding `geo_id`.
#' This function filters the `dt_geo` table to include only records where
#' `nuts3_code` is missing, which corresponds to the **NUTS 2 regional level**
#' (Spanish Autonomous Communities).
#'
#' @param data A data.frame containing a column with INE codes.
#' @param source_col Name of the column in `data` that contains the INE
#' code to match against `dt_geo$ine_es_code`.
#'
#' @return A data.frame with the joined `geo_id` column. The original
#' `source_col` is removed from the returned data.frame.
#' @export
#'
#' @examplesIf interactive()
#' egatur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&secc=1254736195390&idp=1254735576863#_tabs-1254736195390"
#' egatur_tourists_last_date <- ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
#' )
#' egatur_tourists_links <- ine_download_links(
#'   url = egatur_url,
#'   last_date = egatur_tourists_last_date
#' )
#' egatur_tourists_temp_dir <- ine_download_files(df_links = egatur_tourists_links)
#' egatur_tourists_col_types <- readr::cols(
#'   mm_aaaa = readr::col_character(),
#'   A0 = readr::col_integer(),
#'   A0_1 = readr::col_character(),
#'   A0_7 = readr::col_double(),
#'   A1 = readr::col_integer(),
#'   pais = readr::col_character(),
#'   ccaa = readr::col_character(),
#'   A13 = readr::col_integer(),
#'   aloja = readr::col_integer(),
#'   motivo = readr::col_integer(),
#'   A16 = readr::col_integer(),
#'   gastototal = readr::col_double(),
#'   factoregatur = readr::col_double()
#' )
#' egatur_tourists_raw_df <- ine_read_and_concatenate_files(
#'   extract_dir = temp_ine_dir,
#'   file_name_pattern = "tur",
#'   extension = "txt",
#'   col_types = egatur_tourists_col_types,
#'   decimal_mark = "."
#' )
#' map_ine_to_geo_nuts2(
#'   data = egatur_tourists_raw_df,
#'   source_col = "ccaa"
#' )
map_ine_to_geo_nuts2 <- function(data, source_col) {
  if (!(source_col %in% names(data))) {
    stop(sprintf("Column '%s' not found in input dataframe.", source_col))
  }

  geo_map <- tbl(con2, "dt_geo") |>
    filter(is.na(nuts3_code)) |>
    select(geo_id, ine_es_code) |>
    collect()

  data |>
    inner_join(geo_map, by = setNames("ine_es_code", source_col)) |>
    select(-!!sym(source_col))
}

#' Process INE data for EGATUR, ETR, and FRONTUR sources
#'
#' Performs specific calculations and formatting based on the source ID:
#'
#' - **INE-EGATUR**:
#'   - **Tourists** (`is_excursionist = FALSE`): Calculates weighted totals for
#'     expenditure (`gastototal * factoregatur`), number of tourists
#'     (`factoregatur`), and overnight stays (`A13 * factoregatur`).
#'   - **Excursionists** (`is_excursionist = TRUE`): Calculates weighted totals
#'     for expenditure (`gastototal * factoregatur`) and number of excursionists
#'     (`factoregatur`).
#'
#' - **INE-ETR**:
#'   - Accumulates `GASTOFI_TOTAL` by multiplying with `FACTORGAS_TOT`.
#'   - Accumulates `NPERNOC_CORR` by multiplying with `FACTORVI_TOT`.
#'   - Accumulates `FACTORVI_TOT` itself.
#'   - Groups by date and geography (`geo_id`) and sums these accumulated values.
#'
#' - **INE-FRONTUR**:
#'   - Filters for non-resident tourists (`A0_7 == 2`, being `2` the code for
#' non-resident tourists).
#'   - Aggregates by geography, date, and entry way (`A1`), summing `Factor`.
#'   - Joins with metadata to map entry codes (`A1`) to readable variable names.
#'
#' @param data data.frame with raw INE data
#' @param source_id Character. Source identifier
#' @param is_excursionist Boolean. Only used when `source_id == "INE-EGATUR"`.
#' If `TRUE`, applies specific calculation for EGATUR excursionists. If `FALSE`,
#' applies for tourists.
#' @param url Character. URL of the data. It is required for
#' `source_id == "INE-FRONTUR"` to fetch variable metadata (variable names). In
#' addition, if defined, it is used to find if data is flagged as provisional.
#'
#' @return data.frame
#' @export
#'
#' @examplesIf interactive()
#' egatur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&secc=1254736195390&idp=1254735576863#_tabs-1254736195390"
#' egatur_tourists_last_date <- ine_last_definitive_data(
#'   "INE-EGATUR",
#'   variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
#' )
#' egatur_tourists_links <- ine_download_links(
#'   url = egatur_url,
#'   last_date = egatur_tourists_last_date
#' )
#' egatur_tourists_temp_dir <- ine_download_files(df_links = egatur_tourists_links)
#' egatur_tourists_col_types <- readr::cols(
#'   mm_aaaa = readr::col_character(),
#'   A0 = readr::col_integer(),
#'   A0_1 = readr::col_character(),
#'   A0_7 = readr::col_double(),
#'   A1 = readr::col_integer(),
#'   pais = readr::col_character(),
#'   ccaa = readr::col_character(),
#'   A13 = readr::col_integer(),
#'   aloja = readr::col_integer(),
#'   motivo = readr::col_integer(),
#'   A16 = readr::col_integer(),
#'   gastototal = readr::col_double(),
#'   factoregatur = readr::col_double()
#' )
#' egatur_tourists_raw_df <- ine_read_and_concatenate_files(
#'   extract_dir = temp_ine_dir,
#'   file_name_pattern = "tur",
#'   extension = "txt",
#'   col_types = egatur_tourists_col_types,
#'   decimal_mark = "."
#' )
#' egatur_tourists_df <- map_ine_to_geo_nuts2(
#'   data = egatur_tourists_raw_df,
#'   source_col = "ccaa"
#' )
#' ine_process_data(
#'   data = egatur_tourists_df,
#'   source_id = "INE-EGATUR",
#'   is_excursionist = FALSE,
#'   url = egatur_url
#' )
ine_process_data <- function(
  data,
  source_id,
  is_excursionist = FALSE,
  url = NULL
) {
  # 1. Parse date mm_aaaa is MMYYYY
  data_dated <- data |>
    mutate(
      date = as.Date(paste0("01", mm_aaaa), format = "%d%m%Y")
    )

  # 2. Calculate and format
  if (source_id == "INE-FRONTUR") {
    data_long <- data_dated |>
      filter(A0_7 == 2) |> # type_tourist
      group_by(geo_id, date, A1) |>
      summarise(
        variable_value = sum(Factor, na.rm = TRUE),
        .groups = "drop"
      ) |>
      inner_join(
        ine_get_frontur_metadata(
          url = url,
          sheet_name = "Vía de Entrada de los turistas"
        ),
        by = c("A1" = "Código")
      ) |>
      rename(source_varname = `Vía de Entrada de los turistas`) |>
      select(date, geo_id, source_varname, variable_value)
  } else {
    # Logic for EGATUR and ETR (results in data_summarise)
    if (source_id == "INE-EGATUR") {
      if (is_excursionist) {
        data_wider <- data_dated |>
          mutate(
            gastototal_excursio = gastototal * factoregatur,
            factorexcursio = factoregatur
          )
        cols_to_sum <- c("gastototal_excursio", "factorexcursio")
      } else {
        data_wider <- data_dated |>
          mutate(
            A13 = A13 * factoregatur,
            gastototal_egatur = gastototal * factoregatur
          )
        cols_to_sum <- c("A13", "gastototal_egatur", "factoregatur")
      }

      data_summarise <- data_wider |>
        group_by(date, geo_id) |>
        summarise(
          across(
            all_of(cols_to_sum),
            ~ as.numeric(sum(., na.rm = TRUE))
          ),
          .groups = "drop"
        )
    } else if (source_id == "INE-ETR") {
      data_summarise <- data_dated |>
        mutate(
          GASTOFI_TOTAL = GASTOFI_TOTAL * FACTORGAS_TOT
        ) |>
        group_by(date, geo_id) |>
        summarise(
          GASTOFI_TOTAL = sum(GASTOFI_TOTAL, na.rm = TRUE),
          NPERNOC_CORR = sum(NPERNOC_CORR * FACTORVI_TOT, na.rm = TRUE),
          FACTORVI_TOT = sum(FACTORVI_TOT, na.rm = TRUE),
          .groups = "drop"
        )
    } else {
      stop(glue("INE source '{source_id}' not supported."))
    }

    # Shared pivot for EGATUR and ETR
    data_long <- data_summarise |>
      pivot_longer(
        colnames(data_summarise)[-c(1:2)],
        names_to = "source_varname",
        values_to = "variable_value"
      )
  }

  message(glue(
    "Processing {nrow(data_long)} rows for source '{source_id}' after INE aggregations."
  ))

  vars_map <- tbl(con2, "bt_variable_source") |>
    filter(source_id == !!source_id) |>
    select(variable_id, source_varname, units_factor_mult) |>
    collect()

  # Check for unmapped variables
  unmapped_vars <- setdiff(
    unique(data_long$source_varname),
    vars_map$source_varname
  )
  if (length(unmapped_vars) > 0) {
    warning(glue(
      "⚠️ {length(unmapped_vars)} variables not found in 'bt_variable_source' for source '{source_id}': {paste(unmapped_vars, collapse = ', ')}"
    ))
  }

  data_final <- data_long |>
    inner_join(vars_map, by = "source_varname") |>
    mutate(
      variable_value = variable_value * units_factor_mult
    ) |>
    select(-source_varname, -units_factor_mult)

  # 4. Check provisional flags from URL
  # Initialize default values
  data_final <- data_final |>
    mutate(
      variable_value_flags = list(character(0))
    ) |>
    fill_missing_periods(period = "M") |>
    mutate(
      variable_prov = FALSE
    )

  if (!is.null(url) && nzchar(url)) {
    message("Checking provisional status from URL...")
    tryCatch(
      {
        webpage <- read_html(url)
        # "strong elements inside a li inside a ul" -> "ul li strong"
        texts <- webpage |> html_nodes("ul li strong") |> html_text()

        # Months mapping for Spanish (safer than relying on locale)
        months_map <- setNames(
          1:12,
          c(
            "enero",
            "febrero",
            "marzo",
            "abril",
            "mayo",
            "junio",
            "julio",
            "agosto",
            "septiembre",
            "octubre",
            "noviembre",
            "diciembre"
          )
        )

        months_regex <- paste(names(months_map), collapse = "|")

        for (txt in texts) {
          txt_lower <- tolower(txt)
          # Check for "desde ... provisional" pattern
          if (grepl("provisional", txt_lower) && grepl("desde", txt_lower)) {
            # Extract date parts: desde [Month] de [Year]
            date_match <- stringr::str_match(
              txt_lower,
              glue::glue("desde\\s+({months_regex})\\s+de\\s+(\\d{{4}})")
            )

            if (!is.na(date_match[1, 1])) {
              month_name <- date_match[1, 2]
              month_num <- months_map[[month_name]]
              year_num <- date_match[1, 3]

              # Create date object (first of month)
              prov_start_date <- as.Date(paste0(
                year_num,
                "-",
                month_num,
                "-01"
              ))

              message(glue::glue(
                "Found provisional data start date: {month_name} {year_num}"
              ))

              # Update flags for this date AND SUBSEQUENT dates
              data_final <- data_final |>
                mutate(
                  variable_prov = date >= prov_start_date,
                  variable_value_flags = purrr::map2(
                    variable_value_flags,
                    variable_prov,
                    function(flags, prov) {
                      if (prov) {
                        unique(c(flags, "P"))
                      } else {
                        flags
                      }
                    }
                  )
                )

              # Break after finding the first valid provisional note to avoid overwriting
              break
            }
          }
        }
      },
      error = function(e) {
        warning("Could not parse provisional flags from URL: ", e$message)
      }
    )
  }

  # 5. Format remaining columns
  data_final |>
    mutate(
      variable_value_flags = purrr::map_chr(
        variable_value_flags,
        flags_to_pg_array
      ),
      period_id = "M",
      source_id = source_id,
      variable_ts = Sys.time(),
      variable_secret = FALSE,
      user_cre = NA_character_,
      imputed = FALSE,
      imputation_method = NA_character_,
      variable_value_notes = NA_character_
    ) |>
    select(
      variable_id,
      date,
      period_id,
      geo_id,
      variable_value,
      variable_ts,
      source_id,
      variable_prov,
      variable_secret,
      user_cre,
      imputed,
      imputation_method,
      variable_value_flags,
      variable_value_notes
    )
}

#' Get processed INE-EGATUR data (Tourists + Excursionists)
#'
#' Orchestrates the download, reading, and processing of both Tourists and
#' Excursionists microdata from INE-EGATUR.
#'
#' @return A data.frame with the combined and processed data, ready for
#' database insertion.
#' @export
#'
#' @examplesIf interactive()
#' ine_egatur_get_data()
ine_egatur_get_data <- function() {
  egatur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=resultados&secc=1254736195390&idp=1254735576863#_tabs-1254736195390"

  message("--- Processing EGATUR Tourists ---")

  tourists_df <- tryCatch(
    {
      # 1. Check last date
      last_date <- ine_last_definitive_data(
        "INE-EGATUR",
        variable_ids = c("VGAS0001", "VVOL0001", "VVOL0002")
      )

      # 2. Get download links
      links <- ine_download_links(
        url = egatur_url,
        last_date = last_date
      )

      if (nrow(links) > 0) {
        # 3. Download files
        temp_dir <- ine_download_files(df_links = links)

        # 4. Read files
        col_types <- readr::cols(
          mm_aaaa = readr::col_character(),
          A0 = readr::col_integer(),
          A0_1 = readr::col_character(),
          A0_7 = readr::col_double(),
          A1 = readr::col_integer(),
          pais = readr::col_character(),
          ccaa = readr::col_character(),
          A13 = readr::col_integer(),
          aloja = readr::col_integer(),
          motivo = readr::col_integer(),
          A16 = readr::col_integer(),
          gastototal = readr::col_double(),
          factoregatur = readr::col_double()
        )

        raw_df <- ine_read_and_concatenate_files(
          extract_dir = temp_dir,
          file_name_pattern = "tur",
          extension = "txt",
          col_types = col_types,
          decimal_mark = "."
        )

        if (nrow(raw_df) > 0) {
          # 5. Process
          raw_df |>
            select("mm_aaaa", "ccaa", "gastototal", "factoregatur", "A13") |>
            map_ine_to_geo_nuts2(source_col = "ccaa") |>
            ine_process_data(
              source_id = "INE-EGATUR",
              is_excursionist = FALSE,
              url = egatur_url
            )
        } else {
          data.frame()
        }
      } else {
        data.frame()
      }
    },
    error = function(e) {
      warning("Error processing EGATUR Tourists: ", e$message)
      data.frame()
    }
  )

  message("--- Processing EGATUR Excursionists ---")

  excursionists_df <- tryCatch(
    {
      # 1. Check last date
      last_date <- ine_last_definitive_data(
        "INE-EGATUR",
        variable_ids = c("VGAS0002", "VVOL0005")
      )

      # 2. Get download links (Yearly, from text links)
      links <- ine_download_links(
        url = egatur_url,
        last_date = last_date,
        from_dropdown = FALSE,
        frequency = "Y"
      )

      if (nrow(links) > 0) {
        # 3. Download files
        temp_dir <- ine_download_files(df_links = links)

        # 4. Read files
        col_types <- readr::cols(
          mm_aaaa = readr::col_character(),
          A0 = readr::col_integer(),
          A0_1 = readr::col_character(),
          A0_7 = readr::col_double(),
          A1 = readr::col_integer(),
          pais = readr::col_character(),
          ccaa = readr::col_character(),
          gastototal = readr::col_double(),
          factoregatur = readr::col_double()
        )

        raw_df <- ine_read_and_concatenate_files(
          extract_dir = temp_dir,
          file_name_pattern = "exc",
          extension = "txt",
          col_types = col_types,
          decimal_mark = "."
        )

        if (nrow(raw_df) > 0) {
          # 5. Process
          raw_df |>
            select("mm_aaaa", "ccaa", "gastototal", "factoregatur") |>
            map_ine_to_geo_nuts2(source_col = "ccaa") |>
            ine_process_data(
              source_id = "INE-EGATUR",
              is_excursionist = TRUE,
              url = NULL
            )
        } else {
          data.frame()
        }
      } else {
        data.frame()
      }
    },
    error = function(e) {
      warning("Error processing EGATUR Excursionists: ", e$message)
      data.frame()
    }
  )

  # Combine results
  bind_rows(tourists_df, excursionists_df)
}

#' Get INE last update date
#'
#' Scrapes the INE website to find the latest available data date based on the
#' source ID.
#'
#' @param source_id Character string: The identifier for the data source (e.g.,
#' "INE-EGATUR", "INE-FRONTUR").
#'
#' @return Character string with PostgreSQL timestamp format, or NULL on
#' failure.
#' @export
#'
#' @examplesIf interactive()
#' ine_source_last_available("INE-EGATUR")
#' ine_source_last_available("INE-FRONTUR")
#' ine_source_last_available("INE-ETR")
ine_source_last_available <- function(source_id) {
  source_urls <- list(
    "INE-EGATUR" = "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736177002&menu=ultiDatos&idp=1254735576863",
    "INE-FRONTUR" = "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736176996&menu=ultiDatos&idp=1254735576863",
    "INE-ETR" = "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736176990&menu=ultiDatos&idp=1254735576863"
  )

  if (!source_id %in% names(source_urls)) {
    warning(glue(
      "Unknown source_id: '{source_id}'. Supported sources are: {paste(names(source_urls), collapse=', ')}"
    ))
    return(NULL)
  }

  url <- source_urls[[source_id]]

  message(glue("Checking last available date for {source_id}..."))

  tryCatch(
    {
      webpage <- read_html(url)

      # Extract the text containing the PUBLICATION date (e.g., "03/12/2025")
      # This is the SECOND strong tag within the span inside the .texto div.
      date_text <- webpage |>
        html_node(".caja .texto span strong:nth-of-type(2)") |>
        html_text()

      if (is.na(date_text)) {
        warning(glue(
          "Could not find publication date text on INE page for '{source_id}'"
        ))
        return(NULL)
      }

      # Parse date: "03/12/2025" (day/month/year) -> dmy
      parsed_date <- lubridate::dmy(date_text)

      if (is.na(parsed_date)) {
        warning(glue(
          "Failed to parse date string for '{source_id}': {date_text}"
        ))
        return(NULL)
      }

      # Format as PostgreSQL timestamp (e.g., "YYYY-MM-DD HH:MM:SS.000000+00")
      timestamp <- paste0(
        format(parsed_date, "%Y-%m-%d %H:%M:%S", tz = "UTC"),
        ".000000+00"
      )

      message(glue("{source_id} last updated: {timestamp}"))

      return(timestamp)
    },
    error = function(e) {
      warning(glue(
        "Error checking INE last available for '{source_id}': {e$message}"
      ))
      return(NULL)
    }
  )
}

#' Get FRONTUR metadata
#'
#' Scrapes the INE FRONTUR microdata page to download and extract the Excel file
#' containing metadata for a specified sheet.
#' This function temporarily downloads and extracts a ZIP file containing the
#' Excel data and then reads the specified sheet.
#'
#' @param url Character string. The URL of the INE FRONTUR microdata page
#' (e.g., "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736176996&menu=resultados&idp=1254735576863").
#' @param sheet_name Character string. The name of the Excel sheet to read.
#' Defaults to "Vía de Entrada de los turistas".
#'
#' @return A data.frame containing the metadata from the specified sheet of the
#' FRONTUR Excel file.
#' @export
#'
#' @examplesIf interactive()
#' url_frontur <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736176996&menu=resultados&idp=1254735576863#_tabs-1254736195382"
#'
#' # Get default sheet metadata
#' ine_get_frontur_metadata(url_frontur)
#'
#' # Get metadata from a different sheet
#' ine_get_frontur_metadata(
#'   url_frontur,
#'   sheet_name = "Destino principal del viaje"
#' )
ine_get_frontur_metadata <- function(
  url,
  sheet_name = "Vía de Entrada de los turistas"
) {
  webpage <- read_html(url)

  # Extract download link
  links <- webpage |>
    html_nodes("ul.lista_no_vi_no_sang a") |>
    html_attr("href")

  link <- links[str_detect(links, "disreg")]
  link <- paste0("https://www.ine.es", link)

  # Setup temporary files
  temp_folder <- file.path(tempdir(), "frontur_temp")
  zip_file <- tempfile(fileext = ".zip")

  # Ensure clean temporary folder
  if (dir.exists(temp_folder)) {
    unlink(temp_folder, recursive = TRUE)
  }
  dir.create(temp_folder)

  # Download and extract
  tryCatch(
    {
      download.file(link, zip_file, mode = "wb", quiet = TRUE)

      archive_extract(zip_file, dir = temp_folder)

      # Find the Excel file
      files <- list.files(
        temp_folder,
        pattern = "Frontur_OpenData.*\\.xlsx?$",
        full.names = TRUE,
        recursive = TRUE
      )

      if (length(files) == 0) {
        stop("No se encontró el archivo Frontur_OpenData")
      }

      # Read metadata
      readxl::read_excel(
        files[1],
        sheet = sheet_name,
        skip = 2
      )
    },
    finally = {
      # Always cleanup temporary files
      unlink(zip_file)
      unlink(temp_folder, recursive = TRUE)
    }
  )
}

#' Get processed INE-FRONTUR data
#'
#' Orchestrates the download, reading, and processing of FRONTUR microdata.
#'
#' @return A data.frame with the processed data, ready for database insertion.
#' @export
#'
#' @examplesIf interactive()
#' ine_frontur_get_data()
ine_frontur_get_data <- function() {
  frontur_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736176996&menu=resultados&idp=1254735576863#_tabs-1254736195382"

  message("--- Processing FRONTUR ---")

  tryCatch(
    {
      # 1. Check last date
      frontur_last_date <- ine_last_definitive_data("INE-FRONTUR")

      # 2. Get download links
      frontur_links <- ine_download_links(
        url = frontur_url,
        last_date = frontur_last_date
      )

      if (nrow(frontur_links) > 0) {
        # 3. Download files
        frontur_temp_dir <- ine_download_files(df_links = frontur_links)

        # 4. Read files
        frontur_col_types <- readr::cols(
          # mm_aaaa = readr::col_character(),
          A0 = readr::col_integer(),
          A0_1 = readr::col_character(),
          A0_7 = readr::col_double(),
          A1 = readr::col_integer(),
          Residencia = readr::col_character(),
          CCAA = readr::col_character(),
          A14 = readr::col_integer(),
          A15 = readr::col_integer(),
          A16 = readr::col_integer(),
          A13_1 = readr::col_integer(),
          Factor = readr::col_double()
        )

        frontur_raw_df <- ine_read_and_concatenate_files(
          extract_dir = frontur_temp_dir,
          file_name_pattern = "frontur",
          extension = "txt",
          col_types = frontur_col_types,
          decimal_mark = ".",
          date_from_filename = TRUE
        )

        if (nrow(frontur_raw_df) > 0) {
          frontur_raw_df <- frontur_raw_df |>
            select("mm_aaaa", "CCAA", "A0_7", "A1", "Factor")

          # 5. Process
          frontur_df <- map_ine_to_geo_nuts2(
            data = frontur_raw_df,
            source_col = "CCAA"
          )

          ine_process_data(
            data = frontur_df,
            source_id = "INE-FRONTUR",
            url = frontur_url
          )
        } else {
          data.frame()
        }
      } else {
        data.frame()
      }
    },
    error = function(e) {
      warning("Error processing FRONTUR: ", e$message)
      data.frame()
    }
  )
}

#' Get processed INE-ETR data
#'
#' Orchestrates the download, reading, and processing of ETR (Encuesta de Turismo de Residentes) microdata.
#'
#' @return A data.frame with the processed data, ready for database insertion.
#' @export
#'
#' @examplesIf interactive()
#' ine_etr_get_data()
ine_etr_get_data <- function() {
  etr_url <- "https://www.ine.es/dyngs/INEbase/operacion.htm?c=Estadistica_C&cid=1254736176990&menu=resultados&idp=1254735576863#_tabs-1254736195369"

  message("--- Processing ETR ---")

  tryCatch(
    {
      # 1. Check last date
      etr_last_date <- ine_last_definitive_data("INE-ETR")

      # 2. Get download links
      etr_links <- ine_download_links(
        url = etr_url,
        last_date = etr_last_date
      )

      if (nrow(etr_links) > 0) {
        # 3. Download files
        etr_temp_dir <- ine_download_files(df_links = etr_links)

        # 4. Read files
        etr_col_types <- readr::cols(
          ANYO = readr::col_character(),
          MES = readr::col_character(),
          CCAADEST = readr::col_character(),
          FACTORGAS_TOT = readr::col_double(),
          FACTORVI_TOT = readr::col_double(),
          GASTOFI_TOTAL = readr::col_double(),
          NPERNOC_CORR = readr::col_integer()
        )

        etr_raw_df <- ine_read_and_concatenate_files(
          extract_dir = etr_temp_dir,
          file_name_pattern = NULL,
          extension = "csv",
          col_types = etr_col_types,
          decimal_mark = ",",
          date_from_columns = TRUE
        )

        if (nrow(etr_raw_df) > 0) {
          etr_raw_df <- etr_raw_df |>
            dplyr::select(
              "mm_aaaa",
              "CCAADEST",
              "FACTORGAS_TOT",
              "FACTORVI_TOT",
              "GASTOFI_TOTAL",
              "NPERNOC_CORR"
            )

          # 5. Process
          etr_df <- map_ine_to_geo_nuts2(
            data = etr_raw_df,
            source_col = "CCAADEST"
          )

          ine_process_data(
            data = etr_df,
            source_id = "INE-ETR",
            url = etr_url
          )
        } else {
          data.frame()
        }
      } else {
        data.frame()
      }
    },
    error = function(e) {
      warning("Error processing ETR: ", e$message)
      data.frame()
    }
  )
}
