prediction_horizon_ui <- function(id, i18n) {
  ns <- NS(id)
  tagList(
    div(
      span(i18n$t("Predecir"), style = "display: flex; padding-top: 10px"),
      HTML("&nbsp"),
      numericInput(
        inputId = ns("ni_hpred"),
        label = NULL,
        value = 3,
        min = 1,
        max = 10,
        width = 60
      ),
      HTML("&nbsp"),
      span(i18n$t("periodos"), style = "display: flex; padding-top: 10px"),
      class = "prediction-buttons-cont"
    ),
    hr(),
    span(uiOutput(ns("ui_slider_epsilon_intervention")))
  )
}

#' Prediction horizon selection module
#'
#' This module presents the controls to make the prediction and set the target
#' for the intervention:
#' 
#' * A numeric input for the number of periods to predict.
#' * A slider input for the target when running the intervention. The maximum value
#' and the selected value are based on the predicted data and the scaling method.
#' 
#' @note
#' The prediction_horizon_ui function requires an `i18n` argument. the example app
#' nequires only a `lan` argument. The `scaling_method` argument in the server function
#' is used only to manage the possible values in the slider.
#'
#' @param id Module instance id.
#' @param i18n Translation object.
#' @param .data List with the predictions, both the individual indicators and the
#' composite indicators. It is used to set the values of the slider for the target.
#'
#' @return A list with the following reactive objects:
#' * `ni_hpred`: the value of the numeric input with the number of periods to predict.
#' * `slider_epsilon_intervention`: the value of the target as increment of the global indicator value.
#' 
#' @export
#' @aliases prediction_horizon
#' @examplesIf interactive
#' prediction_horizon_app()
#'
prediction_horizon_server <- function(id, i18n, .data, scaling_method) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns

      ##

      ## ➡ slider_epsilon_intervention ----
      output$ui_slider_epsilon_intervention <- renderUI({
        value_pred <- .data()$dim |>
          filter(dimension_id == "GLOBAL") |>
          slice_max(date) |>
          pull(value)
        # maximum approximate value for the series
        max_value <- c(
          "minmax" = 1,
          "refvalue" = 2,
          "zscore" = 3
        )[scaling_method()]
        # maximum increment allowed
        epsilon_max <- round(max_value - value_pred, 2)

        sliderInput(
          ns("slider_epsilon_intervention"),
          label = i18n()$t("Objetivo de mejora"),
          min = 0.01,
          max = epsilon_max,
          step = 0.01,
          value = epsilon_max / 10
        )
      })
      return(list(
        ni_hpred = reactive({
          input$ni_hpred
        }),
        slider_epsilon_intervention = reactive({
          input$slider_epsilon_intervention
        }) |>
          debounce(1500)
      ))
    }
  )
}


#' @export
prediction_horizon_app <- function(lan = "es") {
  library(shiny)
  # library(evastur)
  devtools::load_all()
  translator <- getOption("evastur.translator")
  translator$set_translation_language(lan)

  translator_r <- reactive({
    translator <- getOption("evastur.translator")
    translator$set_translation_language(lan)
    return(translator)
  })

  ## example data
  inds <- con2 |>
  tbl("ft_indicators") |>
  distinct(indicator_id) |>
  pull()
dfind <- get_ft_data(
  data_type = "indicator",
  .nuts_level = 0,
  type_id = inds,
  # country = "ES",
  .source_id = "EVASTUR",
  from_date = "2013-01-01",
  to_date = "2022-12-31"
)
suppressMessages({
  tindicators <- get_transformed_indicators(
    dfind,
    scaling_method = "zscore",
    scaling_type = "time",
    refvalueq = NULL,
    geo_total = "WLD"
  )
})
cindicators <- compute_composite_indicator(
  tindicators,
  selected_source = "EVASTUR"
)
predicted_indicators <- reactive({
  predict_indicators(
  # tindicators |> filter(geo_id == "ESP")
  tindicators |> filter(total)
)
})

  ui <- fluidPage(
    tags$style(HTML(
      "
    .irs--shiny .irs-bar {
    top: 32px;
    height: 1px;
    border-top: 1px solid #6B8A7A;
    border-bottom: 1px solid #6B8A7A;
    background: #6B8A7A;
    cursor: s-resize;
    z-index: 2;
}
.irs--shiny .irs-handle {
    top: 17px;
    width: 19px;
    height: 19px;
    border: none;
    background-color: #6B8A7A;
    box-shadow: none;
    border-radius: 19px;
    z-index: 2;
}

.irs--shiny .irs-from, .irs--shiny .irs-to, .irs--shiny .irs-single {
    color: #ffffff;
    text-shadow: none;
    padding: 1px 3px;
    background-color: #6B8A7A;
    border-radius: 3px;
    font-size: 11px;
    line-height: 1.333;
}

.irs--shiny .irs-grid-text {
    bottom: 5px;
    color: #666666;
}
    "
    )),

    prediction_horizon_ui("prediction_horizon1", translator)
  )

  server <- function(input, output, session) {
    prediction_horizon_server(
      "prediction_horizon1", 
      i18n = translator_r,
      .data = predicted_indicators,
      scaling_method = reactive({"zscore"})
    )
  }

  shinyApp(ui, server)
}
