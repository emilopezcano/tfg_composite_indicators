## Helper function to prepare logo for PDF generation ----
prepare_logo_for_pdf <- function(session) {
  tryCatch({
    cfg <- session$userData$config_theme()

    # Try binary PNG first (LaTeX cannot use SVG directly)
    logo_bin_list <- cfg$logo_bin[[1]]
    if (is.raw(logo_bin_list)) {
      temp_logo <- tempfile(fileext = ".png")
      writeBin(logo_bin_list, temp_logo)
      return(temp_logo)
    }

    # Fall back to SVG: convert to PNG via rsvg
    logo_svg <- cfg$logo_svg |> 
      stringr::str_replace_all("currentColor", cfg$light_hex)
    if (!is.null(logo_svg) && nchar(logo_svg) > 0) {
      temp_logo <- tempfile(fileext = ".png")
      rsvg::rsvg_png(charToRaw(logo_svg), file = temp_logo)
      return(temp_logo)
    }

    return(NULL)
  }, error = function(e) {
    warning("Error preparing logo: ", e$message)
    return(NULL)
  })
}

## PDF Download Module UI ----
pdf_download_ui <- function(id,
                            label = NULL,
                            icon_name = "file-pdf",
                            class = "btn-primary") {
  ns <- NS(id)
  tagList(
    downloadButton(
      outputId = ns("download_pdf"),
      label = label,
      icon = icon(icon_name),
      class = class,
      style = "width:100%"
    )
  )
}

# ## PDF Download Module Server ----
pdf_download_server <- function(id,
                                rmd_template,
                                params = reactive(list()),
                                filename_prefix = "report",
                                i18n = NULL,
                                output_format = "pdf_document") {
  moduleServer(id, function(input, output, session) {
    # Generate report file
    generate_report <- reactive({
      withProgress(
        message = if (is.null(i18n))
          "Generating report..."
        else
          i18n()$t("Generando informe..."),
        value = 0,
        {
          tryCatch({
            incProgress(
              0.1,
              detail = if (is.null(i18n))
                "Validating template..."
              else
                i18n()$t("Validando plantilla...")
            )
            
            template_path <- system.file("app", "templates", rmd_template, package = "evastur")
            
            incProgress(
              0.2,
              detail = if (is.null(i18n))
                "Preparing parameters..."
              else
                i18n()$t("Preparando parámetros...")
            )
            
            report_params <- params()
            report_params$generated_date <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
            report_params$i18n <- i18n()
            
            incProgress(
              0.3,
              detail = if (is.null(i18n))
                "Setting up environment..."
              else
                i18n()$t("Configurando entorno...")
            )
            
            temp_dir <- tempdir()
            temp_rmd <- file.path(temp_dir,
                                  paste0("temp_report_", Sys.getpid(), ".Rmd"))
            
            file.copy(template_path, temp_rmd, overwrite = TRUE)
            
            # Generate output file path
            timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
            extension <- if (output_format == "html_document")
              ".html"
            else
              ".pdf"
            output_file <- file.path(temp_dir,
                                     paste0(filename_prefix, "_", timestamp, extension))
            
            incProgress(
              0.5,
              detail = if (is.null(i18n))
                "Rendering document..."
              else
                i18n()$t("Renderizando documento...")
            )

            if (output_format == "html_document") {
              rmarkdown::render(
                input = temp_rmd,
                output_format = rmarkdown::html_document(
                  toc = TRUE,
                  toc_float = TRUE,
                  theme = "flatly"
                ),
                output_file = output_file,
                params = report_params,
                quiet = TRUE,
                envir = new.env()
              )
            } else {
              rmarkdown::render(
                input = temp_rmd,
                output_format = rmarkdown::pdf_document(latex_engine = "xelatex", toc = FALSE, number_sections = TRUE),
                output_file = output_file,
                params = report_params,
                quiet = TRUE,
                envir = new.env(),

              )
            }
            
            incProgress(0.9,
                        detail = if (is.null(i18n))
                          "Cleaning up..."
                        else
                          i18n()$t("Limpiando..."))
            
            # Clean up temporary files
            if (file.exists(temp_rmd)) {
              unlink(temp_rmd)
            }
            
            incProgress(1,
                        detail = if (is.null(i18n))
                          "Complete!"
                        else
                          i18n()$t("¡Completado!"))
            
            return(output_file)
            
          }, error = function(e) {
            traceback()
            print(e)
            # Clean up
            if (exists("temp_rmd") && file.exists(temp_rmd)) {
              unlink(temp_rmd)
            }
            
            error_msg <- if (is.null(i18n)) {
              paste("Error generating report:", e$message)
            } else {
              paste(i18n()$t("Error ocurrido creando el informe"),
                    ":",
                    e$message)
            }
            
            showNotification(HTML(paste0("<div>", error_msg, "</div>")),
                             type = "error",
                             duration = 10)
            
            return(NULL)
          })
        }
      )
    })
    
    output$download_pdf <- downloadHandler(
      filename = function() {
        timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
        extension <- if (output_format == "html_document") ".html" else ".pdf"
        paste0(filename_prefix, "_", timestamp, extension)
      },
      
      content = function(file) {
        report_file <- generate_report()
        req(report_file)  # Stops here if NULL
        
        file.copy(report_file, file, overwrite = TRUE)
        
        if (file.exists(report_file)) {
          unlink(report_file)
        }
      },
      
      contentType = if (output_format == "html_document") "text/html" else "application/pdf"
    )
  })
}

## PDF Download Module App (Example) ----
pdf_download_app <- function() {
  library(shiny)
  library(bslib)
  library(dplyr)
  library(ggplot2)
  library(plotly)
  
  # Create example RMD template if it doesn't exist
  rmd_path <- file.path(tempdir(), "dashboard_template.Rmd")
  
  rmd_content <- '---
title: "Dashboard Report"
output:
  pdf_document:
    toc: true
    number_sections: true
  html_document:
    toc: true
    toc_float: true
    theme: flatly
params:
  dataset: "mtcars"
  plot_type: "scatter"
  selected_vars: null
  generated_date: ""
---

```{r setup, include=FALSE}
knitr::opts_chunk$set(echo = FALSE, warning = FALSE, message = FALSE)
library(ggplot2)
library(dplyr)
library(knitr)
```

# Executive Summary

This report was generated from the sustainable tourism dashboard on `r params$generated_date`.

**Dataset:** `r params$dataset`
**Plot Type:** `r params$plot_type`
**Selected Variables:** `r paste(params$selected_vars, collapse = ", ")`

# Data Analysis

```{r data-prep}
data <- switch(params$dataset,
               "mtcars" = mtcars,
               "iris" = iris,
               "faithful" = faithful)
```

## Summary Statistics

```{r summary}
kable(summary(data), caption = paste("Summary statistics for", params$dataset))
```

## Data Preview

```{r preview}
kable(head(data, 10), caption = paste("First 10 rows of", params$dataset))
```

# Visualizations

```{r plot, fig.height=6, fig.width=8}
if (params$plot_type == "scatter") {
  if (params$dataset == "mtcars") {
    ggplot(data, aes(x = wt, y = mpg)) +
      geom_point(color = "#6B8A7A", size = 3) +
      geom_smooth(method = "lm", se = FALSE, color = "#4A6741") +
      labs(title = "Weight vs MPG", x = "Weight", y = "Miles per Gallon") +
      theme_minimal()
  } else if (params$dataset == "iris") {
    ggplot(data, aes(x = Sepal.Length, y = Sepal.Width, color = Species)) +
      geom_point(size = 3) +
      labs(title = "Sepal Length vs Width", x = "Sepal Length", y = "Sepal Width") +
      theme_minimal()
  } else {
    ggplot(data, aes(x = waiting, y = eruptions)) +
      geom_point(color = "#6B8A7A", size = 3) +
      labs(title = "Waiting Time vs Eruption Duration", x = "Waiting Time", y = "Eruption Duration") +
      theme_minimal()
  }
} else if (params$plot_type == "histogram") {
  if (params$dataset == "mtcars") {
    ggplot(data, aes(x = mpg)) +
      geom_histogram(bins = 10, fill = "#6B8A7A", alpha = 0.7) +
      labs(title = "Distribution of MPG", x = "Miles per Gallon", y = "Frequency") +
      theme_minimal()
  } else if (params$dataset == "iris") {
    ggplot(data, aes(x = Sepal.Length)) +
      geom_histogram(bins = 15, fill = "#6B8A7A", alpha = 0.7) +
      labs(title = "Distribution of Sepal Length", x = "Sepal Length", y = "Frequency") +
      theme_minimal()
  } else {
    ggplot(data, aes(x = eruptions)) +
      geom_histogram(bins = 15, fill = "#6B8A7A", alpha = 0.7) +
      labs(title = "Distribution of Eruption Duration", x = "Eruption Duration", y = "Frequency") +
      theme_minimal()
  }
} else {
  if (params$dataset == "mtcars") {
    ggplot(data, aes(x = factor(cyl), y = mpg)) +
      geom_boxplot(fill = "#6B8A7A", alpha = 0.7) +
      labs(title = "MPG by Cylinder Count", x = "Cylinders", y = "Miles per Gallon") +
      theme_minimal()
  } else if (params$dataset == "iris") {
    ggplot(data, aes(x = Species, y = Sepal.Length)) +
      geom_boxplot(fill = "#6B8A7A", alpha = 0.7) +
      labs(title = "Sepal Length by Species", x = "Species", y = "Sepal Length") +
      theme_minimal()
  } else {
    ggplot(data, aes(y = eruptions)) +
      geom_boxplot(fill = "#6B8A7A", alpha = 0.7) +
      labs(title = "Eruption Duration Distribution", y = "Eruption Duration") +
      theme_minimal()
  }
}
```

# Methodology

This report was generated using R Markdown with the following parameters:

- **Dataset:** `r params$dataset`
- **Visualization Type:** `r params$plot_type`
- **Generation Date:** `r params$generated_date`

The data analysis follows standard exploratory data analysis practices, including summary statistics and appropriate visualizations based on the data type and user selections.

# Appendix

## Session Information

```{r session-info}
sessionInfo()
```
'

writeLines(rmd_content, rmd_path)

ui <- page_fluid(
  theme = bs_theme(version = 5),
  
  titlePanel("PDF Download Module with RMD Template"),
  
  sidebarLayout(
    sidebarPanel(
      h4("Report Parameters"),
      selectInput(
        "dataset",
        "Choose Dataset:",
        choices = c("mtcars", "iris", "faithful")
      ),
      selectInput(
        "plot_type",
        "Plot Type:",
        choices = c("scatter", "histogram", "boxplot")
      ),
      checkboxGroupInput(
        "selected_vars",
        "Include Variables:",
        choices = c("summary", "plot", "raw_data"),
        selected = c("summary", "plot")
      ),
      
      hr(),
      h4("Download Options"),
      selectInput(
        "output_format",
        "Output Format:",
        choices = c("PDF" = "pdf_document", "HTML" = "html_document")
      ),
      
      fluidRow(column(
        6,
        pdf_download_ui("pdf_dl", label = "PDF", icon_name = "file-pdf")
      ), column(
        6,
        pdf_download_ui("html_dl", label = "HTML", icon_name = "file-code")
      )),
      
      hr(),
      p(strong("Template Path:")),
      p(code(rmd_path), style = "font-size: 10px; word-break: break-all;")
    ),
    
    mainPanel(div(
      id = "main_content",
      h2("Dashboard Preview"),
      
      fluidRow(column(
        6, card(
          card_header("Current Parameters"),
          verbatimTextOutput("current_params")
        )
      ), column(
        6, card(card_header("Data Summary"), verbatimTextOutput("summary"))
      )),
      
      fluidRow(column(12, card(
        card_header("Sample Visualization"),
        plotOutput("sample_plot")
      )))
    ))
  )
)

server <- function(input, output, session) {
  selected_data <- reactive({
    switch(
      input$dataset,
      "mtcars" = mtcars,
      "iris" = iris,
      "faithful" = faithful
    )
  })
  
  report_params <- reactive({
    list(
      dataset = input$dataset,
      plot_type = input$plot_type,
      selected_vars = input$selected_vars
    )
  })
  
  output$current_params <- renderPrint({
    report_params()
  })
  
  output$summary <- renderPrint({
    summary(selected_data())
  })
  
  output$sample_plot <- renderPlot({
    data <- selected_data()
    
    if (input$plot_type == "scatter") {
      if (input$dataset == "mtcars") {
        ggplot(data, aes(x = wt, y = mpg)) +
          geom_point(color = "#6B8A7A", size = 3) +
          theme_minimal() +
          labs(title = "Sample Plot (Weight vs MPG)")
      } else if (input$dataset == "iris") {
        ggplot(data,
               aes(
                 x = Sepal.Length,
                 y = Sepal.Width,
                 color = Species
               )) +
          geom_point(size = 3) +
          theme_minimal() +
          labs(title = "Sample Plot (Sepal Length vs Width)")
      } else {
        ggplot(data, aes(x = waiting, y = eruptions)) +
          geom_point(color = "#6B8A7A", size = 3) +
          theme_minimal() +
          labs(title = "Sample Plot (Waiting vs Eruptions)")
      }
    } else {
      p("Plot preview - see full plot in generated report")
    }
  })
  
  # PDF Download Server
  pdf_download_server(
    "pdf_dl",
    rmd_template = rmd_path,
    params = report_params,
    filename_prefix = "dashboard_report",
    output_format = "pdf_document"
  )
  
  # HTML Download Server
  pdf_download_server(
    "html_dl",
    rmd_template = rmd_path,
    params = report_params,
    filename_prefix = "dashboard_report",
    output_format = "html_document"
  )
}

shinyApp(ui, server)
}

# Run the example app
#pdf_download_app()
