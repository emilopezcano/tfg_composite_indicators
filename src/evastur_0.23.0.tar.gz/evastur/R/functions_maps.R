#' Add a Selected Highlighting Layer to a Leaflet Map
#'
#' This helper function adds (or updates via proxy) a specific group of polygons
#' to represent a "selected" state. It is designed to be used both within
#' \code{renderLeaflet} for initial renders and with \code{leafletProxy} for
#' reactive updates.
#'
#' @param map_obj A leaflet map object or a leaflet proxy object.
#' @param data An sf object containing the geometries to be filtered and
#'   displayed.
#' @param selected_ids A character vector of IDs representing the elements to
#'   highlight.
#' @param id_col The name of the column in \code{data} used to match
#'   \code{selected_ids}. Defaults to "geo_id".
#' @param group_name The name of the leaflet group for these polygons. Defaults
#'   to "selected". This is useful for clearing the specific layer later via
#'   \code{clearGroup()}.
#' @param hex_color A character string representing the hex color for both
#'   stroke and fill. Defaults to "#555555".
#' @param factor A numeric value to adjust the brightness of the base color. Use
#'   a negative value to darken and a positive value to lighten. If NULL, no
#'   adjustment is made and \code{hex_color} is used as is. Defaults to -0.4.
#'
#' @return A leaflet map or proxy object with the selection layer added.
#' @export
#'
#' @examplesIf interactive()
#' \dontrun{
#' map_data <- tbl(con2, "dt_geo") |>
#'   filter(nuts_level == 0) |>
#'   filter(!is.na(geometry)) |>
#'   select(geo_id, geometry) |>
#'   collect() |>
#'   mutate(geometry = sf::st_as_sfc(geometry)) |>
#'   sf::st_as_sf(crs = 4326) |>
#'   mutate(
#'     geo_label = get_geo_label(geo_id, lan = "en")
#'   )
#'
#' oecd_ids <- con2 |>
#'   tbl("bt_geo_group") |> 
#'   filter(geo_group_id == "OECD") |>
#'   pull(geo_id)
#'
#' leaflet(data = map_data) |>
#'   addProviderTiles(providers$CartoDB.Voyager) |>
#'   addPolygons(
#'     layerId = ~geo_id,
#'     label = ~geo_label,
#'     fillColor = "grey",
#'     weight = 1,
#'     color = "darkgrey",
#'     opacity = 1,
#'     fillOpacity = 0.5
#'   ) |> 
#'   map_add_polygons(
#'     data = map_data,
#'     selected_ids = oecd_ids
#'   )
#' }
map_add_polygons <- function(
  map_obj,
  data,
  selected_ids,
  id_col = "geo_id",
  group_name = "selected",
  hex_color = "#555555",
  factor = -0.4
) {
  if (length(selected_ids) == 0 || is.null(data) || nrow(data) == 0) {
    return(map_obj)
  }

  final_color <- if (!is.null(factor)) {
    adjust_color(hex_color, color_type = "hex", factor = factor)
  } else {
    hex_color
  }

  selected_data <- data |>
    dplyr::filter(.data[[id_col]] %in% selected_ids)

  if (nrow(selected_data) == 0) {
    return(map_obj)
  }

  map_obj |>
    leaflet::addPolygons(
      data = selected_data,
      color = final_color,
      weight = 2.5,
      opacity = 1,
      fillColor = final_color,
      fillOpacity = 0.7,
      group = group_name,
      options = leaflet::pathOptions(clickable = FALSE)
    )
}
