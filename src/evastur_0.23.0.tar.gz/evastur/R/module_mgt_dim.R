## Module for editing the dimensions weights

## Module UI ----
mgt_dim_ui <- function(id) {
  ns <- NS(id)
  tagList(
    reactableOutput(ns("rt_dims")),
    uiOutput(ns("ui_buttons"))
  )
}

## Module server ----
mgt_dim_server <- function(id, i18n, .source) {
  moduleServer(
    id,
    function(input, output, session) {
      
      ## edit validation ----
      iv <- InputValidator$new()
      iv$add_rule("ti_weight_basis", sv_required(message = "*"))
      iv$add_rule("ni_weight", sv_required(message = "*"))
      iv$enable()

      ## [R] Available dims ----
      available_dims <- reactive({
        # eventReactive(input$ab_load, {
        edit_count()
        res <- tryCatch({
          get_dims(lan = i18n()$get_translation_language(),
                   source = .source(),
                   global = FALSE)
        },
        error = function(e) {
          showNotification(paste0(
            cleanHTML(i18n()$t("Error al recuperar las dimensiones disponibles. Intenta recargar el dashboard y probar de nuevo")),
            " - ",
            e),
            type = "error",
            duration = NULL)
          return(NULL)}
        )
        return(res)
      })
      
      ## [RV] edit_count ----
      edit_count <- reactiveVal(0)
      
      ## [R] Values to change ----
      values <- reactiveValues(modal_status = -1)
      
      ## [R] selected_row ----
      selected_nrow <- reactive({
        getReactableState("rt_dims", "selected")
      })
      
      ## [O] edit button
      observeEvent(input$ab_edit, {
        if (!is.null(selected_nrow())) {
          dimrow <- available_dims() |> 
            slice(selected_nrow())
          values$modal_status <- 0
          showModal(
            modalDialog(
              title = i18n()$t("Cambiar peso"),
              p(dimrow |> 
                  pull(dimension_name)),
              numericInput(inputId = session$ns("ni_weight"), 
                           label = i18n()$t("Peso"), 
                           value = dimrow |> pull("dimension_weight")),
              textInput(inputId = session$ns("ti_weight_basis"), 
                        label = i18n()$t("Justificación"), 
                        value = dimrow |>
                          pull(dimension_weight_basis)),
              easyClose = TRUE,
              footer = actionButton(session$ns("ab_save"), 
                                    i18n()$t("Guardar"))
            )
          )
        }
      })
      
      ## [O] ab_save ----
      observeEvent(input$ab_save, {
        if (!iv$is_valid()) {
          showNotification(i18n()$t("Datos incompletos"),
                           type = "error")
        } else {
          values$modal_status <- 1
          removeModal()
        }
      })
      
      ## [O] modal_closed ----
      observeEvent(values$modal_status, {
        if (values$modal_status == 1) {
          user <- Sys.info()["user"]
          selected_dim <- available_dims() |> 
            slice(selected_nrow()) |> 
            pull(dimension_id)
          strsql <- glue::glue("UPDATE dt_dimensions SET dimension_weight = {input$ni_weight}, dimension_weight_basis = '{input$ti_weight_basis}', dimension_weight_user = '{user}' WHERE dimension_id = '{selected_dim}'")
          res <- tryCatch({
            dbExecute(con2, strsql)
            edit_count(edit_count() + 1)
            showNotification(i18n()$t("Peso actualizado"))
          },
          error = function(e) {
            showNotification(paste0(cleanHTML(i18n()$t("Error actualizando peso")),
                                    e),
                             duration = NULL,
                             type = "error"
                             
            )
          })
        }
      })
      
      ## ui_buttons ----
      output$ui_buttons <- renderUI({
        is_disabled <- 

        actionButton(
          inputId = session$ns("ab_edit"),
          label = i18n()$t("Editar peso"),
          icon = icon("edit"),
          width = "100%",
          disabled = if (is.null(selected_nrow())) TRUE else FALSE
        )
      })
      
      ## rt_dims - Dimensions table ----
      output$rt_dims <- renderReactable({
        req(available_dims())
        available_dims() |>
          # tibble::rowid_to_column() |>
          select(
            #rowid,
            dimension_id,
            dimension_label,
            dimension_weight,
            dimension_weight_basis
          ) |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables my-3",
            onClick = "select",
            selection = "single",
            theme = reactableTheme(
              rowSelectedStyle = list(
                backgroundColor = "var(--bs-primary)",
                color = "var(--bs-light)",
                boxShadow = "inset 2px 0 0 0 var(--bs-primary)"
              )
            ),
            columns = list(
              dimension_id = colDef(
                name = i18n()$t("Código"),
                maxWidth = 100
              ),
              dimension_label = colDef(
                name = i18n()$t("Nombre"),
                maxWidth = 200
              ),
              dimension_weight = colDef(
                name = i18n()$t("Peso"),
                maxWidth = 200
              ),
              dimension_weight_basis = colDef(
                name = i18n()$t("Justificación peso")
              )
            )
          )
        # actionButton(session$ns("ab_save_"), 
        #              label = i18n()$t("Guardar indicador"))
      })
    })
  
}

## Module app ----

mgt_dim_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  translator <- getOption("evastur.translator")
  
  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    textInput("ti_source", "Source", "EVASTUR"),
    mgt_dim_ui("dimform1"),
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    mgt_dim_server("dimform1", i18n, reactive({input$ti_source}))
  }
  
  shinyApp(ui, server)
  
}

## Run app ----
# mgt_dim_app()