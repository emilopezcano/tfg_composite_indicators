## Functions to get plots for the dashboard

#' Get composite indicators time series plot
#'
#' @param .data data.frame with the data to plot. A column value is needed
#' @param predictions data.frame with the data to add as prediction
#' @param target Target for global indicator improvement
#' @param i18n language object
#' @param background_color background color
#'
#' @export
#'
#' @examples
#' \dontrun{
#' ## 1. All indicators with data
#' inds <- con2 |>
#'    tbl("ft_indicators") |>
#'    distinct(indicator_id) |>
#'    pull()
#' ## 2. Get indicators values for all countries
#' dfind <- get_ft_data(
#'        data_type = "indicator",
#'        .nuts_level = 0,
#'        type_id = inds,
#'        country = NULL,
#'        .source_id = "EVASTUR",
#'        from_date = "2013-01-01",
#'        to_date = "2022-12-31"
#'      )
#' ## 3. Transform the indicators (scale, aggregate total)
#' suppressMessages({
#'   tindicators <- get_transformed_indicators(
#'     dfind,
#'     scaling_method = "zscore",
#'     scaling_type = "time",
#'     refvalueq = NULL,
#'     geo_total = "WLD")})
#' ## 4. Compute composite indicators
#' cindicators <- compute_composite_indicator(
#'   tindicators,
#'   selected_source = "EVASTUR")
#' ## 5. Prepare data for the time series plot
#' sdata <- get_series_data(cindicators,
#'   total = FALSE,
#'   .geo_id = "ESP",
#'   lan = "es",
#'   source = "EVASTUR")
#' ## 6. Plot indicators time series
#' get_ci_ts_plot(sdata)
#' ## 7. Predict new values
#' predicted_indicators <- predict_indicators(tindicators |> filter(geo_id == "ESP"))
#' ## 8. Prepare predicted data for the time series plot
#' sdatapred <- get_series_data(predicted_indicators$dim,
#'   total = FALSE,
#'   .geo_id = "ESP",
#'   lan = "es",
#'   source = "EVASTUR")
#' ## 9. Plot indicators time series, adding prediction and target
#' get_ci_ts_plot(sdata, sdatapred, 0.5, getOption("evastur.translator"))
#' }
get_ci_ts_plot <- function(.data, predictions = NULL, target = NULL, i18n, background_color = "#F0EDE6") {
  ## check input data
  if (!is.data.frame(.data)) {
    stop(".data must be a data.frame")
  } else if (nrow(.data) == 0) {
    stop(".data must be a non-empty data.frame")
  }
  if (!is.null(predictions)) {
    if (!is.data.frame(predictions)) {
      stop("predictions must be a data.frame")
    } else if (nrow(predictions) == 0) {
      stop("predictions must be a non-empty data.frame")
    }
  }
  ## Filter predictions after last indicator value
  if (!is.null(predictions)) {
    maxdate <- max(.data$date)
    predictions <- predictions |>
      filter(date > maxdate) |> #max(.data$date)) |>
      bind_rows(.data |> slice_max(date))
  }
  ## Create data.frame for the series with predictions
  dfseries <- bind_rows(list(ind = .data, pred = predictions), .id = "type") |>
    mutate(date = as.Date(date))

  ## TODO: make this to get_series_data() and avoid a new connection
  ## Complete dimensions info
  dims <- tbl(con2, "dt_dimensions") |>
    select(dimension_id, dimension_color, dimension_order) |>
    mutate(lwd = ifelse(dimension_id == "GLOBAL", 1, 0.5)) |>
    collect()

  dfseries <- dfseries |>
    inner_join(dims, by = "dimension_id")

  dims_wlabel <- dims |>
    inner_join(
      dfseries |>
        distinct(dimension_id, dimension_label),
      by = "dimension_id"
    )

  lwddims <- setNames(dims_wlabel$lwd, dims_wlabel$dimension_label)
  invalid_color_mask <- !is_valid_hex(dims_wlabel$dimension_color)
  if (any(invalid_color_mask)) {
    message("Invalid hex color for dimension(s): ",
            paste(dims_wlabel$dimension_id[invalid_color_mask], collapse = ", "),
            ". Falling back to default color.")
  }
  safe_dim_color <- ifelse(invalid_color_mask, "#6B8A7A", dims_wlabel$dimension_color)
  cdims <- setNames(
    c(safe_dim_color, "orange"),
    c(dims_wlabel$dimension_label, cleanHTML(i18n$t("Objetivo")))
  )
  odims <- dims_wlabel |> arrange(dimension_order) |> pull(dimension_label)
  ltdims <- setNames(c(0, 1:2), c("target", "ind", "pred"))

  ## Create ggplot
  p <- dfseries |>
    mutate(dimension_label = factor(dimension_label, levels = odims)) |> 
    mutate(dimension_label2 = dimension_label) |> 
    ggplot(aes(
      x = date,
      y = value,
      col = dimension_label,
      linewidth = dimension_label,
      linetype = type
    )) +
    geom_line() +
    scale_linewidth_manual(values = lwddims) +
    scale_linetype_manual(values = ltdims) +
    scale_color_manual(values = cdims) +
    guides(linetype = "none", linewidth = "none") +
    labs(title = "", x = "", y = "", col = "", shape = "") +
    theme(
      panel.background = element_rect(fill = background_color),
      plot.background = element_rect(fill = background_color),
      axis.text.x = element_text(angle = 45, vjust = 0.5),
      legend.position = "bottom"
    ) +
    scale_x_date(date_breaks = "1 year", date_labels = "%Y")

  if (!is.null(target)) {
    ## Add intervention target point
    firstpred <- as.Date(maxdate) + lubridate::years(1)
    dfpoint <- data.frame(
      date = firstpred,
      period_id = "Y",
      value = predictions |>
        filter(dimension_id == "GLOBAL") |>
        filter(date == firstpred) |>
        pull(value) +
        target,
      dimension_id = "GLOBAL",
      dimension_label = cleanHTML(i18n$t("Objetivo")),
      dimension_label2 = cleanHTML(i18n$t("Global (objetivo)")),
      type = "target"
    )
    p <- p +
      geom_point(
        data = dfpoint,
        shape = 23,
        fill = "orange",
        # col = "orange",
        size = 3
      ) +
      labs(col = "", shape = "", fill = "")
  }
  p <- p +
      aes(customdata = dimension_label2)
  return(p)
}
