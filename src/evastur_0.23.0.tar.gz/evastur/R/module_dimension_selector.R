## Module UI ----
dimension_selector_ui <- function (id) {
  ns <- NS(id)
  tagList(
    ## Selected area of interest (country or area within country)
    uiOutput(ns("ui_pi_dimension")),
  )
}

## Module Server ----
dimension_selector_server <- function (id, i18n, lan, 
                                       .source_id) {
  moduleServer(
    id,
    function (input, output, session) {
      ns <- NS(id)
      
      ## [R] df_choices_dimension ----
      df_choices_dimension <- reactive({
        get_dims(lan = lan(),
                 source = .source_id(),
                 global = TRUE)
      })
      
      ## [R] dimension_label -----
      dimension_label <- reactive({
        req(input$pi_dimension)
        df_choices_dimension() |> 
          filter(dimension_id == input$pi_dimension) |> 
          pull(dimension_label)
      })
      
      
      # pi_dimension ----
      # Picker input selection of dimension
      output$ui_pi_dimension <- renderUI({
        dfdims <- df_choices_dimension()
        safe_colors <- ifelse(
          is_valid_hex(dfdims$dimension_color),
          dfdims$dimension_color,
          "var(--bs-primary)"
        )
        pickerInput(inputId = session$ns("pi_dimension"),
                    label = i18n()$t("Dimensión"),
                    choices = setNames(dfdims$dimension_id,
                                       dfdims$dimension_label),
                    choicesOpt = list(
                      style = paste0(
                        "background-color: ", safe_colors, ";",
                        "color: #ffffff;"
                      )
                    )) |>
          tagAppendAttributes(class = "compact-picker-input")
      })
      return(
        list(
          pi_dimension = reactive({input$pi_dimension}),
          dimension_label = dimension_label
        )
      )
    }
    
  )
}

## Module App ----

dimension_selector_app <- function(){
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)
  translator <- getOption("evastur.translator")
  
  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    dimension_selector_ui("dimension1"),
    h3("Output from input in app"),
    verbatimTextOutput("input_dimension"),
    verbatimTextOutput("dimension_label")
  )
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    tindicators <- reactive({
      selected_source <- "EVASTUR"
      selected_nuts <- 0
      selected_location <- "ES"
      selected_group <- "WLD"
      selected_date <- "2013-01-01"
      
      inds <- tbl(con2, "dt_indicators") |>
        filter(indicator_active == TRUE) |>
        pull(indicator_id)
      
      dfind <- get_ft_data(data_type = "indicator",
                           .nuts_level = selected_nuts,
                           type_id = inds,
                           country = selected_location,
                           .source_id = selected_source,
                           from_date = selected_date)
      
      
      tindicators <- get_transformed_indicators(dfind,
                                                scaling_method = "zscore",
                                                scaling_type = "time",
                                                geo_total = selected_group)
      
      dfcomp <- tindicators |>
        compute_composite_indicator(selected_source = selected_source)
    })
    dimension_selector_control <- dimension_selector_server(
      "dimension1", 
      i18n = i18n, 
      lan = reactive({input$si_lan}),
      .source_id = reactive({"EVASTUR"})
    )
    output$input_dimension <- renderText({
      dimension_selector_control$pi_dimension()
    })
    output$dimension_label <- renderText({
      dimension_selector_control$dimension_label()
    })
  }
  shinyApp(ui, server)
}

## Run app ----
## Comment for it
# dimension_selector_app()