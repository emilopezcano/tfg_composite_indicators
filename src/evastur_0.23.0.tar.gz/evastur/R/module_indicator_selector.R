## Module UI ----
indicator_selector_ui <- function (id) {
  ns <- NS(id)
  tagList(
    ## Selected indicator
    uiOutput(ns("ui_pi_indicator")),
  )
}

## Module Server ----
#' Module for indicators selection
#'
#' @param id instance id
#' @param i18n translation object
#' @param .source_id indicators source id
#' @param .dimension_id dimension id
#' @param multi whether multiple selection is allowed. Default is `TRUE`.
#' @param maxOptions maximum number of indicators that can be selected when
#'   `multi = TRUE`. Default is 10. If `Inf`, no limit is applied.
#' @param only_inds vector of indicator IDs to filter the choices to a specific
#'   subset. Default is `NULL` (no filtering).
#'
#' @returns server module
#' @export
#'
#' @examples
#' \dontrun{
#' indicator_selector_app()
#' }
indicator_selector_server <- function(
  id,
  i18n,
  .source_id,
  .dimension_id,
  multi = TRUE,
  maxOptions = 10,
  only_inds
) {
  moduleServer(
    id,
    function (input, output, session) {
      ns <- NS(id)

      ## [R] df_choices_indicator ----
      df_choices_indicator <- reactive({
        .lan <- i18n()$get_translation_language()
        res <- get_inds(dim = .dimension_id(), 
                 source = .source_id(),
                 lan = .lan) 
        if (nrow(res) == 0){
          NULL
        } else {
          res |> 
            filter(indicator_id %in% only_inds())
        }
      })

      ## [R] indicator_label -----
      indicator_label <- reactive({
        req(input$pi_indicator)
        df0 <- df_choices_indicator() |>
          filter(indicator_id %in% input$pi_indicator) |>
          collect()
        setNames(df0$indicator_id, df0$indicator_label)
      })

      ## [R] indicator_name -----
      indicator_name <- reactive({
        req(input$pi_indicator)
        df0 <- df_choices_indicator() |>
          filter(indicator_id %in% input$pi_indicator) |>
          collect()
        setNames(df0$indicator_id, df0$indicator_name)
      })

      # pi_indicator ----
      # Picker input selection of indicator
      output$ui_pi_indicator <- renderUI({
        req(.source_id(), .dimension_id(), i18n())
        dfinds <- df_choices_indicator()

        .maxOptions <- if (multi()) maxOptions else 1
        .show_select_all <- multi() && .maxOptions >= nrow(dfinds)

        input_element <- pickerInput(
          inputId = session$ns("pi_indicator"),
          label = i18n()$t("Indicador"),
          choices = setNames(dfinds$indicator_id, dfinds$indicator_label),
          multiple = TRUE,
          selected = "",
          options = pickerOptions(
            maxOptions = .maxOptions,
            actionsBox = TRUE,
            container = "body",
            dropupAuto = FALSE,
            deselectAllText = i18n()$t("Borrar"),
            selectAllText = i18n()$t("Todos"),
            title = i18n()$t("Seleccione"),
            liveSearch = TRUE,
            liveSearchNormalize = TRUE,
            liveSearchPlaceholder = i18n()$t("Buscar"),
            noneSelectedText = i18n()$t("Nada seleccionado")
          )
        )

        # JavaScript to add class to the dropdown menu to hide "select all" button
        input_js <- NULL
        if (!.show_select_all) {
          js_code <- sprintf("
            $(document).one('shiny:bound', function(event) {
              if (event.target.id === '%s') {
                setTimeout(function() {
                  var $el = $('#' + event.target.id);
                  var picker = $el.data('selectpicker');
                  if (picker && picker.$menu) {
                    picker.$menu.parent().addClass('picker-only-clear');
                  }
                }, 50);
              }
            });
          ", session$ns("pi_indicator"))

          input_js <- tags$script(HTML(js_code))
        }

        tagList(
          input_element,
          input_js
        )
      })

      return(
        list(
          pi_indicator = reactive({
            input$pi_indicator
          }),
          indicator_label = indicator_label,
          indicator_name = indicator_name
        )
      )
    }
  )
}

## Module App ----

indicator_selector_app <- function(){
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)
  translator <- getOption("evastur.translator")
  
  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    indicator_selector_ui("indicator1"),
    h3("Output from input in app"),
    verbatimTextOutput("input_indicator"),
    verbatimTextOutput("indicator_label")
  )
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    
    indicator_selector_control <- indicator_selector_server(
      "indicator1", 
      i18n = i18n, 
      .source_id = reactive({"EVASTUR"}),
      .dimension_id = reactive({"ECO"}),
      multi = reactive({TRUE}),
      only_inds = reactive({c("IECO0001", "IECO0002")})
    )
    output$input_indicator <- renderText({
      indicator_selector_control$pi_indicator()
    })
    output$indicator_label <- renderText({
      paste0(
        indicator_selector_control$indicator_label(),
        ": ",
        names(indicator_selector_control$indicator_label()),
        collapse = "\n")
    })
  }
  shinyApp(ui, server)
}
