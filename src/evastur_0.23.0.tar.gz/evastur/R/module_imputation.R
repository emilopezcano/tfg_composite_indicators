#' Imputation run button (UI module)
#'
#' Simple namespaced button to trigger imputation
#' @param id module id
#' @param i18n translator (optional, used for labels)
#' @export
imputation_ui <- function(id, i18n = getOption("evastur.translator")) {
  ns <- NS(id)
  tagList(
    actionButton(
      ns("run"),
      label = i18n$t("Ejecutar imputación"),
      class = "btn-primary",
      style = "width:100%"
    )
  )
}

#' Imputation run server (module)
#'
#' Shows a SweetAlert confirmation, runs impute_vars on df_input(), returns reactive of imputation result.
#' Optionally updates ft_variables in con2 when update_db = TRUE (default FALSE).
#'
#' @param id module id
#' @param df_input reactive that returns the input data.frame for impute_vars
#' @param method character imputation method (passed to impute_vars)
#' @param options list options for impute_vars
#' @param update_db logical; if TRUE attempts to upsert imputed values into ft_variables (con2 must be available)
#' @param con DBI connection (default: con2 from global)
#' @param i18n translator object (optional)
#' @return reactive that contains the imputation result (the list returned by impute_vars) or NULL
#' @export
#' @examplesIf interactive()
#' imputation_app()
imputation_server <- function(
  id,
  df_input,
  method = "Amelia",
  options = list(),
  update_db = FALSE,
  con,
  i18n = getOption("evastur.translator")
) {
  moduleServer(id, function(input, output, session) {
    # reactive to hold imputation result
    impute_result <- reactiveVal(NULL)

    observeEvent(input$run, {
      # ask confirmation via sweetalert (shinyWidgets)
      shinyWidgets::ask_confirmation(
        inputId = session$ns("confirm_impute"),
        title = i18n$t("Confirmar imputación"),
        text = i18n$t(
          "¿Desea ejecutar la imputación? Los valores imputados podrán actualizar la tabla de variables."
        ),
        btn_labels = c(i18n$t("No"), i18n$t("Sí")),
        btn_colors = c("#d9534f", "#5cae6e")
      )
    })

    observeEvent(input$confirm_impute, {
      # input$confirm_impute is TRUE when user confirms
      if (isTRUE(input$confirm_impute)) {
        req(df_input())

        # run imputation with progress notification
        shinyWidgets::sendSweetAlert(
          session = session,
          title = i18n$t("Imputación en curso"),
          text = i18n$t("Por favor espere..."),
          type = "info",
          closeOnClickOutside = FALSE
        )

        # Run impute_vars; keep this synchronous and capture errors
        res <- tryCatch(
          {
            withCallingHandlers(
              {
                impute_vars(df_input(), method = method, options = options)
              },
              message = function(m) {
                # optionally forward messages
              }
            )
          },
          error = function(e) {
            shinyWidgets::sendSweetAlert(
              session = session,
              title = i18n$t("Error"),
              text = paste(i18n$t("La imputación falló:"), e$message),
              type = "error"
            )
            NULL
          }
        )

        if (!is.null(res)) {
          impute_result(res)

          # optionally update DB (use your preferred upsert function)
          if (isTRUE(update_db)) {
            # ensure connection available
            if (is.null(con)) {
              shinyWidgets::sendSweetAlert(
                session = session,
                title = i18n$t("No hay conexión"),
                text = i18n$t(
                  "No se proporcionó la conexión a la base de datos."
                ),
                type = "warning"
              )
            } else {
              df_values <- res$df_values
              df_vars_meta <- res$df_variables
              df_new <- df_input() |>
                filter(is.na(variable_value)) |>
                select(-variable_value) |>
                left_join(
                  df_values |>
                    mutate(date = as.character(date)) |>
                    tidyr::pivot_longer(
                      cols = -c(geo_id, date, source_id, period_id),
                      names_to = "variable_id",
                      values_to = "variable_value"
                    ),
                  by = c(
                    "variable_id",
                    "geo_id",
                    "date",
                    "source_id",
                    "period_id"
                  )
                ) |>
                left_join(
                  df_vars_meta |> rename(variable_id = variable),
                  by = "variable_id"
                ) |>
                mutate(
                  variable_value_flags = "{I}",
                  variable_value_notes = paste0(
                    "Imputed by EVASTOUR using method ",
                    Method,
                    " (R2:",
                    round(R2_overimpute, 2),
                    ")"
                  ),
                  variable_ts = Timestamp,
                  user_cre = paste(Sys.info()[["user"]], "(I)")
                ) |>
                select(
                  variable_id,
                  geo_id,
                  date,
                  source_id,
                  period_id,
                  variable_value,
                  variable_value_flags,
                  variable_value_notes,
                  variable_ts,
                  user_cre
                )

              # align types and upsert: prefer rows_upsert if supported
              key_cols <- c(
                "variable_id",
                "geo_id",
                "date",
                "source_id",
                "period_id"
              )
              try_upsert <- try(
                dplyr::rows_upsert(
                  x = dplyr::tbl(con, "ft_variables"),
                  y = df_new,
                  by = key_cols,
                  in_place = TRUE,
                  copy = TRUE
                ),
                silent = TRUE
              )

              if (inherits(try_upsert, "try-error")) {
                # fallback to explicit SQL upsert if rows_upsert fails
                try(
                  {
                    # function update_ft_variables expected; fallback not implemented here
                    if (exists("update_ft_variables")) {
                      update_ft_variables(con, df_new)
                    } else {
                      stop(
                        "rows_upsert failed and no update_ft_variables fallback is available."
                      )
                    }
                  },
                  silent = TRUE
                )
              }

              shinyWidgets::sendSweetAlert(
                session = session,
                title = i18n$t("Imputación completada"),
                text = i18n$t("Imputación ejecutada y tabla actualizada."),
                type = "success"
              )
            } # end con check
          } else {
            shinyWidgets::sendSweetAlert(
              session = session,
              title = i18n$t("Imputación completada"),
              text = i18n$t(
                "Imputación ejecutada. No se actualizó la base de datos (update_db = FALSE)."
              ),
              type = "success"
            )
          }
        } # end res not null
      } else {
        # user cancelled
        shinyWidgets::sendSweetAlert(
          session = session,
          title = i18n$t("Cancelado"),
          text = i18n$t("Imputación cancelada por el usuario."),
          type = "info"
        )
      }
    })

    # return reactive with result
    impute_result
  })
}

#' Imputation module test app
#' @export
imputation_app <- function() {
  library(shiny)
  library(shinyWidgets)
  library(dplyr)
  library(tidyr)
  library(evastur)

  ui <- fluidPage(
    titlePanel("Imputation Module Test"),
    sidebarLayout(
      sidebarPanel(
        imputation_ui("imputation1")
      ),
      mainPanel(
        verbatimTextOutput("impute_result")
      )
    )
  )

  server <- function(input, output, session) {
    # Sample input data
    selected_nuts <- 2
    selected_location <- NULL
    selected_date <- "1900-01-01"
    selected_to_date <- Sys.Date()

    vars <- tbl(con2, "dt_variables") |>
      pull(variable_id)

    selected_source <- reactive({
      tbl(con2, "ft_variables") |>
        distinct(source_id) |>
        pull() |>
        str_subset("^INSTO", negate = TRUE)
    })

    df_var_ini <- reactive({
      get_ft_data(
        "variable",
        .nuts_level = selected_nuts,
        type_id = vars,
        country = selected_location,
        .source_id = selected_source(),
        from_date = selected_date,
        to_date = selected_to_date
      ) |>
        ## RESTORE NA VALUES
        mutate(
          variable_value = if_else(
            stringr::str_detect(variable_value_flags, "I") &
              stringr::str_detect(variable_value_notes, "EVASTOUR") &
              !is.na(stringr::str_detect(variable_value_flags, "I")) &
              !is.na(stringr::str_detect(variable_value_notes, "EVASTOUR")),
            NA_real_,
            variable_value
          )
        )
    })

    # Call imputation module
    impute_res <- imputation_server(
      id = "imputation1",
      df_input = df_var_ini,
      con = con2,
      method = "Amelia",
      options = list(m = 5, corr_values = c(0.8, 0.7, 0.5)),
      update_db = TRUE
    )

    output$impute_result <- renderPrint({
      res <- impute_res()
      if (is.null(res)) {
        "No imputation result yet."
      } else {
        str(res)
      }
    })
  }

  shinyApp(ui, server)
}
