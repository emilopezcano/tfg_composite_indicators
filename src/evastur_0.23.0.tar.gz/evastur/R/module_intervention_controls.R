intervention_controls_ui <- function(id, i18n) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("ui_cbg_dimensions")),
    uiOutput(ns("ui_pi_inds"))
  )
}

#' Intervention controls module
#'
#' This module presents the controls for performing the intervention:
#'
#' * A button to run the first layer intervention.
#' * A checkbox group to select the dimensions to intervene in the first layer.
#' * A button to run the second layer intervention.
#' * A Picker Input to select the indicators to intervene in the second layer.
#'
#' @note
#' The intervention_controls_ui function requires an `i18n` argument. the example app
#' nequires `lan` and `source` arguments.
#'
#' @param id Module instance id.
#' @param i18n Translation object.
#' @param .datanpred data.frame with the composite indicators series used for the prediction.
#' @param .datapred List with the predictions, both the individual indicators and the
#' composite indicators. It is used to get the codes of the available dimensions.
#' @param .dataind data.frame with the indicators data used in the prediction.
#' @param source source of indicators for getting dimensions labels.
#' @param geo Geographical area code.
#' @param .epsilon Target for the global indicator improvement.
#' @param .scaling_method method Scaling method used for the computation of the
#' scaled and composite indicators.
#'
#' @return The values of the input controls:
#' * cbg_dimensions
#' * pi_inds
#' In addition, the results of the intervention:
#' * res_intervention_step1
#' * res_intervention_step2
#'
#' @examplesIf interactive
#' intervention_controls_app()
#' intervention_controls_app(lan = "es", .epsilon = 0.17)
intervention_controls_server <- function(
  id,
  i18n,
  .datanpred,
  .datapred,
  .dataind,
  source,
  geo,
  .epsilon,
  .scaling_method
) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns

      ## [R] dims_pred ----
      dims_pred <- reactive({
        .datapred()$dim |>
          filter(dimension_id != "GLOBAL") |>
          distinct(dimension_id) |>
          pull()
      })

      ## ui_cbg_dimensions ----
      output$ui_cbg_dimensions <- renderUI({
        req(dims_pred())
        req(length(dims_pred()) > 0)

        dims <- get_dims(i18n()$get_translation_language(), source(), FALSE) |>
          filter(dimension_id %in% dims_pred())
        checkboxGroupInput(
          ns("cbg_dimensions"),
          label = i18n()$t("Actuar sobre:"),
          choices = setNames(dims$dimension_id, dims$dimension_label),
          selected = dims$dimension_id
        )
      })

      ## [R] cbg_dimensions_debounced ----
      cbg_dimensions_debounced <- reactive({
        input$cbg_dimensions
      }) |> debounce(1500)

      #### [E] Step 1 Intervention (dimensions) ----
      res_intervention_step1 <- reactive({
        req(cbg_dimensions_debounced())
        req(.epsilon())

        if (geo() == "_TOTAL_") {
          dfnpred <- .datanpred() |>
            filter(total)
        } else {
          dfnpred <- .datanpred() |>
            filter(geo_id == geo())
        }
        data_to_int <- bind_rows(dfnpred, .datapred()$dim) |>
          filter(dimension_id != "GLOBAL") |>
          inner_join(
            con2 |>
              tbl("dt_dimensions") |>
              inner_join(
                tbl(con2, "bt_source_subdimension") |>
                  distinct(source_id, dimension_id) |>
                  filter(source_id == "EVASTUR"),
                by = "dimension_id"
              ) |>
              select(
                dimension_id,
                dimension_weight,
                dimension_color,
                dimension_order
              ) |>
              inner_join(
                tbl(con2, "lt_dimensions") |>
                  filter(dimension_lang == i18n()$get_translation_language()) |>
                  select(dimension_id, dimension_label, dimension_name),
                by = "dimension_id"
              ) |>
              collect(),
            by = "dimension_id"
          ) |>
          arrange(dimension_order)
        compute_intervention(
          .data = data_to_int,
          year = min(year(as.Date(.datapred()$dim$date))),
          epsilon = .epsilon(),
          mu_l = 1,
          mu_u = length(dims_pred()),
          scaling_method = .scaling_method(),
          layer = 1,
          var_no_modify = setdiff(dims_pred(), input$cbg_dimensions)
        )
      })

      ## ui_pi_inds ----
      output$ui_pi_inds <- renderUI({
        req(res_intervention_step1())

        dims_int <- res_intervention_step1() |>
          filter(beta != 0) |>
          pull(var)
        inds_int <- .datapred()$ind |>
          distinct(indicator_id, dimension_id) |>
          filter(dimension_id %in% dims_int) |>
          pull(indicator_id)
        df <- con2 |>
          tbl("v_indicators_select") |>
          filter(
            indicator_lang == i18n()$get_translation_language(),
            source_id == !!source(),
            indicator_id %in% inds_int
          ) |>
          select(
            indicator_id,
            indicator_label,
            dimension_id,
            dimension_label
          ) |>
          collect()
        choiceslist <- split(df, df$dimension_label) |>
          map(
            ~ {
              setNames(.x$indicator_id, .x$indicator_label)
            }
          )
        pickerInput(
          ns("pi_inds"),
          label = i18n()$t("Indicadores permitidos"),
          choices = choiceslist,
          multiple = TRUE,
          selected = df$indicator_id,
          options = pickerOptions(
            container = "body",
            dropupAuto = FALSE
          )
        )
      })

      ## [R] pi_inds_debounced ----
      pi_inds_debounced <- reactive({
        input$pi_inds
      }) |> debounce(1500)

      #### [E] Step 2 Intervention (dimensions) ----
      res_intervention_step2 <- reactive({
        req(res_intervention_step1())
        req("pi_inds" %in% names(input))

        if (geo() == "_TOTAL_") {
          dfnpred <- .datanpred() |>
            filter(total)
        } else {
          dfnpred <- .datanpred() |>
            filter(geo_id == (geo()))
        }

        get_intervention_layer2(
          counterfactual_dimen = res_intervention_step1(),
          data_npred = dfnpred,
          data_pred = .datapred(),
          data_ind_original = .dataind(),
          actionable_indicators = pi_inds_debounced(),
          .scaling_method = .scaling_method(),
          lan = i18n()$get_translation_language(),
          source = source()
        )
      })

      return(list(
        cbg_dimensions = reactive({
          input$cbg_dimensions
        }),
        pi_inds = reactive({
          input$pi_inds
        }),
        res_intervention_step1 = res_intervention_step1,
        res_intervention_step2 = res_intervention_step2
      ))
    }
  )
}

#' @export
intervention_controls_app <- function(
  lan = "es",
  source = "EVASTUR",
  scaling_method = "zscore",
  geo = "_TOTAL_",
  .epsilon = 0.17
) {
  library(shiny)
  devtools::load_all()
  translator <- getOption("evastur.translator")
  translator$set_translation_language(lan)

  translator_r <- reactive({
    translator <- getOption("evastur.translator")
    translator$set_translation_language(lan)
    return(translator)
  })

  ## example data
  inds <- con2 |>
    tbl("ft_indicators") |>
    distinct(indicator_id) |>
    pull()
  dfind <- get_ft_data(
    data_type = "indicator",
    .nuts_level = 0,
    type_id = inds,
    # country = "ES",
    .source_id = "EVASTUR",
    from_date = "2013-01-01",
    to_date = "2022-12-31"
  )

  tindicators <- reactive({
    suppressMessages({
      get_transformed_indicators(
        dfind,
        scaling_method = "zscore",
        scaling_type = "time",
        refvalueq = NULL,
        geo_total = "WLD"
      )
    })
  })
  
  cindicators <- reactive({
    compute_composite_indicator(
      tindicators(),
      selected_source = "EVASTUR"
    ) |> filter(total)
  }) 
  predicted_indicators <- reactive({
    predict_indicators(
      # tindicators |> filter(geo_id == "ESP")
      tindicators() |> filter(total)
    )
  })

  ui <- fluidPage(
    intervention_controls_ui("intervention_controls1", translator),
    verbatimTextOutput("out1"),
    verbatimTextOutput("out2"),
    reactableOutput("table")
  )

  server <- function(input, output, session) {
    intervention_controls_server1 <- intervention_controls_server(
      "intervention_controls1",
      translator_r,
      .datanpred = cindicators,
      .datapred = predicted_indicators,
      .dataind = tindicators,
      source = reactive({
        source
      }),
      .epsilon = reactive({
        .epsilon
      }),
      geo = reactive(geo),
      .scaling_method = reactive(scaling_method)
    )

    output$out1 <- renderPrint({intervention_controls_server1$res_intervention_step1()})
    output$out2 <- renderPrint({intervention_controls_server1$res_intervention_step2()})
    output$table <- renderReactable({
      get_intervention_table(
        .data = intervention_controls_server1$res_intervention_step2(),
        i18n = translator
      )
    })
  }

  shinyApp(ui, server, options = list(port = 3838))
}
