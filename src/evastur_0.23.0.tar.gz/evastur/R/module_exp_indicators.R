exp_indicators_ui <- function(id) {
  ns <- NS(id)
  tagList(
    reactableOutput(ns("rt_indicators"))
  )
}

exp_indicators_server <- function(id, i18n) {
  moduleServer(
    id,
    function(input, output, session) {
      df_indicators <- reactive({
        lan <- i18n()$get_translation_language()
        con2 |> 
          tbl("v_indicators_without_dim") |> 
          filter(indicator_lang == lan) |> 
          select(indicator_name,
                 indicator_label,
                 indicator_description,
                 indicator_id) |>
          mutate(indicator_id2 = indicator_id, .before = 1) |> 
          collect() 
      })
      output$rt_indicators <- renderReactable({
        df_indicators() |> 
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables" ,
            columns = list(
              indicator_id2 = colDef(
                name = "",
                filterable = TRUE,
                maxWidth = 200
              ),
              ## indicator_name ----
              indicator_name = colDef(
                name = i18n()$t("Indicador"),
                filterable = TRUE,
                minWidth = 450
              ),
              ## indicator_id ----
              indicator_id = colDef(
                name = "",
                minWidth = 30,
                sortable = FALSE,
                html = TRUE,
                cell = function(value){
                  rt_doc_button(nav_id = "btn_ind_doc",
                                nav_value = value, i18n())
                }
              ),
              ## indicator_label ----
              indicator_label = colDef(
                show = FALSE),
              indicator_description = colDef(
                name = "",
                sortable = FALSE,
                html = TRUE,
                maxWidth = 30,
                cell = function(value, index){
                  as.character(tooltip(bs_icon("info-circle"),
                                       paste0(df_indicators()$indicator_label[index],
                                              ": ",
                                              value)))
                }
              )
            )
          )
      })
    }
  )
}


exp_indicators_app <- function(){
  
  library(shiny)
  devtools::load_all()
  translator <- getOption("evastur.translator")
  
  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    exp_indicators_ui("ind1")
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    exp_indicators_server("ind1", i18n = i18n)
  }
  
  shinyApp(ui, server, options = list(port = 3800))
  
}

# exp_indicators_app()