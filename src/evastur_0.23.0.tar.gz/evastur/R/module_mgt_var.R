## Module to manage customized variables

## Module UI ----
mgt_var_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(
      class = "search-input-cont",
      uiOutput(ns("ui_si_label")),
      searchInput(
        inputId = ns("si_new_variable"),
        label = NULL,
        placeholder = "",
        btnSearch = icon("search"),
        btnReset = icon("remove"),
        width = "100%"
      )
    ),
    accordion(
      id = ns("ac_varform"),
      open = FALSE,
      multiple = FALSE,
      accordion_panel(
        title = textOutput(ns("txt_newvariable")),
        value = ns("acp_varform"),
        mgt_var_form_ui(ns("mgt_var_form_ui_new"))
      ),
      accordion_panel(
        title = textOutput(ns("txt_existingvariables")),
        value = ns("acp_varfound"),
        uiOutput(ns("ui_card_var"))
      )
    )
  )
}

## Module server ----
mgt_var_server <- function(id, i18n, .source, dim, onlycustom, selected_custom_var = reactive(NULL)) {
  moduleServer(
    id,
    function(input, output, session) {
      ## [M] variable form ----
      form_result <- mgt_var_form_server("mgt_var_form_ui_new", i18n, selected_custom_var)

      ## [O] ui_card_var ----
      output$ui_card_var <- renderUI({
        req(df_matching_vars())
        card(
          reactableOutput(session$ns("rt_variables"))
        )
      })

      ## [O] Open accordion when a custom variable is selected ----
      observeEvent(selected_custom_var(), {
        req(selected_custom_var(), selected_custom_var() != "_NONE_")
        accordion_panel_set("ac_varform", values = session$ns("acp_varform"))
      }, ignoreInit = TRUE)
      ## ui_si_label - Render translated label with tooltip ----
      output$ui_si_label <- renderUI({
        lan <- i18n()$get_translation_language()
        span(
          cleanHTML(i18n()$t("Buscar variables")),
          tooltip(
            bs_icon("info-circle"),
            title = "info",
            get_text("info_new_variable", lan)
          ),
          options = list(trigger = "hover")
        )
      })

      ## update_si_new_variable - Update search input placeholder ----
      observe({
        updateSearchInput(
          session = session,
          inputId = "si_new_variable",
          placeholder = cleanHTML(
            i18n()$t("Busque una variable existente o cree una nueva")
          )
        )
      })

      ## txt_newvariable ----

      output$txt_newvariable <- renderText({
        i18n()$t("Crear/Modificar variable")
      })

      ## txt_existingvariables ----

      output$txt_existingvariables <- renderText({
        i18n()$t("Variables disponibles")
      })

      ## [RV] search_performed ----
      search_performed <- reactiveVal(FALSE)

      ## [RV] df_matching_vars ----
      df_matching_vars <- reactiveVal(NULL)

      ## [F] fetch_matching_vars ----
      fetch_matching_vars <- function() {
        req(dim())
        req(!is.null(onlycustom()))

        lan <- i18n()$get_translation_language()
        search_term <- input$si_new_variable

        tbl0 <- tbl(con2, "lt_variables") |>
          filter(variable_lang == lan)

        if (nzchar(search_term)) {
          # Escape wildcards % and _ to treat them as literal characters
          escaped_term <- gsub("([%_])", "\\\\\\1", search_term)
          pattern <- paste0("%", escaped_term, "%")
          safe_pattern <- dbQuoteString(con2, pattern)
          tbl0 <- tbl0 |>
            filter(sql(paste0("variable_name ILIKE ", safe_pattern, " ESCAPE '\\' OR variable_id ILIKE ", safe_pattern, " ESCAPE '\\'")))
        }

        tbl0 <- tbl0 |>
          inner_join(
            tbl(con2, "dt_variables") |>
              select(variable_id),
            by = "variable_id"
          ) |>
          select(
            variable_id,
            variable_name,
            variable_description) |>
          mutate(
            doc_id = variable_id
          )

        if (onlycustom()) {
          tbl0 <- tbl0 |>
            filter(variable_id %like% "VCUS%")
        }

        varsdim <- vars_in_dim(dim(), .source())
        df <- tbl0 |>
          filter(variable_id %in% varsdim) |>
          collect()

        return(df)
      }

      observeEvent(input$si_new_variable_search, {
        search_performed(TRUE)
        accordion_panel_set("ac_varform", values = session$ns("acp_varfound"))
        df_matching_vars(fetch_matching_vars())
      })

      observeEvent(input$si_new_variable_reset, {
        search_performed(FALSE)
        df_matching_vars(NULL)
        accordion_panel_close("ac_varform", session$ns("acp_varfound"))
      })

      # Update results when filters change, but only if search has been performed
      observe({
        req(search_performed())
        # Triggers
        dim(); onlycustom(); form_result$last_modified()
        
        df_matching_vars(fetch_matching_vars())
      })
      # ## [O] ui_ab_new_var ----
      # output$ui_ab_new_var <- renderUI({
      #   actionButton(inputId = session$ns("ab_new_var"),
      #                label = i18n()$t("Crear nueva"),
      #                disabled = TRUE)
      # })

      ## rt_variables - Reactable matching vars ----
      output$rt_variables <- renderReactable({
        df <- df_matching_vars()
        if (is.null(df)) return(NULL)
        df |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            columns = list(
              variable_description = colDef(
                name = "",
                html = TRUE,
                minWidth = 30,
                cell = function(value, index) {
                  as.character(tooltip(bs_icon("info-circle"), value))
                }
              ),
              variable_id = colDef(
                name = i18n()$t("Código"),
                minWidth = 100,
                filterable = TRUE
              ),
              variable_name = colDef(
                name = i18n()$t("Nombre"),
                minWidth = 400
              ),
              doc_id = colDef(
                name = "",
                minWidth = 30,
                sortable = FALSE,
                html = TRUE,
                cell = function(value, index) {
                  rt_doc_button(
                    nav_id = "btn_var_doc",
                    nav_value = value,
                    i18n()
                  )
                }
              )
            )
          )
      })

      ## Return ----
      return(
        list(
          last_modified = form_result$last_modified
        )
      )
    }
  )
}

## Module app ----

mgt_var_app <- function() {
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  library(reactable)
  translator <- getOption("evastur.translator")

  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    textInput("ti_source", "Source", "EVASTUR"),
    checkboxInput("cbi_onlycustom", "Only custom"),
    dim_selector_buttons_ui("dimsel1"),
    mgt_var_ui("var1"),
  )

  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    dim_selected <- dim_selector_buttons_server(
      "dimsel1",
      i18n,
      reactive({
        input$ti_source
      })
    )

    mgt_var_server(
      "var1",
      i18n,
      reactive({
        input$ti_source
      }),
      dim_selected,
      reactive({
        input$cbi_onlycustom
      })
    )
  }

  shinyApp(ui, server, options = list(port = 3800))
}

## Run app ----
# mgt_var_app()
