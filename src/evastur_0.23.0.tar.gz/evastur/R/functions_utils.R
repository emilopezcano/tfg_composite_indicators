## Utility functions

#' Clean up the HTML by removing tags.
#' 
#' This function cleans all html tags from strings. It was needed to clean translations from shiny.i18n in some contexts.
#'
#'
#' @param htmlString String with html tags
#'
#' @return A text string without the HTML tags.
#'
#' @author Emilio L. Cano
#' @export
#' @examples
#' cleanHTML("<title>Example to clean</title>")
cleanHTML <- function(htmlString) {
  return(gsub("<.*?>", "", htmlString))
}

#' Get traffic lights colour for IDA
#' 
#' Gets a colour to be used when formatting source tables.
#'
#' @param x ida_id
#'
#' @returns RGB colour
#' @export
#' 
#' @author Emilio L. Cano
#'
#' @examples
#' get_ida_col(1)
get_ida_col <- function(x){
  if(is.na(x)){
    return("#FFF")
  }
  if(x == 1){
    "#B81D13"
  } else if (x == 2){
    "#EFB700"
  } else if (x == 3){
    "#008450"
  } else{
    "#FFF"
  }
}

#' Convert R color to hex for HTML
#' 
#' This function takes an R valid colour name and returns its HEX value for using it in HTML.
#' 
#' @note
#' Not used anymore but the function is kept because it might be usefuel later.
#'
#' @param x R colour name
#' @param alpha Include alpha passed directly to `col2rgb()`
#'
#' @returns A character HTML hex colour
#' @export
#' 
#' @author Emilio L. Cano
#' @source https://stackoverflow.com/questions/70121336/hexadecimal-codes-for-r-built-in-colours
#'
#' @examples
#' col2hex("red")
#' col2hex(c("red", "blue"))
col2hex <- function(x, alpha = FALSE) {
  args <- as.data.frame(t(col2rgb(x, alpha = alpha)))
  args <- c(args, list(names = names(x), maxColorValue = 255))
  do.call(rgb, args)
}

#' Check if the current user can edit an item
#'
#' Evaluates ShinyProxy identity variables to determine whether the current
#' user has permission to edit a given record.
#'
#' @details
#' Permission is granted if:
#' * ShinyProxy variables are **not** set (local/development mode) – all users
#'   can edit, or
#' * The user belongs to the admin group configured in
#'   `getOption("evastur.admin_group")`, or
#' * The `SHINYPROXY_USERNAME` environment variable matches `user_cre`.
#'
#' @param user_cre Character. The username stored in the `user_cre` column of
#'   the relevant database record.
#'
#' @returns `TRUE` if the user may edit the item, `FALSE` otherwise.
#' @export
#'
#' @examples
#' can_edit_item("alice")
can_edit_item <- function(user_cre) {
  username <- Sys.getenv("SHINYPROXY_USERNAME")
  if (username == "") {
    return(TRUE)
  }
  usergroups <- Sys.getenv("SHINYPROXY_USERGROUPS")
  admin_group <- getOption("evastur.admin_group", default = "")
  is_admin <- nchar(admin_group) > 0 &&
    grepl(admin_group, usergroups, fixed = TRUE)
  is_owner <- username == user_cre
  is_admin || is_owner
}
