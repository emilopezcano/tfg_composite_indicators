## Module to manage custom geographic groups

## Module UI ----
mgt_geo_ui <- function(id) {
  ns <- NS(id)
  tagList(
    div(
      class = "search-input-cont",
      uiOutput(ns("ui_si_label")),
      searchInput(
        inputId = ns("si_new_geo"),
        label = NULL,
        placeholder = "",
        btnSearch = icon("search"),
        btnReset = icon("remove"),
        width = "100%"
      )
    ),
    accordion(
      id = ns("ac_geoform"),
      open = FALSE,
      multiple = FALSE,
      accordion_panel(
        title = textOutput(ns("txt_newgeogroup")),
        value = ns("acp_geoform"),
        mgt_geo_form_ui(ns("mgt_geo_form_ui_new"))
      ),
      accordion_panel(
        title = textOutput(ns("txt_existinggeogroups")),
        value = ns("acp_geofound"),
        uiOutput(ns("ui_card_geo"))
      )
    )
  )
}

## Module server ----
mgt_geo_server <- function(id, i18n, onlycustom, selected_custom_area = reactive(NULL)) {
  moduleServer(
    id,
    function(input, output, session) {

      ## [M] geo form ----
      form_result <- mgt_geo_form_server("mgt_geo_form_ui_new", i18n, selected_custom_area)
      
      ## [O] ui_card_geo ----
      output$ui_card_geo <- renderUI({
        req(df_geo_groups())
        card(
          reactableOutput(session$ns("rt_geo_groups"))
        )
      })

      ## [O] Open accordion on selection ----
      observeEvent(selected_custom_area(), {
        req(selected_custom_area(), selected_custom_area() != "_NONE_")
        accordion_panel_set("ac_geoform", values = session$ns("acp_geoform"))
      }, ignoreInit = TRUE)
      
      ## ui_si_label - Render translated label with tooltip ----
      output$ui_si_label <- renderUI({
        lan <- i18n()$get_translation_language()
        span(
          cleanHTML(i18n()$t("Buscar áreas geográficas")),
          tooltip(
            bs_icon("info-circle"),
            title = "info",
            get_text("info_search_geo", lan)
          ),
          options = list(trigger = "hover")
        )
      })

      ## update_si_new_geo - Update search input placeholder ----
      observe({
        updateSearchInput(
          session = session,
          inputId = "si_new_geo",
          placeholder = cleanHTML(
            i18n()$t("Busque un área geográfica existente o cree una nueva")
          )
        )
      })
      
      ## txt_newgeogroup ----
      output$txt_newgeogroup <- renderText({
        i18n()$t("Crear/Modificar áreas geográficas")
      })
      
      ## txt_existinggeogroups ----
      output$txt_existinggeogroups <- renderText({
        i18n()$t("Áreas geográficas disponibles")
      })
      
      ## [RV] search_performed ----
      search_performed <- reactiveVal(FALSE)

      ## [RV] df_geo_groups ----
      df_geo_groups <- reactiveVal(NULL)

      ## [F] fetch_geo_groups ----
      fetch_geo_groups <- function() {
        req(!is.null(onlycustom()))

        lan <- i18n()$get_translation_language()
        search_term <- input$si_new_geo

        tbl0 <- tbl(con2, "lt_geo") |>
          filter(geo_lang == lan)

        if (nzchar(search_term)) {
          # Escape wildcards % and _ to treat them as literal characters
          escaped_term <- gsub("([%_])", "\\\\\\1", search_term)
          pattern <- paste0("%", escaped_term, "%")
          safe_pattern <- dbQuoteString(con2, pattern)
          tbl0 <- tbl0 |>
            filter(sql(paste0("geo_name ILIKE ", safe_pattern, " ESCAPE '\\' OR geo_id ILIKE ", safe_pattern, " ESCAPE '\\'")))
        }

        tbl0 <- tbl0 |>
          select(geo_id, geo_name, geo_label, geo_description)

        if (onlycustom()) {
          tbl0 <- tbl0 |>
            filter(geo_id %like% "GCUS%")
        }

        df <- tbl0 |> collect()
        return(df)
      }

      observeEvent(input$si_new_geo_search, {
        search_performed(TRUE)
        accordion_panel_set("ac_geoform", values = session$ns("acp_geofound"))
        df_geo_groups(fetch_geo_groups())
      })

      observeEvent(input$si_new_geo_reset, {
        search_performed(FALSE)
        df_geo_groups(NULL)
        accordion_panel_close("ac_geoform", session$ns("acp_geofound"))
      })

      # Update results when filters change, but only if search has been performed
      observe({
        req(search_performed())
        # Triggers
        onlycustom(); form_result$last_modified()
        
        df_geo_groups(fetch_geo_groups())
      })
      
      ## rt_geo_groups - Reactable geo groups ----
      output$rt_geo_groups <- renderReactable({
        df <- df_geo_groups()
        if (is.null(df)) return(NULL)
        geo_df <- df
        reactable(
          geo_df,
          language = get_rt_lang(i18n()$get_translation_language()),
          class = "exploration-tables",
          columns = list(
            geo_description = colDef(
              name = "",
              html = TRUE,
              minWidth = 30,
              cell = function(value, index) {
                label <- geo_df$geo_label[index]

                if (!is.na(value) && !is.na(label) && value != "" && value != label) {
                  as.character(tooltip(bs_icon("info-circle"), value))
                } else {
                  ""
                }
              }
            ),
            geo_id = colDef(
              name = i18n()$t("Código"),
              minWidth = 100,
              filterable = TRUE
            ),
            geo_name = colDef(
              name = i18n()$t("Nombre"),
              minWidth = 300
            ),
            geo_label = colDef(
              name = i18n()$t("Etiqueta"),
              minWidth = 150
            )
          )
        )
      })
      
      ## Return list ----
      return(
        list(
          last_modified = form_result$last_modified
        )
      )
      
    }
  )
}

## Module app ----

mgt_geo_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  library(reactable)
  translator <- getOption("evastur.translator")
  
  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    checkboxInput("cbi_onlycustom", "Only custom", value = TRUE),
    mgt_geo_ui("geo1"),
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    mgt_geo_server("geo1", i18n, reactive({input$cbi_onlycustom}), reactive(NULL))
  }
  
  shinyApp(ui, server)
  
}

## Run app ----
# mgt_geo_app()
