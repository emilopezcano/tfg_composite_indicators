#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import shiny
#' @import bslib
#' @import bsicons
#' @import shinyWidgets
#' @import dplyr
#' @import leaflet
#' @import sf
#' @import ggplot2
#' @import tidyr
#' @import shiny.i18n
#' @import SDGdetector
#' @import RColorBrewer
#' @import readr
#' @import readxl
#' @import DBI
#' @import mapSpain
#' @import gt
#' @import gfonts
#' @import lubridate
#' @import stringr
#' @import shinyBS
#' @import reactable
#' @import reshape2
#' @importFrom plotly add_text
#' @importFrom plotly layout
#' @importFrom plotly plotlyOutput
#' @importFrom plotly renderPlotly
#' @importFrom plotly event_data
#' @importFrom plotly ggplotly
#' @importFrom plotly style
#' @importFrom purrr map2
#' @importFrom purrr map
#' @importFrom purrr map_chr
#' @importFrom purrr map_df
#' @importFrom purrr map_lgl
#' @importFrom purrr insistently
#' @importFrom purrr rate_delay
#' @importFrom grafify scale_colour_grafify
#' @importFrom forecast forecast
#' @importFrom rvest read_html
#' @importFrom rvest html_nodes
#' @importFrom rvest html_node
#' @importFrom rvest html_text
#' @importFrom rvest html_text2
#' @importFrom rvest html_attr
#' @importFrom rvest html_element
#' @import ompr
#' @import ompr.roi
#' @import ROI.plugin.symphony
#' @import shinyvalidate
#' @importFrom selenider selenider_session
#' @importFrom selenider open_url
#' @importFrom selenider s
#' @importFrom selenider elem_attr
#' @importFrom selenider find_element
#' @importFrom selenider elem_text
#' @importFrom selenider close_session
#' @importFrom selenider chromote_options
#' @importFrom glue glue
#' @importFrom httr GET http_error http_status content status_code headers content
#' @importFrom archive archive_extract
## usethis namespace: end
NULL
