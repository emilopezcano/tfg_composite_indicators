## Module for the columns of a new indicator

## Module UI ----
mgt_ind_form_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_columns(
      col_widths = c(12, 4, 4, 4, 12),
      card(
        uiOutput(ns("ui_ti_indicator_name"))
      ),
      card(
        uiOutput(ns("ui_ti_indicator_label")),
        uiOutput(ns("ui_pi_dimension_id")),
        uiOutput(ns("ui_pi_subdimension_id"))
      ),
      card(
        uiOutput(ns("ui_pi_indicator_direction")),
        uiOutput(ns("ui_tai_indicator_des"))
        
        # numericInput(session$ns("ni_indicator_order"),
        #              label = i18n()$t("Orden"),
        #              value = NULL),
      ),
      card(
        uiOutput(ns("ui_ni_indicator_weight")),
        uiOutput(ns("ui_tai_indicator_weight_basis"))
        
      ),
      card(
        layout_columns(
          col_widths = c(4, 8),
          tagList(
            uiOutput(ns("ui_pi_variables")),
            uiOutput(ns("ui_tai_indicator_formula"))
          ),
          tagList(
            uiOutput(ns("ui_ab_copy_formula")),
            reactableOutput(ns("rt_selected_vars"))
          )
        )
      ),
      uiOutput(ns("ui_ab_save_ind"))
    )
    
    
  )
}

## Module server ----
mgt_ind_form_server <- function(id, i18n, .source, selected_custom_ind = reactive(NULL)) {
  moduleServer(
    id,
    function(input, output, session) {

      last_modified <- reactiveVal(0)

      ## Validation ----
      iv2 <- InputValidator$new()
      iv2$add_rule("ti_indicator_name",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("ti_indicator_label",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("tai_indicator_des",
                   sv_required(message = "*"
                               # message = i18n()$t("Obligatorio")
                   )
      )
      iv2$add_rule("pi_dimension_id",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("pi_subdimension_id",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("ni_indicator_weight",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("tai_indicator_weight_basis",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("pi_variables",
                   sv_required(message = "*"
                   )
      )
      iv2$add_rule("tai_indicator_formula",
                   sv_required(message = "*"
                   )
      )
      iv2$enable()

      ## [R] is_edit_mode ----
      is_edit_mode <- reactive({
        sel <- selected_custom_ind()
        !is.null(sel) && nchar(sel) > 0 && sel != "_NONE_"
      })

      ## [RV] new_id ----
      new_id <- reactiveVal({
        next_id("indicator", "ICUS")
      })

      ## [RVs] desired_values – holds pre-fill data for create/edit ----
      desired_values <- reactiveValues(
        name         = "",
        label        = "",
        description  = "",
        direction    = "+",
        weight       = 1,
        weight_basis = "",
        formula      = "",
        dim_id       = NULL,
        subdim_id    = NULL,
        var_ids      = character(0)
      )

      ## [RV] item_user_cre ----
      item_user_cre <- reactiveVal("")

      ## [O] Load or reset form when selection changes ----
      observeEvent(selected_custom_ind(), {
        sel <- selected_custom_ind()
        if (!is.null(sel) && nchar(sel) > 0 && sel != "_NONE_") {
          # Edit mode: load existing data
          new_id(sel)
          lan <- i18n()$get_translation_language()
          tryCatch({
            lt_row <- con2 |>
              tbl("lt_indicators") |>
              filter(indicator_id == !!sel, indicator_lang == lan) |>
              collect()
            dt_row <- con2 |>
              tbl("dt_indicators") |>
              filter(indicator_id == !!sel) |>
              select(indicator_id, indicator_formula, indicator_direction,
                     indicator_weight, indicator_weight_basis, user_cre) |>
              collect()
            bt_subdim <- con2 |>
              tbl("bt_indicator_subdimension") |>
              filter(indicator_id == !!sel, source_id == !!.source()) |>
              select(dimension_id, subdimension_id) |>
              collect()
            bt_vars <- con2 |>
              tbl("bt_indicator_variable") |>
              filter(indicator_id == !!sel) |>
              pull(variable_id)

            if (nrow(lt_row) > 0) {
              desired_values$name  <- lt_row$indicator_name[1]
              desired_values$label <- lt_row$indicator_label[1]
              desired_values$description   <- lt_row$indicator_description[1]
            }
            if (nrow(dt_row) > 0) {
              desired_values$direction    <- dt_row$indicator_direction[1]
              desired_values$weight       <- dt_row$indicator_weight[1]
              desired_values$weight_basis <- ifelse(
                is.na(dt_row$indicator_weight_basis[1]),
                "",
                dt_row$indicator_weight_basis[1]
              )
              desired_values$formula <- ifelse(
                is.na(dt_row$indicator_formula[1]),
                "",
                dt_row$indicator_formula[1]
              )
              item_user_cre(dt_row$user_cre[1])
            } else {
              item_user_cre("")
            }
            if (nrow(bt_subdim) > 0) {
              desired_values$dim_id   <- bt_subdim$dimension_id[1]
              desired_values$subdim_id <- bt_subdim$subdimension_id[1]
            } else {
              desired_values$dim_id    <- NULL
              desired_values$subdim_id <- NULL
            }
            desired_values$var_ids <- bt_vars
          }, error = function(e) {
            showNotification(paste0(i18n()$t("Error cargando indicador"), ": ", e$message),
                             type = "error")
          })
        } else {
          # Create mode: reset to defaults
          new_id(next_id("indicator", "ICUS"))
          desired_values$name         <- ""
          desired_values$label        <- ""
          desired_values$description          <- ""
          desired_values$direction    <- "+"
          desired_values$weight       <- 1
          desired_values$weight_basis <- ""
          desired_values$formula      <- ""
          desired_values$dim_id       <- NULL
          desired_values$subdim_id    <- NULL
          desired_values$var_ids      <- character(0)
          item_user_cre("")
        }
      }, ignoreNULL = FALSE)


      ## RENDER UI ----

      ### ti_indicator_name ----
      output$ui_ti_indicator_name <- renderUI({
        req(new_id())
        textInputIcon(session$ns("ti_indicator_name"),
                      width = "100%",
                      label = span(cleanHTML(i18n()$t("Nombre")),
                                   tooltip(bs_icon("info-circle"),
                                           title = "info",
                                           i18n()$t("Nombre completo (una frase)")
                                   ),
                                   options = list(trigger = "hover")
                      ),
                      value = desired_values$name,
                      icon = list(NULL, icon("at"))
        )
      })
      
      ### ti_indicator_label ----
      output$ui_ti_indicator_label <- renderUI({
        tagList(
          p(
            if (is_edit_mode()) i18n()$t("Editar") else i18n()$t("Crear"),
            ": ",
            strong(new_id())
          ),
          textInputIcon(session$ns("ti_indicator_label"),
                        width = "100%",
                        label = span(cleanHTML(i18n()$t("Etiqueta")),
                                     tooltip(bs_icon("info-circle"),
                                             title = "info",
                                             i18n()$t("Nombre corto (una o pocas palabras)")
                                     ),
                                     options = list(trigger = "hover")
                        ),
                        value = desired_values$label,
                        icon = list(NULL, icon("tag")))
        )
      })
      
      ### pi_dimension_id ----
      output$ui_pi_dimension_id <- renderUI({
        req(new_id())
        dims_choices <- available_dims() |>
          add_row(dimension_id = "",
                  dimension_label = cleanHTML(i18n()$t("Selecciona una")),
                  .before = 1)
        pickerInput(session$ns("pi_dimension_id"),
                    width = "100%",
                    label = i18n()$t("Dimensión"),
                    setNames(dims_choices$dimension_id,
                             dims_choices$dimension_label),
                    selected = desired_values$dim_id,
                    options = list(container = "body"))
      })
      
      ### pi_subdimension_id ----
      output$ui_pi_subdimension_id <- renderUI({
        req(new_id())
        pickerInput(session$ns("pi_subdimension_id"),
                    width = "100%",
                    label = i18n()$t("Subdimensión"),
                    setNames(subdims()$subdimension_id,
                             subdims()$subdimension_label),
                    selected = desired_values$subdim_id,
                    options = list(container = "body"))
      })
      
      ### pi_indicator_direction ----
      output$ui_pi_indicator_direction <- renderUI({
        req(new_id())
        pickerInput(session$ns("pi_indicator_direction"),
                    width = "100%",
                    label = span(cleanHTML(i18n()$t("Sentido")),
                                 tooltip(bs_icon("info-circle"),
                                         title = "info",
                                         i18n()$t("Sentido del indicador: + si a mayor valor, más sostenible, y - al contrario")
                                 )),
                    choices = c("+", "-"),
                    selected = desired_values$direction)
      })
      
      ### pi_tai_indicator_des ----
      output$ui_tai_indicator_des <- renderUI({
        req(new_id())
        textAreaInput(session$ns("tai_indicator_des"),
                      label = span(cleanHTML(i18n()$t("Descripción")),
                                   tooltip(bs_icon("info-circle"),
                                           title = "info",
                                           i18n()$t("Descripción completa (un párrafo)")
                                   ),
                                   options = list(trigger = "hover")
                      ),
                      value = desired_values$description,
                      height = "170px",
                      width = "100%")

      })
      
      ### ni_indicator_weight ----
      output$ui_ni_indicator_weight <- renderUI({
        req(new_id())
        numericInputIcon(session$ns("ni_indicator_weight"),
                         width = "100%",
                         label = span(cleanHTML(i18n()$t("Peso")),
                                      tooltip(bs_icon("info-circle"),
                                              title = "info",
                                              i18n()$t("Peso del indicador en el cálculo del indicador compuesto de la dimensión")
                                      ),
                                      options = list(trigger = "hover")
                         ),
                         value = desired_values$weight,
                         icon = list(NULL, icon("weight-hanging")))

      })
      
      ### tai_indicator_weight_basis ----
      output$ui_tai_indicator_weight_basis <- renderUI({
        req(new_id())
        textAreaInput(session$ns("tai_indicator_weight_basis"),
                      label = span(cleanHTML(i18n()$t("Justificación peso")),
                                   tooltip(bs_icon("info-circle"),
                                           title = "info",
                                           i18n()$t("Explicación que justifique la asignación del peso del indicador en el indicador compuesto de su dimensión")
                                   ),
                                   options = list(trigger = "hover")
                      ),
                      height = "180px",
                      width = "100%")
      })

      ### pi_variables ----
      output$ui_pi_variables <- renderUI({
        req(new_id())
        pickerInput(session$ns("pi_variables"),
                    label = span(cleanHTML(i18n()$t("Variables involucradas")),
                                 tooltip(bs_icon("info-circle"),
                                         title = "info",
                                         i18n()$t("Variables que intervienen en el cálculo del indicador. Si el indicador coincide con el valor de una variable, indicar solo esa variable.")
                                 ),
                                 options = list(trigger = "hover")
                    ),
                    multiple = TRUE,
                    choices = setNames(available_vars()$variable_id,
                                       available_vars()$variable_label),
                    selected = desired_values$var_ids,
                    options = pickerOptions(title = i18n()$t("Seleccione"),
                                            liveSearch = TRUE,
                                            liveSearchNormalize = TRUE,
                                            liveSearchPlaceholder = i18n()$t("Buscar"),
                                            noneSelectedText = i18n()$t("Nada seleccionado"),
                                            container = "body"
                    )
        )
      })

      ### tai_indicator_formula ----
      output$ui_tai_indicator_formula <- renderUI({
        req(new_id())
        textAreaInput(session$ns("tai_indicator_formula"),
                      label = span(cleanHTML(i18n()$t("Fórmula")),
                                   tooltip(bs_icon("info-circle"),
                                           title = "info",
                                           i18n()$t("Fórmula para calcular el indicador con las variables involucradas")
                                   ),
                                   options = list(trigger = "hover")
                      ),
                      value = desired_values$formula
        )})

      ### rt_selected_vars ----
      output$rt_selected_vars <- renderReactable({
        req(new_id())
        req(input$pi_variables)
        reactable(selected_vars(),
                  language = get_rt_lang(i18n()$get_translation_language()),
                  class = "exploration-tables",
                  columns = list(
                    variable_id = colDef(
                      name = i18n()$t("Código"),
                      maxWidth = 150,
                    ),
                    variable_name = colDef(
                      name = i18n()$t("Nombre")
                    )
                  )
        )

      })

      ### ab_copy_formula ----
      output$ui_ab_copy_formula <- renderUI({
        req(input$pi_variables)
        actionButton(session$ns("ab_copy_formula"),
                     label = i18n()$t("Copiar a fórmula"),
                     icon = icon("copy"))

      })

      ### save_button_label ----
      output$save_button_label <- renderUI({
        if (is_edit_mode()) i18n()$t("Actualizar") else i18n()$t("Crear")
      })

      ### ab_save_ind ----
      output$ui_ab_save_ind <- renderUI({
        div(
          style = "display: flex; gap: 10px; width: 100%; align-items: stretch;",
          div(
            style = "flex: 70; min-width: 0;",
            actionButton(
              session$ns("ab_save_ind"),
              label = uiOutput(session$ns("save_button_label"), inline = TRUE),
              icon = if (is_edit_mode()) icon("floppy-disk") else icon("plus"),
              class = "btn-light",
              width = "100%"
            )
          ),
          conditionalPanel(
            condition = "output.show_delete",
            ns = session$ns,
            style = "flex: 30; min-width: 0; display: flex;",
            actionButton(
              session$ns("ab_delete_ind"),
              label = uiOutput(session$ns("delete_button_label"), inline = TRUE),
              icon = icon("trash-can"),
              width = "100%",
              class = "btn-danger"
            )
          )
        )
      })

      ## [O] delete_button_label ----
      output$delete_button_label <- renderUI({
        i18n()$t("Eliminar")
      })

      ## [O] show_delete ----
      output$show_delete <- reactive({ is_edit_mode() })
      outputOptions(output, "show_delete", suspendWhenHidden = FALSE)

      ## [R] Available variables ----
      available_vars <- reactive({
        res <- tryCatch({
          varsdim <- vars_in_dim("GLOBAL", .source())
          con2 |>
            tbl("v_variables_select") |>
            filter(variable_lang == i18n()$get_translation_language(),
                   variable_id %in% varsdim) |>
            collect()
        },
        error = function(e) {
          showNotification(paste0(
            cleanHTML(i18n()$t("Error al recuperar las variables disponibles. Intenta recargar el dashboard y probar de nuevo")),
            " - ",
            e),
            type = "error",
            duration = NULL)
          return(NULL)}
        
        )
        return(res)
      })
      
      ## [R] Available dimensions ----
      available_dims <- reactive({
        res <- tryCatch({
          get_dims(lan = i18n()$get_translation_language(),
                   source = .source(),
                   global = FALSE)
        },
        error = function(e) {
          showNotification(paste0(
            cleanHTML(i18n()$t("Error al recuperar las dimensiones disponibles. Intenta recargar el dashboard y probar de nuevo")),
            " - ",
            e),
            type = "error",
            duration = NULL)
          return(NULL)}
        )
        return(res)
      })
      
      ## [R] subdims ----
      subdims <- reactive({con2 |>
          tbl("lt_subdimensions") |>
          filter(dimension_id == input$pi_dimension_id,
                 subdimension_lang == i18n()$get_translation_language()) |>
          select(subdimension_id, subdimension_label) |>
          collect() |>
          add_row(subdimension_id = "",
                  subdimension_label = cleanHTML(i18n()$t("Selecciona una")),
                  .before = 1)
      })
      
      ## [R] selected_vars ----
      
      selected_vars <- reactive({
        available_vars() |>
          filter(variable_id %in% input$pi_variables) |>
          select(variable_id, variable_name) |>
          collect()
      })
      
      
      
      
      ## [O] ui_ab_copy_formula ----
      observeEvent(input$ab_copy_formula, {
        updateTextAreaInput(session, "tai_indicator_formula",
                            value = paste(input$pi_variables, collapse = " ? "))
      })
      
      
      ## [O] ab_save_ind ----
      observeEvent(input$ab_save_ind, {
        if (!iv2$is_valid()) {
          showNotification(i18n()$t("Datos incompletos"),
                           type = "error")
        } else {
          # Permission check
          if (!can_edit_item(item_user_cre())) {
            showNotification(i18n()$t("No tienes permisos para editar este elemento"),
                             type = "error")
            return(NULL)
          }

          chr_source <- .source()
          current_user <- Sys.getenv("SHINYPROXY_USERNAME", unset = Sys.info()[["user"]])

          if (is_edit_mode()) {
            # UPDATE existing indicator
            lan <- i18n()$get_translation_language()
            tryCatch({
              tbl(con2, "lt_indicators") |>
                rows_update(
                  tibble(
                    indicator_id          = new_id(),
                    indicator_lang        = lan,
                    indicator_name        = input$ti_indicator_name,
                    indicator_label       = input$ti_indicator_label,
                    indicator_description = input$tai_indicator_des
                  ),
                  by = c("indicator_id", "indicator_lang"),
                  in_place = TRUE,
                  copy = TRUE,
                  unmatched = "ignore"
                )
              tbl(con2, "dt_indicators") |>
                rows_update(
                  tibble(
                    indicator_id           = new_id(),
                    indicator_formula      = input$tai_indicator_formula,
                    indicator_direction    = input$pi_indicator_direction,
                    indicator_weight       = input$ni_indicator_weight,
                    indicator_weight_basis = input$tai_indicator_weight_basis,
                    indicator_weight_user  = current_user
                  ),
                  by = "indicator_id",
                  in_place = TRUE,
                  copy = TRUE,
                  unmatched = "ignore"
                )
              # Update subdimension assignment (delete then insert for composite PK safety)
              tbl(con2, "bt_indicator_subdimension") |>
                rows_delete(
                  tibble(indicator_id = new_id(), source_id = chr_source),
                  by = c("indicator_id", "source_id"),
                  unmatched = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              tbl(con2, "bt_indicator_subdimension") |>
                rows_insert(
                  tibble(
                    indicator_id    = new_id(),
                    source_id       = chr_source,
                    dimension_id    = input$pi_dimension_id,
                    subdimension_id = input$pi_subdimension_id
                  ),
                  by = c("indicator_id", "dimension_id", "subdimension_id", "source_id"),
                  conflict = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              tbl(con2, "bt_indicator_variable") |>
                rows_delete(
                  tibble(indicator_id = new_id()),
                  by = "indicator_id",
                  unmatched = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              purrr::walk(input$pi_variables, function(var_id) {
                tbl(con2, "bt_indicator_variable") |>
                  rows_insert(
                    tibble(
                      indicator_id = new_id(),
                      variable_id  = var_id
                    ),
                    by = c("indicator_id", "variable_id"),
                    conflict = "ignore",
                    in_place = TRUE,
                    copy = TRUE
                  )
              })
              last_modified(Sys.time())
              sendSweetAlert(title = i18n()$t("Actualizar"),
                             text = i18n()$t("Indicador actualizado"),
                             type = "success")
            }, error = function(e) {
              showNotification(paste0(
                cleanHTML(i18n()$t("Error al actualizar indicador")),
                " - ", e),
                type = "error",
                duration = NULL)
            })
          } else {
            # INSERT new indicator
            tryCatch({
              tbl(con2, "dt_indicators") |>
                rows_insert(
                  tibble(
                    indicator_id           = new_id(),
                    indicator_original_name = input$ti_indicator_name,
                    indicator_order        = NA_integer_,
                    indicator_formula      = input$tai_indicator_formula,
                    indicator_direction    = input$pi_indicator_direction,
                    indicator_weight       = input$ni_indicator_weight,
                    indicator_weight_basis = input$tai_indicator_weight_basis,
                    indicator_weight_user  = current_user,
                    user_cre               = current_user,
                    ts_cre                 = Sys.time()
                  ),
                  by = "indicator_id",
                  conflict = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              tbl(con2, "bt_indicator_source") |>
                rows_insert(
                  tibble(
                    indicator_id = new_id(),
                    source_id    = chr_source
                  ),
                  by = c("indicator_id", "source_id"),
                  conflict = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              purrr::walk(i18n()$get_languages(), function(lan_code) {
                tbl(con2, "lt_indicators") |>
                  rows_upsert(
                    tibble(
                      indicator_id          = new_id(),
                      indicator_lang        = lan_code,
                      indicator_name        = input$ti_indicator_name,
                      indicator_label       = input$ti_indicator_label,
                      indicator_description = input$tai_indicator_des
                    ),
                    by = c("indicator_id", "indicator_lang"),
                    in_place = TRUE,
                    copy = TRUE
                  )
              })
              tbl(con2, "bt_indicator_subdimension") |>
                rows_insert(
                  tibble(
                    indicator_id    = new_id(),
                    dimension_id    = input$pi_dimension_id,
                    subdimension_id = input$pi_subdimension_id,
                    source_id       = chr_source
                  ),
                  by = c("indicator_id", "dimension_id", "subdimension_id", "source_id"),
                  conflict = "ignore",
                  in_place = TRUE,
                  copy = TRUE
                )
              purrr::walk(input$pi_variables, function(var_id) {
                tbl(con2, "bt_indicator_variable") |>
                  rows_insert(
                    tibble(
                      indicator_id = new_id(),
                      variable_id  = var_id
                    ),
                    by = c("indicator_id", "variable_id"),
                    conflict = "ignore",
                    in_place = TRUE,
                    copy = TRUE
                  )
              })
              new_id(next_id("indicator", "ICUS"))
              last_modified(Sys.time())
              sendSweetAlert(title = i18n()$t("Guardar"),
                             text = i18n()$t("Indicador guardado"),
                             type = "success")
            }, error = function(e) {
              showNotification(paste0(
                cleanHTML(i18n()$t("Error al insertar indicador")),
                " - ",
                e),
                type = "error",
                duration = NULL)
            })
          }
        }
      })


      ## [O] ab_delete_ind ----
      observeEvent(input$ab_delete_ind, {
        confirmSweetAlert(
          session = session,
          inputId = "confirm_delete_ind",
          title = i18n()$t("Confirmar eliminación"),
          text = paste0(
            i18n()$t("¿Está seguro/a de eliminar"),
            " ",
            new_id(),
            "? ",
            i18n()$t("Esta acción no se puede deshacer")
          ),
          type = "warning",
          btn_labels = c(i18n()$t("Cancelar"), i18n()$t("Eliminar")),
          btn_colors = c(get_theme_color(session, "primary"), get_theme_color(session, "danger")),
          html = TRUE
        )
      })

      ## [O] confirm_delete_ind ----
      observeEvent(input$confirm_delete_ind, {
        req(input$confirm_delete_ind)

        iid <- new_id()
        tryCatch({
          DBI::dbWithTransaction(con2, {
            DBI::dbExecute(con2, "DELETE FROM bt_indicator_variable WHERE indicator_id = $1", params = list(iid))
            DBI::dbExecute(con2, "DELETE FROM bt_indicator_subdimension WHERE indicator_id = $1", params = list(iid))
            DBI::dbExecute(con2, "DELETE FROM bt_indicator_source WHERE indicator_id = $1", params = list(iid))
            DBI::dbExecute(con2, "DELETE FROM lt_indicators WHERE indicator_id = $1", params = list(iid))
            DBI::dbExecute(con2, "DELETE FROM dt_indicators WHERE indicator_id = $1", params = list(iid))
          })
          last_modified(Sys.time())
          sendSweetAlert(
            session = session,
            title = i18n()$t("Eliminado"),
            text = i18n()$t("Indicador eliminado correctamente"),
            type = "success"
          )
        }, error = function(e) {
          showNotification(
            paste0(i18n()$t("Error al eliminar el indicador"), ": ", e$message),
            duration = NULL,
            type = "error"
          )
        })
      })

      ## Return ----
      return(
        list(
          last_modified = last_modified
        )
      )
    })

}

## Module app ----

mgt_ind_app <- function(){

  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  translator <- getOption("evastur.translator")

  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    textInput("ti_source", "Source", "EVASTUR"),
    mgt_ind_form_ui("indform1"),
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    mgt_ind_form_server("indform1", i18n, reactive({input$ti_source}))
  }
  
  shinyApp(ui, server)
  
}

## Run app ----
# mgt_ind_app()
