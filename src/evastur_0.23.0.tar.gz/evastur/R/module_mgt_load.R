## Module for editing the dimensions weights

## Module UI ----
mgt_load_ui <- function(id) {
  ns <- NS(id)
  tagList(
    layout_columns(
      col_widths = c(4, 8),
      card(
        uiOutput(ns("ui_buttons")),
      ),
      card(
        card_title(textOutput(ns("to_preview_title"))),
        uiOutput(ns("link_example_variable")),
         reactableOutput(ns("rt_vars"))#,
      )
    )
  )
}

## Module server ----
#' Module for loading new data
#'
#' @param id module id
#' @param i18n translation object
#'
#' @returns last success load
#'
#' @export
#' @examples
#' mgt_load_app()
mgt_load_server <- function(id, i18n) {
  moduleServer(
    id,
    function(input, output, session) {
      ## form validation ----
      iv <- InputValidator$new()
      iv$add_rule("fi_vars_load", sv_required(message = "*"))

      iv$enable()


      ## [RV] last_load ----
      rval <- reactiveValues(last_success_load = "never load")

      ## to_preview_title
      output$to_preview_title <- renderText({
        i18n()$t("Previsualización")
      })

      ## link_example_variable ----
      output$link_example_variable <- renderUI({
        a(
          href = "www/data/VCUS0001_PRT.csv",
          i18n()$t("Descargar fichero de ejemplo")
        )
      })

      ## ui_buttons ----
      output$ui_buttons <- renderUI({
        tagList(
          fileInput(
            session$ns("fi_vars_load"), 
            i18n()$t("Datos de variables"),
            buttonLabel = paste0(i18n()$t("Examinar"), "..."),
            placeholder = i18n()$t("Ningún archivo seleccionado"),
            width = "100%"
          ),
          actionButton(
            session$ns("ab_save"),
            i18n()$t("Guardar datos"),
            icon = icon("database")
          )
        )
      })

      ## [R] dfvars - data frame variable values
      dfvars <- reactive({
        req(input$fi_vars_load)
        file <- input$fi_vars_load
        read.csv(file$datapath)
      })

      ## rt_vars ----
      output$rt_vars <- renderReactable({
        dfvars() |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "preview-tables"
          )
      })

      ## [O] ab_save ----
      observeEvent(input$ab_save, {
        if (!iv$is_valid()) {
          showNotification(i18n()$t("Datos incompletos"), type = "error")
        } else {
          if (nrow(dfvars()) > 0) {
            ft_variables <- dfvars() |>
              mutate(
                variable_ts = Sys.time(),
                #  variable_secret = FALSE,
                #  variable_prov = FALSE,
                source_id = "CUSTOM",
                user_cre = Sys.info()["user"]
              )
            res1 <- tryCatch(
              {
                dbAppendTable(con2, "ft_variables", ft_variables)
                showNotification(
                  cleanHTML(i18n()$t("Valores de variables guardados")),
                  type = "message"
                )
                TRUE
              },
              error = function(e) {
                showNotification(
                  paste0(
                    cleanHTML(i18n()$t("Error subiendo datos de variables")),
                    e
                  ),
                  duration = NULL,
                  type = "error"
                )
                FALSE
              }
            )
          }
          if (res1) {
            rval$last_success_load <- as.character(Sys.time())
            sendSweetAlert(
              title = i18n()$t("Éxito"),
              text = i18n()$t("Se han guardado los datos correctamente"),
              type = "success"
            )
          }
        }
      })
      return(reactive({
        rval$last_success_load
      }))
    }
  )
}

## Module app ----

mgt_load_app <- function() {
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  translator <- getOption("evastur.translator")

  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    # textInput("ti_source", "Source", "EVASTUR"),
    mgt_load_ui("load1"),
  )

  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    mgt_load_server("load1", i18n)
  }

  shinyApp(ui, server, options = list(port = 3800))
}
