## Functions that return tables



#' Get intervention table
#' 
#' Gets the table with the indicators to be intervened
#' 
#' @param .data Result of the step 2 intervention
#' @param i18n Translation object
#' @param primary_color color used for header background
#' 
#' @return A reactable object with the formatted intervention results.
#' 
#' @export
#' @examplesIf interactive
#' inds <- con2 |>
#'   tbl("ft_indicators") |>
#'   distinct(indicator_id) |>
#'   pull()
#' dfind <- get_ft_data(
#'   data_type = "indicator",
#'   .nuts_level = 0,
#'   type_id = inds,
#'   #' country = "ES",
#'   .source_id = "EVASTUR",
#'   from_date = "2013-01-01",
#'   to_date = "2022-12-31"
#' )
#' suppressMessages({
#'   tindicators <- get_transformed_indicators(
#'     dfind,
#'     scaling_method = "zscore",
#'     scaling_type = "time",
#'     refvalueq = NULL,
#'     geo_total = "WLD"
#'   )
#' })
#' cindicators <- compute_composite_indicator(
#'   tindicators,
#'   selected_source = "EVASTUR"
#' ) |>
#'   filter(total)
#' predicted_indicators <- predict_indicators(
#'   #' tindicators |> filter(geo_id == "ESP")
#'   tindicators |> filter(total)
#' )
#' pred_dim <- predicted_indicators$dim
#' pred_ind <- predicted_indicators$ind
#' datadim <- bind_rows(cindicators, pred_dim) |>
#'   filter(dimension_id != "GLOBAL") |>
#'   inner_join(
#'     con2 |>
#'       tbl("dt_dimensions") |>
#'       inner_join(
#'         tbl(con2, "bt_source_subdimension") |>
#'           distinct(source_id, dimension_id) |>
#'           filter(source_id == "EVASTUR"),
#'         by = "dimension_id"
#'       ) |>
#'       select(dimension_id, dimension_weight, dimension_color) |>
#'       inner_join(
#'         tbl(con2, "lt_dimensions") |>
#'           filter(dimension_lang == "es") |>
#'           select(dimension_id, dimension_label, dimension_name),
#'         by = "dimension_id"
#'       ) |>
#'       collect(),
#'     by = "dimension_id"
#'   )
#' # intervention <- compute_intervention(datadim, 2023, 0.3, 1, 3)
#' intervention <- compute_intervention(datadim, 2023, 0.17, 1, 3)
#' # intervention <- compute_intervention(datadim, 2023, 0.1, 1, 3)
#' dims_int <- intervention |>
#'   filter(beta != 0) |>
#'   pull(var)
#' inds_int <- predicted_indicators$ind |>
#'   distinct(indicator_id, dimension_id) |>
#'   filter(dimension_id %in% dims_int) |>
#'   pull(indicator_id)
#' dataind <- bind_rows(tindicators, pred_ind) |>
#'   filter(dimension_id == "ECO") |>
#'   inner_join(
#'     con2 |> 
#'       tbl("dt_indicators") |> 
#'       select(indicator_id, indicator_weight) |> 
#'       collect(),
#'     by = "indicator_id"
#'   ) |> 
#'   inner_join(
#'     con2 |>
#'       tbl("dt_dimensions") |>
#'       inner_join(
#'         tbl(con2, "bt_source_subdimension") |>
#'           distinct(source_id, dimension_id) |>
#'           filter(source_id == "EVASTUR"),
#'         by = "dimension_id"
#'       ) |>
#'       select(dimension_id, dimension_weight, dimension_color) |>
#'       collect(),
#'     by = "dimension_id"
#'   ) |>
#'   inner_join(
#'     tbl(con2, "lt_indicators") |>
#'       filter(indicator_lang == "es") |>
#'       select(indicator_id, indicator_label, indicator_name) |>
#'       collect(),
#'     by = "indicator_id"
#'   )
#' intervention2 <- compute_intervention(
#'   .data = dataind,
#'   year = 2023,
#'   epsilon = intervention |> filter(var == "ECO") |> pull(beta),
#'   mu_l = 1,
#'   mu_u = dataind |> distinct(indicator_id) |> pull() |> length(),
#'   layer = 2,
#'   var_no_modify = NULL
#' )
#' intl2 <- get_intervention_layer2(
#'   counterfactual_dimen = intervention,
#'   data_npred = cindicators,
#'   data_pred = predicted_indicators,
#'   data_ind_original = tindicators,
#'   actionable_indicators = inds_int,
#'   .scaling_method = "zscore",
#'   lan = "es",
#'   source = "EVASTUR"
#' )
#' get_intervention_table(intl2, getOption("evastur.translator"))
get_intervention_table <- function(.data, i18n, primary_color = "#6B8A7A") {
  unfeasible_dims <- attr(.data, "unfeasible_dims")

  if (!is.null(unfeasible_dims) && length(unfeasible_dims) > 0) {
    unfeasible_rows <- tibble::tibble(
      Dimension = unfeasible_dims$name,
      label = toupper(i18n$t("No factible")),
      value_pred = NA_real_,
      beta = NA_real_,
      value_counterfactual = NA_real_,
      unscaled_value_pred = NA_real_,
      unscaled_value_counterfactual = NA_real_,
      col = unfeasible_dims$color
    )

    .data <- dplyr::bind_rows(.data, unfeasible_rows)
  }

  .data |>
    select(
      Dimension,
      label,
      value_pred,
      beta,
      value_counterfactual,
      unscaled_value_pred,
      unscaled_value_counterfactual,
      col
    ) |>
    mutate(
      unscaled_change = unscaled_value_counterfactual - unscaled_value_pred
    ) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      class = "exploration-tables",
      defaultColDef = colDef(
        headerClass = "exploration-tables-header",
        headerStyle = primary_color
      ),
      columns = list(
        Dimension = colDef(
          name = "",
          maxWidth = 50,
          html = TRUE,
          cell = function(value, index) {
            .style = paste0("color:", .data$col[index])
            span(icon("circle", class = "fas"), style = .style)
          }
        ),
        label = colDef(name = i18n$t("Indicador")),
        value_pred = colDef(show = FALSE),
        value_counterfactual = colDef(show = FALSE),
        beta = colDef(
          name = i18n$t("Intervención (escalada)"),
          format = colFormat(digits = 2)
        ),
        unscaled_value_pred = colDef(
          name = i18n$t("Predicción sin intervención"),
          format = colFormat(digits = 2)
        ),
        unscaled_value_counterfactual = colDef(
          name = i18n$t("Predicción tras intervención"),
          format = colFormat(digits = 2)
        ),
        unscaled_change = colDef(
          name = i18n$t("Cambio necesario"),
          format = colFormat(digits = 2)
        ),
        col = colDef(show = FALSE)
      )
    )
}

#' Get sources reactable
#'
#' @param con connection
#' @param i18n translator
#' @param primary_color color used for header background
#'
#' @returns a reactable object
#' @export
#'
#' @examplesIf interactive()
#' library(evastur)
#' i18n <- getOption("evastur.translator")
#' get_reactable_sources(con, i18n)
get_reactable_sources <- function(con, i18n, primary_color = "#6B8A7A") {
  sources_bd <- tbl(con, "ind_sources") |> 
    inner_join(tbl(con, "ind_sources_labs"), by = "id_source") |> 
    left_join(tbl(con, "ind_sources_ida"), by = "ida_id") |> 
    left_join(
      tbl(con, "ind_sources_ida_labs") ,
      by = c("ida_id", "language")
    ) |> 
    filter(language == i18n$get_translation_language()) |> 
  collect()
  
  last_data <- datos_indicadores |> 
    group_by(fuente) |> 
    summarise(last_period = max(Periodo)) |> 
    inner_join(
      sources_bd |> 
        filter(language == i18n$get_translation_language()) |> 
        select(id_source, name),
      by = c("fuente" = "name")
    )
  
  sources_bd <- sources_bd |> 
    left_join(
      last_data,
      by = "id_source"
    )  |> 
    select(-fuente) |> 
    arrange(order) 
  
  sources_bd |> 
    select(label, name, description, 
           ida_name, ida_comment, ida_id,
           last_period) |> 
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      class = "exploration-tables",
      defaultColDef = colDef(
        headerClass = "exploration-tables-header",
        headerStyle = primary_color
      ),
      columns = list(
        label = colDef(
          html = TRUE,
          maxWidth = 400,
          name = cleanHTML(i18n$t("Fuente")
          )
        ),
        name = colDef(
          name = "",
          html = TRUE,
          maxWidth = 200,
          cell = function(value, index){
            as.character(a(href = sources_bd$url[index], 
                           target = "_blank",
                           value))
          }),
        description = colDef(
          name = "",
          html = TRUE,
          maxWidth = 40,
          cell = function(value, index){
            as.character(tooltip(bs_icon("info-circle"),
                                 value))
          }
        ),
        ida_name = colDef(
          name = "IDA",
          # headerClass = "ida-header",
          align = "center",
          html = TRUE,
          maxWidth = 100,
          style = function(value, index){
            list(color = get_ida_col(sources_bd$ida_id[index]),
                 fontWeight = "bold")
          },
          cell = function(value, index){
            span(ifelse(is.na(value), "", value), 
                 title = sources_bd$ida_comment[index])
          }
        ),
        ida_comment = colDef(show = FALSE),
        ida_id = colDef(show = FALSE),
        last_period = colDef(
          maxWidth = 100,
          name = cleanHTML(i18n$t("Último periodo"))
        )
      )
    )
}

#' Get indicators reactable
#'
#' @param i18n translator
#' @param primary_color color used for header background
#'
#' @returns a reactable object
#' @export
#'
#' @examplesIf interactive
#' library(evastur)
#' i18n <- getOption("evastur.translator")
#' get_reactable_indicators(i18n)
get_reactable_indicators <- function(i18n, primary_color = "#6B8A7A") {
  ind_df <- datos_indicadores |> 
    group_by(fuente, Dimension, indicador, clasificacion) |> 
    summarise(first_period = min(Periodo),
              last_period = max(Periodo),
              .groups = "drop") |> 
    mutate(indicator_description = "Coming soon: indicator description",
           .after = indicador)

  ind_df |> 
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      class = "exploration-tables",
      defaultPageSize = 5,
      defaultColDef = colDef(
        headerClass = "exploration-tables-header",
        headerStyle = primary_color
      ),
      columns = list(
        fuente = colDef(
          name = cleanHTML(i18n$t("Fuente")),
          filterable = TRUE,
          maxWidth = 150
        ),
        Dimension = colDef(
          name = cleanHTML(i18n$t("Dimensión")),
          filterable = TRUE,
          maxWidth = 150
        ),
        indicador = colDef(
          name = cleanHTML(i18n$t("Indicador")),
          filterable = TRUE,
          maxWidth = 500,
          details = function(index){
            div("coming soon: indicator methodology",
                style = "color: #CCC; margin: 10px")
          }
        ),
        indicator_description = colDef(
          name = "",
          html = TRUE,
          maxWidth = 30,
          cell = function(value, index){
            as.character(tooltip(bs_icon("info-circle"),
                                 value))
          }
        ),
        clasificacion = colDef(
          name = cleanHTML(i18n$t("Clasificación")),
          filterable = TRUE,
          maxWidth = 110
        ),
        first_period = colDef(
          name = cleanHTML(i18n$t("Primer periodo")),
          maxWidth = 80
        ),
        last_period = colDef(
          name = cleanHTML(i18n$t("Último periodo")),
          maxWidth = 80
        )
      )
    )
}
