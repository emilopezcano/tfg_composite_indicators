## Module for visualizing and comparing indicators

## Reusable plot functions ----

#' Create visualization comparison plot (between geographical areas)
#'
#' @param dfind data.frame with indicator data for plotting lines
#' @param dfgroup data.frame with grouped/composite data for main lines
#' @param plot_title string with the plot title
#' @param geo_total string with the total geographical area identifier
#' @param geo_list vector with geographical area identifiers to compare
#' @param i18n translation object
#' @param background_color background color
#'
#' @export
create_viz_geo_comparison_plot <- function(dfind, dfgroup, plot_title,
                                          geo_total, geo_list, i18n, background_color = "#F0EDE6") {
  # Same logic as original server code
  if (!is.null(dfind)) {
    if (nrow(dfind) > 0) {
      p <- ggplot(data = dfind)
      p <- p +
        geom_line(mapping = aes(x = date, y = value), linetype = 2)
    } else {
      p <- ggplot()
    }
  } else{
    p <- ggplot()
  }

  # Between geographical areas logic
  p <- p +
    aes(x = date, y = value, col = geo_id) +
    geom_line(data = dfgroup, linetype = 1)

  # Add styling (exactly as in server)
  p <- p +
    labs(title = plot_title,
         x = "",
         y = "",
         color = "") +
    theme(panel.background = element_rect(fill = background_color),
          plot.background = element_rect(fill = background_color),
          axis.text.x = element_text(angle = 45, vjust = 0.5),
          legend.position = "bottom") +
    scale_x_date(date_breaks = "1 year", date_labels = "%Y")

  # Apply color palette (exactly as in server)
  cols <- ggthemes::tableau_color_pal()(10)
  pal <- setNames(
    c("black", cols[1:length(geo_list)]),
    c(geo_total, geo_list)
  )
  p <- p +
    aes(customdata = geo_label) +
    scale_color_manual(values = pal)

  return(p)
}

#' Create visualization comparison plot (within geographical area)
#'
#' @param dfind data.frame with indicator data for plotting lines
#' @param dfgroup data.frame with grouped/composite data for main lines
#' @param plot_title string with the plot title
#' @param dim_id string with dimension identifier
#' @param ind_list vector with indicator identifiers to compare
#' @param i18n translation object
#' @param background_color background color
#'
#' @export
create_viz_ind_comparison_plot <- function(dfind, dfgroup, plot_title,
                                          dim_id, ind_list, i18n, background_color = "#F0EDE6") {
  # Same logic as original server code
  if (!is.null(dfind)) {
    if (nrow(dfind) > 0) {
      p <- ggplot(data = dfind)
      p <- p +
        geom_line(mapping = aes(x = date, y = value), linetype = 2)
    } else {
      p <- ggplot()
    }
  } else{
    p <- ggplot()
  }

  # Within geographical area logic
  p <- p +
    aes(x = date, y = value, col = indicator_id) +
    geom_line(data = dfgroup,
              mapping = aes(col = dimension_id),
              linetype = 1)

  # Add styling (exactly as in server)
  p <- p +
    labs(title = plot_title,
         x = "",
         y = "",
         color = "") +
    theme(panel.background = element_rect(fill = background_color),
          plot.background = element_rect(fill = background_color),
          axis.text.x = element_text(angle = 45, vjust = 0.5),
          legend.position = "bottom") +
    scale_x_date(date_breaks = "1 year", date_labels = "%Y")

  # Apply customdata logic (exactly as in server)
  if (is.null(ind_list)){
    p <- p +
      aes(customdata = dimension_id)
  } else {
    p <- p +
      aes(customdata = indicator_label)
  }

  # Apply color palette (exactly as in server)
  cols <- ggthemes::tableau_color_pal()(10)
  dimcol <- tryCatch({
    tbl(con2, "dt_dimensions") |>
      filter(dimension_id == !!dim_id) |>
      pull(dimension_color)
  }, error = function(e) "#6B8A7A")

  if (length(dimcol) == 0 || !is_valid_hex(dimcol)) {
    if (length(dimcol) > 0 && !is_valid_hex(dimcol)) {
      message("Invalid hex color for dimension '", dim_id, "': '", dimcol,
              "'. Falling back to default color.")
    }
    dimcol <- "#6B8A7A"
  }

  pal <- setNames(
    c(dimcol, cols[1:length(ind_list)]),
    c(dim_id, ind_list)
  )
  p <- p +
    scale_color_manual(values = pal)

  return(p)
}

## Module UI ----
indicator_viz_plot_ui <- function(id) {
  ns <- NS(id)
  tagList(
    plotlyOutput(ns("series_indicator"))
  )
}

## Module server ----
#' Visualization and comparison of indicators
#' 
#' Plots time series of indicators. If comp_type is "within", several indicators of a dimension can be compared within a geographical area. If comp_type is "between", an indicator or dimension can be compared between several geographical areas.
#' 
#'
#' @param id instance id
#' @param i18n translation object
#' @param .data data.frame with data to plot
#' @param signif number of decimal numbers in labels
#' @param comp_type type of comparison: within or between
#' @param dim dimension
#' @param ind indicators within the dimension
#' @param geo geographical areas to compare
#' @param geo_total group of geographical areas to use as total
#' @param source id of the source to be used, i.g., EVASTUR
#' @param year year to show in the map for the indicator original value visualization
#' @param dimlabel Dimension label for plot title
#' @param indlabel Indicator label for plot title
#' @param geolabel Geographical area label for plot title
#' @param geo_totallabel Total area label for plot title
#'
#' @returns The data used in the plot
#'
#' @examples
#' \dontrun{
#' indicator_viz_plot_app()
#' }
indicator_viz_plot_server <- function(id, i18n, 
                                      .data, 
                                      signif, 
                                      comp_type,
                                      dim,
                                      ind,
                                      geo,
                                      geo_total,
                                      .source,
                                      year,
                                      dimlabel,
                                      indlabel,
                                      geolabel,
                                      geo_totallabel) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- session$ns
      ## [R] comp_ind ----
      comp_ind <- reactive({
        compute_composite_indicator(.data(),
                                    selected_source = .source())
      })
      ## [R] dfind ----
      dfind <- reactive({
        req(nrow(.data()) > 0)
        lan <- i18n()$get_translation_language()
        dfind <- .data() |>
          mutate(date = as.Date(date)) |> 
          filter(indicator_id %in% ind())
        if (comp_type == "within"){
          if (geo() == "_TOTAL_"){
            dfind <- dfind |> 
              filter(geo_id == geo_total())
          } else {
            dfind <- dfind |> 
              filter(geo_id == geo())
          }
          dfind <- dfind |> 
            left_join(tbl(con2, "lt_indicators") |> 
                        filter(indicator_lang == lan) |> 
                        select(indicator_id, indicator_label, indicator_name) |> 
                        collect(),
                      by = "indicator_id"
            )
        } else if (comp_type == "between"){
          if (is.null(ind())){
            dfind <- comp_ind() |> 
              mutate(date = as.Date(date)) |> 
              filter(dimension_id == dim()) |> 
              left_join(tbl(con2, "lt_dimensions") |> 
                          filter(dimension_lang == lan) |> 
                          select(dimension_id, indicator_label = dimension_label,
                                 indicator_name = dimension_name) |> 
                          collect(),
                        by = "dimension_id")
          } else {
            dfind <- dfind |> 
              left_join(tbl(con2, "lt_indicators") |> 
                          filter(indicator_lang == lan) |> 
                          select(indicator_id, indicator_label, indicator_name) |> 
                          collect(),
                        by = "indicator_id"
              )
          }
          dfind <- dfind |> 
            filter(geo_id %in% geo())
        }
        dfind |> 
          left_join(tbl(con2, "lt_geo") |> 
                      filter(geo_lang == lan) |> 
                      select(geo_id, geo_label) |> 
                      collect(),
                    by = "geo_id"
          ) |> 
          mutate(period = get_period(date, period_id))
        
        # return(dfind)
      })

      ## [R] dfgroup ----
      dfgroup <- reactive({
        req(nrow(.data()) > 0)
        lan <- i18n()$get_translation_language()
        if (comp_type == "within"){
          dfgroup <- comp_ind() |> 
            mutate(date = as.Date(date))
          if (geo() == "_TOTAL_"){
            dfgroup <- dfgroup |> 
              filter(dimension_id == dim(),
                     geo_id == geo_total())
          } else {
            dfgroup <- dfgroup |> 
              filter(dimension_id == dim(),
                     geo_id == geo())
          } 
          dfgroup <- dfgroup |> 
            left_join(tbl(con2, "lt_dimensions") |> 
                        filter(dimension_lang == lan) |> 
                        select(dimension_id, indicator_label = dimension_label,
                               indicator_name = dimension_name) |> 
                        collect(),
                      by = "dimension_id")
        } else if (comp_type == "between"){
          if(is.null(ind())){
            dfgroup <- comp_ind() |> 
              mutate(date = as.Date(date)) |> 
              filter(dimension_id == dim(),
                     geo_id == geo_total()) |> 
              left_join(tbl(con2, "lt_dimensions") |> 
                          filter(dimension_lang == lan) |> 
                          select(dimension_id, indicator_label = dimension_label,
                                 indicator_name = dimension_name) |> 
                          collect(),
                        by = "dimension_id")
            
          } else {
            dfgroup <- .data() |> 
              mutate(date = as.Date(date)) |> 
              filter(geo_id == geo_total(),
                     indicator_id %in% ind()) |> 
              left_join(tbl(con2, "lt_indicators") |> 
                          filter(indicator_lang == lan) |> 
                          select(indicator_id, indicator_label, indicator_name) |> 
                          collect(),
                        by = "indicator_id"
              )
          }
        }
        dfgroup |> 
          left_join(tbl(con2, "lt_geo") |> 
                      filter(geo_lang == lan) |> 
                      select(geo_id, geo_label) |> 
                      collect(),
                    by = "geo_id"
          ) |> 
          mutate(period = get_period(date, period_id))
        # return(dfgroup |> mutate(indicator_label = "INDICATOR LABEL"))
      })

      ## [R] df_selected ----
      df_selected <- reactive({
        if (comp_type == "within"){
          df0 <- dfind() |> 
            filter(indicator_id == !!clicked_id())
        } else if (comp_type == "between"){
          if (length(clicked_id()) == 1 && !is.na(clicked_id())){
            df0 <- dfind() |>
              filter(geo_id == !!clicked_id())
          } else {
            df0 <- dfgroup()
          }
        }
        return(df0)
      })

      ## [R] geo_orig ----
      geo_orig <- reactive({
        if (comp_type == "within") {
          res <- geo() 
        } else if (comp_type == "between") {
          if (length(clicked_id()) == 1 && !is.na(clicked_id())){
            res <- clicked_id()
          } else {
            res <- "_TOTAL_"
          }
        }
        return(res)
      })

      ## [R] geolabel_orig ----
      geolabel_orig <- reactive({
        if (comp_type == "within") {
          res <- geolabel()
        } else if (comp_type == "between") {
          if (length(clicked_id()) == 1 && !is.na(clicked_id())) {
            res <- geolabel()[clicked_id()]
          } else {
            res <- geo_totallabel()
          }
        }
        return(unname(res))
      })

      ## [M] indicators_plots ----
      indicators_plots_server(
        "indicators_plots_viz",
        .data = df_selected,
        .geo = geo_orig,
        .date = reactive({paste0(year(), "-01-01")}) ,
        i18n = i18n,
        # geolabel = reactive({"geolabel"}),
        geolabel = geolabel_orig,
        indlabel = ind_ori_label)

      ## [ER] clicked_id ----
      clicked_id <- eventReactive(
        event_data("plotly_click", source = ns("series_indicator")),
        {
          click_data <- event_data(
            "plotly_click",
            source = ns("series_indicator")
          )
          if (comp_type == "within") {
            res <- unique(dfind()$indicator_id)[click_data$curveNumber + 1]
          } else if (comp_type == "between") {
            res <- unique(dfind()$geo_id)[click_data$curveNumber + 1]
          }
          return(res)
        })

      ## [OE] click on plot when plot is ready ----
      observeEvent(
        plot_ready(),
        {
          if (!isTRUE(plot_ready())) {
            return()
          }

          local({
            observeEvent(
              event_data("plotly_click", source = ns("series_indicator")),
              {
                if (nrow(df_selected()) == 0 || is.null(ind())) {
                  showNotification(i18n()$t(
                    "Los indicadores compuestos no tienen valores originales que representar."
                  ))
                } else {
                  shinyWidgets::sendSweetAlert(
                    title = names(indlabel())[1],
                    html = TRUE,
                    text = tagList(indicators_plots_ui(ns(
                      "indicators_plots_viz"
                    ))),
                    width = 800,
                    btn_labels = "Close",
                    btn_colors = "var(--bs-primary)"
                  )
                }
              })
          })
        })

      ## [R] plot_title ----
      plot_title <- reactive({
        if (comp_type == "between") {
          if (is.null(ind())) {
            dimlabel()
          } else{
            names(indlabel())[1]
          }
        } else if (comp_type == "within"){
          if (geo() == "_TOTAL_"){
            geo_totallabel()
          } else {
            geolabel()[geo()]
          }
        }
      })

      ## [R] ind_ori_label ----
      ind_ori_label <- reactive({
        if (comp_type == "between") {
          if (is.null(ind())) {
            ""
          } else{
            ind()
          }
        } else if (comp_type == "within"){
          clicked_id()
        }
      })

      plot_ready <- reactiveVal(FALSE)

      ## series_indicator ----
      output$series_indicator <- renderPlotly({
        req(dim())

        df <- dfind()
        if (is.null(df) || nrow(df) == 0) {
          p <- ggplot()
        } else {
          p <- ggplot(df, aes(x = date, y = value)) +
            geom_line(linetype = 2)
        }

        if (comp_type == "within") {
          p <- p +
            aes(x = date, y = value, col = indicator_id) +
            geom_line(
              data = dfgroup(),
              mapping = aes(col = dimension_id),
              linetype = 1
            )
        } else if (comp_type == "between") {
          p <- p +
            aes(x = date, y = value, col = geo_id) +
            geom_line(data = dfgroup(), linetype = 1)
        }

        p <- p +
          labs(title = plot_title(), x = "", y = "", color = "") +
          theme(
            panel.background = element_rect(
              fill = get_theme_color(session = session, bs_variable = "light")
            ),
            plot.background = element_rect(
              fill = get_theme_color(session = session, bs_variable = "light")
            ),
            axis.text.x = element_text(angle = 45, vjust = 0.5),
            legend.position = "bottom"
          ) +
          scale_x_date(date_breaks = "1 year", date_labels = "%Y")
        cols <- ggthemes::tableau_color_pal()(10)
        if (comp_type == "between") {
          pal <- setNames(
            c("black", cols[1:length(geo())]),
            c(geo_total(), geo())
          )
          series_type <- i18n()$t("Área geográfica")
          p <- p +
            aes(customdata = geo_label) +
            scale_color_manual(values = pal)
        } else if (comp_type == "within") {
          series_type <- i18n()$t("Indicador")
          if (is.null(ind())) {
            p <- p +
              aes(customdata = dimension_id)
          } else {
            p <- p +
              aes(customdata = indicator_label)
          }
          dimcol <- tbl(con2, "dt_dimensions") |>
            filter(dimension_id == !!dim()) |>
            pull(dimension_color)
          if (length(dimcol) == 0 || !is_valid_hex(dimcol)) {
            if (length(dimcol) > 0 && !is_valid_hex(dimcol)) {
              message("Invalid hex color for dimension '", dim(), "': '", dimcol,
                      "'. Falling back to default color.")
            }
            dimcol <- "#6B8A7A"
          }
          pal <- setNames(
            c(dimcol, cols[1:length(ind())]),
            c(dim(), ind())
          )
          p <- p +
            scale_color_manual(values = pal)
        }
        suppressWarnings({
          plt <- ggplotly(p, source = ns("series_indicator")) |>
            style(
              hovertemplate = paste0(
                "<b>", series_type, ":</b> %{customdata}<extra></extra><br>",
                "<b>", i18n()$t("Año"), ":</b> %{x}<br>",
                "<b>", i18n()$t("Valor"), ":</b> %{y}<br>"
              )
            ) |>
            plotly::event_register("plotly_click") |>
            plotly::event_register("plotly_hover") |>
            plotly::config(displaylogo = FALSE)
            plot_ready(TRUE)
            plt
        })
      })

      return(list(
        data_ind = dfind,
        data_group = dfgroup
      ))
    }
  )
}

## Module app ----
indicator_viz_plot_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  library(ggplot2)
  library(plotly)
  translator <- getOption("evastur.translator")

  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    indicator_viz_plot_ui("viz1"),
    h3("Indicators data"),
    reactableOutput("rt_vizdata"),
    h3("Grouped data"),
    reactableOutput("rt_vizdatagroup")
  )

  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    dseries <- reactive({
      selected_source <- "EVASTUR"
      selected_nuts <- 0
      selected_location <- "ES"
      selected_group <- "OECD"
      selected_date <- "2014-01-01"
      selected_to_date <- "2023-12-31"
      selected_dimension <- "ECO"

      inds <- tbl(con2, "dt_indicators") |>
        filter(indicator_active == TRUE) |>
        select(indicator_id) |> 
        inner_join(tbl(con2, "bt_indicator_subdimension"),
                   by = "indicator_id") |> 
        pull(indicator_id)

      suppressMessages(dfind <- get_ft_data(data_type = "indicator",
                                            .nuts_level = selected_nuts,
                                            type_id = inds,
                                            country = selected_location,
                                            .source_id = selected_source,
                                            from_date = selected_date,
                                            to_date = selected_to_date)
      )
      suppressMessages(
        tindicators <- get_transformed_indicators(dfind,
                                                  scaling_method = "zscore",
                                                  scaling_type = "time",
                                                  geo_total = selected_group)
      )
    })

    indicator_viz <- indicator_viz_plot_server(
      "viz1", 
      i18n, 
      .data = dseries,
      signif = reactive({
        session$userData$config()$signif
      }
      ),
      # comp_type = "within", # ONLY ONE GEO
      comp_type = "between", # ONLY ONE IND
      dim = reactive("ECO"),
      # ind = reactive(c("IECO0001", "IECO0002")),
      # ind = reactive({NULL}), # FOR PLOTTING ONLY THE DIMENSION
      ind = reactive(c("IECO0001")),
      # geo = reactive({c("ESP")}),
      # geo = reactive({"_TOTAL_"}), # FOR PLOTTING ONLY THE TOTAL
      geo = reactive({c("ESP", "FRA", "PRT")}),
      geo_total = reactive({"OECD"}),
      .source = reactive({"EVASTUR"}),
      year = reactive({"2022"}),
      dimlabel = reactive({"Economic"}),
      indlabel = reactive({"INDICATOR LABEL"}),
      # geolabel = reactive({NULL}),
      geolabel = reactive({setNames(
        c("ESPAÑA", "FRANCIA", "PORTUGAL"),
        c("ESP", "FRA", "PRT"))}),
      geo_totallabel = reactive({"GEO TOTAL LABEL"})
    )

    output$rt_vizdata <- renderReactable({
      req(indicator_viz$data_ind())
      indicator_viz$data_ind() |> 
        reactable(language = get_rt_lang(input$si_lan))
    })
    output$rt_vizdatagroup <- renderReactable({
      req(indicator_viz$data_group())
      indicator_viz$data_group() |> 
        reactable(language = get_rt_lang(input$si_lan))
    })
  }

  shinyApp(ui, server, options = list(port = 3800))
}
