## Module UI ----
geo_level_selector_ui <- function(id, vertical = FALSE) {
  ns <- NS(id)
  tagList(
    ## Scope national or supranational
    uiOutput(ns("ui_rgb_geo_scope")),
    ## Group for the area of interest (country or group of countries)
    uiOutput(ns("ui_pi_geo_group")),
    ## Territorial units
    uiOutput(ns("ui_pi_nuts"))
  )
}

## Module Server ----
## TODO: refactor avoid two arguments (lan is in i18n)

#' Geographical level selector module
#'
#' This module contains three inputs: Geographical scope, geographical
#' group, and territorial units. It outputs a list with the selected
#' values of these inputs.
#'
#' Description of the objects within the server function of the model.
#'
#' **UI Inputs:**
#'
#' * `rgb_geo_scope`: National or Supranational
#' * `pi_geo_group`: List of groups to select the one to be used. If scope
#' is supranational, then the choices are the groups of countries or any other
#' geography is selected. If scope is national, then the choices are the
#'  territories with the selected nuts level is shown.
#'  * `pi_nuts`: List of territorial units within a country for national scope.
#'  Shows the names according to the specific country nomenclature, or generic
#'  if there is no specific nomenclature.
#'
#' **Reactive Objects:**
#'
#' * `dfgroups`: Data frame with the available groups in the database. If
#' scope is Supranational, then the list contains geographies with "nuts_level"
#' 101. If scope is National, then the list contains geographies with
#' "nuts_level" 0, i.e., countries.
#' * `group_values`: List with two elements that depend on the scope: the label
#' for the group selector and the selected group by default.
#' * `dfnuts`: Data frame with the territorial units selector options.
#'
#'
#' @name geo_level_selector
#'
#' @param id Module instance id
#' @param i18n Language object
#' @param lan Current language
#' @param last_modified Timestamp to refresh the selector when needed
#' @param vertical If TRUE radio buttons are displayed vertically
#'
#' @returns
#' * `rgb_geo_scope` Geographical scope (national or supranational)
#' * `pi_geo_group` Id of the group of territories
#' * `pi_nuts` id of the within-country territorial units (if national scope)
#'
#' @examplesIf interactive
#' geo_level_selector_app("es")
#' geo_level_selector_app("en")
geo_level_selector_server <- function (id, i18n, lan, last_modified = reactive(NULL), vertical = FALSE) {

  moduleServer(
    id,
    function(input, output, session) {
      ns <- NS(id)
      ## rgb_geo_scope ----
      output$ui_rgb_geo_scope <- renderUI({
        radioGroupButtons(
          inputId = session$ns("rgb_geo_scope"),
          label = i18n()$t("Alcance"),
          choices = setNames(
            c("S", "N"),
            i18n()$t(c("Supranacional", "Nacional"))
          ),
          selected = session$userData$config()$geo_scope,
          justified = TRUE,
          direction = if(vertical) "vertical" else "horizontal"
        )
      })

      ## [R] dfgroups ----
      # available groups data frame
      dfgroups <- reactive({
        req(input$rgb_geo_scope)
        last_modified()
        get_geo_groups(
          .nuts_level = ifelse(input$rgb_geo_scope == "N", 0, 101),
          lan = lan()
        )
      })

      ## [R] group_values
      # Selected group and groups label depending on scope
      group_values <- reactive({
        req(input$rgb_geo_scope)
        if (input$rgb_geo_scope == "N") {
          group_label <- i18n()$t("País")
          group_selected <- session$userData$config()$geo_country_id
        } else {
          group_label <- i18n()$t("Grupo de países")
          group_selected <- session$userData$config()$geo_group_id
        }
        return(list(group_label = group_label, group_selected = group_selected))
      })

      ## pi_geo_group ----
      # Picker input selection of country or group of countries
      output$ui_pi_geo_group <- renderUI({
        req(input$rgb_geo_scope)
        dfg <- dfgroups()
        pickerInput(
          inputId = session$ns("pi_geo_group"),
          label = isolate(group_values()$group_label),
          choices = setNames(dfg$geo_id, dfg$geo_label),
          selected = group_values()$group_selected,
          options = pickerOptions(
            container = "body",
            dropupAuto = FALSE,
            title = i18n()$t("Seleccione"),
            liveSearch = TRUE,
            liveSearchNormalize = TRUE,
            liveSearchPlaceholder = i18n()$t("Buscar")
          )
        )
      })

      ## ui_pi_nuts ----
      # PickerInput for territorial units
      output$ui_pi_nuts <- renderUI({
        req(input$rgb_geo_scope == "N")
        req(input$pi_geo_group)
        dfn <- dfnuts()
        pickerInput(
          inputId = session$ns("pi_nuts"),
          label = i18n()$t("Unidades territoriales"),
          choices = setNames(dfn$nuts_level_id, dfn$nuts_level_name),
          selected = session$userData$config()$geo_nuts_id,
          options = pickerOptions(
            container = "body",
            dropupAuto = FALSE,
            title = i18n()$t("Seleccione"),
            liveSearch = TRUE,
            liveSearchNormalize = TRUE,
            liveSearchPlaceholder = i18n()$t("Buscar")
          )
        )
      })

      ## [R] dfnuts ----
      # Get a data.frame for the territorial units selector options
      dfnuts <- reactive({
        
        country <- get_iso2_code(session$userData$config()$geo_country_id)
        # con2 |> tbl("dt_nuts_levels") |>
        #   inner_join(
        #     tbl(con2, "lt_nuts_levels") |>
        #       filter(nuts_level_lang == lan,
        #              nuts_level_country == country),
        #     by = "nuts_level_id")|>
        #   arrange(nuts_level_order) |>
        #   select(nuts_level_id, nuts_level_name) |>
        #   collect()

        get_geo_nuts(
          lan = lan(),
          loc = country
        )
      })

      ## Return list ----
      return(
        list(
          rgb_geo_scope = reactive({
            input$rgb_geo_scope
          }),
          pi_geo_group = reactive({
            input$pi_geo_group
          }),
          pi_nuts = reactive({
            input$pi_nuts
          })
        )
      )
    }
  )
}


## Module App ----

#' @export
geo_level_selector_app <- function(lan = "es") {
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)
  translator <- getOption("evastur.translator")

  ui <- fluidPage(
    geo_level_selector_ui("geo_selector1"),
    h3("Output from input in app"),
    verbatimTextOutput("scope"),
    verbatimTextOutput("group"),
    verbatimTextOutput("nuts")
  )
  server <- function(input, output, session) {
    geo_level_selector_controls <- geo_level_selector_server(
      "geo_selector1",
      i18n = reactive(translator),
      lan = reactive({
        lan
      })
    )
    output$scope <- renderText({
      geo_level_selector_controls$rgb_geo_scope()
    })
    output$group <- renderText({
      geo_level_selector_controls$pi_geo_group()
    })
    output$nuts <- renderText({
      geo_level_selector_controls$pi_nuts()
    })
  }
  shinyApp(ui, server, options = list(port = 3801))
}
