onlycustom_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("ui_ms_onlycustom"))
  )
}

onlycustom_server <- function(id, i18n) {
  moduleServer(
    id,
    function(input, output, session) {
      output$ui_ms_onlycustom <- renderUI({
        materialSwitch(
          inputId = session$ns("ms_onlycustom"),
          label = i18n()$t("Solo personalizados"), 
          value = FALSE,
          status = "primary",
          right = FALSE
        )
      })
      return(reactive({input$ms_onlycustom}))
    }
  )
}


onlycustom_app <- function(){
  ui <- fluidPage(
    onlycustom_ui("onlycustom1"),
    verbatimTextOutput("outres")
  )
  
  server <- function(input, output, session) {
    res <- onlycustom_server("onlycustom1",
                             getOption("evastur.translator"))
    output$outres <- renderText({
      res()
    })
  }
  
  shinyApp(ui, server)
}