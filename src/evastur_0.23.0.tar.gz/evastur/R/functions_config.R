## Functions for platform configuration

#' Get app configuration
#'
#' Gets the global app configuration for a given profile from the `ct_app` table.
#' If the profile is NULL or does not exist in the database, the default profile
#' is used instead.
#'
#' @note
#' This function only retrieves configuration data from `ct_app`. Theme-related
#' information (colors, logos) should be retrieved separately using [get_theme_config()].
#'
#' ### Configuration options (`ct_app`)
#' * **profile_id**: Unique identifier for the configuration profile.
#' * **app_title** (`EVASTOUR`): Application title displayed in the header.
#' * **default_lang** (`en`): Default language (ISO 639-1 code).
#' * **default_geo_scope** (`S`): Default geographical scope - `N` (National) or `S` (Supranational).
#' * **default_geo_group_id** (`WLD`): Default geographical area group (for countries).
#' * **default_geo_nuts_id** (`2`): Default NUTS (national regions level) (1-4).
#' * **default_geo_country_id** (`ESP`): Default country `geo_id` for national selections.
#' * **default_location** (`ES`): Default country location (ISO2 code).
#' * **nperiods** (`10`): Number of periods for series.
#' * **map_bins** (`5`): Number of intervals for legends maps.
#' * **signif** (`2`): Number of significant digits in outputs.
#' * **include_current_year** (`FALSE`): Whether to include the current year if any data available.
#' * **aggregation_function** (`median`): Aggregation function for total group indicator (will not be used in the future)
#' * **default_geo_country_selected** (`_TOTAL_`): Default `geo_id` selected country for supranational scope.
#' * **default_geo_nuts_selected** (`_TOTAL_`): Default `geo_id` of region for national scope.
#' * **refvalue_q** (`0.95`): Quantile for reference value when missing.
#' * **scaling_method**: Scaling method - one of `zscore`, `minmax`, `refvalue`.
#' * **scaling_type**: Scaling type - one of `time`, `geo`.
#' * **source**: Data source identifier.
#' * **last_period**: Last time period to include in analysis.
#' * **pred_method**: Prediction method - one of `ma` (moving average), `auto.arima`.
#' * **theme_id**: Reference to visual theme in `ct_themes` table.
#'
#' @param profile Character string with the profile_id to retrieve. 
#'   Use `"default"` for the default configuration.
#'
#' @returns A one-row data.frame (tibble) with the configuration settings for 
#'   the specified profile. The returned object has a `msg` attribute containing
#'   a status message about the profile loading.
#'
#' @seealso [get_theme_config()] for retrieving theme-specific configuration including logos.
#'
#' @export
#' @examples
#' get_app_config("default")
#' get_app_config("ine_es")
#' get_app_config("unwto")
get_app_config <- function(profile) {
  if (is.null(profile)) {
    profile <- "default"
    msgres <- "No profile selected, the default one will be used."
  }

  dfconfig <- con2 |>
    tbl("ct_app") |>
    collect()

  if (!(profile %in% dfconfig$profile_id)) {
    msgres <- paste0(
      profile,
      " profile does not exist in the database. The default profile will be used."
    )
    profile <- "default"
  } else {
    msgres <- paste0(profile, " was loaded correctly.")
  }

  config_full <- dfconfig |>
    filter(profile_id == profile)

  structure(config_full, msg = msgres)
}

#' Get theme configuration
#'
#' Retrieves visual theme configuration from the `ct_themes` table, including
#' colors and logo assets (both binary PNG and inline SVG formats).
#'
#' @details
#' Logo data is automatically cleaned and normalized:
#' * Binary logos (`logo_bin`) are extracted from list format if needed.
#' * Empty, NULL, or invalid logo data is converted to `NA`.
#' * SVG logos are validated and empty strings converted to `NA`.
#'
#' ### Theme configuration fields (`ct_themes`)
#' * **theme_id**: Unique identifier for the theme.
#' * **primary_hex**: Primary brand color in hexadecimal format (e.g., `#6B8A7A`).
#'   Used for navigation bars, buttons, and primary UI elements.
#' * **light_hex**: Light accent color in hexadecimal format (e.g., `#F2F6FF`).
#'   Used for text, backgrounds, and secondary UI elements.
#' * **logo_bin**: Binary data (`raw` vector) containing a PNG logo image.
#'   `NA` if no binary logo is available.
#' * **logo_svg**: Character string with inline SVG markup for a scalable logo.
#'   `NA` if no SVG logo is available. Preferred over binary when available.
#'
#' @note
#' SVG logos take priority over binary logos in the UI rendering logic.
#' Binary logos are base64-encoded before display.
#'
#' @param theme_id Character string with the theme identifier to retrieve.
#'
#' @returns A one-row data.frame (tibble) with theme configuration, or `NULL` 
#'   if the theme_id doesn't exist in the database. Logo fields are cleaned
#'   and normalized to either valid data or `NA`.
#'
#' @seealso [get_app_config()] for retrieving application configuration.
#'
#' @export
#' @examples
#' # Get theme configuration
#' theme <- get_theme_config(1)
#' 
#' # Check if theme exists
#' if (!is.null(theme)) {
#'   print(theme$primary_hex)
#' }
#' 
#' # Check logo availability
#' has_svg <- !is.na(theme$logo_svg)
#' has_png <- !is.na(theme$logo_bin[[1]])
get_theme_config <- function(theme_id) {
  theme_config <- con2 |>
    tbl("ct_themes") |>
    filter(theme_id == !!theme_id) |>
    select(theme_id, primary_hex, light_hex, logo_bin, logo_svg) |>
    collect()
  
  if (nrow(theme_config) == 0) {
    return(NULL)
  }
  
  # Clean logos
  theme_config |>
    mutate(
      logo_bin = map(logo_bin, function(x) {
        if (is.null(x) || length(x) == 0 || all(is.na(x))) {
          return(NA)
        }
        if (is.list(x)) x <- x[[1]]
        if (is.raw(x) && length(x) > 0) {
          return(x)
        }
        return(NA)
      }),
      logo_svg = if_else(
        is.na(logo_svg) | is.null(logo_svg) | logo_svg == "",
        NA_character_,
        logo_svg
      )
    )
}
