#' Get data from database fact tables
#'
#' Gets the indicator or variable data for all the geographies of a given level
#' and for all available periods.
#'
#'
#' @param data_type one of variable, indicator
#' @param .nuts_level A valid geographical aggregation level (0, 1, 2, 3, 4, 99, 101)
#' @param country Country in case level is higher than 0
#' @param type_id vector of ids of the type of data if not global (variable or indicator)
#' @param .source_id selected data source
#' @param from_date ISO date for filtering periods from that date
#' @param to_date ISO date for filtering periods up to that date
#'
#' @returns a data.frame with one row per geography and period and its value column
#'
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#' selected_source <- "EVASTUR"
#' selected_nuts <- 2
#' selected_location <- "ES"
#' selected_group <- "ESP"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' dfind_es <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#' vars <- tbl(con2, "dt_variables") |>
#'   pull(variable_id)
#'
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' selected_source <- tbl(con2, "ft_variables") |>
#' distinct(source_id) |>
#'   pull() |> str_subset("^INSTO", negate = TRUE)
#'
#' dvar_wld <- get_ft_data(data_type = "variable",
#'                      .nuts_level = selected_nuts,
#'                      type_id = vars,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#' ## INSTO EXAMPLE
#' selected_source <- "EVASTUR"
#' selected_nuts <- 99
#' selected_location <- NULL
#' selected_group <- "INSTO"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
get_ft_data <- function(
  data_type = c("indicator", "variable"),
  .nuts_level,
  country = NULL,
  type_id,
  .source_id = NULL,
  from_date,
  to_date
) {
  if (!(data_type %in% c("indicator", "variable"))) {
    stop("data_type should be one of variable, indicator")
  }
  ## Symbols for variables or indicators ----
  tablename <- paste0("ft_", data_type, "s")
  colSym <- rlang::sym(paste0(data_type, "_id"))
  type_value = paste0(data_type, "_value")

  ## Arguments values validation ----
  if (
    !(.nuts_level %in%
      (tbl(con2, "dt_nuts_levels") |>
        collect() |>
        pull(nuts_level_id)))
  ) {
    stop("unknown nuts_level")
  }
  if (.nuts_level %in% 1:4 & is.null(country)) {
    warning("For nuts level ", .nuts_level, " it is needed to supply a country")
    return(NULL)
  }
  if (!(.nuts_level %in% 1:4) & !is.null(country)) {
    message(
      "For nuts level ",
      .nuts_level,
      " it is not needed to supply a country,
            it will be ignored"
    )
  }

  ## TODO: check if this is necessary after the changes in #134
  if (.nuts_level == 99) {
    .source_id <- con2 |>
      tbl(tablename) |>
      filter(source_id %like% 'INSTO%') |>
      distinct(source_id) |>
      pull()
  }

  ## tbl with the indicators/variables to subset
  # tbl(con2, paste0("dt_", data_type, "s")) |>
  #   filter(indicator_id %in% type_id) |> collect()
  #
  ## TODO: How to manage several sources for the same geo
  ## Read, filter, select from DB ----
  df0 <- tbl(con2, tablename) |>
    inner_join(
      tbl(con2, "dt_geo") |>
        filter(geo_active == TRUE) |>
        select(geo_id, nuts_level, country_iso2_code),
      by = "geo_id"
    ) |>
    filter(
      nuts_level == .nuts_level,
      as.Date(date) >= as.Date(from_date),
      as.Date(date) <= as.Date(to_date),
      ifelse(.nuts_level %in% 1:4, country_iso2_code == country, TRUE),
      !!colSym %in% type_id
    ) |>
    select(
      -ends_with("_ts"), #- source_id,
      -user_cre,
      -nuts_level,
      -country_iso2_code
    )
  if (!is.null(.source_id)) {
    df0 <- df0 |>
      filter(source_id %in% .source_id)
  }

  if (data_type == "variable") {
    df0 <- df0 |>
      inner_join(
        tbl(con2, "bt_variable_source") |>
          select(variable_id, source_id, source_units),
        by = c("variable_id", "source_id")
      )
  } else if (data_type == "indicator") {
    df0 <- df0 |>
      select(-source_id)
  }

  return(structure(
    df0 |> collect(),
    country = country,
    nuts_level = .nuts_level
  ))
}


#' Get transformed indicator values
#'
#' Transforms indicator values to be used in the dashboard. First, only the most recent
#' periods are filtered. Then, if the aggregated destination target is a group of countries,
#' those countries are filtered. Next, the aggregated indicator is computed.
#' Finally, the indicator values are scaled with a given method.
#'
#' If `scaling_type` is `time`, then the values are scaled with respect to the
#' same geography throughout time. If `scaling-type` is `geo`, then the values
#' are scaled with respect to the rest of the geographies of the same level in the
#' given period.
#'
#' @param .data data frame with the indicator original values and an attribute "country"
#' @param maxper Maximum number of periods
#' @param scaling_method Scaling method (zscore, refval, minmax)
#' @param scaling_type type of scaling: time or geo
#' @param refvalueq quantile to be the reference value (only for scaling_method = refval)
#' @param aggregation_function Aggregation function to compute the total indicator
#' for the group of destinations (usually mean or median, but can be any summary function)
#'
#' @returns a data.frame with one row per geography and period plus a total, and two value columns (original and scaled)
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2014-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#'## SPAIN
#' selected_source <- "EVASTUR"
#' selected_nuts <- 2
#' selected_location <- "ES"
#' selected_group <- "ESP"
#' selected_date <- "2013-01-01"
#' to_date <- "2023-01-01"
#'
#' dfind_es <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = to_date)
#'
#' tindicators <- get_transformed_indicators(dfind_es,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = NULL)
get_transformed_indicators <- function(
  .data,
  maxper = getOption("evastur.nperiods"),
  scaling_method,
  scaling_type = c("time", "geo"),
  refvalueq = NULL,
  aggregation_function = getOption("evastur.aggregation_function"),
  geo_total,
  .source_id = "EVASTUR"
) {
  ## Filter only latest dates ----
  last_dates <- .data |>
    distinct(date) |>
    slice_max(date, n = maxper) |>
    pull()
  df0 <- .data |>
    filter(date %in% last_dates) #|>
  # mutate(total = FALSE)

  ## Extract data attributes ----
  country <- attr(.data, "country")
  nuts_level <- attr(.data, "nuts_level")
  ## Filter group of countries if nuts_level was country ----
  if (nuts_level == 0) {
    if (!is.null(geo_total)) {
      # countries_in_total <- tbl(con2, "dt_geo") |>
      #   filter(!!rlang::sym(tolower(geo_total)) == TRUE) |>
      #   pull(geo_id)
      countries_in_total <- tbl(con2, "bt_geo_group") |>
        filter(geo_group_id == geo_total) |>
        pull(geo_id)
      df0 <- df0 |>
        filter(geo_id %in% c(geo_total, countries_in_total))
      geo_total_id <- geo_total
    } else {
      stop("It is needed a geo_total code for filtering countries")
    }
    ## Get country geo_id if nuts level ----
  } else {
    if (!is.null(geo_total)) {
      message("geo_total is ignored as nuts_level is not country")
    }
    if (nuts_level %in% 1:4) {
      geo_total_id <- tbl(con2, "dt_geo") |>
        filter(iso2_code == country) |>
        pull(geo_id)
    } else if (nuts_level == 99) {
      geo_total_id <- "INSTO"
      .source_id <- "INSTO"
    }
  }

  ## Compute total destinations aggregated indicator ----
  # dftotal <- df0 |>
  #   group_by(date, period_id, indicator_id) |>
  #   summarise(
  #     indicator_value = do.call(
  #       aggregation_function,
  #       list(indicator_value, na.rm = TRUE)
  #     ),
  #     .groups = "drop"
  #   ) |>
  #   mutate(total = TRUE, geo_id = geo_total_id)

  ## Join indicator values with total, get direction, rename value ----
  df0 <- df0 |>
    # bind_rows(dftotal) |>
    inner_join(
      tbl(con2, "dt_indicators") |>
        select(indicator_id, indicator_direction) |>
        collect(),
      by = "indicator_id"
    ) |>
    inner_join(
      tbl(con2, "bt_indicator_subdimension") |>
        filter(source_id == .source_id) |>
        select(indicator_id, dimension_id) |>
        collect(),
      by = c("indicator_id")
    ) |>
    rename(value = indicator_value)

  df <- scale_indicator(
    df0,
    scaling_method = scaling_method,
    refvalueq = refvalueq,
    scaling_type = scaling_type
  )
  return(df)
}


#' Get data for plotting a map
#'
#' Gets the data for the map filtered by a given period
#'
#' @param .data a data.frame with a row per geography and period and the values of a variable, an indicator (possibly scaled) or a composite indicator.
#' @param .date An ISO date for the period to be represented (optional; if NULL, no date filtering is applied)
#' @param value_type type of value to be represented (variable, indicator, dimension)
#' @param type_id id of the type of value to be represented
#' @param bins Number of bins in the discrete legend
#'
#' @returns an sf object with one row per geography at a given time point
#' @export
#'
#' @examples
#' ## LEVEL 0
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#'
#' dfmap <- dfcomp |> get_map_data(lan = "es")
#'
#' ## LEVEL 2
#' selected_source <- "EVASTUR"
#' selected_nuts <- 2
#' selected_location <- "ES"
#' selected_group <- "ESP"
#' selected_date <- "2013-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#'
#' dfmap <- dfcomp |> get_map_data(lan = "es")
get_map_data <- function(
  .data,
  .date = NULL,
  value_type = "dimension",
  type_id = "GLOBAL",
  bins = getOption("evastur.map_bins"),
  lan
) {
  if (is.null(.data)) {
    warning("No data for the map")
    return(NULL)
  }

  df <- .data |>
    filter(
      if (!is.null(.date)) date == .date else TRUE,
      !!rlang::sym(paste0(value_type, "_id")) == type_id,
      total == FALSE
    ) |>
    left_join(
      tbl(con2, "dt_geo") |>
        select(geo_id, geometry) |>
        inner_join(
          tbl(con2, "lt_geo") |>
            filter(geo_lang == lan) |>
            select(geo_id, geo_label),
          by = "geo_id"
        ) |>
        collect(),
      by = "geo_id"
    ) |>
    replace_na(list(geometry = "POLYGON EMPTY"))

  df$value[is.nan(df$value)] <- NA

  quartiles <- quantile(df$value, probs = seq(0, 1, 1 / bins), na.rm = TRUE)
  if (anyDuplicated(quartiles)) {
    if (length(unique(quartiles)) == 1) {
      df$quartile <- as.character(round(unique(quartiles), 2))
    } else {
      df$quartile <- paste(range(df$value), collapse = " - ")
    }
  } else {
    df <- df |>
      mutate(
        quartile = cut(
          value,
          breaks = quartiles,
          include.lowest = TRUE,
          labels = FALSE
        )
      )
  }
  df |> sf::st_as_sf(wkt = "geometry")
}

#' Get available sources
#'
#' Gets the available sources in the indicators table
#'
#' @returns a vector with the sources ids
#' @export
#'
#' @examples
#' get_available_sources()
get_available_sources <- function() {
  tbl(con2, "ft_indicators") |>
    distinct(source_id) |>
    inner_join(
      tbl(con2, "dt_sources"),
      by = "source_id"
    ) |>
    arrange(source_order) |>
    pull(source_id)
}


#' Documentation tables
#'
#' @param data_type type of data (indicator, variable, source)
#' @param type_id id of the type of data
#'
#' @returns list with documentation about variables or indicators or source
#' @export
#'
#' @examples
#' list_tables <- documentation_tables("indicator", "ISOC0001")
#' list_tables <- documentation_tables("indicator", "IECO0001")
#' list_tables <- documentation_tables("variable", "VGAS0001", "en")
#' list_tables <- documentation_tables("variable", "VCUS0001", "es")
#' list_tables <- documentation_tables(data_type = "source",
#'                                     type_id = "INE-EGATUR",
#'                                     lang = "en")
#'
#'
documentation_tables <- function(
  data_type = c("indicator", "variable", "source"),
  type_id,
  lang = "es"
) {
  # Define tables and columns according to data type
  config <- list(
    variable = list(
      tablename = c(
        "bt_variable_source",
        "bt_indicator_variable",
        "lt_variables",
        "dt_variables"
      ),
      colSym = rlang::sym("variable_id"),
      lanSym = rlang::sym("variable_lang"),
      bt_lt_tables = c("lt_sources", "lt_indicators")
    ),
    indicator = list(
      tablename = c(
        "bt_indicator_source",
        "lt_indicators",
        "bt_indicator_variable",
        "bt_indicator_subdimension",
        "bt_indicator_ods",
        "dt_indicators",
        "bt_indicator_similarity"
      ),
      colSym = rlang::sym("indicator_id"),
      lanSym = rlang::sym("indicator_lang"),
      bt_lt_tables = c(
        "lt_sources",
        "lt_variables",
        "lt_subdimensions",
        "lt_dimensions",
        "lt_ods",
        "lt_similarity_levels"
      )
    ),
    source = list(
      tablename = c("lt_sources", "bt_variable_source", "dt_sources"),
      colSym = rlang::sym("source_id"),
      lanSym = rlang::sym("source_lang"),
      bt_lt_tables = c("lt_sources", "lt_variables")
    )
  )

  if (!(data_type %in% names(config))) {
    warning("To be implemented")
    return(NULL)
  }

  # Extract configuration according to data_type
  cfg <- config[[data_type]]
  table_list <- list()

  for (tbl_name in cfg$tablename) {
    if (str_detect(tbl_name, "lt")) {
      table_list[[tbl_name]] <- tbl(con2, tbl_name) |>
        filter(!!cfg$colSym == type_id, !!cfg$lanSym == lang) |>
        collect()
    } else if (str_detect(tbl_name, "bt")) {
      # For the cases when the data_type is not the last item
      # in the bt table, e.g., bt_indicator_variable
      tbl_name_splitted <- str_split(tbl_name, "_")[[1]]
      if (tbl_name_splitted[3] == data_type) {
        tbl_name_splitted <- tbl_name_splitted[c(3, 1, 2)]
      }
      pattern <- tbl_name_splitted[3]
      pattern_short <- substr(
        pattern,
        ceiling(nchar(pattern) / 2),
        nchar(pattern)
      )
      name_query <- cfg$bt_lt_tables[str_detect(
        cfg$bt_lt_tables,
        pattern_short
      )]

      if (length(name_query) == 0) {
        next
      }

      bt_table <- tbl(con2, tbl_name) |>
        filter(!!cfg$colSym == type_id) |>
        collect()

      for (name_q in name_query) {
        bt_lt_table <- tbl(con2, name_q) |> collect()

        lang_col <- colnames(bt_lt_table)[str_detect(
          colnames(bt_lt_table),
          "lang"
        )]
        id_col <- colnames(bt_lt_table)[str_detect(colnames(bt_lt_table), "id")]

        if (length(lang_col) == 0 || length(id_col) == 0) {
          next
        }

        bt_lt_table <- bt_lt_table |> filter(.data[[lang_col]] == lang)
        bt_table <- bt_table |> inner_join(bt_lt_table, by = id_col)
      }

      table_list[[tbl_name]] <- bt_table
    } else {
      table_list[[tbl_name]] <- tbl(con2, tbl_name) |>
        filter(!!cfg$colSym == type_id) |>
        collect()
    }
  }

  return(table_list)
}

#' Get data for plotting a time series plot
#'
#' Gets the data for the time series plot filtered by a given destination
#'
#' @param .data a data.frame with a row per destination and period and the values of a variable, an indicator (possibly scaled) or a composite indicator.
#' @param total If TRUE, the series of the total indicator is filtered. If FALSE, then a .geo_id is needed
#' @param .geo_id a destination id
#' @param value_type type of value to be represented (variable, indicator, dimension)
#' @param type_id id of the type of value to be represented
#' @param lan language
#' @param source Source
#'
#' @returns a data.frame with one row per period for a given destination
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#' get_series_data(dfcomp, lan = "es", source = selected_source)
get_series_data <- function(
  .data,
  total = TRUE,
  .geo_id = NULL,
  value_type = "dimension",
  type_id = NULL,
  lan,
  source
) {
  if (is.null(.data)) {
    warning("No data for the series plot")
    return(NULL)
  }
  if (is.null(type_id)) {
    type_id <- .data |>
      distinct(get(paste0(value_type, "_id"))) |>
      pull()
  }
  if (!total & is.null(.geo_id)) {
    warning("Either total = TRUE or a .geo_id are needed")
    return(NULL)
  }
  if (total) {
    df <- .data |>
      filter(total == TRUE)
  } else {
    df <- .data |>
      filter(
        geo_id == .geo_id,
        !!rlang::sym(paste0(value_type, "_id")) %in% type_id
      ) #|>
  }

  df |>
    inner_join(
      get_dims(lan = lan, source = source, global = TRUE),
      by = paste0(value_type, "_id")
    )
}

#' Get geographical area groups
#'
#' Only for getting countries (nuts level = 0) or groups of countries (nuts level = 101)
#'
#' @param .nuts_level NUTS level
#' @param lan Language
#'
#' @returns Data.frame with the groups (countries or regions in country)
#' @export
#'
#' @examples
#' get_geo_groups(101, "es")
#' get_geo_groups(0, "es")
get_geo_groups <- function(.nuts_level, lan) {
  if (!(.nuts_level %in% c(0, 101))) {
    stop("nuts level must be 0 or 101")
  }
  con2 |>
    tbl("dt_geo") |>
    filter(nuts_level == .nuts_level, geo_active == TRUE) |>
    inner_join(
      tbl(con2, "lt_geo") |>
        filter(geo_lang == lan),
      by = c("geo_id")
    ) |>
    arrange(geo_order, geo_label) |>
    select(nuts_level, geo_id, geo_label) |>
    collect()
}

# TODO: retrieve custom groups from a new column in dt_geo
#' Get custom geographical groups
#'
#' Returns only country groups with geo_id starting with "GCUS"
#'
#' @param lan Language code
#' @returns Data.frame with custom groups (geo_ids starting with GCUS)
#' @export
#'
#' @examples
#' get_custom_geo_groups("es")
#' get_custom_geo_groups("en")
get_custom_geo_groups <- function(lan) {
  con2 |>
    tbl("dt_geo") |>
    filter(geo_active == TRUE, str_detect(geo_id, "^GCUS")) |>
    inner_join(
      tbl(con2, "lt_geo") |>
        filter(geo_lang == lan),
      by = c("geo_id")
    ) |>
    arrange(geo_order, geo_label) |>
    select(nuts_level, geo_id, geo_label) |>
    collect()
}

#' Get label of a geographies group
#'
#' Returns the geographies group label in the provided language
#'
#' #' @note
#' If there is no label in the language, then the id is returned as label
#'
#' @param lan language
#' @param group_id group id
#'
#' @returns a string with the group label in the selected language
#' @export
#'
#' @examples
#' get_geo_group_label("es", "OECD")
#' get_geo_group_label("en", "ASEAN")
#' get_geo_group_label("pt", "ASEAN")
get_geo_group_label <- function(lan, group_id) {
  res <- con2 |>
    tbl("lt_geo") |>
    filter(geo_lang == lan, geo_id == group_id) |>
    pull(geo_label)

  if (length(res) == 0) {
    group_id
  } else {
    res
  }
}


#' Get geography label
#'
#' Returns the label of a geography in a given language given its id.
#'
#' @note
#' If there is no label in the language, then the id is returned as label
#'
#' @param geo_ids vector of ids to get the labels
#' @param lan language
#' @param geo_group id of the group, if any
#'
#' @returns named vector with ids and labels
#' @export
#'
#' @examples
#' get_geo_label("ESP", "en")
#' get_geo_label(c("_TOTAL_", "ESP", "FRA", "PRT"), "en", "OECD")
get_geo_label <- function(geo_ids, lan, geo_group = NULL) {
  # Save the geo selected input as a vector
  # geo_ids <- input$pi_geo_selected
  # If the total group is provided, use its id
  if (!is.null(geo_group)) {
    geo_ids[geo_ids == "_TOTAL_"] <- geo_group
  }
  # Get the names of the selected geographies from database
  geo_labels <- con2 |>
    tbl("lt_geo") |>
    filter(geo_lang == lan, geo_id %in% geo_ids) |>
    inner_join(tbl(con2, "dt_geo"), by = "geo_id") |>
    arrange(geo_order) |>
    select(geo_id, geo_label) |>
    collect()
  setNames(geo_labels$geo_label, geo_labels$geo_id)
}

#' Get ISO2 code of a country by its id
#'
#' @param id geography code in dt_geo
#'
#' @returns The iso code of the geography
#' @export
#'
#' @examples
#' get_iso2_code("ESP")
#' get_iso2_code("WLD")
#' get_iso2_code("AAAA")
get_iso2_code <- function(id) {
  con2 |>
    tbl("dt_geo") |>
    filter(geo_id == id) |>
    pull(iso2_code)
}

#' Get territorial units
#'
#' Gets data frame with codes and names of territorial units given a language
#' and a country location
#'
#' @note
#' The codes 1 to 9 of territorial units (nuts) are reserved for
#' within-country territorial divisions.
#'
#' @param lan language
#' @param loc country iso2 code
#'
#' @returns data.frame with columns nuts_level_id, nuts_level_name
#' @export
#'
#' @examples
#' get_geo_nuts("es", "ES")
#' get_geo_nuts("en", "UK")
get_geo_nuts <- function(lan, loc) {
  locs <- con2 |>
    tbl("lt_nuts_levels") |>
    distinct(nuts_level_country) |>
    pull()
  if (!loc %in% locs) {
    loc <- "00"
  }
  con2 |>
    tbl("dt_nuts_levels") |>
    ## TODO: Document somewhere else that 1:9 is reserved for within country
    ## territorial divisions
    filter(nuts_level_id %in% 1:9) |>
    inner_join(
      tbl(con2, "lt_nuts_levels") |>
        filter(nuts_level_lang == lan, nuts_level_country == loc),
      by = "nuts_level_id"
    ) |>
    arrange(nuts_level_order) |>
    select(nuts_level_id, nuts_level_name) |>
    collect()
}

#' Gets nuts label
#'
#' @param level nuts level
#' @param lan language
#' @param loc location (ISO2 country code)
#'
#' @returns the label, specific if the country is available, generic if not
#' @export
#'
#' @examples
#' get_nuts_label(2, "en", "ES")
#' get_nuts_label(2, "en", "FR")
get_nuts_label <- function(level, lan, loc) {
  lt_nuts_levels <- con2 |>
    tbl("lt_nuts_levels") |>
    filter(nuts_level_id == level, nuts_level_lang == lan) |>
    collect()
  if (!(loc %in% lt_nuts_levels$nuts_level_country)) {
    loc <- "00"
  }
  lt_nuts_levels |>
    filter(nuts_level_country == loc) |>
    pull(nuts_level_label)
}

#' Get Geographies
#'
#' Gets a data.frame of geographies for selections
#'
#' @param .nuts_level NUTS level (0 for countries, NULL for groups)
#' @param lan language
#' @param group geography group id
#' @param .nuts_level_inner NUTS level for countries when .nuts_level is 0
#'
#' @returns a data.frame
#' @export
#'
#' @examples
#' get_geos(0, "en", "ESP")
#' get_geos(101, "en", "WLD")
#' get_geos(101, "en", "OECD")
#' get_geos(NULL, "en", "OECD")
#' get_geos(NULL, "en", "INSTO")
get_geos <- function(
  .nuts_level_group,
  lan,
  group,
  .nuts_level_inner = getOption("evastur.default_geo_nuts_id")
) {
  tbl0 <- con2 |>
    tbl("dt_geo") |>
    filter(geo_active == TRUE) |>
    inner_join(
      tbl(con2, "lt_geo") |>
        filter(geo_lang == lan),
      by = c("geo_id")
    )
  if (is.null(.nuts_level_group)) {
    tbl1 <- tbl0 |>
      inner_join(
        con2 |>
          tbl("bt_geo_group") |>
          filter(geo_group_id == group),
        by = "geo_id"
      )
  } else if (.nuts_level_group == 0) {
    if ((tolower(group) %in% colnames(tbl0))) {
      return(NULL)
    } else {
      tbl1 <- tbl0 |>
        filter(
          country_iso2_code == !!get_iso2_code(group),
          nuts_level == .nuts_level_inner
        )
    }
  } else {
    stop("nuts level must be 0 or NULL")
  }

  # if(.nuts_level == 0){
  # } else if (.nuts_level == 101){
  #   if(!(tolower(group) %in% colnames(tbl0))){
  #     return(NULL)
  #   } else{
  #   }
  # } else if (.nuts_level == 99){
  #   tbl1 <- tbl0 |>
  #     filter(nuts_level == .nuts_level)
  # }
  tbl1 |>
    arrange(geo_order, geo_label) |>
    select(
      geo_id,
      geo_label,
      geo_name,
      geo_description,
      nuts_level,
      country_iso2_code
    ) |>
    collect()
}


#' Get dimensions
#'
#' Gets dimensions from the database
#'
#' @param lan language code (char)
#' @param source source code (char)
#' @param global whether to include the global dimension or not
#'
#' @returns data frame with the dimensions with their texts
#' @export
#'
#' @examples
#' get_dims("es", "EVASTUR", TRUE)
#' get_dims("es", "EVASTUR", FALSE)
#' get_dims("en", "EVASTUR", FALSE)
#' get_dims("en", "ETIS", FALSE)
#' get_dims("en", "INSTO", FALSE)
get_dims <- function(lan, source, global) {
  con2 |>
    tbl("v_dimensions_sel") |>
    filter(
      dimension_lang == lan,
      source_id == source,
      ifelse(global, TRUE, dimension_id != "GLOBAL")
    ) |>
    collect()
}


#' Variables used by indicators in a dimension
#'
#' @param dim dimension id
#' @param source source id
#'
#' @returns A vector with unique variable ids
#' @export
#'
#' @examples
#' vars_in_dim("ECO", "EVASTUR")
#' vars_in_dim("GLOBAL", "EVASTUR")
vars_in_dim <- function(dim, source) {
  tbl0 <- con2 |>
    tbl("dt_variables") |>
    select(variable_id) |>
    left_join(
      tbl(con2, "bt_indicator_variable"),
      by = "variable_id"
    ) |>
    left_join(
      tbl(con2, "bt_indicator_subdimension") |>
        filter(source_id == source),
      by = "indicator_id"
    )
  if (dim != "GLOBAL") {
    tbl0 <- tbl0 |>
      filter(dimension_id == dim)
  }
  tbl0 |>
    distinct(variable_id) |>
    pull(variable_id) |>
    str_subset("^INSTO", negate = TRUE)
}

#' Indicators within a dimension
#'
#' @param dim dimension id
#' @param source source id
#'
#' @returns A vector with unique indicator ids
#' @export
#'
#' @examples
#' inds_in_dim(dim = "ECO", source = "EVASTUR")
#' inds_in_dim(dim = "GLOBAL", source = "EVASTUR")
inds_in_dim <- function(dim, source) {
  tbl0 <- con2 |>
    tbl("bt_indicator_subdimension") |>
    filter(source_id == source)
  if (dim != "GLOBAL") {
    tbl0 <- tbl0 |>
      filter(dimension_id == dim)
  }
  tbl0 |> distinct(indicator_id) |> pull(indicator_id)
}

#' Get indicators data.frame for selections
#'
#' If dimension is GLOBAL, then all the indicators of the source is shown
#'
#' @param dim dimension
#' @param source indicators source
#' @param lan language
#'
#' @returns a data.frame with the labels of the indicators
#' @export
#'
#' @examples
#' get_inds("ECO", "EVASTUR", "es")
#' get_inds("GLOBAL", "EVASTUR", "en")
get_inds <- function(dim, source, lan) {
  tbl0 <- con2 |>
    tbl("bt_indicator_subdimension") |>
    filter(source_id == source)
  if (dim != "GLOBAL") {
    tbl0 <- tbl0 |>
      filter(dimension_id == dim)
  }
  tbl0 |>
    distinct(indicator_id) |>
    inner_join(
      tbl(con2, "lt_indicators") |>
        filter(indicator_lang == lan),
      by = "indicator_id"
    ) |>
    collect()
}

#' Next automatic Id for dimensional tables given a prefix
#'
#' This is intended for indicator system management, i.e.,
#' provide automatic incremental "custom" variable and indicator Ids,
#' but can be eventually used for any other dimensional table (dt_*)
#' with some refactoring
#'
#' @param what entity: variable, indicator, geo, ...
#' @param prefix The prefix for the id
#'
#' @returns string with the next custom id code
#' @export
#'
#' @examples
#' next_id("variable", "VCUS")
#' next_id("indicator", "ICUS")
#' next_id("indicator", "IECO")
#' next_id("geo", "GCUS")
next_id <- function(what = c("variable", "indicator", "geo"), prefix) {
  idcolumn <- glue::glue("{what}_id")
  if (what == "geo") {
    # TODO: refactor this
    tablename <- glue::glue("dt_{what}")
  } else {
    tablename <- glue::glue("dt_{what}s")
  }
  prefix_wildcard <- glue::glue("{prefix}%")
  last_id <- con2 |>
    tbl(tablename) |>
    filter(!!rlang::sym(idcolumn) %like% prefix_wildcard) |>
    pull(matches(idcolumn)) |>
    max() |>
    str_sub(nchar(prefix) + 1, -1)
  if (is.na(last_id)) {
    last_id <- 0
  }
  paste0(
    prefix,
    str_pad(1 + as.numeric(last_id), width = 4, pad = "0")
  )
}


#' Get indicators count
#'
#' Count the number of available indicators per geographic unit by dimension and data source.
#'
#' @param .data A data frame containing indicator data with columns: geo_id, indicator_id, date
#' @param geo_total Geographic total code for filtering countries (required when nuts_level is 0)
#' @param .dimension Tourism dimension to filter by (default: "GLOBAL" for all ECO/ENV/SOC dimensions)
#'
#' @return A data frame with one row per geography, containing:
#' - geo_id: Geographic identifier
#' - value: Count of distinct indicators for the geography
#' - date: Latest date considered for the geography
#' - dimension_id: Dimension identifier (e.g., "ECO", "ENV", "SOC")
#' - total: FALSE, as it refers to individual geographies
#'
#' @details
#' The function joins with dimension metadata, counts distinct indicators per geography, and
#' results with the latest date from the aggregated count.
#'
#' @export
#'
#' @examples
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "EU27_2020"
#' selected_date <- "2013-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' nindicators <- get_indicators_count(dfind, geo_total = selected_group)
get_indicators_count <- function(
  .data,
  geo_total = NULL,
  .dimension = "GLOBAL"
) {
  ## Get all data ----
  df0 <- .data

  ## Extract data attributes ----
  nuts_level <- attr(.data, "nuts_level")
  country <- attr(.data, "country")

  ## Get all geo_ids based on NUTS level ----
  all_geo_ids <- NULL

  ## For countries: get from geo_group table ----
  if (nuts_level == 0) {
    if (is.null(geo_total)) {
      stop("It is needed a geo_total code for filtering countries")
    }

    all_geo_ids <- tbl(con2, "bt_geo_group") |>
      filter(geo_group_id == geo_total) |>
      collect() |>
      distinct(geo_id)

    df0 <- df0 |> filter(geo_id %in% all_geo_ids$geo_id)

    ## For sub-national areas (NUTS 1-4): get from dt_geo table ----
  } else if (nuts_level %in% 1:4) {
    if (is.null(country)) {
      warning(
        "For nuts level ",
        nuts_level,
        " it is needed to supply a country"
      )
    } else {
      all_geo_ids <- tbl(con2, "dt_geo") |>
        filter(
          nuts_level == !!nuts_level,
          country_iso2_code == country,
          geo_active == TRUE
        ) |>
        collect() |>
        distinct(geo_id)

      df0 <- df0 |> filter(geo_id %in% all_geo_ids$geo_id)
    }
  }

  ## Create dimension filter (same logic as module_indicators_map.R) ----
  dimension_filter <- if (.dimension == "GLOBAL") {
    c("ECO", "ENV", "SOC")
  } else {
    .dimension
  }

  ## Join with dimension data and count indicators ----
  dimension_data <- tbl(con2, "bt_indicator_subdimension") |>
    filter(dimension_id %in% dimension_filter) |>
    select(indicator_id, dimension_id) |>
    collect()

  counts <- df0 |>
    inner_join(dimension_data, by = "indicator_id") |>
    group_by(geo_id) |>
    summarise(
      value = n_distinct(indicator_id),
      date = if (all(is.na(date))) as.Date(NA) else max(date, na.rm = TRUE),
      .groups = "drop"
    )

  ## Fill with 0 for geographies with no indicators ----
  if (!is.null(all_geo_ids)) {
    result <- all_geo_ids |>
      left_join(counts, by = "geo_id") |>
      mutate(value = coalesce(value, 0L))
  } else {
    result <- counts
  }

  ## Add metadata columns ----
  result |>
    mutate(
      dimension_id = .dimension,
      total = FALSE
    )
}

#' Get valid time periods from DB
#'
#' Gets valid time periods and their numerical order
#'
#' @returns Table dt_periods from DB
#' @export
#'
#' @examples
#' get_dt_periods()
get_dt_periods <- function() {
  dt_periods <-
    con2 |>
    tbl("dt_periods") |>
    collect()
}


#' Get data table of variables from DB
#'
#' Get variable information and aggregation
#'
#' @returns Table dt_variables from DB
#' @export
#'
#' @examples
#' get_dt_variables()
get_dt_variables <- function() {
  con2 |>
    tbl("dt_variables") |>
    collect()
}


#' Get data table of aggregation functions from DB
#'
#' Get aggregation information to link R and SQL code
#'
#' @returns Table dt_aggregations from DB
#' @export
#'
#' @examples
#' get_dt_aggregations()
get_dt_aggregations <- function() {
  dt_aggregations <-
    con2 |>
    tbl("dt_aggregations") |>
    collect()
}


#' Get bt_indicator_variable from DB
#'
#' Provide a tibble with indicator IDs and their associated variable IDs
#'
#' @returns Table bt_indicator_variable from DB
#' @export
#'
#' @examples
#' get_bt_indicator_variable()
get_bt_indicator_variable <- function() {
  bt_indicator_variable <-
    con2 |>
    tbl("bt_indicator_variable") |>
    collect()
}


#' Get dt_indicators from DB
#'
#' Provide a tibble with indicator IDs, their name and their formula
#'
#' @returns Table dt_indicators from DB
#' @export
#'
#' @examples
#' get_dt_indicators()
get_dt_indicators <- function() {
  con2 |>
    tbl("dt_indicators") |>
    collect()
}


#' Get bt_periods_parents from DB
#'
#' Provide a table with valid periods and their relation with superior periods
#' For example, period_i = M, period_parent = Y and n_periods = 12
#'
#' @returns Table bt_periods_parents from DB
#' @export
#'
#' @examples
#' get_bt_periods_parents()
get_bt_periods_parents <- function() {
  DBI::dbReadTable(con2, "bt_periods_parents")
}


#' Insert geographies into a geographic group
#'
#' Inserts one or more geography IDs into a specified geographic group in the
#' bt_geo_group table. Conflicts are ignored, so existing records are not duplicated.
#'
#' @param geo_ids vector of geography IDs to insert into the group
#' @param geo_group_id geographic group identifier
#'
#' @returns result of rows_insert
#' @export
#'
#' @examples
#' \dontrun{
#' insert_geo_group(c("USA", "CAN", "MEX"), "GCUS0001")
#' }
insert_geo_group <- function(geo_ids, geo_group_id) {
  tbl(con2, "bt_geo_group") |>
    rows_insert(
      tibble(
        geo_id = geo_ids,
        geo_group_id = geo_group_id
      ),
      by = c("geo_id", "geo_group_id"),
      conflict = "ignore",
      in_place = TRUE,
      copy = TRUE
    )
}

#' Delete geographies from a geographic group
#'
#' Deletes one or more geography IDs into a specified geographic group in the
#' bt_geo_group table. Conflicts are ignored, so existing records are not duplicated.
#'
#' @param geo_ids vector of geography IDs to delete into the group
#' @param geo_group_id geographic group identifier
#'
#' @returns result of rows_delete
#' @export
#'
#' @examples
#' \dontrun{
#' delete_geo_group(c("USA", "CAN", "MEX"), "GCUS0001")
#' }
delete_geo_group <- function(geo_ids, geo_group_id) {
  tbl(con2, "bt_geo_group") |>
    rows_delete(
      tibble(
        geo_id = geo_ids,
        geo_group_id = geo_group_id
      ),
      by = c("geo_id", "geo_group_id"),
      unmatched = "ignore",
      in_place = TRUE,
      copy = TRUE
    )
}


#' Add a custom geography group
#'
#' Creates a new custom geography entry in both the dt_geo and lt_geo tables.
#' The geography is created with specified NUTS level and empty polygon geometry.
#' Localization entries are created for both English and Spanish using the same text.
#'
#' @param geo_id string identifying the new geography group
#' @param geo_name string with the full name for the geography group
#' @param geo_label string with the short label for the geography group
#' @param geo_description string with the description for the geography group
#' @param nuts_level integer specifying the NUTS level
#'
#' @return The geo_id of the created geography group
#'
#' @examples
#' \dontrun{
#' add_custom_geo_group("GCUS0001", "South Europe", "South Europe", "South Europe", 101)
#' }
add_custom_geo_group <- function(
  geo_id,
  geo_name,
  geo_label,
  geo_description,
  nuts_level
) {
  tbl(con2, "dt_geo") |>
    rows_insert(
      tibble(
        geo_id = geo_id,
        geo_original_name = geo_name,
        nuts_level = nuts_level,
        geo_order = 9,
        geometry = "POLYGON EMPTY",
        geo_active = TRUE
      ),
      conflict = "ignore",
      in_place = TRUE,
      copy = TRUE
    )

  tbl(con2, "lt_geo") |>
    rows_upsert(
      tibble(
        geo_id = geo_id,
        geo_lang = "en",
        geo_name = geo_name,
        geo_label = geo_label,
        geo_description = geo_description
      ),
      by = c("geo_id", "geo_lang"),
      in_place = TRUE,
      copy = TRUE
    )

  tbl(con2, "lt_geo") |>
    rows_upsert(
      tibble(
        geo_id = geo_id,
        geo_lang = "es",
        geo_name = geo_name,
        geo_label = geo_label,
        geo_description = geo_description
      ),
      by = c("geo_id", "geo_lang"),
      in_place = TRUE,
      copy = TRUE
    )

  return(geo_id)
}

#' Update a custom geography group
#'
#' Updates an existing custom geography entry in both the dt_geo and lt_geo tables.
#' Updates the metadata and localization entries for both English and Spanish.
#'
#' @param geo_id string identifying the geography group to update
#' @param geo_name string with the full name for the geography group
#' @param geo_label string with the short label for the geography group
#' @param geo_description string with the description for the geography group
#' @param nuts_level integer specifying the NUTS level
#'
#' @return The geo_id of the updated geography group
#' @export
#'
#' @examples
#' \dontrun{
#' update_custom_geo_group("GCUS0001", "Southern Europe", "S. Europe", "Southern European countries", 101)
#' }
update_custom_geo_group <- function(
  geo_id,
  geo_name,
  geo_label,
  geo_description,
  nuts_level
) {
  tbl(con2, "dt_geo") |>
    rows_update(
      tibble(
        geo_id = geo_id,
        geo_original_name = geo_name,
        nuts_level = nuts_level
      ),
      by = "geo_id",
      in_place = TRUE,
      copy = TRUE,
      unmatched = "ignore"
    )

  tbl(con2, "lt_geo") |>
    rows_update(
      tibble(
        geo_id = geo_id,
        geo_lang = "en",
        geo_name = geo_name,
        geo_label = geo_label,
        geo_description = geo_description
      ),
      by = c("geo_id", "geo_lang"),
      in_place = TRUE,
      copy = TRUE,
      unmatched = "ignore"
    )

  tbl(con2, "lt_geo") |>
    rows_update(
      tibble(
        geo_id = geo_id,
        geo_lang = "es",
        geo_name = geo_name,
        geo_label = geo_label,
        geo_description = geo_description
      ),
      by = c("geo_id", "geo_lang"),
      in_place = TRUE,
      copy = TRUE,
      unmatched = "ignore"
    )

  return(geo_id)
}

#' Delete a custom geography group
#'
#' Deletes a custom geography entry from dt_geo, lt_geo (all languages),
#' and bt_geo_group tables.
#'
#' @param geo_id string identifying the geography group to delete
#'
#' @return TRUE if successful
#' @export
#'
#' @examples
#' \dontrun{
#' delete_custom_geo_group("GCUS0001")
#' }
delete_custom_geo_group <- function(geo_id) {
  tryCatch({
    DBI::dbWithTransaction(con2, {
      # Delete member associations from bt_geo_group
      DBI::dbExecute(con2, "DELETE FROM bt_geo_group WHERE geo_group_id = $1", params = list(geo_id))
      # Delete ALL language translations from lt_geo
      DBI::dbExecute(con2, "DELETE FROM lt_geo WHERE geo_id = $1", params = list(geo_id))
      # Delete main record from dt_geo
      DBI::dbExecute(con2, "DELETE FROM dt_geo WHERE geo_id = $1", params = list(geo_id))
    })
    return(TRUE)
  }, error = function(e) {
    warning("Error deleting custom geo group: ", e$message)
    return(FALSE)
  })
}

#' Get country form selected language
#'
#' @param lan Language code
#'
#' @returns a list with elements df and selected
#' @export
#'
#' @examples
#' get_country_from_language("es")
get_country_from_language <- function(lan) {
  dflocations <- con2 |>
    tbl("dt_locations") |>
    arrange(location_order, location_id) |>
    collect()
  locations_by_lan <- dflocations |>
    filter(default_lan == lan) |>
    arrange(location_order) |>
    collect()

  if (nrow(locations_by_lan) > 0) {
    selected <- locations_by_lan |>
      slice(1) |>
      pull(location_id)
  } else {
    selected <- getOption("evastur.default_location")
  }

  return(list(df = dflocations, selected = selected))
}

#' Get sources available in a fact table
#'
#' @param table_name Name of the table
#' @return character vector with the sources
#' @export
#'
#' @examples
#' available_sources("ft_variables")
available_sources <- function(table_name) {
  sources <- tbl(con2, table_name) |> # get data from the table ft_variables
    collect() |>
    pull(source_id) |>
    unique()

  message("Available sources of data table ", table_name, ":")
  sources
}

#' Get computable indicators given a set of variables
#'
#' This function returns a vector of indicator that can be computed
#' with the variables provided as argument
#'
#' @param vars Vector of variable IDs.
#'
#' @returns A vector of indicators IDs.
#'
#' @export
#' @examples
#' \dontrun{
#' get_dt_variables() |> pull(variable_id) |> get_computable_inds()
#' }
get_computable_inds <- function(vars) {
  get_bt_indicator_variable() |>
    group_by(indicator_id) |>
    filter(all(variable_id %in% vars)) |>
    ungroup() |>
    distinct(indicator_id) |>
    pull(indicator_id)
}

#' Get indicators metadata
#'
#' This function returns the metadata needed to compute indicators from variables,
#' i.e., the formula, the involved variables, and the aggregation functions for
#' each involved variable.
#'
#' @param inds Vector of indicators to get the metadata for.
#' @param summarised Whether to return a summarised data frame with list columns
#'
#' @returns A data frame with columns:
#' * indicator_id
#' * indicator_formula
#' * vars: list column (if summarised) with variables IDs. Otherwise, one row per variable.
#' * funs_geo: list column with variables geo aggregation functions
#' * funs_time: list column with variables time aggregation functions
#'
#' @export
#' @examples
#' \dontrun{
#' get_dt_variables() |>
#'   pull(variable_id) |>
#'   get_computable_inds() |>
#'   get_indicators_metadata()
#' }
get_indicators_metadata <- function(inds, summarised = TRUE) {
  df_full <- con2 |>
    tbl("dt_indicators") |>
    filter(indicator_id %in% inds, indicator_active) |>
    select(indicator_id, indicator_formula) |>
    inner_join(
      con2 |>
        tbl("bt_indicator_variable") |>
        inner_join(
          con2 |>
            tbl("dt_variables") |>
            select(
              variable_id,
              variable_aggregation_time,
              variable_aggregation_geo
            ) |>
            inner_join(
              con2 |>
                tbl("dt_aggregations") |>
                select(aggregation_id, ag_time_fun = aggregation_rfunction),
              by = c("variable_aggregation_time" = "aggregation_id")
            ) |>
            inner_join(
              con2 |>
                tbl("dt_aggregations") |>
                select(aggregation_id, ag_geo_fun = aggregation_rfunction),
              by = c("variable_aggregation_geo" = "aggregation_id")
            ),
          by = "variable_id"
        ),
      by = "indicator_id"
    ) |>
    collect()

  if (summarised) {
    df_full |>
      group_by(indicator_id, indicator_formula) |>
      summarise(
        vars = list(variable_id),
        funs_geo = list(ag_geo_fun),
        funs_time = list(ag_time_fun),
        .groups = "drop"
      )
  } else {
    df_full
  }
}


#' Get imputation flags
#' 
#' This function retrieves the imputation flags used in the provided data frame and returns their labels in the specified language. It extracts the unique flag IDs from the variable_value_flags column, filters the lt_flags table for those IDs and the given language, and returns a data frame with flag_id and flag_name.
#'
#' @param .data A data frame containing a column variable_value_flags with the flags used in the data. The flags are expected to be in the format "{flag1,flag2,...}" or NA.
#' @param lan Language code to filter the flags (e.g., "en", "es").
#'
#' @returns A data frame with columns flag_id and flag_name for the flags used in the data and available in the specified language.
#'
#' @export
#' @examples
#' dd <- con2 |>
#'   tbl("ft_variables") |>
#'   filter(geo_id == "ESP") |>
#'   collect()
#' get_imputation_flags(dd, "es")
get_imputation_flags <- function(.data, lan) {
  ff <- con2 |> tbl("lt_flags") |> filter(indicator_lang == lan)
  used_flags <- .data |>
    mutate(
      flags = case_when(
        is.na(variable_value_flags) ~ NA, 
        variable_value_flags == "{}" ~ list(character(0)), 
        TRUE ~ str_remove_all(variable_value_flags, "^\\{|\\}$") |> 
          str_split(",") |> 
          map(~.x) 
      )
    ) |>
    select(-variable_value_flags) |>
    pull(flags) |>
    unlist() |>
    unique()
  ff |> filter(flag_id %in% used_flags) |> 
    select(flag_id, flag_name) |> 
    collect()
}