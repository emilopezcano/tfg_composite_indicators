## Module UI ----
documentation_ui <- function(id) {
  ns <- NS(id)
  tagList(
    waiter::autoWaiter(),
    navset_tab(
      nav_panel(
        title = textOutput(ns("txt_db")),
        card(uiOutput(ns("ui_vmarkdown_generator")))
      ),
      nav_panel(
        title = textOutput(ns("txt_details")),
        card(uiOutput(ns("md_details")))
      ),
      nav_panel(
        title = textOutput(ns("txt_coverage")),
        card(uiOutput(ns("ui_coverage")))
      )
    )
  )
}

## Module Server ----
documentation_server <- function(
  id,
  i18n,
  lan,
  data_type,
  type_id,
  scope,
  group,
  from_date,
  to_date,
  group_label,
  nuts_id
) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- NS(id)

      ## txt_db ----
      output$txt_db <- renderText({
        i18n()$t("Información general")
      })
      ## txt_details ----
      output$txt_details <- renderText({
        i18n()$t("Detalles")
      })
      ## txt_coverage ----
      output$txt_coverage <- renderText({
        i18n()$t("Cobertura")
      })

      ## [R] doc_data ----
      doc_data <- reactive({
        req(lan())
        req(type_id())
        documentation_tables(
          data_type = data_type,
          type_id = type_id(),
          lang = lan()
        )
      })

      ## ui_vmarkdown_generator  ----
      output$ui_vmarkdown_generator <- renderUI({
        req(lan())
        req(type_id())
        req(doc_data())
        req(i18n())

        if (data_type == "variable") {
          res_ui <- ui_var_doc(doc_data(), i18n())
          # name <- doc_data()[["lt_variables"]] |> pull(variable_name)
        } else if (data_type == "indicator") {
          res_ui <- ui_ind_doc(doc_data(), i18n())
          # name <- doc_data()[["lt_indicators"]] |> pull(indicator_name)
        } else if (data_type == "source") {
          res_ui <- ui_source_doc(doc_data(), i18n())
        }

        return(withMathJax(res_ui))
      })

      ## md_details ----
      output$md_details <- renderUI({
        if (data_type == "variable") {
          name_path <- "variables"
        } else if (data_type == "indicator") {
          name_path <- "indicadores"
        } else if (data_type == "source") {
          name_path <- "sources"
        }
        mdfile <- system.file(
          "app/txt",
          lan(),
          name_path,
          paste0(type_id(), ".md"),
          package = "evastur"
        )

        doc <- includeMarkdown(mdfile)

        if (file.exists(mdfile)) {
          doc <- includeMarkdown(mdfile)
        } else {
          doc <- i18n()$t("No hay información adicional")
        }
        return(withMathJax(doc))
      })

      ## [R] cov_data ----
      cov_data <- reactive({
        lan <- i18n()$get_translation_language()
        if (scope() == "S") {
          .nuts_level <- 0
        } else if (scope() == "N") {
          .nuts_level <- nuts_id()
        }
        if (data_type == "variable") {
          fttable <- "ft_variables"
          valueSym = rlang::sym("variable_value")
          idSym = rlang::sym("variable_id")
        } else if (data_type == "indicator") {
          fttable <- "ft_indicators"
          valueSym = rlang::sym("indicator_value")
          idSym = rlang::sym("indicator_id")
        } else if (data_type == "source") {
          fttable <- "ft_variables"
          valueSym = rlang::sym("variable_value")
          idSym = rlang::sym("source_id")
        }

        if (scope() == "S") {
          tbl_geo <- con2 |>
            tbl("v_geo_groups") |>
            filter(
              geo_lang == lan,
              nuts_level == .nuts_level,
              geo_group_id == !!group()
            ) |>
            select(geo_id, geo_label)
        } else {
          ## TODO: fix this, for scope N, it is the country code, but here we have "WLD"
          .group <- group()
          .iso2 <- get_iso2_code(.group)
          tbl_geo <- con2 |>
            tbl("v_geo_groups") |>
            filter(
              geo_lang == lan,
              nuts_level == .nuts_level,
              country_iso2_code == .iso2
            ) |>
            select(geo_id, geo_label)
        }

        .from_date <- from_date()
        .to_date <- to_date()
        tbl0 <- con2 |>
          tbl(fttable) |>
          inner_join(tbl_geo, by = "geo_id") |>
          filter(
            !!idSym == !!type_id(),
            as.Date(date) >= as.Date(.from_date),
            as.Date(date) <= as.Date(.to_date)
          )

        df0 <- tbl0 |>
          filter(!is.na(!!valueSym)) |>
          collect()

        df_first <- df0 |>
          slice_min(date) |>
          distinct(date, period_id)
        df_last <- df0 |>
          slice_max(date) |>
          distinct(date, period_id)
        df_nper <- df0 |> distinct(date) |> tally()
        df_ngeo <- df0 |> distinct(geo_id) |> tally()

        if (data_type == "source") {
          df0 <- df0 |>
            group_by(variable_id) |>
            summarise(
              rows = n(),
              geos = n_distinct(geo_id),
              dates = n_distinct(date)
            ) |>
            inner_join(
              tbl(con2, "lt_variables") |>
                filter(variable_lang == !!lan()) |>
                select(variable_id, variable_name) |>
                collect(),
              by = "variable_id"
            )
        }
        # filter(source_id == !!type_id())

        return(list(
          first = get_period(df_first$date, df_first$period_id),
          last = get_period(df_last$date, df_last$period_id),
          nper = df_nper$n,
          ngeo = df_ngeo$n,
          df = df0
        ))
      })

      ## [R] level_label ----
      level_label <- reactive({
        if (scope() == "S") {
          .label <- i18n()$t("Países")
        } else {
          .label <- get_nuts_label(
            level = nuts_id(),
            lan = lan(),
            loc = get_iso2_code(group())
          )
        }
        return(.label)
      })

      ## ui_coverage ----
      output$ui_coverage <- renderUI({
        if (data_type %in% c("variable", "indicator")) {
          tagList(
            h3(group_label()),
            h4(paste0(level_label(), ": ", cov_data()$ngeo, ".")),
            # p(paste0(
            #   cov_data()$ngeo, " ",
            #   i18n()$t("países"),
            #   "."),
            plotlyOutput(ns("barplot_geo_s")),
            reactableOutput(ns("rt_cov_geo")),
            h4(i18n()$t("Periodos")),
            p(paste0(
              i18n()$t("Desde"),
              " ",
              cov_data()$first,
              " ",
              i18n()$t("hasta"),
              " ",
              cov_data()$last,
              ", ",
              cov_data()$nper,
              " ",
              i18n()$t("periodos"),
              "."
            )),

            plotlyOutput(ns("barplot_periods_s")),
            reactableOutput(ns("rt_cov_time"))
          )
        } else {
          reactableOutput(ns("rt_cov_source"))
          # p(i18n()$t("La cobertura de datos se muestra solo para variables e indicadores."))
        }
      })

      output$rt_cov_source <- renderReactable({
        cov_data()$df |>
          select(variable_id, variable_name, rows, geos, dates) |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            columns = list(
              variable_id = colDef(
                name = ""
              ),
              variable_name = colDef(
                name = i18n()$t("Variable")
              ),
              rows = colDef(
                name = i18n()$t("Filas totales")
              ),
              geos = colDef(
                name = i18n()$t("Áreas geográficas cubiertas")
              ),
              dates = colDef(
                name = i18n()$t("Periodos cubiertos")
              )
            )
          )
      })

      output$barplot_geo_s <- renderPlotly({
        p <- cov_data()$df |>
          count(geo_id) |>
          ggplot(aes(n)) +
          geom_bar(
            fill = get_theme_color(session = session, bs_variable = "primary")
          ) +
          theme_bw() +
          labs(
            title = i18n()$t(
              "Distribución de la cobertura de áreas geográficas"
            ),
            y = i18n()$t("Número de áreas geográficas"),
            x = i18n()$t("Número de periodos")
          )

        ggplotly(p) |>
          plotly::config(displaylogo = FALSE)
      })

      output$barplot_periods_s <- renderPlotly({
        p <- cov_data()$df |>
          count(date) |>
          ggplot(aes(n)) +
          geom_bar(
            fill = get_theme_color(session = session, bs_variable = "primary")
          ) +
          theme_bw() +
          labs(
            title = i18n()$t("Distribución de la cobertura de periodos"),
            x = i18n()$t("Número de áreas geográficas"),
            y = i18n()$t("Número de periodos")
          )

        ggplotly(p) |>
          plotly::config(displaylogo = FALSE)
      })

      output$rt_cov_geo <- renderReactable({
        cov_data()$df |>
          count(geo_id, geo_label) |>
          arrange(n) |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            columns = list(
              geo_id = colDef(
                name = ""
              ),
              geo_label = colDef(
                name = i18n()$t("Área geográfica")
              ),
              n = colDef(
                name = i18n()$t("Número de Períodos")
              )
            )
          )
      })
      output$rt_cov_time <- renderReactable({
        cov_data()$df |>
          count(date) |>
          arrange(n) |>
          reactable(
            language = get_rt_lang(i18n()$get_translation_language()),
            class = "exploration-tables",
            columns = list(
              date = colDef(name = i18n()$t("Período")),
              n = colDef(
                name = i18n()$t("Número de áreas geográficas")
              )
            )
          )
      })
    }
  )
}


## Module App ----
documentation_app <- function() {
  library(shiny)
  library(shinyWidgets)
  # library(evastur)
  devtools::load_all()
  library(dplyr)
  library(shiny.i18n)

  translator <- getOption("evastur.translator")

  ui <- fluidPage(
    selectInput("si_lan", "Language", c("es", "en", "fr")),
    selectInput("si_type", "Type", c("indicator", "variable", "source")),
    geo_level_selector_ui("geo_level_selector1"),
    conditionalPanel(
      "input.si_type == 'indicator'",
      selectInput(
        "si_indicator_id",
        "Indicator",
        c("ISOC0001", "IECO0001", "IAMB0004", "IECO0014", "IECO0003", "IECO0004")
      ),
      documentation_ui("docind1")
    ),
    conditionalPanel(
      "input.si_type == 'variable'",
      selectInput("si_variable_id", "Variable", c("VVOL0001", "VENER0001")),
      documentation_ui("docvar1")
    ),
    conditionalPanel(
      "input.si_type == 'variable'",
      selectInput("si_variable_id", "Variable", c("VVOL0001", "VENER0001")),
      documentation_ui("docvar1")
    ),
    conditionalPanel(
      "input.si_type == 'source'",
      selectInput("si_source_id", "Source", c("UNWTO-STATS", "INE-EGATUR")),
      documentation_ui("docsource1")
    ),
  )

  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })

    geo_level_selector_controls <- geo_level_selector_server(
      "geo_level_selector1",
      i18n = i18n,
      lan = reactive({
        input$si_lan
      })
    )

    documentation_server(
      "docind1",
      i18n = i18n,
      lan = reactive(input$si_lan),
      data_type = "indicator",
      type_id = reactive(input$si_indicator_id),
      scope = geo_level_selector_controls$rgb_geo_scope,
      group = geo_level_selector_controls$pi_geo_group,
      from_date = reactive({
        paste0(2022 - 10 + 1, "-01-01")
      }),
      to_date = reactive({
        paste0("2022", "-12-31")
      }),
      group_label = geo_level_selector_controls$pi_geo_group
    )

    documentation_server(
      "docvar1",
      i18n = i18n,
      lan = reactive(input$si_lan),
      data_type = "variable",
      type_id = reactive(input$si_variable_id),
      scope = geo_level_selector_controls$rgb_geo_scope,
      group = geo_level_selector_controls$pi_geo_group,
      from_date = reactive({
        paste0(2022 - 10 + 1, "-01-01")
      }),
      to_date = reactive({
        paste0("2022", "-12-31")
      }),
      group_label = geo_level_selector_controls$pi_geo_group
    )
    documentation_server(
      "docsource1",
      i18n = i18n,
      lan = reactive(input$si_lan),
      data_type = "source",
      type_id = reactive(input$si_source_id),
      scope = geo_level_selector_controls$rgb_geo_scope,
      group = geo_level_selector_controls$pi_geo_group,
      from_date = reactive({
        paste0(2022 - 10 + 1, "-01-01")
      }),
      to_date = reactive({
        paste0("2022", "-12-31")
      }),
      group_label = geo_level_selector_controls$pi_geo_group
    )
  }

  shinyApp(ui, server)
}

## Run app ----
# documentation_app()
