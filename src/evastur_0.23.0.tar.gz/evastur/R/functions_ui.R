## Functions that return UI objects to be included in UI outputs
## Except tables, plots and maps that are in other scripts

#' Language picker input
#'
#' Generates the pi_language input for the UI
#'
#' @return picker input
#' @export
#'
#' @examplesIf interactive
#' language_pickerInput(getOption("evastur.translator")) |>
#'   htmltools::html_print()
language_pickerInput <- function(i18n) {
  langs <- i18n$get_languages()
  flags <- c(
    "www/img/spanish_flag.png",
    "www/img/us-uk-flag.svg",
    "www/img/france_flag.png",
    "www/img/portugal_flag.png"
  )
  labs <- paste0('<img src="', flags, '" width="20" height="15"/>&nbsp;', langs)
  pickerInput(
    inputId = "pi_language",
    inline = TRUE,
    choices = langs,
    multiple = FALSE,
    selected = i18n$get_translation_language(),
    choicesOpt = list(content = setNames(labs, langs))
  )
}

#' Sidebar generator
#'
#' Generates the right sidebar of the app. Includes a tab with the selection controls, and the "info" tab.
#' The latter is directly filled in the `app_server`` file.
#'
#' @return sidebar object
#' @author Emilio L. Cano, Javier Saugar, Natalia Madrueño, Rubén Rodríguez
#' @export
#' @examplesIf interactive
#' st_sidebar(getOption("evastur.translator"))
st_sidebar <- function(i18n) {
  sidebar(
    id = "sidebar_right",
    position = "right",
    navset_tab(
      id = "tabs_sidebar",
      nav_panel(
        title = div(
          icon("hand-pointer"),
          i18n$t("Selección")
        ),
        value = "tab_selection",
        tags$br(),

        ### Dimension selector ----
        conditionalPanel(
          "input.menu == 'page_home_v2' | input.menu == 'page_visualization_v2' | (input.menu == 'page_exploration' & input.tabs_exploration == 'tab_geographical_areas')",
          # geo_selector_ui("geo_selector1"),
          dimension_selector_ui("dimension_selector_sidebar")
        ),

        ### year selector ----
        conditionalPanel(
          "input.menu == 'page_home_v2' | (input.menu == 'page_exploration' & input.tabs_exploration == 'tab_evastur_exploration')",
          uiOutput("ui_pi_year")
        ),

        ### geo selector ----
        conditionalPanel(
          "input.menu == 'page_home_v2' | (input.menu == 'page_exploration' & input.tabs_exploration == 'tab_evastur_exploration') | (input.menu == 'page_visualization_v2' & input.tabs_visualization2 == 'tab_visualization_ind') | (input.menu == 'page_analysis_v2' & input.tabs_analysis2 == 'tab_prediction_analysis2')",
          uiOutput("ui_geo_selector1")
        ),

        ### custom groups selector for geographical areas ----
        conditionalPanel(
          "input.menu == 'page_management' & input.tabs_management == 'tab_management_geo'",
          custom_groups_selector_ui("custom_groups_selector")
        ),

        ### groups selector for geographical areas ----
        conditionalPanel(
          "input.menu == 'page_exploration' & input.tabs_exploration == 'tab_geographical_areas'",
          geo_level_selector_ui("geo_level_selector_config")
        ),

        ### Visualization ----
        conditionalPanel(
          "input.menu == 'page_visualization_v2'",
          indicator_selector_ui("indicator_selector1")
        ),
        conditionalPanel(
          "input.menu == 'page_visualization_v2' & input.tabs_visualization2 == 'tab_visualization_geo'",
          geo_selector_ui("geo_selector2")
        ),

        ### Experimental ----
        conditionalPanel(
          "input.menu == 'page_experimental' & input.tabs_experimental == 'tab_recommendation_analysis'",
          br(),
          fluidRow(actionButton(
            "calculo_rec",
            i18n$t("Cálculo"),
            class = "btn-block"
          )),
          br(),
          fluidRow(actionButton("showModal", i18n$t("Configura los pesos")))
        ),

        ### Analysis ----
        conditionalPanel(
          "input.menu == 'page_analysis_v2' & input.tabs_analysis2 == 'tab_prediction_analysis2'",
          prediction_horizon_ui("prediction_horizon1", i18n = i18n),
          intervention_controls_ui("intervention_controls1", i18n)
        ),

        ### Management ----
        conditionalPanel(
          "input.menu == 'page_management' & (input.tabs_management == 'tab_management_variables' | input.tabs_management == 'tab_management_indicators')",
          dim_selector_buttons_ui("dimsel1")
        ),
        conditionalPanel(
          "input.menu == 'page_management' & input.tabs_management == 'tab_management_variables'",
          uiOutput("ui_pi_custom_variables")
        ),
        conditionalPanel(
          "input.menu == 'page_management' & input.tabs_management == 'tab_management_indicators'",
          uiOutput("ui_pi_custom_indicators")
        ),
        conditionalPanel(
          "input.menu == 'page_management' & input.tabs_management == 'tab_management_geo'",
          geo_selector_ui("geo_selector3")
        ),

        ### onlycustom ----
        conditionalPanel(
          "input.menu == 'page_management' & 
            (input.tabs_management == 'tab_management_variables' | 
            input.tabs_management == 'tab_management_indicators' | 
            input.tabs_management == 'tab_management_geo') | 
            (input.menu == 'page_exploration' & input.tabs_exploration == 'tab_evastur_exploration')",
          onlycustom_ui("onlycustom1")
        ),

        ### No additional selections ----
        conditionalPanel(
          "(input.menu == 'page_exploration' & input.tabs_exploration == 'tab_indicators_exploration') | 
            input.menu == 'page_config' |
            input.menu == 'page_management' & 
              (input.tabs_management == 'tab_management_dimensions' | 
                input.tabs_management == 'tab_management_load') | 
            (input.menu == 'page_exploration' & input.tabs_exploration == 'tab_sources_exploration')",
          p(
            i18n$t("No hay selecciones adicionales en este apartado"),
            style = "color: gray;"
          )
        ),

        ### Imputation ----
        conditionalPanel(
          "input.menu == 'page_data_update'",
          imputation_ui("imputation1", i18n = i18n)
        ),

        ### Download PDF buttons ----
        conditionalPanel(
          "input.menu == 'page_home_v2'",
          div(
            hr(),
            pdf_download_ui(
              "home_pdf_download",
              label = i18n$t("Informe indicadores"),
              icon_name = "file-pdf",
              class = "btn-primary"
            ),
            hr(),
            div(
              class = "mt-2",
              pdf_download_ui(
                "imputation_pdf_download",
                label = i18n$t("Informe imputación"),
                icon_name = "file-pdf",
                class = "btn-primary"
              ),
              checkboxInput("cb_imputation_all_years", i18n$t("Todos los años"), value = FALSE)
            )
          )
        ),
        conditionalPanel(
          "input.menu == 'page_visualization_v2' & input.tabs_visualization2 == 'tab_visualization_geo'",
          div(
            hr(),
            pdf_download_ui(
              "viz_geo_pdf_download",
              label = i18n$t("Informe PDF"),
              icon_name = "file-pdf",
              class = "btn-primary"
            )
          )
        ),
        conditionalPanel(
          "input.menu == 'page_visualization_v2' & input.tabs_visualization2 == 'tab_visualization_ind'",
          div(
            hr(),
            pdf_download_ui(
              "viz_ind_pdf_download",
              label = i18n$t("Informe PDF"),
              icon_name = "file-pdf",
              class = "btn-primary"
            )
          )
        ),
        conditionalPanel(
          "input.menu == 'page_analysis_v2' & input.tabs_analysis2 == 'tab_prediction_analysis2'",
          div(
            hr(),
            pdf_download_ui(
              "analysis_pdf_download",
              label = i18n$t("Informe PDF"),
              icon_name = "file-pdf",
              class = "btn-primary"
            )
          )
        ),
      ),
      nav_panel(
        title = "",
        icon = icon("info"),
        value = "tab_info",
        uiOutput("info_sidebar")
      )
    )
  )
}

#' Theme style generator
#'
#' Generates a bootstrap theme to be included in app_ui.
#'
#' @return theme style
#' @author Emilio L. Cano
#' @export
#' @examples
#' mytheme()
mytheme <- function() {
  ## TODO: include in settings and use from there
  bs_theme(
    fg = "#F0EDE6",
    bg = "#6B8A7A",
    navbar_bg = "#6B8A7A",
    "card-bg" = "#F0EDE6",
    "card-height" = "125%",
    "card-color" = "black",
    primary = "#6B8A7A",
    secondary = "#6B8A7A",
    light = "#F0EDE6",
    success = "#5cae6e",
    danger = "#d96363",
    base_font = font_google("Roboto"),
    code_font = font_google("JetBrains Mono"),
    heading_font = font_google('Roboto')
  ) |>
    bs_add_variables("bslib-spacer" = "1rem")
}

#' Get theme colors
#'
#' Extracts primary and light colors from the current session theme
#'
#' @param session Shiny session object
#' @param bs_variable Bootstrap variable to extract. Default = `"primary"`.
#'
#' @return A list with primary_hex and light_hex
#' @export
get_theme_color <- function(session, bs_variable = "primary") {
  bs_get_variables(
    session$getCurrentTheme(),
    bs_variable
  )[[bs_variable]]
}

#' Check if a string is a valid hex color
#'
#' @param color Character vector to check.
#'
#' @return Logical vector; `TRUE` for valid 3- or 6-digit hex colors.
#' @export
#'
#' @examples
#' is_valid_hex("#6B8A7A")
#' is_valid_hex(c("#fff", "#GGG", NA))
is_valid_hex <- function(color) {
  grepl("^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$", color)
}

#' Adjust color brightness (lighten or darken)
#'
#' Adjusts brightness of a color in either RGB or HEX format.
#'
#' @param color Color to modify. Either a character string (hex color like
#' "#6B8A7A") or a numeric vector of 3 RGB values (0–255).
#' @param color_type Character, either "hex" or "rgb". Must be specified
#' explicitly.
#' @param factor Numeric factor in (0, 1). Positive = lighten, negative =
#' darken. Default = `0.3`.
#'
#' @return Same format as input (`hex` or numeric RGB).
#' @export
#'
#' @examples
#' adjust_color("#6B8A7A", -0.3, color_type = "hex")   # darken
#' adjust_color("#6B8A7A",  0.3, color_type = "hex")   # lighten
#' adjust_color(c(107,138,122), -0.3, color_type = "rgb")
adjust_color <- function(color, color_type, factor = 0.3) {
  color_type <- match.arg(color_type, c("hex", "rgb"))

  if (!is.numeric(factor) || factor < -1 || factor > 1) {
    stop("factor must be between -1 and 1.")
  }

  if (color_type == "hex") {
    if (!is.character(color) || length(color) != 1) {
      stop("For color_type='hex', color must be a single hex string like '#6B8A7A'.")
    }
    if (!is_valid_hex(color)) {
      stop(paste0("Invalid hex color: '", color, "'. Expected format: '#RRGGBB' or '#RGB'."))
    }
    rgb_vals <- col2rgb(color)
  } else if (color_type == "rgb") {
    if (!is.numeric(color) || length(color) != 3) {
      stop(
        "For color_type='rgb', color must be a numeric vector of length 3 (R,G,B)."
      )
    }
    rgb_vals <- matrix(color, ncol = 1)
  }

  if (factor > 0) {
    new_rgb <- pmin(255, rgb_vals + (255 - rgb_vals) * factor)
  } else if (factor < 0) {
    new_rgb <- pmax(0, rgb_vals * (1 + factor))
  } else {
    new_rgb <- rgb_vals
  }

  if (color_type == "hex") {
    return(rgb(new_rgb[1], new_rgb[2], new_rgb[3], maxColorValue = 255))
  } else {
    return(as.numeric(new_rgb))
  }
}

#' Get complementary color
#'
#' Calculates the complementary color of a hex color by shifting its hue 180 degrees.
#'
#' @param hex_color Character, hex color string (e.g., "#6B8A7A").
#'
#' @return Character, hex color string.
#' @export
get_complementary_color <- function(hex_color) {
  rgb_vals <- col2rgb(hex_color) / 255
  hsv_vals <- rgb2hsv(rgb_vals)
  
  # Shift hue by 0.5 (180 degrees)
  hsv_vals[1, 1] <- (hsv_vals[1, 1] + 0.5) %% 1
  
  # Convert back to hex
  do.call(hsv, as.list(hsv_vals))
}

#' Create color palette from a primary color
#'
#' Generates a color palette with a configurable number of tones
#' around a primary color (lighter and darker variations).
#'
#' @param primary_color Character string with hex color (e.g., "#6B8A7A")
#' @param n Integer, number of colors (>=3). Default = `4`.
#' @param range Numeric (0–1), total range of brightness variation. Default =
#' `0.6`.
#'
#' @return Character vector of hex colors.
#' @export
#'
#' @examples
#' create_color_palette("#6B8A7A", n = 4)
#' create_color_palette("#6B8A7A", n = 7, range = 0.8)
create_color_palette <- function(primary_color, n = 4, range = 0.6) {
  if (!is.character(primary_color) || length(primary_color) != 1) {
    stop("primary_color must be a single hex string (e.g. '#6B8A7A').")
  }

  if (n < 3) {
    stop("n must be >= 3.")
  }

  if (range <= 0 || range > 1) {
    stop("range must be between 0 and 1.")
  }

  # Generate sequence of brightness adjustments (from light to dark)
  steps <- seq(range / 2, -range / 2, length.out = n)

  # Apply brightness adjustment explicitly for hex
  sapply(steps, function(f) {
    adjust_color(color = primary_color, color_type = "hex", factor = f)
  })
}


#' User interface for variables documentation
#'
#' @param list_tables list of tables generated with documentation_tables()
#' @param i18n translation object
#'
#' @returns a div object to be used in the UI
#' @author Javier Saugar, Emilio L. Cano
#' @export
#'
#' @examplesIf interactive
#'
#' list_tables <- documentation_tables("variable", "VGAS0001")
#' ui_var_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("variable", "VCUS0001")
#' ui_var_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("variable", "VVOL0001")
#' ui_var_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
ui_var_doc <- function(list_tables, i18n) {
  description <- list_tables[["lt_variables"]] |>
    pull(variable_description)
  source <- list_tables[["bt_variable_source"]] |>
    pull(source_name)

  rtvar <- list_tables$lt_variables |>
    select(variable_id, variable_label) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        variable_id = colDef(
          name = i18n$t("Código"),
          width = 120
        ),
        variable_label = colDef(
          name = i18n$t("Etiqueta")
        )
      )
    )
  rtsources <- list_tables$bt_variable_source |>
    select(
      source_id,
      source_name,
      source_varname,
      source_units,
      units_factor_mult,
      source_units_ori,
      period_id
    ) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        source_id = colDef(
          name = ""
        ),
        source_name = colDef(
          name = i18n$t("Fuente")
        ),
        source_varname = colDef(
          name = i18n$t("Variable origen")
        ),
        source_units = colDef(
          name = i18n$t("Unidades")
        ),
        units_factor_mult = colDef(
          html = TRUE,
          name = i18n$t("Factor multiplicador"),
          cell = function(value, index) {
            if (value != 1) {
              info <- as.character(tooltip(
                bs_icon("question-circle"),
                list_tables$bt_variable_source$source_units_ori[index]
              ))
            } else {
              info <- ""
            }
            paste0(value, info)
          }
        ),
        source_units_ori = colDef(
          show = FALSE
        ),
        period_id = colDef(
          name = i18n$t("Periodo del dato"),
        )
      )
    )
  rtind <- list_tables$bt_indicator_variable |>
    select(indicator_id, indicator_name) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        indicator_id = colDef(
          name = ""
        ),
        indicator_name = colDef(
          name = i18n$t("Indicador")
        )
      )
    )

  div(
    rtvar,
    if (str_sub(list_tables$dt_variables$variable_id, end = 4) == "VCUS") {
      p(HTML(paste0(
        strong(i18n$t("NOTA"), ": "),
        i18n$t("Esta es una variable personalizada, creada por el usuario"),
        " ",
        list_tables$dt_variables$user_cre,
        " ",
        i18n$t("el día"),
        " ",
        as.Date(list_tables$dt_variables$ts_cre),
        "."
      )))
    },

    h3(i18n$t("Descripción")),
    description <- list_tables[["lt_variables"]] |> pull(variable_description),
    tags$br(),
    h3(i18n$t("Operaciones de agregado")),
    tags$ul(
      tags$li(paste0(
        i18n$t("Temporal"),
        ": ",
        list_tables$dt_variables$variable_aggregation_time
      )),
      tags$li(paste0(
        i18n$t("Espacial"),
        ": ",
        list_tables$dt_variables$variable_aggregation_time
      ))
    ),
    h3(i18n$t("Fuentes de datos")),
    p(paste0(
      i18n$t(
        "Los datos de las variables se pueden encontrar en las siguientes fuentes"
      ),
      ": "
    )),
    br(),
    rtsources,
    br(),
    p(i18n$t(
      "El factor multiplicador se aplica al dato original para homogeneizar la magnitud de las unidades en las distintas fuentes, por ejemplo cuanto la variable original está en miles, millones, etc."
    )),
    h3(i18n$t("Indicadores")),
    p(paste0(
      i18n$t("La variable se utiliza en los siguientes indicadores"),
      ": "
    )),
    br(),
    rtind,
  )
}


#' User interface for indicators documentation
#'
#' @param list_tables list of tables generated with documentation_tables()
#' @param i18n translation object
#'
#' @returns a div object to be used in the UI
#' @author Javier Saugar, Emilio L. Cano
#' @export
#'
#' @examplesIf interactive
#' list_tables <- documentation_tables("indicator", "IAMB0004")
#' ui_ind_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("indicator", "ISOC0001")
#' ui_ind_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("indicator", "IECO0012")
#' ui_ind_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("indicator", "IECO0001")
#' ui_ind_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("indicator", "ICUS0001")
#' ui_ind_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("indicator", "IECO0003")
#' ui_ind_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
ui_ind_doc <- function(list_tables, i18n, source) {
  description <- list_tables[["lt_indicators"]] |>
    pull(indicator_description)
  source <- list_tables[["bt_indicator_source"]] |>
    pull(source_name)
  dimension <- list_tables[["bt_indicator_subdimension"]] |>
    pull(dimension_name)
  subdimension <- list_tables[["bt_indicator_subdimension"]] |>
    pull(subdimension_name)
  formula <- list_tables[["dt_indicators"]] |>
    pull(indicator_formula)
  variables <- list_tables[["bt_indicator_variable"]] |>
    pull(variable_name)
  dfvars <- list_tables$bt_indicator_variable |>
    inner_join(
      tbl(con2, "dt_variables") |>
        select(
          variable_id,
          variable_aggregation_time,
          variable_aggregation_geo
        ) |>
        collect(),
      by = "variable_id"
    )
  ## TODO: check this source_id hardcoding
  ind_class <- list_tables$bt_indicator_subdimension |>
    filter(source_id == "EVASTUR") |>
    select(dimension_name, subdimension_name)

  ind_class_other <- list_tables$bt_indicator_subdimension |>
    filter(source_id != "EVASTUR") |>
    select(source_id, dimension_name, subdimension_name)

  rtind <- list_tables$lt_indicators |>
    select(indicator_id, indicator_label) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        indicator_id = colDef(
          name = i18n$t("Código"),
          width = 120
        ),
        indicator_label = colDef(
          name = i18n$t("Etiqueta")
        )
      )
    )

  rtvar <- dfvars |>
    select(
      variable_id,
      variable_name,
      variable_aggregation_time,
      variable_aggregation_geo
    ) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        variable_id = colDef(
          name = i18n$t("Código"),
          width = 120
        ),
        variable_name = colDef(
          name = i18n$t("Variable")
        ),
        variable_aggregation_time = colDef(
          name = i18n$t("Operación de agregado temporal"),
          width = 120
        ),
        variable_aggregation_geo = colDef(
          name = i18n$t("Operación de agregado espacial"),
          width = 120
        )
      )
    )

  rt_class <- ind_class_other |>
    select(source_id, dimension_name, subdimension_name) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        source_id = colDef(
          name = i18n$t("Fuente"),
          width = 100
        ),
        dimension_name = colDef(
          name = i18n$t("Dimensión")
        ),
        subdimension_name = colDef(
          name = i18n$t("Subdimensión")
        )
      )
    )

  ## df_sim ----
  df_sim <- list_tables$bt_indicator_similarity |>
    inner_join(
      con2 |>
        tbl("lt_indicators") |>
        filter(indicator_lang == i18n$get_translation_language()) |>
        collect(),
      by = c("sim_indicator_id" = "indicator_id")
    )
  ## rt_sim ----
  rt_sim <- df_sim |>
    select(
      indicator_label,
      sim_level_label,
      sim_level_description
    ) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        indicator_label = colDef(
          name = i18n$t("Indicador"),
          minWidth = 300,
          cell = function(value, index) {
            paste0(value, " (", df_sim$sim_indicator_id[index], ")")
          }
        ),
        sim_level_label = colDef(
          name = i18n$t("Nivel de similitud")
        ),
        sim_level_description = colDef(
          name = "",
          maxWidth = 30,
          html = TRUE,
          cell = function(value, index) {
            as.character(tooltip(bs_icon("info-circle"), value))
          }
        )
      )
    )
  ## df_related_inverse ----
  df_related_inverse <- tbl(con2, "bt_indicator_similarity") |>
    filter(sim_indicator_id == list_tables$dt_indicators$indicator_id) |>
    inner_join(
      tbl(con2, "lt_indicators") |>
        filter(indicator_lang == i18n$get_translation_language()) |>
        select(indicator_id, indicator_label, indicator_name),
      by = "indicator_id"
    ) |>
    select(indicator_id, indicator_name) |>
    collect()

  ## start output ----
  div(
    rtind,
    if (str_sub(list_tables$dt_indicators$indicator_id, end = 4) == "ICUS") {
      p(HTML(paste0(
        strong(i18n$t("NOTA"), ": "),
        i18n$t("Este es un indicador personalizado, creado por el usuario"),
        " ",
        list_tables$dt_indicators$user_cre,
        " ",
        i18n$t("el día"),
        " ",
        as.Date(list_tables$dt_indicators$ts_cre),
        "."
      )))
    },
    if (!list_tables$dt_indicators$indicator_active) {
      p(HTML(paste0(
        strong(i18n$t("NOTA"), ": "),
        i18n$t(
          "Este indicador está desactivado. No se utiliza en los cálculos de indicadores compuestos"
        ),
        "."
      )))
    },
    h3(i18n$t("Descripción")),
    p(description),
    h3(i18n$t("Sentido")),
    if (list_tables$dt_indicators$indicator_direction == "+") {
      p(i18n$t(
        "El sentido del indicador es positivo, es decir, cuanto mayor es el valor, más sostenible es el turismo en su dimensión."
      ))
    } else {
      p(i18n$t(
        "El sentido del indicador es negativo, es decir, cuanto mayor es el valor, menos sostenible es el turismo en su dimensión."
      ))
    },
    ## Indicator computation ----
    h3(i18n$t("Cálculo del indicador")),
    if (length(variables) == 1) {
      div(
        p(
          paste0(
            i18n$t("El indicador se corresponde directamente con la variable"),
            " '",
            variables,
            "', ",
            i18n$t("código"),
            " ",
            list_tables$bt_indicator_variable$variable_id,
            ". "
          ),
          i18n$t(
            "Si la variable implica cálculos con datos que no están disponibles, es posible que el cálculo no sea trazable."
          )
        ),
        rtvar,
        br(),
        p(i18n$t(
          "Agregando los periodos de tiempo y las áreas geográficas mediante las operaciones que se indican en la tabla."
        ))
      )
    } else if (length(variables) == 0) {
        p(paste0(
          i18n$t(
            "El indicador no se puede calcular. No tiene fórmula ni variables relacionadas."
          )
        )
      )
    } else {
      div(
        p(paste0(
          i18n$t("El indicador se calcula usando las siguientes variables"),
          ":"
        )),
        rtvar,
        br(),
        p(
          i18n$t("Mediante la siguiente"),
          HTML(paste0(strong(i18n$t("fórmula")), ":"))
        ),
        formula_to_latex(paste0(
          list_tables$lt_indicators$indicator_id,
          " = ",
          formula
        )),
        p(i18n$t(
          "Agregando los periodos de tiempo y las áreas geográficas mediante las operaciones que se indican en la tabla."
        ))
      )
    },

    ## Classification ----
    h3(i18n$t("Clasificación del indicador")),
    if (nrow(ind_class != 0)) {
      tagList(
        p(i18n$t(
          "El indicador tiene la siguiente clasificación en el Sistema de Indicadores EVASTUR:"
        )),
        tags$ul(
          tags$li(HTML(
            paste0(strong(i18n$t("Dimensión")), ": "),
            ind_class$dimension_name
          )),
          tags$ul(tags$li(
            HTML(paste0(strong(i18n$t("Subdimensión")), ": ")),
            ind_class$subdimension_name
          ))
        ),

        if (all(is.na(list_tables$bt_indicator_source$indicator_refvalue))) {
          p(i18n$t(
            "El indicador no tiene asignado un valor de referencia para el escalado por este método."
          ))
        } else {
          p(
            i18n$t(
              "El valor de referencia del indicador para el escalado por ese método es:"
            ),
            ifelse(
              nrow(list_tables$bt_indicator_source) == 1,
              list_tables$bt_indicator_source$indicator_refvalue,
              paste0(
                list_tables$bt_indicator_source$indicator_refvalue,
                " (",
                list_tables$bt_indicator_source$source_id,
                ")",
                collapse = "; "
              )
            )
          )
        },
        p(
          i18n$t("El indicador tiene un peso igual a"),
          strong(list_tables$dt_indicators$indicator_weight),
          i18n$t("en el cálculo del indicador compuesto de la dimensión.")
        )
      )
    } else {
      p(i18n$t(
        "El indicador no está clasificado en el Sistema de Indicadores EVASTUR."
      ))
    },

    if (nrow(ind_class_other) != 0) {
      div(
        p(
          "El indicador se encuentra en clasificaciones de otras fuentes de la biblioteca de indicadores:"
        ),
        rt_class
      )
    },

    ## ODS ----
    if (nrow(list_tables$bt_indicator_ods) > 0) {
      tagList(
        h3(i18n$t("Relación con los Objetivos de Desarrollo Sostenible (ODS)")),
        p(i18n$t("El indicador está relacionado con los siguientes ODS:")),
        list_tables$bt_indicator_ods |>
          arrange(ods_id) |>
          select(ods_id, ods_name) |>
          unite("ods", sep = ": ") |>
          mutate(ods = paste(i18n$t("ODS"), ods)) |>
          pull() |>
          lapply(tags$li) |>
          tags$ul()
      )
    },

    ## Related indicators ----
    if (nrow(list_tables$bt_indicator_similarity) > 0) {
      tagList(
        h3(i18n$t("Indicadores relacionados")),
        p(i18n$t(
          "El indicador está relacionado con los siguientes otros indicadores:"
        )),
        rt_sim
      )
    },
    ## Related indicators (inverse) ----
    if (nrow(df_related_inverse) > 0) {
      tagList(
        div(
          h3(i18n$t("Indicadores que hacen referencia a este indicador")),
          p(i18n$t(
            "Los siguientes indicadores incluyen este indicador como indicador relacionado:"
          ))
        ),
        df_related_inverse |>
          reactable(
            language = get_rt_lang(i18n$get_translation_language()),
            bordered = TRUE,
            class = "exploration-tables",
            columns = list(
              indicator_id = colDef(
                name = i18n$t("Código"),
                width = 120
              ),
              indicator_name = colDef(
                name = i18n$t("Indicador")
              )
            )
          )
      )
    }
  )
}

#' User interface for data sources documentation
#'
#' @param list_tables list of tables generated with documentation_tables()
#' @param i18n translation object
#'
#' @returns a div object to be used in the UI
#' @author Javier Saugar, Emilio L. Cano
#' @export
#'
#' @examplesIf interactive
#' list_tables <- documentation_tables("source", "INE-EGATUR")
#' ui_source_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
#' list_tables <- documentation_tables("source", "UNWTO-STATS")
#' ui_source_doc(list_tables, getOption("evastur.translator")) |>
#'   htmltools::html_print()
ui_source_doc <- function(list_tables, i18n) {
  description <- list_tables[["lt_sources"]] |>
    pull(source_description)
  rtsource <- list_tables$lt_sources |>
    select(source_id, source_label) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        source_id = colDef(
          name = i18n$t("Código"),
          width = 120
        ),
        source_label = colDef(
          name = i18n$t("Etiqueta")
        )
      )
    )
  rtvars <- list_tables$bt_variable_source |>
    select(variable_name, source_units, period_id) |>
    reactable(
      language = get_rt_lang(i18n$get_translation_language()),
      bordered = TRUE,
      class = "exploration-tables",
      columns = list(
        variable_name = colDef(
          name = i18n$t("Variable")
        ),
        source_units = colDef(
          name = i18n$t("Unidades")
        ),
        period_id = colDef(
          "Periodo del dato"
        )
      )
    )
  dfida <- con2 |>
    tbl("lt_sources_ida") |>
    filter(
      ida_lang == !!i18n$get_translation_language(),
      ida_id == list_tables$dt_sources$ida_id
    ) |>
    collect()

  div(
    rtsource,
    h3(i18n$t("Descripción")),
    p(description),
    p(a(
      i18n$t("Enlace a la fuente"),
      href = list_tables$dt_sources$source_url,
      target = "_blank"
    )),
    h3(i18n$t("Nivel de automatización")),
    p(HTML(paste0(strong(dfida$ida_name), ": ", dfida$ida_description)), "."),
    if (dfida$ida_id == 4) {
      p(paste0(
        i18n$t("Última comprobación"),
        ": ",
        list_tables$dt_sources$source_last_checking,
        "."
      ))
    },
    tags$br(),
    h3(i18n$t("Variables")),
    p(paste0(
      i18n$t("La fuente ofrece datos para las siguientes variables"),
      ": "
    )),
    rtvars
  )
}

#' Create valuebox with a KPI
#'
#' @param .data Data frame of compound indicators
#' @param kpi One of trend, rank, dist, last
#' @param .total if TRUE, the total indicator is considered
#' @param .global if TRUE, the global indicator is considered
#' @param .geo_id if total  is FALSE, then a geography must be provided
#' @param .dimension_id  if .global is false, then a dimension must be provided
#' @param i18n translation object
#'
#' @returns a value box for using in the dahsboard ui
#' @author Javier Saugar, Emilio L. Cano
#' @export
#'
#' @examplesIf interactive
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
#'
#' vbox_kpi(dfcomp, "trend", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "rank", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "dist", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "last", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "last", total = FALSE, geo_id = "ESP", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "last", global = FALSE, dimension_id = "ECO", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "last", total = FALSE, geo_id = "ESP", global = FALSE, dimension_id = "ECO", i18n = getOption("evastur.translator"))
#' vbox_kpi(dfcomp, "last", total = FALSE, geo_id = "ESP", global = FALSE, dimension_id = "ECO", i18n = getOption("evastur.translator"))
#'
#' ## INSTO
#'
#' selected_source <- "EVASTUR"
#' selected_nuts <- 0
#' selected_location <- "ES"
#' selected_group <- "WLD"
#' selected_date <- "2013-01-01"
#' selected_to_date <- "2023-12-31"
#'
#' inds <- tbl(con2, "dt_indicators") |>
#'   filter(indicator_active == TRUE) |>
#'   pull(indicator_id)
#'
#' dfind <- get_ft_data(data_type = "indicator",
#'                      .nuts_level = selected_nuts,
#'                      type_id = inds,
#'                      country = selected_location,
#'                      .source_id = selected_source,
#'                      from_date = selected_date,
#'                      to_date = selected_to_date)
#'
#'
#' tindicators <- get_transformed_indicators(dfind,
#'                                           scaling_method = "zscore",
#'                                           scaling_type = "time",
#'                                           geo_total = selected_group)
#'
#' dfcomp <- tindicators |>
#'   compute_composite_indicator(selected_source = selected_source)
vbox_kpi <- function(
  .data,
  kpi,
  total = TRUE,
  global = TRUE,
  geo_id = NULL,
  dimension_id = NULL,
  i18n
) {
  ## initialise class
  kpi_class <- "NA"
  ## Trend ----
  if (kpi == "trend") {
    .title <- "Tendencia"
    .value <- round(
      kpi_trend(
        .data,
        .total = total,
        .global = global,
        .geo_id = geo_id,
        .dimension_id = dimension_id
      ),
      2
    )

    if (is.na(.value)) {
      kpi_class <- "NA"
    } else if (.value > 0) {
      kpi_class <- "improve"
    } else if (.value < 0) {
      kpi_class <- "worsen"
    } else {
      kpi_class <- "steady"
    }

    ## Last ----
  } else if (kpi == "last") {
    .title <- "STI"
    .value <- round(
      kpi_last(
        .data,
        .total = total,
        .global = global,
        .geo_id = geo_id,
        .dimension_id = dimension_id
      ),
      2
    )

    if (is.na(.value)) {
      kpi_class <- "NA"
    } else if (attr(.data, "scaling_method") == "zscore") {
      ### z-score ----
      if (.value > 1) {
        kpi_class <- "improve"
      } else if (.value < -1) {
        kpi_class <- "worsen"
      } else {
        kpi_class <- "steady"
      }
    } else if (attr(.data, "scaling_method") == "minmax") {
      ### Max-Min ----
      if (.value > 0.75) {
        kpi_class <- "improve"
      } else if (.value < 0.25) {
        kpi_class <- "worsen"
      } else {
        kpi_class <- "steady"
      }
    } else if (attr(.data, "scaling_method") == "refvalue") {
      ### Reference ----
      if (.value > 1) {
        kpi_class <- "improve"
      } else if (.value < 1) {
        kpi_class <- "worsen"
      } else {
        kpi_class <- "steady"
      }
    }
    ## Dist ----
  } else if (kpi == "dist") {
    .title <- "Distancia al máximo"
    dist <- kpi_dist(
      .data,
      .total = total,
      .global = global,
      .geo_id = geo_id,
      .dimension_id = dimension_id
    )
    if (is.na(dist)) {
      .value <- NA
      kpi_class <- "NA"
    } else if (dist < 0.25) {
      .value <- "< 0.25"
      kpi_class <- "improve"
    } else if (dist > 0.25) {
      .value <- "> 0.25"
      kpi_class <- "worsen"
    } else {
      .value <- "0.25"
      kpi_class <- "steady"
    }
    ## Rank ----
  } else if (kpi == "rank") {
    .title <- "Ranking años"
    pos <- kpi_rank(
      .data,
      .total = total,
      .global = global,
      .geo_id = geo_id,
      .dimension_id = dimension_id
    )
    .value <- paste0(pos, "º")
    if (is.na(pos)) {
      .value <- NA
      kpi_class <- "NA"
    } else if (pos == 1) {
      kpi_class <- "best"
    } else if (pos > 1 & pos <= 2) {
      kpi_class <- "improve"
    } else if (pos > 2 & pos <= 8) {
      kpi_class <- "steady"
    } else if (pos > 8) {
      kpi_class <- "worsen"
    }
  }

  if (kpi_class == "NA") {
    .value <- ""
    .color <- "#f0ad4e"
    .icon <- "question-diamond"
  } else if (kpi_class == "improve") {
    .color <- "#5cae6e"
    .icon <- "arrow-up-square"
  } else if (kpi_class == "steady") {
    .color <- "#f0ad4e"
    .icon <- "dash-square"
  } else if (kpi_class == "worsen") {
    .color <- "#d96363"
    .icon <- "arrow-down-square"
  } else if (kpi_class == "best") {
    .color <- "#5cae6e"
    .icon <- "check-square"
  }

  value_box(
    title = i18n$t(.title),
    value = .value,
    showcase = span(
      bs_icon(name = .icon, size = "50px"),
      style = paste0("color:", .color)
    ),
    max_height = "150px",
    class = "vb-titles"
  )
}

#' Get Reactable language configuration
#'
#' Generates a [reactable::reactableLang] object for localizing the
#' interface of `reactable` tables. It synchronizes the table's internal text
#' (search, pagination, info) with the package's global translator and selected
#' language. Specifically the translation of the following items is handled:
#' * `searchPlaceholder`: Placeholder for the table search input.
#' * `noData`: Placeholder text when the table has no data.
#' * `pageInfo`: Text for the page info.
#' * `pagePrevious` / `pageNext`: Text for pagination buttons.
#' * `pagePreviousLabel` / `pageNextLabel`: Accessible labels for pagination
#'   buttons
#'
#' @section Required translation keys:
#' This function expects the following keys to be present in the
#' `translation_*.csv` files:
#' \itemize{
#'   \item `"Buscar"`: Search input.
#'   \item `"No se han encontrado registros"`: Empty table data.
#'   \item `"Anterior"`, `"Siguiente"`: Pagination buttons.
#'   \item `"Página anterior"`, `"Página siguiente"`: Pagination labels.
#'   \item `"de"`, `"filas"`: Page info parts.
#'   \item `"Ordenar"`, `"Filtrar"`: Column actions.
#'   \item `"Mostrar"`, `"Página"`: Page options and labels.
#'   \item `"Ir a la página"`, `"Filas por página"`: Explicit controls.
#'   \item `"Contraer/expandir grupo"`, `"Ver detalles"`: Row actions.
#'   \item `"Seleccionar todas las filas"` (+ group, + single): Row selection.
#' }
#'
#' @param lang Character. "en" or "es". If NULL, uses `evastur.default_lang`
#'   option.
#' @return A [reactable::reactableLang] object.
#'
#' @export
#'
#' @examplesIf interactive()
#' library(shiny)
#' library(reactable)
#' library(evastur)
#'
#' ui <- fluidPage(
#'   reactableOutput("table")
#' )
#'
#' server <- function(input, output, session) {
#'   output$table <- renderReactable({
#'     reactable(
#'       mtcars[1:5, 1:5],
#'       language = get_rt_lang("es"),
#'       searchable = TRUE,
#'       showPagination = TRUE
#'     )
#'   })
#' }
#'
#' shinyApp(ui, server)
get_rt_lang <- function(lang = NULL) {
  i18n <- getOption("evastur.translator")

  if (is.null(lang)) {
    lang <- getOption("evastur.default_lang", default = "en")
  }

  # Temporarily change the translator's language to capture the strings
  old_lang <- i18n$get_translation_language()
  i18n$set_translation_language(lang)

  rt_lang <- reactable::reactableLang(
    sortLabel = paste(i18n$t("Ordenar"), "{name}"),
    filterPlaceholder = "",
    filterLabel = paste(i18n$t("Filtrar"), "{name}"),
    searchPlaceholder = i18n$t("Buscar"),
    searchLabel = i18n$t("Buscar"),
    noData = i18n$t("No se han encontrado registros"),
    pageNext = i18n$t("Siguiente"),
    pagePrevious = i18n$t("Anterior"),
    pageNumbers = paste("{page}", i18n$t("de"), "{pages}"),
    pageInfo = paste(
      "{rowStart}\u2013{rowEnd}",
      i18n$t("de"),
      "{rows}",
      i18n$t("filas")
    ),
    pageSizeOptions = paste(i18n$t("Mostrar"), "{rows}"),
    pageNextLabel = i18n$t("Página siguiente"),
    pagePreviousLabel = i18n$t("Página anterior"),
    pageNumberLabel = paste(i18n$t("Página"), "{page}"),
    pageJumpLabel = i18n$t("Ir a la página"),
    pageSizeOptionsLabel = i18n$t("Filas por página"),
    groupExpandLabel = i18n$t("Contraer/expandir grupo"),
    detailsExpandLabel = i18n$t("Ver detalles"),
    selectAllRowsLabel = i18n$t("Seleccionar todas las filas"),
    selectAllSubRowsLabel = i18n$t("Seleccionar todas las filas del grupo"),
    selectRowLabel = i18n$t("Seleccionar fila")
  )

  # Restore the original language of the translator
  i18n$set_translation_language(old_lang)

  rt_lang
}
