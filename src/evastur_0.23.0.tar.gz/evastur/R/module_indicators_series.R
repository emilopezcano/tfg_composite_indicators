## Module for representing indicator values in a time series plot

## Module UI ----
indicator_series_ui <- function(id) {
  ns <- NS(id)
  tagList(
    plotlyOutput(ns("series_indicator"))
  )
}

## Module server ----
indicator_series_server <- function(id, i18n, .data, signif) {
  moduleServer(
    id,
    function(input, output, session) {
      ## series_indicator ----
      output$series_indicator <- renderPlotly({
        light_color <- get_theme_color(session = session, bs_variable = "light")
        create_series(.data(), signif(), i18n(), background_color = light_color)
      })
      
      return(reactive({.data()}))
    }
  )
}


#' Title
#'
#' @param .data data frame
#' @param signif significant digits
#' @param i18n language object
#' @param background_color background color
#'
#' @returns The server module object
#' @export
#'
#' @examples
#' indicator_series_app()
create_series <- function(.data, signif, i18n, background_color = "#F0EDE6") {
  
  req(nrow(.data) > 0)
  
  dfseries <- .data |> 
    mutate(date = as.Date(date))
  
  ## TODO: adapt to other data type (variable, indicator)
  udims <- unique(dfseries$dimension_id)
  dims <- 
    tbl(con2, "dt_dimensions") |> 
    select(dimension_id, dimension_color, dimension_order) |> 
    mutate(lwd = ifelse(dimension_id == "GLOBAL", 1, 0.5)) |> 
    collect() 
  
  dfseries <- dfseries |> 
    select(-any_of(c("dimension_color", "dimension_order"))) |> 
    inner_join(dims,
               by = "dimension_id")
  
  dims_wlabel <- dims |> 
    inner_join(dfseries |> 
                 distinct(dimension_id, dimension_label),
               by = "dimension_id")
  
  
  lwddims <- setNames(dims_wlabel$lwd, dims_wlabel$dimension_label)
  safe_dim_color <- ifelse(is_valid_hex(dims_wlabel$dimension_color), dims_wlabel$dimension_color, "#6B8A7A")
  cdims <- setNames(safe_dim_color, dims_wlabel$dimension_label)
  odims <- dims_wlabel |> arrange(dimension_order) |> pull(dimension_label)
  
  p <- dfseries |> 
    mutate(dimension_label = factor(dimension_label, levels = odims)) |> 
    ggplot(aes(x = date, 
               y = value, 
               col = dimension_label,
               group = dimension_label,
               linewidth = dimension_label,
               text = paste0("<b>", i18n$t("Periodo"), ":</b> ", get_period(date, period_id), "<br>",
                             "<b>", dimension_label, ":</b> ", scales::label_number(accuracy = 0.01, scale_cut = scales::cut_short_scale())(value))
    )) +
    geom_line() +  
    scale_linewidth_manual(values = lwddims) +
    scale_color_manual(values = cdims) +
    labs(title = "",
         x = "",
         y = "") +
    theme(panel.background = element_rect(fill = background_color),
          plot.background = element_rect(fill = background_color),
          axis.text.x = element_text(angle = 45, vjust = 0.5),
          legend.position = "bottom") +
    scale_x_date(date_breaks = "1 year", date_labels = "%Y") +
    scale_y_continuous(labels = scales::label_number(scale_cut = scales::cut_short_scale()))
  
  # if(scaling == "refvalue"){
  #   p <- p +
  #     scale_y_continuous(breaks = seq(0, .rango, by = .rango/20)) 
  # }
  
  # Adding custom data to get Dimension variable
  p <- p + 
    aes(customdata = dimension_label)  
  
  # Legend
  l <- list(
    font = list(
      family = "sans-serif",
      size = 10,
      color = "black"),
    bgcolor = "transparent",
    bordercolor = "transparent",
    xanchor = "center",
    x = 0.5,
    y = -0.2,
    orientation = "h",
    borderwidth = 0,
    title = list(text = '')
  )
  
  # Transform ggplot to ggplotly and personalise the hover
  ggplotly(p, tooltip = "text") |>
    layout(legend = l) |>
    plotly::config(displaylogo = FALSE)
}


## Module app ----

indicator_series_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  library(ggplot2)
  library(plotly)
  translator <- getOption("evastur.translator")
  
  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    selectInput("si_location", "Country", c("ES", "UK")),
    selectInput("si_source", "Source", c("EVASTUR", "INSTO")),
    selectInput("si_country_group", "Country group", 
                tbl(con2, "dt_geo") |> 
                  filter(nuts_level == 101) |> 
                  pull(geo_id)),
    textInput("ti_scope", "Scope", "S"),
    textInput("ti_group", "Group (or country)", "WLD"),
    textInput("ti_group_label", "Group or country label", "World"),
    
    geo_selector_ui("geosel1"),
    indicator_series_ui("series1"),
    reactableOutput("rt_seriesdata")
    
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    geo_selector <- geo_selector_server(
      "geosel1", 
      i18n = i18n, 
      lan = reactive({input$si_lan}),
      geo_scope = reactive(input$ti_scope),
      geo_group = reactive(input$ti_group),
      geo_selected = reactive({"_TOTAL_"})
    )
    
    
    dseries <- reactive({
      # req(geo_selector$pi_geo_level())
      req(input$si_source, input$si_location, input$si_country_group,
          input$ti_scope)
      selected_maxperiods <- 10
      selected_last_date <- "2022-12-31"
      selected_group <- input$si_country_group
      selected_source <- input$si_source
      inds <- tbl(con2, "dt_indicators") |>
        filter(indicator_active == TRUE) |>
        pull(indicator_id) 
      .country <- {
        if(input$ti_scope == "N"){
          get_iso2_code(id = input$ti_group)
        } else{
          NULL
        }
      }
      dfind <- get_ft_data(
        data_type = "indicator",
        .nuts_level = 0,
        type_id = inds,
        country = .country,
        .source_id = selected_source,
        from_date = tbl(con2, "ft_indicators") |>
          filter(source_id == input$si_source) |>
          summarise(last = max(date, na.rm = TRUE)) |>
          pull() |>
          as.Date() - lubridate::years(selected_maxperiods -1),
        to_date = selected_last_date)
      
      tindicators <- get_transformed_indicators(dfind,
                                                scaling_method = "zscore",
                                                scaling_type = "time",
                                                geo_total = selected_group)
      
      dfcomp <- tindicators |> 
        compute_composite_indicator(selected_source = selected_source)
      
      dfcomp |> get_series_data(.geo_id = "WLD", 
                                lan = input$si_lan,
                                source = input$si_source)
      
    })
    indicator_series <- indicator_series_server(
      "series1", 
      i18n, 
      .data = dseries,
      signif = reactive({
        session$userData$config()$signif
      }
      ))
    
    output$rt_seriesdata <- renderReactable({
      req(indicator_series())
      indicator_series() |> 
        reactable(language = get_rt_lang(input$si_lan))
    })
  }
  
  shinyApp(ui, server)
  
}
