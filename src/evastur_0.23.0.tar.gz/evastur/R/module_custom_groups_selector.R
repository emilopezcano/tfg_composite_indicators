## Module UI ----
custom_groups_selector_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("ui_pi_custom_groups"))
  )
}

## Module Server ----
custom_groups_selector_server <- function(id, i18n, lan, last_modified = reactive(NULL)) {
  moduleServer(
    id,
    function(input, output, session) {
      ns <- NS(id)
      
      ## [R] dfcustomgroups ----
      dfcustomgroups <- reactive({
        last_modified()
        df <- get_custom_geo_groups(lan = lan())
        if (!is.null(df)) {
          df |>
            add_row(
              geo_id = "_NONE_",
              geo_label = i18n()$t("Nada seleccionado"),
              .before = 1
            )
        }
      })
      
      ## [R] geo_group_label ----
      # Label of the group
      geo_group_label <- reactive({
        req(input$pi_custom_groups)
        get_geo_group_label(lan(), input$pi_custom_groups)
      })
      
      ## ui_pi_custom_groups ----
      output$ui_pi_custom_groups <- renderUI({
        req(dfcustomgroups())
        
        pickerInput(
          inputId = session$ns("pi_custom_groups"),
          label = i18n()$t("Áreas personalizadas"),
          choices = setNames(dfcustomgroups()$geo_id,
                            dfcustomgroups()$geo_label),
          selected = "_NONE_",
          options = pickerOptions(
            container = "body",
            dropupAuto = FALSE
          )
        )
      })
      
      ## Return reactive values ----
      return(
        list(
          pi_custom_groups = reactive({input$pi_custom_groups}),
          geo_group_label = geo_group_label
        )
      )
    }
  )
}

## Module App ----

#' @export
custom_groups_selector_app <- function(){
  library(shiny)
  library(shinyWidgets)
  library(dplyr)
  library(shiny.i18n)
  devtools::load_all()
  translator <- getOption("evastur.translator")
  
  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es")),
    custom_groups_selector_ui("custom_groups_selector1"),
    h3("Output from custom groups selector"),
    verbatimTextOutput("selected_group"),
    verbatimTextOutput("group_label")
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    custom_groups_selector_controls <- custom_groups_selector_server(
      "custom_groups_selector1", 
      i18n = i18n, 
      lan = reactive({input$si_lan})
    )
    
    output$selected_group <- renderText({
      paste("Selected group:", custom_groups_selector_controls$pi_custom_groups())
    })
    
    output$group_label <- renderText({
      paste("Selected group label:", custom_groups_selector_controls$geo_group_label())
    })
  }
  
  shinyApp(ui, server)
}

#custom_groups_selector_app()