#' Get text for dashboard
#'
#' @param where Place in the dashboar (page+tab+element)
#' @param lan Language
#'
#' @returns Markdown text
#' @export
#'
#' @examples
#' getText("page_home_tab_insto_sidebar", "en")
get_text <- function(where, lan) {
  path <- system.file(
    "app",
    "txt",
    lan,
    paste0(where, ".md"),
    package = "evastur"
  )

  if (path == "") {
    warning(paste(
      "File not found:",
      paste0("inst/app/txt/", lan, "/", paste0(where, ".md"))
    ))
    return("")
  }

  markdown(paste(readLines(path, warn = FALSE), collapse = "\n"))
}
