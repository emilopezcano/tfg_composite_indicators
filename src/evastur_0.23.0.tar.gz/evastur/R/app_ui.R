#' App user interface
#'
#' Internal function, called within app_run()
#'
#' @return a bslib_page object, to be used in a call to shiny::shinyApp()
#' @export
#'
#' @seealso [app_server()]
#'
#' @examplesIf interactive()
#' library(evastur)
#' shiny::shinyApp(app_ui(), app_server)
app_ui <- function() {
  # Config ----
  # Language ----
  i18n <- getOption("evastur.translator")
  i18n$set_translation_language(getOption("evastur.default_lang"))

  # Page ----
  page_sidebar(
    tags$head(
      tags$link(
        rel = "stylesheet",
        type = "text/css",
        href = "www/css/styles.css"
      ),
      tags$link(
        rel = "stylesheet",
        type = "text/css",
        href = "www/css/custom_bootstrap.css"
      ),
      ## JS scripts ----
      tags$script(HTML(
        "
      Shiny.addCustomMessageHandler('readQueryString', function(message) {
        var params = new URLSearchParams(window.location.search);
        var valor = params.get(message.param);
        Shiny.setInputValue(message.inputId, valor);
      });
    "
      )),
      tags$script(HTML(
        "
          Shiny.addCustomMessageHandler('update-title', function(message) {
            document.title = message;
          });
        "
      ))
      ),
    waiter::autoWaiter(),
    ## Theme ----
    theme = mytheme(),
    ## HTML header ----
    window_title = "",
    title = div(
      usei18n(i18n),
      class = "apptitle-container",
      div(
        class = "apptitle-left",
        uiOutput("ui_logo")
      ),
      div(
        class = "apptitle-center",
        h1(textOutput("app_title"), class = "apptitle")
      ),
      div(
        class = "apptitle-right",
        language_pickerInput(i18n),
        img(src = "www/img/ods.png", class = "rightlogo")
      )
    ),
    ## Right Sidebar ----
    sidebar = st_sidebar(i18n),
    ## Nav left sidebar ----
    card(
      fill = TRUE,
      id = "main_card",
      navset_pill_list(
        selected = "page_home_v2",
        id = "menu",
        ## page_home_v2 ----
        nav_panel(
          title = i18n$t("Inicio"),
          icon = icon("gauge-high"),
          value = "page_home_v2",
          layout_columns(
            col_widths = c(6, 6),
            height = 450,
            ### Home map ----
            card(
              full_screen = TRUE,
              card_header(
                uiOutput("ui_header_map_home", inline = TRUE),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput("ui_info_map_home", class = "info-buttons"),
                  options = list(trigger = "hover")
                ),
                popover(
                  bsicons::bs_icon("database"),
                  reactableOutput("rt_map_home_data"),
                  uiOutput("ui_dl_map_home_data"),
                  options = list(customClass = "popup-data")
                ),
                class = "cardheader"
              ),
              card_body(class = "p-0", indicator_map_ui("map1")),
              class = "card_maps_plot"
            ),

            ### Home series ----
            card(
              full_screen = TRUE,
              card_header(
                uiOutput("ui_header_series_home", inline = TRUE),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput("ui_info_series_home", class = "info-buttons"),
                  options = list(trigger = "hover")
                ),
                popover(
                  bsicons::bs_icon("database"),
                  reactableOutput("rt_series_home_data"),
                  uiOutput("ui_dl_series_home_data"),
                  options = list(customClass = "popup-data")
                ),
                class = "cardheader"
              ),
              card_body(class = "p-0", indicator_series_ui("series1")),
              class = "card_maps_plot"
            )
          ),
          ### Value boxes ----
          uiOutput("vbs_home")
        ),

        ## Page exploration ----
        nav_panel(
          title = div(icon("table"), i18n$t("Exploración")),
          value = "page_exploration",
          navset_card_tab(
            id = "tabs_exploration",
            ### Tab EVASTUR Indicators System -----
            nav_panel(
              title = span(
                i18n$t("Sistema de Indicadores EVASTUR"),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput("info_is_exploration", class = "info-buttons"),
                  options = list(trigger = "hover")
                )
              ),
              value = "tab_evastur_exploration",
              uiOutput("ui_evastur_is")
            ),
            ### Tab sources ----
            nav_panel(
              title = span(
                i18n$t("Fuentes de datos"),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput("info_sources_exploration", class = "info-buttons"),
                  options = list(trigger = "hover")
                )
              ),
              value = "tab_sources_exploration",
              exp_sources_ui("sources1")
            ),
            ### Tab indicators ----
            nav_panel(
              title = span(
                i18n$t("Biblioteca de indicadores"),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput(
                    "info_indicators_exploration",
                    class = "info-buttons"
                  ),
                  options = list(trigger = "hover")
                )
              ),
              exp_indicators_ui("expind1"),
              value = "tab_indicators_exploration"
            ),
            ### Tab geographical areas ----
            nav_panel(
              title = span(
                i18n$t("Áreas geográficas"),
                popover(
                  bsicons::bs_icon("info-circle"),
                  span(
                    i18n$t(
                      "Exploración de los indicadores activos de las áreas geográficas seleccionadas"
                    ),
                    class = "info-buttons"
                  ),
                  options = list(trigger = "hover")
                )
              ),
              layout_columns(
                col_widths = c(6, 6),
                ### Geographical map ----
                card(
                  full_screen = TRUE,
                  card_header(
                    span(i18n$t("Indicadores Activos"), inline = TRUE),
                    popover(
                      bsicons::bs_icon("info-circle"),
                      span(
                        i18n$t(
                          "Número de indicadores activos por área geográfica"
                        ),
                        class = "info-buttons"
                      ),
                      options = list(trigger = "hover")
                    ),
                    popover(
                      bsicons::bs_icon("database"),
                      reactableOutput("rt_map_exploration_map_popup"),
                      uiOutput("ui_dl_map_exploration_map"),
                      options = list(customClass = "popup-data")
                    ),
                    class = "cardheader"
                  ),
                  card_body(
                    class = "p-0",
                    indicator_geomap_ui("geo_map"),
                  ),
                  class = "card_maps_plot"
                ),

                ### Placeholder card ----
                card(
                  full_screen = TRUE,
                  card_header(
                    uiOutput("ui_header_map_exploration_data", inline = TRUE),
                    popover(
                      bsicons::bs_icon("info-circle"),
                      span(
                        i18n$t(
                          "Principales datos de las áreas geográficas seleccionadas"
                        ),
                        class = "info-buttons"
                      ),
                      options = list(trigger = "hover")
                    ),
                    popover(
                      bsicons::bs_icon("database"),
                      reactableOutput("rt_map_exploration_data_popup"),
                      uiOutput("ui_dl_map_exploration_data"),
                      options = list(customClass = "popup-data")
                    ),
                    class = "cardheader"
                  ),
                  card_body(
                    class = "p-0",
                    reactableOutput("rt_map_exploration_data"),
                  ),
                  class = "card_maps_plot"
                )
              ),
              value = "tab_geographical_areas"
            )
          )
        ),
        ## page_visualization_v2 ----
        nav_panel(
          title = div(icon("map"), i18n$t("Visualización")),
          value = "page_visualization_v2",
          navset_card_tab(
            id = "tabs_visualization2",
            ### tab_visualization_geo ----
            nav_panel(
              title = span(
                i18n$t("Comparación áreas geográficas"),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput("info_viz_geo", class = "info-buttons"),
                  options = list(trigger = "hover")
                ),
                popover(
                  bsicons::bs_icon("database"),
                  reactableOutput("rt_viz_geo_data"),
                  uiOutput("ui_dl_viz_geo_data"),
                  options = list(customClass = "popup-data")
                )
              ),
              value = "tab_visualization_geo",
              card(
                full_screen = TRUE,
                card_body(class = "p-0", indicator_viz_plot_ui("viz_geo")),
                class = "card_maps_plot"
              )
            ),
            ### tab_visualization_ind ----
            nav_panel(
              title = span(
                i18n$t("Comparación indicadores"),
                popover(
                  bsicons::bs_icon("info-circle"),
                  uiOutput("info_viz_ind", class = "info-buttons"),
                  options = list(trigger = "hover")
                ),
                popover(
                  bsicons::bs_icon("database"),
                  reactableOutput("rt_viz_ind_data"),
                  uiOutput("ui_dl_viz_ind_data"),
                  options = list(customClass = "popup-data")
                )
              ),
              value = "tab_visualization_ind",
              card(
                full_screen = TRUE,
                card_body(class = "p-0", indicator_viz_plot_ui("viz_ind")),
                class = "card_maps_plot"
              )
            )
          )
        ),
        ## page_analysis_v2----
        nav_panel(
          title = div(icon("chart-line"), i18n$t("Análisis")),
          value = "page_analysis_v2",
          navset_card_tab(
            id = "tabs_analysis2",

            ### Tab Prediction ----
            nav_panel(
              title = i18n$t("Predicción del indicador STI"),
              value = "tab_prediction_analysis2",
              #### Plot prediction ----
              card(
                full_screen = TRUE,
                card_header(
                  uiOutput("ui_header_series_pred", inline = TRUE),
                  popover(
                    bsicons::bs_icon("info-circle"),
                    uiOutput("info_prediction_plot2", class = "info-buttons"),
                    options = list(trigger = "hover")
                  ),
                  popover(
                    bsicons::bs_icon("database"),
                    reactableOutput("rt_series_pred_data"),
                    uiOutput("ui_dl_series_pred_data"),
                    options = list(customClass = "popup-data")
                  ),
                  class = "cardheader"
                ),
                card_body(class = "p-0", plotlyOutput("plot_prediction2")),
                class = "card_maps_plot"
              ),
              #### Value boxes intervention ----
              uiOutput("vbs_intervention2"),
              #### Table intervention ----
              reactableOutput("rt_intervention2")
            ),
          )
        ),
        ## Page management ----
        nav_panel(
          icon = bs_icon("gear-wide-connected"),
          title = i18n$t("Gestión SI"),
          value = "page_management",
          # h3(i18n$t("Definición de indicadores")),
          navset_card_tab(
            id = "tabs_management",
            ### Tab variables ----
            nav_panel(
              title = i18n$t("Variables"),
              value = "tab_management_variables",
              mgt_var_ui("mgtvar1")
            ),
            ### Tab indicadores ----
            nav_panel(
              title = i18n$t("Indicadores"),
              value = "tab_management_indicators",
              mgt_ind_ui("mgtind1")
            ),
            ### Tab geographic groups ----
            nav_panel(
              title = i18n$t("Áreas Geográficas"),
              value = "tab_management_geo",
              mgt_geo_ui("mgtgeo1")
            ),
            ### Tab dimensions ----
            nav_panel(
              title = i18n$t("Dimensiones"),
              value = "tab_management_dimensions",
              mgt_dim_ui("mgtdim1")
            ),
            ### Tab data loading ----
            nav_panel(
              title = i18n$t("Carga de datos"),
              value = "tab_management_load",
              mgt_load_ui("mgtload1")
            )
          )
        ),
        ## Page Data update ----
        nav_panel(
          icon = bs_icon("cloud-arrow-up"),
          title = i18n$t("Actualización de datos"),
          value = "page_data_update",
          mgt_update_ui("mgt_update")
        ),
        ## Page Experimental ----
        nav_panel(
          icon = icon("flask"),
          title = i18n$t("Experimental"),
          value = "page_experimental",
          navset_card_tab(
            id = "tabs_experimental",
            ### Tab recommendation system ----
            nav_panel(
              title = i18n$t("Modelo de recomendación de indicadores"),
              value = "tab_recommendation_analysis",
              layout_columns(
                col_widths = c(7, 5),
                #### Map zones ----
                card(
                  full_screen = TRUE,
                  card_header(
                    i18n$t("Zonas turísticas"),
                    popover(
                      bsicons::bs_icon("info-circle"),
                      uiOutput(
                        "info_zone_recommendation_analysis",
                        class = "info-buttons"
                      ),
                      options = list(trigger = "hover")
                    ),
                    class = "cardheader"
                  ),
                  card_body(class = "p-0", leafletOutput("mapa_zonas")),
                  class = "card_maps_plot"
                ),
                #### Result recommendation ----
                page_fillable(
                  uiOutput("recommendation_result"),
                  card(
                    full_screen = FALSE,
                    card_header(
                      i18n$t("Zona turística"),
                      popover(
                        bsicons::bs_icon("info-circle"),
                        uiOutput(
                          "info_recommendation_zone_selected",
                          class = "info-buttons"
                        ),
                        options = list(trigger = "hover")
                      ),
                      class = "cardheader"
                    ),
                    card_body(class = "p-0", uiOutput("zona_nombre")),
                    class = "card_maps_plot"
                  ),
                  card(
                    full_screen = FALSE,
                    card_header(
                      i18n$t("Indicadores recomendados"),
                      popover(
                        bsicons::bs_icon("info-circle"),
                        uiOutput(
                          "info_recommendation_result",
                          class = "info-buttons"
                        ),
                        options = list(trigger = "hover")
                      ),
                      class = "cardheader"
                    ),
                    card_body(class = "p-0", uiOutput("recomendacion")),
                    class = "card_maps_plot"
                  )
                )
              )
            )
          )
        ),
        ## page_config ----
        nav_panel(
          icon = bs_icon("gear"),
          title = i18n$t("Configuración"),
          value = "page_config",
          config_ui("config1", i18n),
          verbatimTextOutput("txtprofile")
        ),

        ## Page Help ----
        nav_panel(
          icon = bs_icon("question"),
          title = i18n$t("Ayuda"),
          value = "page_help",
          navset_card_tab(
            ### Tab about ----
            nav_panel(
              icon = bs_icon("info-square"),
              title = i18n$t("Acerca de"),
              value = "tab_about_help",
              uiOutput("ui_about_help_txt")
            ),
            ### Tab manual ----
            nav_panel(
              icon = bs_icon("file-text"),
              title = i18n$t("Manual de usuario"),
              value = "tab_manual_help",
              htmlOutput("iframe_manual")
            )
          )
        ),
        widths = c(2, 10)
      )
    ),

    p(
      HTML("&copy; Dephimática & DSLAB URJC ", year(Sys.Date())),
      class = "footer"
    )
  )
  # )
}
