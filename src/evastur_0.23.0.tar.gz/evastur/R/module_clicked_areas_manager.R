## Module for managing clicked geographical areas

## Module UI ----
clicked_areas_manager_ui <- function(id) {
  ns <- NS(id)
  div(
    uiOutput(ns("clicked_areas_list")),
    br(),
    actionButton(
      ns("handle_clicked"),
      uiOutput(ns("btn_handle_clicked_text"), inline = TRUE), 
      width = "100%",
      class = "mt-2"
    )
  )
}

## Module server ----
clicked_areas_manager_server <- function(id, i18n, clicked_elements, .data, selected_custom_group, geo_group, geo_group_label) {
  moduleServer(
    id,
    function(input, output, session) {
      last_modified <- reactiveVal(0)
      
      # Helper to get current DB members
      get_current_db_geos <- function() {
        req(selected_custom_group$pi_custom_groups())
        # Check if i18n() has the method, otherwise default to "en" or similar to avoid crash
        lan <- tryCatch(i18n()$get_translation_language(), error = function(e) "en")
        
        get_geos(
          .nuts_level_group = NULL, 
          lan = lan, 
          group = selected_custom_group$pi_custom_groups()
        )
      }
      
      # Render button text
      output$btn_handle_clicked_text <- renderUI({
        i18n()$t("Guardar composición del área")
      })
      
      # Render clicked areas list
      output$clicked_areas_list <- renderUI({
        if (length(clicked_elements()) > 0) {
          selected_data <- .data() |> filter(geo_id %in% clicked_elements())
          country_names <- selected_data$geo_label

          lapply(country_names, function(name) {
            tags$span(name, class = "badge bg-primary me-1 mb-1")
          })
          
        } else {
          tags$em(
            i18n()$t("No hay áreas seleccionadas"),
            style = "color: black;"
          )
        }
      })
      
      # Handle Clicked Areas button
      observeEvent(input$handle_clicked, {
        custom_group_id <- selected_custom_group$pi_custom_groups()
        
        if (
          is.null(custom_group_id) ||
          (custom_group_id == "_NONE_")
        ) {
          showModal(modalDialog(
            title = i18n()$t("No hay ningún grupo personalizado seleccionado"),
            tags$div(
              class = "alert alert-warning",
              icon("info-circle"), " ",
              i18n()$t("Por favor, crea y selecciona primero un grupo personalizado")
            ),
            footer = modalButton(i18n()$t("Cancelar")),
            easyClose = TRUE
          ))
        } else if (length(clicked_elements()) > 0) {
          
          # Fetch current DB state
          current_df <- get_current_db_geos()
          current_names <- if(!is.null(current_df)) current_df$geo_label else character(0)
          
          # Fetch new selection names
          selected_data <- .data() |> filter(geo_id %in% clicked_elements())
          new_names <- selected_data$geo_label
          
          # Calculate Diff
          added_names <- sort(setdiff(new_names, current_names))
          removed_names <- sort(setdiff(current_names, new_names))
          kept_names <- sort(intersect(current_names, new_names))
          
          has_changes <- length(added_names) > 0 || length(removed_names) > 0
          
          showModal(modalDialog(
            title = tagList(
              i18n()$t("Confirmar cambios en el grupo"),
              tags$em(selected_custom_group$geo_group_label())
            ), 
            tags$div(
              style = "max-height: 60vh; overflow-y: auto; padding: 5px;",
              if (has_changes && length(kept_names) > 0) {
                tags$div(
                  class = "mb-4",
                  tags$h6(class = "text-primary", icon("check-circle"), " ", i18n()$t("Sin cambios:")),
                  tags$div(
                    class = "ms-3",
                    lapply(kept_names, function(name) {
                      tags$span(name, class = "badge bg-primary me-1 mb-1", style = "opacity: 0.8;")
                    })
                  )
                )
              },
              if (length(added_names) > 0) {
                tags$div(
                  class = "mb-4",
                  tags$h6(class = "text-success", icon("plus-circle"), " ", i18n()$t("Nuevos:")),
                  tags$div(
                    class = "ms-3",
                    lapply(added_names, function(name) {
                      tags$span(name, class = "badge bg-success me-1 mb-1")
                    })
                  )
                )
              },
              if (length(removed_names) > 0) {
                tags$div(
                  class = "mb-4",
                  tags$h6(class = "text-danger", icon("minus-circle"), " ", i18n()$t("Eliminados:")),
                  tags$div(
                    class = "ms-3",
                    lapply(removed_names, function(name) {
                      tags$span(name, class = "badge bg-danger me-1 mb-1")
                    })
                  )
                )
              },
              if (!has_changes) {
                tags$div(
                  class = "alert alert-info",
                  icon("info-circle"), " ",
                  i18n()$t("No hay cambios respecto a la selección guardada.")
                )
              }
            ),
            footer = tagList(
              modalButton(i18n()$t("Cancelar")),
              if (has_changes) {
                actionButton(
                  session$ns("confirm_update"),
                  i18n()$t("Guardar cambios"),
                  class = "btn-primary",
                  icon = icon("save"),
                  style = "color: white;"
                )
              }
            ),
            size = "m",
            easyClose = TRUE
          )) 
        } else {
          showModal(modalDialog(
            title = i18n()$t("No hay áreas seleccionadas"),
            tags$div(
              class = "alert alert-warning",
              icon("info-circle"), " ",
              i18n()$t("Por favor, selecciona primero áreas en el mapa")
            ),
            footer = modalButton(i18n()$t("Cancelar")),
            easyClose = TRUE
          ))
        }
      })
      
      # Confirm Update Button
      observeEvent(input$confirm_update, {
        group_id <- selected_custom_group$pi_custom_groups()
        
        # 1. Get current members to delete them
        current_df <- get_current_db_geos()
        if (!is.null(current_df) && nrow(current_df) > 0) {
          delete_geo_group(current_df$geo_id, group_id)
        }
        
        # 2. Insert new members
        insert_geo_group(clicked_elements(), group_id)
        
        removeModal()
        last_modified(Sys.time())
      })

      ## Return ----
      return(
        list(
          last_modified = last_modified
        )
      )

    }
  )
}