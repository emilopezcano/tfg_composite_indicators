#' Variable distance between points
#'
#' @param datos dataframe
#' @param ix_variable variable index
#' @param fila_i i row
#' @param fila_j j row
#'
#' @return distance
#' @export
#' @examples
#' \dontrun{
#' distancia_variable(datos, variable,fila_i, fila_j)
#' }
distancia_variable <- function(datos, ix_variable, fila_i, fila_j) {
  ## error si indice variable es mayor que el numero de columnas de los datos
  if (ix_variable > dim(datos)[2]) {
    stop(
      "ix_variable debe ser menor o igual que el número de columnas de los datos"
    )
  }

  ## error si indice variable es mayor que el numero de columnas de los datos
  if (any(c(fila_i, fila_j) > dim(datos)[1])) {
    stop(
      "fila_i y fila_j deben ser menor o igual que el número de filas de los datos"
    )
  }

  ## rango de la variable para estandarizar la distancia
  rango_variable = max(datos[, ix_variable], na.rm = T) -
    min(datos[, ix_variable], na.rm = T)

  ## distancia entre i y j
  dist = abs(datos[fila_i, ix_variable] - datos[fila_j, ix_variable]) /
    rango_variable

  return(dist)
}


#' Distance between points
#'
#' @param datos data
#' @param pesos weights
#' @param fila_i i row
#' @param fila_j j row
#'
#' @return Total distance
#' @export
#' @examples
#' \dontrun{
#' distancia_total(datos,pesos,fila_i=i, fila_j=j)
#' }

distancia_total <- function(datos, pesos, fila_i, fila_j) {
  ## error si indice variable es mayor que el numero de columnas de los datos
  if (any(c(fila_i, fila_j) > dim(datos)[1])) {
    stop(
      "fila_i y fila_j deben ser menor o igual que el número de filas de los datos"
    )
  }

  ## error si indice variable es mayor que el numero de columnas de los datos
  if (length(pesos) != dim(datos)[2]) {
    stop(
      "pesos deben tener la misma longitud que el número de columnas de los datos"
    )
  }

  ## estandarizo los pesos
  pesos = pesos / sum(pesos)

  ## numero de variables
  n_variables = dim(datos)[2]

  ##vector vacio para almacenar la distancia en cada variables
  distancia_variables = numeric(n_variables)

  ## bucle recorriendo las variables
  for (variable in 1:n_variables) {
    distancia_variables[variable] = distancia_variable(
      datos,
      variable,
      fila_i,
      fila_j
    )
  }

  distancia_total = sum(distancia_variables * pesos, na.rm = T)

  return(distancia_total)
}


#' distance matrix for variables
#'
#' @param datos data frame
#' @param pesos weights
#'
#' @return distance matrix
#' @export
#' @examples
#' \dontrun{
#' funcion_matriz_distancia(recommendation_table(),slider_values())
#' }
funcion_matriz_distancia <- function(datos, pesos) {
  ## numero de filas
  n = dim(datos)[1]
  ## inicializo la matriz de distancia
  matriz_distancia = matrix(NA, nrow = n, ncol = n)

  ## recorro todos las filas y relleno la matriz triangular inferior
  for (i in 1:n) {
    for (j in i:n) {
      matriz_distancia[j, i] = distancia_total(
        datos,
        pesos,
        fila_i = i,
        fila_j = j
      )
      matriz_distancia[i, j] = matriz_distancia[j, i]
    }
  }

  ## pongo nombres a filas y columnas
  row.names(matriz_distancia) = colnames(matriz_distancia) = row.names(datos)
  # # lo paso a distancia
  # matriz_distancia=as.dist(matriz_distancia)
  return(matriz_distancia)
}
