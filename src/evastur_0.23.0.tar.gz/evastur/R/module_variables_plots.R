variables_plots_ui <- function(id) {
  ns <- NS(id)
  tagList(
    navset_card_tab(
      nav_panel(title = textOutput(ns("serietitle")),
                plotlyOutput(ns("var_series"))
      ),
      nav_panel(title = textOutput(ns("maptitle")),
                leafletOutput(ns("var_map")))
    )
  
  )
}

variables_plots_server <- function(id, .data, .geo, .date, i18n, geolabel, varlabel) {
  moduleServer(
    id,
    function(input, output, session) {
      ## tabs titles ----
      output$serietitle <- renderText({
        i18n()$t("Serie temporal")
      })
      output$maptitle <- renderText({
        i18n()$t("Mapa")
      })
      
      ## series ----
      output$var_series <- renderPlotly({
        # print(.data())
        # print(.geo())
        # validate(
        #   need(
        #     .geo() != "_TOTAL_",
        #     i18n()$t("Se necesita seleccionar un área geográfica")
        #   )
        # )

        df_full <- .data()
        validate(
          need(
            nrow(df_full) > 0,
            i18n()$t("No hay datos disponibles para mostrar.")
          )
        )

        is_total_selection <- length(.geo()) == 1 && identical(.geo(), "_TOTAL_")
        if (is_total_selection) {
          df_plot <- df_full |> filter(total)
        } else {
          df_plot <- df_full |> filter(geo_id %in% .geo())
        }
        validate(
          need(
            nrow(df_plot) > 0,
            i18n()$t("No hay datos históricos para la zona seleccionada.")
          )
        )
        
        # req(nrow(.data()) > 0)
        lan <- i18n()$get_translation_language()
        .units <- con2 |> 
          tbl("lt_units") |> 
          filter(unit_lang == lan,
                 unit_id == !!.data()$source_units[1]) |> 
          pull(unit_name)
        
        
        # Detect if monthly data is present (if period_id is missing)
        has_period <- "period_id" %in% names(df_plot)
        default_period <- "Y"
        if (!has_period) {
          if (length(unique(lubridate::month(as.Date(df_plot[["date"]])))) > 1) {
            default_period <- "M"
          }
        }
        
        # Pre-calculating formatted dates for tooltips to be safe
        df_plot <- df_plot |>
          mutate(
            tooltip_date = if (has_period) {
              get_period(date, period_id)
            } else {
              get_period(date, default_period)
            }
          )

        p <- df_plot |>
          ggplot(aes(x = as.Date(date), y = variable_value, group = 1,
                     text = paste0("<b>", i18n()$t("Periodo"), ":</b> ", tooltip_date, "<br>",
                                   "<b>", i18n()$t("Valor"), ":</b> ", scales::label_number(accuracy = 0.01, scale_cut = scales::cut_short_scale())(variable_value), " ", .units))) +
          geom_line(
            color = get_theme_color(session = session, bs_variable = "primary")
          ) +
          geom_point(
            color = get_theme_color(session = session, bs_variable = "primary"),
            size = 0.2
          ) +
          labs(title = geolabel(), x = "", y = .units) +
          theme(
            panel.background = element_rect(
              fill = get_theme_color(session = session, bs_variable = "light")
            ),
            plot.background = element_rect(
              fill = get_theme_color(session = session, bs_variable = "light")
            ),
            axis.text.x = element_text(angle = 45, vjust = 0.5)
          ) +
          scale_x_date(date_breaks = "1 year", date_labels = "%Y") +
          scale_y_continuous(
            labels = scales::label_number(scale_cut = scales::cut_short_scale())
          )
        
        ggplotly(p, tooltip = "text") |>
          plotly::config(displaylogo = FALSE)
        
      })
      
      ## map ----
      output$var_map <- renderLeaflet({
        df_raw <- .data()

        validate(
          need(nrow(df_raw) > 0, i18n()$t("No hay datos disponibles"))
        )

        df <- df_raw |>
          filter(date == .date(), !total) |>
          left_join(
            tbl(con2, "dt_geo") |>
              select(geo_id, geometry) |>
              collect(),
            by = "geo_id"
          ) |>
          replace_na(list(geometry = "POLYGON EMPTY")) |>
          sf::st_as_sf(wkt = "geometry")

        primary_color <- get_theme_color(
          session = session,
          bs_variable = "primary"
        )
        color_palette <- create_color_palette(primary_color = primary_color)

        bounds <- as.numeric(st_bbox(df))
        validate(need(all(!is.na(bounds)), message = "Unbounded map"))
        if (all(abs(bounds[c(1, 3)]) > 179)) {
          zoom1 <- 1
        } else {
          zoom1 <- NULL
        }

        labels <- sprintf(
          paste0("<strong>%s</strong><br/>%s: %s"),
          df$geo_label,
          varlabel(),
          # legend_text(),
          replace_na(
            scales::label_number(accuracy = 0.01, scale_cut = scales::cut_short_scale())(df$variable_value),
            i18n()$t("No disponible")
          )
        ) |>
          lapply(htmltools::HTML)

        pal <- colorNumeric(
          palette = color_palette,
          domain = df$variable_value,
          na.color = "transparent"
        )

        complementary_color <- get_complementary_color(primary_color)
        current_geo <- .geo()

        df <- df |>
          mutate(
            is_selected = geo_id %in% current_geo,
            poly_fill = dplyr::if_else(is_selected, complementary_color, pal(variable_value)),
            poly_weight = dplyr::if_else(is_selected, 2, 1),
            poly_color = dplyr::if_else(is_selected, complementary_color, primary_color),
            poly_dash = dplyr::if_else(is_selected, "", "3"),
            poly_opacity = dplyr::if_else(is_selected, 0.8, 0.7)
          )

        df |>
          leaflet() |>
          addProviderTiles(
            provider = providers$CartoDB.VoyagerLabelsUnder,
            options = list(noWrap = TRUE, minZoom = zoom1)
          ) |>
          addPolygons(
            layerId = ~geo_id,
            fillColor = ~poly_fill,
            weight = ~poly_weight,
            opacity = 1,
            color = ~poly_color,
            dashArray = ~poly_dash,
            fillOpacity = ~poly_opacity,
            highlightOptions = highlightOptions(
              weight = 2,
              color = adjust_color(
                color = primary_color,
                color_type = "hex",
                factor = -0.4
              ),
              dashArray = "",
              fillOpacity = 0.7,
              bringToFront = TRUE
            ),
            label = labels
          ) |>
          addControl(h5(paste0(lubridate::year(as.Date(.date())), " - ", geolabel())))
      })
    }
  )
}

variables_plots_app <- function(){
  library(shiny)
  library(dplyr)
  devtools::load_all()
  translator <- getOption("evastur.translator")
  
  ui <- fluidPage(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    selectInput("si_location", "Country", c("ES", "UK")),
    selectInput("si_source", "Source", c("EVASTUR", "INSTO")),
    selectInput("si_country_group", "Country group", 
                tbl(con2, "dt_geo") |> 
                  filter(nuts_level == 101) |> 
                  pull(geo_id)),
    textInput("ti_scope", "Scope", "S"),
    textInput("ti_group", "Group (or country)", "WLD"),
    textInput("ti_group_label", "Group or country label", "World"),
    selectInput("si_variable", label = "Variable", 
                choices =    tbl(con2, "dt_variables") |>
                  pull(variable_id),
                selected = "VVOL0002"),
    numericInput("ni_nperiods", label = "Nº periods", value = 10),
    numericInput("ni_lastperiod", label = "last period", value = 2022),
    
    geo_selector_ui("geosel1"),
    variables_plots_ui("varplots1")
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    geo_selector <- geo_selector_server(
      "geosel1", 
      i18n = i18n, 
      lan = reactive({input$si_lan}),
      geo_scope = reactive(input$ti_scope),
      geo_group = reactive(input$ti_group),
      geo_selected = reactive(input$ti_group)
    )
    
    source_vars <- reactive({
      tbl(con2, "ft_variables") |>
        distinct(source_id) |> 
        pull()
    })
    
    ### [R] Nuts level depending on selection ----
    nuts_level <- reactive({
      req(input$ti_scope)
      req(input$ti_group)
      if (input$ti_scope == "N"){
        .nuts_level <- session$userData$config()$geo_nuts_id
      } else {
        if (input$ti_group == "INSTO"){
          .nuts_level <- 99
        } else {
          .nuts_level <- 0
        }
      }
    })
    
    vars <- reactive({
      tbl(con2, "dt_variables") |>
        pull(variable_id)
    })
    
    dfvar <- reactive({
      if(input$si_source == "INSTO"){
        selected_sources <- str_subset(source_vars(),
                                       "^INSTO")
      } else{
        selected_sources <- str_subset(source_vars(),
                                       "^INSTO", negate = TRUE)
      }
      df <- get_ft_data(
        data_type = "variable",
        .nuts_level = nuts_level(),
        type_id = vars(),
        country = input$si_location,
        .source_id = selected_sources,
        from_date = paste0(input$ni_lastperiod - input$ni_nperiods + 1, 
                           "-01-01"),
        to_date = paste0(input$ni_lastperiod, "-12-31")
      ) |> 
        filter(variable_id == input$si_variable) |> 
        left_join(tbl(con2, "lt_geo") |> 
                    filter(geo_lang == input$si_lan) |> 
                    select(geo_id, geo_label) |> 
                    collect(),
                  by = "geo_id"
        ) |> 
        mutate(period = get_period(date, period_id) )# |>
        # select(period,
        #        date,
        #        geo_id,
        #        geo_label,
        #        # geo_name,
        #        variable_value,
        #        source_units,
        #        source_id,
        #        # variable_prov,
        #        # variable_secret#,
        #        #info)
        # )
      # print(df)
      return(df)
    })
    
    variables_plots_server("varplots1", dfvar, 
                           .geo = geo_selector$pi_geo_selected,
                           .date = reactive({paste0(input$ni_lastperiod, "-01-01")}),
                           i18n = i18n,
                           geolabel = geo_selector$geo_selected_label,
                           varlabel = reactive({input$si_variable}))
  }
  
  shinyApp(ui, server)
}

# variables_plots_app()
