## Module for creating custom geographic groups

## Module UI ----
mgt_geo_form_ui <- function(id) {
  ns <- NS(id)
  tagList(
    uiOutput(ns("geo_form"))
  )
  
}

## Module server ----
mgt_geo_form_server <- function(id, i18n, selected_custom_area = reactive(NULL)) {
  moduleServer(
    id,
    function(input, output, session) {

      last_modified <- reactiveVal(0)

      iv <- InputValidator$new()
      iv$add_rule("ti_geo_name",
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$add_rule("ti_geo_label",
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$add_rule("tai_geo_description",
                  sv_required(message = "*"
                              # message = i18n()$t("Obligatorio")
                  )
      )
      iv$enable()

      ## [R] is_edit_mode ----
      is_edit_mode <- reactive({
        !is.null(selected_custom_area()) &&
        selected_custom_area() != "_NONE_"
      })

      ## [RV] new_id ----
      new_id <- reactiveVal({
        next_id("geo", "GCUS")
      })

      ## [O] Update new_id when selected_custom_area changes ----
      observeEvent(selected_custom_area(), {
        if (is_edit_mode()) {
          new_id(selected_custom_area())
        } else {
          new_id(next_id("geo", "GCUS"))
        }
      })

      ## [R] existing_data - Load existing data in edit mode ----
      existing_data <- reactive({
        geo_id_val <- new_id()
        lan <- i18n()$get_translation_language()

        req(geo_id_val)
        req(is_edit_mode())

        tbl(con2, "lt_geo") |>
          filter(geo_id == geo_id_val, geo_lang == lan) |>
          collect()
      })

      ## [O] Pre-populate form fields in edit mode ----
      observeEvent(existing_data(), {
        req(nrow(existing_data()) > 0)
        data <- existing_data()[1, ]

        updateTextInput(session, "ti_geo_name", value = data$geo_name)
        updateTextInput(session, "ti_geo_label", value = data$geo_label)
        updateTextAreaInput(session, "tai_geo_description", value = data$geo_description)
      })

      ## [O] Clear form fields when switching to create mode ----
      observeEvent(selected_custom_area(), {
        req(!is_edit_mode())

        updateTextInput(session, "ti_geo_name", value = "")
        updateTextInput(session, "ti_geo_label", value = "")
        updateTextAreaInput(session, "tai_geo_description", value = "")
      })

      ## [O] form_header - Dynamic header showing mode and ID ----
      output$form_header <- renderUI({
        p(
          if (is_edit_mode()) i18n()$t("Editar") else i18n()$t("Crear"),
          ": ",
          strong(new_id())
        )
      })

      ## [O] save_button_label - Dynamic button label ----
      output$save_button_label <- renderUI({
        if (is_edit_mode()) i18n()$t("Actualizar") else i18n()$t("Guardar descripción del área")
      })

      ## [O] delete_button_label - Delete button label ----
      output$delete_button_label <- renderUI({
        i18n()$t("Eliminar")
      })

      ## [O] show_delete - Show delete button in edit mode ----
      output$show_delete <- reactive({ is_edit_mode() })
      outputOptions(output, "show_delete", suspendWhenHidden = FALSE)

      output$geo_form <- renderUI({
        lan <- i18n()$get_translation_language()
        # TODO: In the future, allow picking any nuts_level
        # nuts_levels <- con2 |>
        #   tbl("dt_nuts_levels") |>
        #   select(nuts_level_id, nuts_level_original_name) |>
        #   collect() |>
        #   arrange(nuts_level_id)

        tagList(
          layout_columns(
            col_widths = c(6, 6),
            card(
              uiOutput(session$ns("form_header")),
              textInputIcon(session$ns("ti_geo_name"),
                            width = "100%",
                            label = span(cleanHTML(i18n()$t("Nombre")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Nombre completo (una frase)")
                                         ),
                                         options = list(trigger = "hover")
                            ),

                            icon = list(NULL, icon("at"))),
              textInputIcon(session$ns("ti_geo_label"),
                            label = span(cleanHTML(i18n()$t("Etiqueta")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Nombre corto (una o pocas palabras)")
                                         ),
                                         options = list(trigger = "hover")
                            ),
                            icon = list(NULL, icon("tag"))),
              # TODO: In the future, allow picking any nuts_level
              pickerInput(session$ns("pi_nuts_level"),
                         label = span(cleanHTML(i18n()$t("Nivel NUTS")),
                                     tooltip(bs_icon("info-circle"),
                                             title = "info",
                                             i18n()$t("Nivel geográfico")
                                     ),
                                     options = list(trigger = "hover")
                         ),
                         # choices = setNames(nuts_levels$nuts_level_id,
                         #                   nuts_levels$nuts_level_original_name),
                         choices = setNames(101, i18n()$t("Grupo de países")),
                         selected = 101,
                         options = list(container = "body")
              ),
              textAreaInput(session$ns("tai_geo_description"),
                            label = span(cleanHTML(i18n()$t("Descripción")),
                                         tooltip(bs_icon("info-circle"),
                                                 title = "info",
                                                 i18n()$t("Descripción completa (un párrafo)")
                                         ),
                                         options = list(trigger = "hover")
                            ),
                            height = "100px",
                            width = "100%"),
              div(
                style = "display: flex; gap: 10px; width: 100%; align-items: stretch;",

                div(
                  style = "flex: 70; min-width: 0;", 
                  actionButton(
                    session$ns("ab_save_geo"),
                    label = uiOutput(session$ns("save_button_label"), inline = TRUE),
                    icon = icon("floppy-disk"),
                    width = "100%"
                  )
                ),

                # Only show delete button in edit mode
                conditionalPanel(
                  condition = "output.show_delete",
                  ns = session$ns,
                  style = "flex: 30; min-width: 0; display: flex;", 
                  actionButton(
                    session$ns("ab_delete_geo"),
                    label = uiOutput(session$ns("delete_button_label"), inline = TRUE),
                    icon = icon("trash-can"),
                    width = "100%",
                    class = "btn-outline-danger"
                  )
                )
              )
            ),
            card(
              card_body(
                class = "p-0",
                indicator_geomap_ui("geo_map_2"),
              ),
              card_footer(
                clicked_areas_manager_ui("geo_area_manager")
              ),
            )
          )
        )
      })
      outputOptions(output, "geo_form", suspendWhenHidden = FALSE)
      
      
      
      ## [O] ab_save_geo ----
      observeEvent(input$ab_save_geo, {
        if (!iv$is_valid()) {
          showNotification(i18n()$t("Datos incompletos"),
                           type = "error")
        } else {
          if (is_edit_mode()) {
            # Update existing geo group
            update_custom_geo_group(
              geo_id = new_id(),
              geo_name = input$ti_geo_name,
              geo_label = input$ti_geo_label,
              geo_description = input$tai_geo_description,
              nuts_level = as.numeric(input$pi_nuts_level)
            )

            last_modified(Sys.time())

            sendSweetAlert(title = i18n()$t("Actualizar"),
                           text = i18n()$t("Área geográfica actualizada"),
                           type = "success")
          } else {
            # Create new geo group
            add_custom_geo_group(
              geo_id = new_id(),
              geo_name = input$ti_geo_name,
              geo_label = input$ti_geo_label,
              geo_description = input$tai_geo_description,
              nuts_level = as.numeric(input$pi_nuts_level)
            )

            new_id({next_id("geo", "GCUS")})
            last_modified(Sys.time())

            sendSweetAlert(title = i18n()$t("Guardar"),
                           text = i18n()$t("Área geográfica guardada"),
                           type = "success")
          }
        }

      })

      ## [O] ab_delete_geo ----
      observeEvent(input$ab_delete_geo, {
        confirmSweetAlert(
          session = session,
          inputId = "confirm_delete",
          title = i18n()$t("Confirmar eliminación"),
          text = paste0(
            i18n()$t("¿Está seguro/a de eliminar"),
            " ",
            new_id(),
            "? ",
            i18n()$t("Esta acción no se puede deshacer")
          ),
          type = "warning",
          btn_labels = c(i18n()$t("Cancelar"), i18n()$t("Eliminar")),
          btn_colors = c(get_theme_color(session, "primary"), get_theme_color(session, "danger")),
          html = TRUE
        )
      })

      ## [O] confirm_delete ----
      observeEvent(input$confirm_delete, {
        req(input$confirm_delete) # Only proceed if confirmed (TRUE)

        delete_custom_geo_group(new_id())

        # Update timestamp to trigger parent refresh
        last_modified(Sys.time())

        # Show success notification
        sendSweetAlert(
          session = session,
          title = i18n()$t("Eliminado"),
          text = i18n()$t("Área geográfica eliminada correctamente"),
          type = "success"
        )

        # Clear form fields
        updateTextInput(session, "ti_geo_name", value = "")
        updateTextInput(session, "ti_geo_label", value = "")
        updateTextAreaInput(session, "tai_geo_description", value = "")
      })

      ## Return list ----
      return(
        list(
          last_modified = last_modified
        )
      )
    }
  )
}

## Module app ----

mgt_geo_form_app <- function(){
  
  library(shiny)
  library(shinyWidgets)
  library(evastur)
  library(shiny.i18n)
  library(bslib)
  library(bsicons)
  library(dplyr)
  translator <- getOption("evastur.translator")
  
  ui <- bslib::page_fluid(
    selectInput("si_lan", "Language", c("en", "es", "fr")),
    mgt_geo_form_ui("geoform1"),
  )
  
  server <- function(input, output, session) {
    i18n <- reactive({
      selected <- input$si_lan
      if (length(selected) > 0 && selected %in% translator$get_languages()) {
        translator$set_translation_language(selected)
      }
      translator
    })
    
    mgt_geo_form_server("geoform1", i18n)
  }
  
  shinyApp(ui, server)
  
}

## Run app ----
# mgt_geo_form_app()