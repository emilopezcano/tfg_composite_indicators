# Setup ----

# library(shiny)
# library(shinyWidgets)
# library(bslib, warn.conflicts = FALSE)
# library(ggplot2)
# library(shiny.i18n)
# library(SDGdetector)
# library(RColorBrewer)
# library(gfonts)
# library(lubridate, warn.conflicts = FALSE)
# library(gt)
# library(dplyr, warn.conflicts = FALSE)
# library(dbplyr, warn.conflicts = FALSE)
# library(readr)
# library(readxl)
# library(tidyr)
# library(sf)
# library(DBI)
# library(purrr)
# library(stringr)
# library(bsicons)
# library(shinyalert, warn.conflicts = FALSE)
# library(leaflet)
# library(mapSpain)
# library(plotly, warn.conflicts = FALSE)
# library(shinyBS, warn.conflicts = FALSE)
# CONFLICTS 
## lubridate: date, intersect, setdiff, union
## plotly: ggplot2::last_plot; stats::filter; graphics::layout

## Configuration ----

# config <- config::get(file = "conf/config.yml")


## Language ----

# suppressWarnings(
#   i18n <- Translator$new(translation_csvs_path = 'translations/')
#   # Warning message:
#   #   In load_local_config(translation_csv_config) :
#   #   You didn't specify config translation yaml file. Default settings are used.
# )
# 
# lang <- Sys.getenv("DEFAULT_LANGUAGE", unset = config$default_language)
# 
# i18n$set_translation_language(lang)



## On docker desktop

# con_is_up <- DBI::dbCanConnect(RPostgres::Postgres(),
#                                host = Sys.getenv("HOST"),
#                                dbname = "evastur_db",
#                                port = 5432,
#                                user = "evastur",
#                                password = Sys.getenv("PGPWD"))
# 
# if(con_is_up){
#   
#   con <- DBI::dbConnect(RPostgres::Postgres(),
#                         host = Sys.getenv("HOST"),
#                         dbname = "evastur_db",
#                         port = 5432,
#                         user = "evastur",
#                         password = Sys.getenv("PGPWD"))
# } else{
#   con <- NULL
# }
