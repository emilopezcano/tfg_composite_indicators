# Repository Guidelines

## Project Structure & Module Organization
The project is a **package-centric Shiny application**:

- `R/`: Core package code. Modules follow module_<area>_<detail>.R; shared helpers use functions_*.R. App entrypoints: `app_ui.R`, `app_server.R`, `app_run.R`.
- `inst/app/`: Shiny assets, texts, and translations (see `inst/app/translations/)`.
- `data/`: Packaged datasets (.rda).
- `man/`: Generated Rd docs (via roxygen2).
- `vignettes/`: Long-form docs.
- `renv/`: Reproducible R env. Project file: `sustainable_tourism_app.Rproj`.
- Containerization: `Dockerfile`, `docker-compose.yml`.

### Global Objects & Database
* **DB Connection (`con2`):** Database connections are named `con2` and are available throughout the application as global objects.
  * **Note:** Do not pass the connection as a function parameter; assume `con2` exists in the environment.
* **Security:** Never commit credentials. Use `.Renviron` and access via `Sys.getenv()`.

## Build, Test, and Development Commands
- Setup deps: R -e 'renv::restore()' — restore locked package versions.
- Run app (installed or loaded): R -e 'evastur::app_run()'.
- Dev run (hot-reload): R -e 'devtools::load_all(); evastur::app_run()'.
- Lint: R -e 'lintr::lint_package()'.
- Document: R -e 'devtools::document()' — update NAMESPACE and man/.
- Build/check: R -e 'devtools::check()' or R CMD build . && R CMD check *.tar.gz.

## Coding Style & Naming Conventions
- Indentation: 2 spaces; max 100 cols; no tabs.
- Naming: snake_case for functions/objects; files use module_*, functions_*, app_*. Keep numeric prefixes only when order matters (e.g., 1_fn_utils.R).
- Roxygen comments for all exported functions; include examples when feasible.
- Prefer tidyverse style; vectorized ops; avoid side effects in helpers.
- Use native pipe `|>`; avoid `%>%` unless justified.
- Avoid print()/cat()/message() in computational functions; use message()/warning() only for logging/debugging flow.
- SQL/ETL: Use transactions for multi-step ops; prevent SQL injection with parameterized queries.

## Testing Guidelines
- Framework: testthat. Place tests in tests/testthat/ with files like test-<topic>.R.
- Run tests: R -e 'devtools::test()'.
- Coverage (optional): R -e 'covr::report()'.
- Aim for tests around data transforms (functions_*) and module servers with testServer() examples.

## Commit & Pull Request Guidelines
- Commits: Use Conventional Commits (e.g., feat: add geo level selector, fix: correct z-score scaling). Keep small and focused.
- Update docs: run devtools::document() when signatures change; edit NEWS.md for user-visible changes.
- PRs must include: clear description, linked issues, reproduction steps, before/after screenshots for UI, notes on data/translation updates (e.g., files under inst/app/txt/ or inst/app/translations/).
- CI/readiness: ensure devtools::check() passes locally and lints are clean.

## Security & Configuration
- Secrets: store in ~/.Renviron or project .Renviron; never commit credentials. Use Sys.getenv() in code.
- Large data: keep raw inputs out of git when possible; document sources in R/functions_etl.R and use deterministic ETL.

## Architecture Overview
- Package-centric Shiny app: UI/server in R/, content and static assets in inst/app/, run via evastur::app_run() for a stable entrypoint.
