DBI::dbCanConnect(RPostgres::Postgres(),
                  host = Sys.getenv("HOST"),
                  dbname = "evastur_db",
                  port = 5432,
                  user = "evastur",
                  password = Sys.getenv("PGPWD"))
